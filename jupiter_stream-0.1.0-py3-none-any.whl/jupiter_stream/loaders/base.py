"""配置加载器抽象基类 / Configuration Loader Abstract Base Class"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Union

logger = logging.getLogger(__name__)


class ConfigLoader(ABC):
    """配置加载器抽象基类 / Configuration Loader Abstract Base Class

    定义了配置加载器的标准接口。
    Defines the standard interface for configuration loaders.

    所有配置加载器都应该继承此类并实现相应的方法。
    All configuration loaders should inherit from this class.

    Example:
        >>> class JSONLoader(ConfigLoader):
        ...     def load(self, config_path):
        ...         with open(config_path) as f:
        ...             return json.load(f)
        ...     def load_string(self, config_string):
        ...         return json.loads(config_string)
        ...     def supports_format(self, file_path):
        ...         return str(file_path).endswith('.json')
    """

    def __init__(self):
        """初始化加载器"""
        self.logger = logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def load(self, config_path: Union[str, Path]) -> Dict[str, Any]:
        """从文件加载配置 / Load configuration from file

        Args:
            config_path: 配置文件路径

        Returns:
            配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: 配置格式错误
        """
        pass

    @abstractmethod
    def load_string(self, config_string: str) -> Dict[str, Any]:
        """从字符串加载配置 / Load configuration from string

        Args:
            config_string: 配置字符串内容

        Returns:
            配置字典

        Raises:
            ValueError: 配置格式错误
        """
        pass

    @abstractmethod
    def supports_format(self, file_path: Union[str, Path]) -> bool:
        """检查是否支持指定格式 / Check if format is supported

        Args:
            file_path: 文件路径

        Returns:
            是否支持该格式
        """
        pass

    def validate_config(self, config: Dict[str, Any]) -> bool:
        """验证配置结构 / Validate configuration structure

        子类可以覆盖此方法添加自定义验证逻辑。
        Subclasses can override this method to add custom validation.

        Args:
            config: 配置字典

        Returns:
            配置是否有效

        Raises:
            ValueError: 配置无效时的详细错误信息
        """
        # 基本验证：确保是字典
        if not isinstance(config, dict):
            raise ValueError("Configuration must be a dictionary")

        # 必须有 source
        if "source" not in config:
            raise ValueError("Configuration must have a 'source' section")

        source_config = config["source"]
        if not isinstance(source_config, dict):
            raise ValueError("'source' must be a dictionary")
        if "type" not in source_config:
            raise ValueError("'source' must have a 'type' field")

        # processors 是可选的
        if "processors" in config:
            if not isinstance(config["processors"], list):
                raise ValueError("'processors' must be a list")
            for i, proc in enumerate(config["processors"]):
                if not isinstance(proc, dict):
                    raise ValueError(f"Processor {i} must be a dictionary")
                if "type" not in proc:
                    raise ValueError(f"Processor {i} must have a 'type' field")

        # sinks 是可选的
        if "sinks" in config:
            if not isinstance(config["sinks"], list):
                raise ValueError("'sinks' must be a list")
            for i, sink in enumerate(config["sinks"]):
                if not isinstance(sink, dict):
                    raise ValueError(f"Sink {i} must be a dictionary")
                if "type" not in sink:
                    raise ValueError(f"Sink {i} must have a 'type' field")

        self.logger.debug("Configuration validation passed")
        return True

    def preprocess_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """预处理配置 / Preprocess configuration

        可以在加载后对配置进行预处理，如展开环境变量、解析路径等。
        Can preprocess config after loading, e.g., expand env vars, resolve paths.

        Args:
            config: 原始配置字典

        Returns:
            处理后的配置字典
        """
        import os
        from pathlib import Path

        def expand_env_vars(value):
            """递归展开环境变量"""
            if isinstance(value, str):
                # 展开环境变量 (e.g., $HOME, ${USER})
                return os.path.expandvars(value)
            elif isinstance(value, dict):
                return {k: expand_env_vars(v) for k, v in value.items()}
            elif isinstance(value, list):
                return [expand_env_vars(item) for item in value]
            return value

        def expand_paths(value):
            """递归展开路径"""
            if isinstance(value, str):
                # 检查是否是路径类参数
                if any(keyword in str(value).lower() for keyword in ["path", "dir", "file"]):
                    # 展开 ~ 和相对路径
                    return str(Path(value).expanduser().resolve())
                return value
            elif isinstance(value, dict):
                result = {}
                for k, v in value.items():
                    # 对包含 path 的键进行路径展开
                    if "path" in k.lower() or "dir" in k.lower() or "file" in k.lower():
                        if isinstance(v, str):
                            result[k] = str(Path(v).expanduser().resolve())
                        else:
                            result[k] = expand_paths(v)
                    else:
                        result[k] = expand_paths(v)
                return result
            elif isinstance(value, list):
                return [expand_paths(item) for item in value]
            return value

        # 先展开环境变量，再展开路径
        config = expand_env_vars(config)
        config = expand_paths(config)

        return config

    def __repr__(self) -> str:
        """字符串表示"""
        return f"{self.__class__.__name__}()"
