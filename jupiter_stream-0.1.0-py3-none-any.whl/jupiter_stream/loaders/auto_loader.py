"""自动格式检测配置加载器 / Auto Format Detection Configuration Loader"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .base import ConfigLoader
from .yaml_loader import YAMLConfigLoader

logger = logging.getLogger(__name__)


class JSONConfigLoader(ConfigLoader):
    """JSON 配置加载器 / JSON Configuration Loader

    内置的 JSON 格式支持，无需额外依赖。
    Built-in JSON format support without extra dependencies.
    """

    def load(self, config_path: Union[str, Path]) -> Dict[str, Any]:
        """从文件加载 JSON 配置"""
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        if not config_path.is_file():
            raise ValueError(f"Path is not a file: {config_path}")

        if not self.supports_format(config_path):
            raise ValueError(f"Unsupported file format: {config_path.suffix}. Expected .json")

        try:
            with open(config_path, encoding="utf-8") as f:
                config = json.load(f)

            # 预处理配置
            config = self.preprocess_config(config)

            # 验证配置
            self.validate_config(config)

            self.logger.info(f"Successfully loaded JSON configuration from {config_path}")
            return config

        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse JSON file: {e}")
        except Exception as e:
            self.logger.error(f"Error loading JSON configuration: {e}")
            raise

    def load_string(self, config_string: str) -> Dict[str, Any]:
        """从字符串加载 JSON 配置"""
        try:
            config = json.loads(config_string)

            # 预处理配置
            config = self.preprocess_config(config)

            # 验证配置
            self.validate_config(config)

            self.logger.debug("Successfully loaded JSON configuration from string")
            return config

        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse JSON string: {e}")
        except Exception as e:
            self.logger.error(f"Error loading JSON configuration from string: {e}")
            raise

    def supports_format(self, file_path: Union[str, Path]) -> bool:
        """检查是否支持 JSON 格式"""
        file_path = Path(file_path)
        return file_path.suffix.lower() == ".json"


class AutoConfigLoader(ConfigLoader):
    """自动格式检测配置加载器 / Auto Format Detection Configuration Loader

    根据文件扩展名自动选择合适的加载器。
    Automatically selects the appropriate loader based on file extension.

    支持的格式 / Supported formats:
        - YAML (.yaml, .yml) - 需要 PyYAML
        - JSON (.json) - 内置支持

    Example:
        >>> loader = AutoConfigLoader()
        >>> config = loader.load("pipeline.yaml")  # 自动使用 YAML 加载器
        >>> config = loader.load("pipeline.json")  # 自动使用 JSON 加载器
        >>> config = loader.load_string(content, format="yaml")  # 指定格式

    扩展支持 / Extension support:
        可以通过 register_loader() 方法注册自定义加载器。
        Custom loaders can be registered via register_loader().
    """

    def __init__(self):
        """初始化自动加载器"""
        super().__init__()
        self._loaders: Dict[str, ConfigLoader] = {}
        self._register_default_loaders()

    def _register_default_loaders(self):
        """注册默认的加载器"""
        # 注册 JSON 加载器（总是可用）
        json_loader = JSONConfigLoader()
        self.register_loader(".json", json_loader)
        self.logger.debug("Registered JSON loader")

        # 尝试注册 YAML 加载器（如果 PyYAML 可用）
        # 延迟实例化，只在真正需要时才检查 PyYAML
        import importlib.util

        if importlib.util.find_spec("yaml") is not None:
            # 如果 yaml 可用，实例化加载器
            yaml_loader = YAMLConfigLoader()
            self.register_loader(".yaml", yaml_loader)
            self.register_loader(".yml", yaml_loader)
            self.logger.debug("Registered YAML loader")
        else:
            self.logger.warning(
                "PyYAML not installed. YAML configuration support is disabled. "
                "Install with: pip install PyYAML"
            )

    def register_loader(self, extension: str, loader: ConfigLoader) -> None:
        """注册自定义加载器

        Args:
            extension: 文件扩展名（如 '.toml', '.ini'）
            loader: ConfigLoader 实例

        Example:
            >>> auto_loader = AutoConfigLoader()
            >>> auto_loader.register_loader('.toml', TOMLConfigLoader())
        """
        if not extension.startswith("."):
            extension = "." + extension

        extension = extension.lower()
        self._loaders[extension] = loader
        self.logger.info(f"Registered loader for {extension} files: {loader}")

    def get_loader(self, file_path: Union[str, Path]) -> ConfigLoader:
        """根据文件路径获取合适的加载器

        Args:
            file_path: 文件路径

        Returns:
            合适的 ConfigLoader 实例

        Raises:
            ValueError: 如果没有合适的加载器
        """
        file_path = Path(file_path)
        extension = file_path.suffix.lower()

        if extension not in self._loaders:
            supported = ", ".join(self._loaders.keys())
            raise ValueError(
                f"Unsupported configuration format: {extension}. " f"Supported formats: {supported}"
            )

        return self._loaders[extension]

    def load(self, config_path: Union[str, Path]) -> Dict[str, Any]:
        """从文件加载配置

        自动检测文件格式并使用相应的加载器。

        Args:
            config_path: 配置文件路径

        Returns:
            配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: 不支持的格式或解析错误
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        if not config_path.is_file():
            raise ValueError(f"Path is not a file: {config_path}")

        # 获取合适的加载器
        loader = self.get_loader(config_path)

        # 使用加载器加载配置
        config = loader.load(config_path)

        self.logger.info(
            f"Successfully loaded configuration from {config_path} "
            f"using {loader.__class__.__name__}"
        )

        return config

    def load_string(self, config_string: str, format: Optional[str] = None) -> Dict[str, Any]:
        """从字符串加载配置

        Args:
            config_string: 配置字符串内容
            format: 格式提示（'yaml', 'json' 等）。如果未指定，尝试自动检测。

        Returns:
            配置字典

        Raises:
            ValueError: 格式错误或无法自动检测格式
        """
        # 如果指定了格式
        if format:
            if not format.startswith("."):
                format = "." + format
            format = format.lower()

            if format not in self._loaders:
                supported = ", ".join(self._loaders.keys())
                raise ValueError(
                    f"Unsupported configuration format: {format}. "
                    f"Supported formats: {supported}"
                )

            loader = self._loaders[format]
            return loader.load_string(config_string)

        # 尝试自动检测格式
        config_string = config_string.strip()

        # 尝试 JSON
        if config_string.startswith("{") or config_string.startswith("["):
            try:
                if ".json" in self._loaders:
                    return self._loaders[".json"].load_string(config_string)
            except ValueError:
                pass

        # 尝试 YAML
        if ".yaml" in self._loaders:
            try:
                return self._loaders[".yaml"].load_string(config_string)
            except ValueError:
                pass

        # 无法自动检测
        raise ValueError(
            "Cannot auto-detect configuration format. "
            "Please specify the format parameter or ensure the content is valid JSON/YAML."
        )

    def supports_format(self, file_path: Union[str, Path]) -> bool:
        """检查是否支持指定格式

        Args:
            file_path: 文件路径

        Returns:
            是否支持该格式
        """
        file_path = Path(file_path)
        extension = file_path.suffix.lower()
        return extension in self._loaders

    def get_supported_formats(self) -> List[str]:
        """获取支持的格式列表

        Returns:
            支持的文件扩展名列表
        """
        return list(self._loaders.keys())

    def __repr__(self) -> str:
        """字符串表示"""
        formats = ", ".join(self._loaders.keys())
        return f"AutoConfigLoader(formats=[{formats}])"
