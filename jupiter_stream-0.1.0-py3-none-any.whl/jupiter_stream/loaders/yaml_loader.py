"""YAML 配置加载器 / YAML Configuration Loader"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Union

from .base import ConfigLoader

logger = logging.getLogger(__name__)


class YAMLConfigLoader(ConfigLoader):
    """YAML 配置加载器 / YAML Configuration Loader

    支持从 YAML 格式的配置文件加载 Pipeline 配置。
    Supports loading Pipeline configuration from YAML files.

    Features:
        - 支持 .yaml 和 .yml 扩展名
        - 支持环境变量展开
        - 支持路径自动展开
        - 支持 !include 标签引入其他文件

    Example:
        >>> loader = YAMLConfigLoader()
        >>> config = loader.load("pipeline.yaml")
        >>> # 或从字符串加载
        >>> config = loader.load_string(yaml_content)
    """

    def __init__(self):
        """初始化 YAML 加载器"""
        super().__init__()
        self._yaml = None
        self._ensure_yaml_installed()

    def _ensure_yaml_installed(self):
        """确保 PyYAML 已安装"""
        try:
            import yaml

            self._yaml = yaml
            self.logger.debug("PyYAML is available")
        except ImportError:
            raise ImportError(
                "PyYAML is required for YAML configuration support. "
                "Install it with: pip install PyYAML or pip install jupiter-stream[yaml]"
            )

    def _setup_yaml_loader(self):
        """设置自定义 YAML 加载器

        添加自定义标签支持，如 !include 等。
        """
        import yaml

        class CustomLoader(yaml.SafeLoader):
            """自定义 YAML 加载器"""

            pass

        def include_constructor(loader, node):
            """!include 标签构造器

            允许在 YAML 中引入其他文件：
            source: !include source.yaml
            """
            include_path = loader.construct_scalar(node)
            include_path = Path(include_path)

            # 如果是相对路径，相对于当前 YAML 文件
            if not include_path.is_absolute():
                current_file = Path(loader.name) if hasattr(loader, "name") else Path.cwd()
                include_path = current_file.parent / include_path

            if not include_path.exists():
                raise FileNotFoundError(f"Include file not found: {include_path}")

            with open(include_path, encoding="utf-8") as f:
                return yaml.safe_load(f)

        # 注册自定义标签
        CustomLoader.add_constructor("!include", include_constructor)

        return CustomLoader

    def load(self, config_path: Union[str, Path]) -> Dict[str, Any]:
        """从文件加载配置

        Args:
            config_path: 配置文件路径

        Returns:
            配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: YAML 格式错误
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        if not config_path.is_file():
            raise ValueError(f"Path is not a file: {config_path}")

        if not self.supports_format(config_path):
            raise ValueError(
                f"Unsupported file format: {config_path.suffix}. " f"Expected .yaml or .yml"
            )

        try:
            with open(config_path, encoding="utf-8") as f:
                # 使用自定义加载器
                custom_loader = self._setup_yaml_loader()
                custom_loader.name = str(config_path)  # 保存文件路径供 !include 使用
                config = self._yaml.load(f, Loader=custom_loader)

            if config is None:
                config = {}

            # 预处理配置（展开环境变量和路径）
            config = self.preprocess_config(config)

            # 验证配置
            self.validate_config(config)

            self.logger.info(f"Successfully loaded configuration from {config_path}")
            return config

        except self._yaml.YAMLError as e:
            raise ValueError(f"Failed to parse YAML file: {e}")
        except Exception as e:
            self.logger.error(f"Error loading configuration: {e}")
            raise

    def load_string(self, config_string: str) -> Dict[str, Any]:
        """从字符串加载配置

        Args:
            config_string: YAML 格式的配置字符串

        Returns:
            配置字典

        Raises:
            ValueError: YAML 格式错误
        """
        try:
            # 使用 safe_load 避免安全问题
            config = self._yaml.safe_load(config_string)

            if config is None:
                config = {}

            # 预处理配置
            config = self.preprocess_config(config)

            # 验证配置
            self.validate_config(config)

            self.logger.debug("Successfully loaded configuration from string")
            return config

        except self._yaml.YAMLError as e:
            raise ValueError(f"Failed to parse YAML string: {e}")
        except Exception as e:
            self.logger.error(f"Error loading configuration from string: {e}")
            raise

    def supports_format(self, file_path: Union[str, Path]) -> bool:
        """检查是否支持指定格式

        Args:
            file_path: 文件路径

        Returns:
            是否支持该格式
        """
        file_path = Path(file_path)
        return file_path.suffix.lower() in [".yaml", ".yml"]

    def save(self, config: Dict[str, Any], output_path: Union[str, Path]) -> None:
        """保存配置到文件（额外功能）

        Args:
            config: 配置字典
            output_path: 输出文件路径
        """
        output_path = Path(output_path)

        # 确保父目录存在
        output_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                self._yaml.safe_dump(
                    config, f, default_flow_style=False, allow_unicode=True, sort_keys=False
                )
            self.logger.info(f"Configuration saved to {output_path}")
        except Exception as e:
            self.logger.error(f"Error saving configuration: {e}")
            raise

    def to_string(self, config: Dict[str, Any]) -> str:
        """将配置转换为 YAML 字符串（额外功能）

        Args:
            config: 配置字典

        Returns:
            YAML 格式的字符串
        """
        return self._yaml.safe_dump(
            config, default_flow_style=False, allow_unicode=True, sort_keys=False
        )

    def merge_configs(self, *configs: Dict[str, Any]) -> Dict[str, Any]:
        """合并多个配置（额外功能）

        后面的配置会覆盖前面的配置。

        Args:
            *configs: 多个配置字典

        Returns:
            合并后的配置字典
        """
        import copy

        def deep_merge(base: dict, update: dict) -> dict:
            """深度合并两个字典"""
            result = copy.deepcopy(base)
            for key, value in update.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = deep_merge(result[key], value)
                elif key in result and isinstance(result[key], list) and isinstance(value, list):
                    # 对于列表，默认替换而不是追加
                    result[key] = value
                else:
                    result[key] = value
            return result

        result = {}
        for config in configs:
            result = deep_merge(result, config)

        return result

    def __repr__(self) -> str:
        """字符串表示"""
        return "YAMLConfigLoader()"
