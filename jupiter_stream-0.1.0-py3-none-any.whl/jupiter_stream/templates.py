"""预定义文本函数模板 / Predefined Text Function Templates

提供安全的预定义函数模板，用于在配置文件中引用。
Provides safe predefined function templates for use in configuration files.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable, List, Optional

from .core.pipeline.registry import register_template, registry

if TYPE_CHECKING:
    from jupiter_stream.core.pipeline.frame import Frame


@register_template("frame_counter")
def frame_counter(frame: Frame) -> str:
    """显示帧号 / Display frame number"""
    return f"Frame: {frame.frame_id}"


@register_template("timestamp")
def timestamp(frame: Frame) -> str:
    """显示时间戳 / Display timestamp"""
    return f"Time: {frame.timestamp:.2f}s"


@register_template("source_info")
def source_info(frame: Frame) -> str:
    """显示源信息 / Display source information"""
    source_id = frame.source_id or "Unknown"
    return f"Source: {source_id}"


@register_template("video_info")
def video_info(frame: Frame) -> str:
    """显示视频信息 / Display video information"""
    video_name = frame.metadata.get("video_name", "N/A")
    video_frame = frame.metadata.get("video_frame", frame.frame_id)
    return f"Video: {video_name} | Frame: {video_frame}"


@register_template("image_info")
def image_info(frame: Frame) -> str:
    """显示图片信息 / Display image information"""
    image_name = frame.metadata.get("image_name", "N/A")
    image_index = frame.metadata.get("image_index", 0)
    total_images = frame.metadata.get("total_images", 0)
    return f"Image: {image_name} ({image_index + 1}/{total_images})"


@register_template("detection_count")
def detection_count(frame: Frame) -> str:
    """显示检测对象数量 / Display detection count"""
    detections = frame.metadata.get("detections", {})
    count = detections.get("count", 0)
    return f"Detections: {count}"


@register_template("detection_summary")
def detection_summary(frame: Frame) -> str:
    """显示检测摘要 / Display detection summary"""
    detections = frame.metadata.get("detections", {})
    count = detections.get("count", 0)
    inference_time = detections.get("inference_time", 0)
    return f"Detections: {count} | Time: {inference_time:.2f}ms"


@register_template("detection_details")
def detection_details(frame: Frame) -> str:
    """显示检测详情 / Display detection details"""
    detections = frame.metadata.get("detections", {})
    objects = detections.get("objects", [])
    if not objects:
        return "No detections"

    # 统计每种类别的数量
    class_counts = {}
    for obj in objects:
        class_name = obj.get("class", "unknown")
        class_counts[class_name] = class_counts.get(class_name, 0) + 1

    # 格式化输出
    details = ", ".join([f"{name}: {count}" for name, count in class_counts.items()])
    return f"Detected: {details}"


@register_template("frame_and_timestamp")
def frame_and_timestamp(frame: Frame) -> str:
    """显示帧号和时间戳 / Display frame number and timestamp"""
    return f"Frame: {frame.frame_id} | Time: {frame.timestamp:.2f}s"


@register_template("full_info")
def full_info(frame: Frame) -> str:
    """显示完整信息 / Display full information"""
    source_id = frame.source_id or "Unknown"
    return f"Source: {source_id} | Frame: {frame.frame_id} | Time: {frame.timestamp:.2f}s"


def metadata_value(key: str) -> Callable[[Frame], str]:
    """从 metadata 中提取指定键的值 / Extract value from metadata by key

    使用示例 / Usage example:
        template: "metadata:video_name"
        template: "metadata:detections.count"
    """

    def _get_metadata(frame: Frame) -> str:
        # 支持嵌套键，如 "detections.count"
        keys = key.split(".")
        value = frame.metadata
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k, "N/A")
            else:
                return "N/A"
        return str(value)

    return _get_metadata


def custom_format(template: str) -> Callable[[Frame], str]:
    """自定义格式化字符串 / Custom format string

    支持的占位符 / Supported placeholders:
        {frame_id} - 帧号
        {timestamp} - 时间戳
        {source_id} - 源 ID
        {metadata.key} - metadata 中的值

    使用示例 / Usage example:
        template: "format:Frame {frame_id} at {timestamp:.2f}s"
        template: "format:{metadata.video_name} - {frame_id}"
    """

    def _format(frame: Frame) -> str:
        # 准备替换字典
        replacements = {
            "frame_id": frame.frame_id,
            "timestamp": frame.timestamp,
            "source_id": frame.source_id or "Unknown",
        }

        # 处理 metadata 占位符
        result = template
        import re

        metadata_pattern = r"\{metadata\.([^}]+)\}"
        for match in re.finditer(metadata_pattern, template):
            key_path = match.group(1)
            keys = key_path.split(".")
            value = frame.metadata
            for k in keys:
                if isinstance(value, dict):
                    value = value.get(k, "N/A")
                else:
                    value = "N/A"
                    break
            result = result.replace(match.group(0), str(value))

        # 格式化其他占位符
        try:
            return result.format(**replacements)
        except (KeyError, ValueError) as e:
            return f"Format error: {e}"

    return _format


def get_template_function(template_spec: str) -> Optional[Callable[[Frame], str]]:
    """根据模板规范获取函数 / Get function by template specification

    支持的格式 / Supported formats:
        - 简单模板: "frame_counter", "detection_count"
        - metadata 提取: "metadata:video_name", "metadata:detections.count"
        - 自定义格式: "format:Frame {frame_id} at {timestamp:.2f}s"

    Args:
        template_spec: 模板规范字符串 / Template specification string

    Returns:
        函数或 None / Function or None
    """
    if not template_spec:
        return None

    # 处理 metadata: 前缀
    if template_spec.startswith("metadata:"):
        key = template_spec[9:]  # 去掉 "metadata:" 前缀
        return metadata_value(key)

    # 处理 format: 前缀
    if template_spec.startswith("format:"):
        template = template_spec[7:]  # 去掉 "format:" 前缀
        return custom_format(template)

    # 从注册表获取模板函数
    return registry.get_template(template_spec)


def list_templates() -> List[str]:
    """列出所有可用的模板名称 / List all available template names"""
    return registry.list_templates()
