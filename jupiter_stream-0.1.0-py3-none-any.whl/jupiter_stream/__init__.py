"""
Jupiter-Stream - 通用视频流处理框架
Universal Video Stream Processing Framework
"""

from __future__ import annotations

from pathlib import Path

# 直接导入 sources/sinks/processors 以触发 @register_* 装饰器注册
from . import (
    processors,  # noqa: F401
    sinks,  # noqa: F401
    sources,  # noqa: F401
)
from .__version__ import __author__, __license__, __version__
from .builders import CodePipelineBuilder, ConfigPipelineBuilder
from .core import (
    Frame,
    Pipeline,
    PipelineManager,
    Processor,
    ProcessorChain,
    Sink,
    Source,
    create_frame,
)
from .core.pipeline.builder import FluentPipelineBuilder, PipelineBuilder
from .core.pipeline.factory import ComponentFactory, factory

# New architecture components
from .core.pipeline.registry import (
    ComponentRegistry,
    register_processor,
    register_sink,
    register_source,
    register_template,
    registry,
)
from .loaders import AutoConfigLoader, ConfigLoader, YAMLConfigLoader

# Template functions
from .templates import get_template_function, list_templates

# Lazy imports for cv2/torch dependent modules
# These are defined in __getattr__ below

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Core
    "Frame",
    "create_frame",
    "Source",
    "Processor",
    "ProcessorChain",
    "Sink",
    "Pipeline",
    "PipelineManager",
    # Sources (lazy loaded)
    "VideoSource",
    # Processors (lazy loaded)
    "Resize",
    "Annotate",
    "Label",
    # Sinks (lazy loaded)
    "DisplaySink",
    "CallbackSink",
    "FFmpegVideoSink",
    # New architecture - Registry
    "ComponentRegistry",
    "registry",
    "register_source",
    "register_processor",
    "register_sink",
    "register_template",
    # New architecture - Factory
    "ComponentFactory",
    "factory",
    # New architecture - Builders
    "PipelineBuilder",
    "FluentPipelineBuilder",
    "CodePipelineBuilder",
    "ConfigPipelineBuilder",
    # New architecture - Loaders
    "ConfigLoader",
    "YAMLConfigLoader",
    "AutoConfigLoader",
    # Templates
    "get_template_function",
    "list_templates",
    # Utility functions
    "get_scripts_dir",
    "get_script_path",
]


def __getattr__(name: str):
    """Lazy import for cv2/torch dependent components."""
    # Sources
    if name == "VideoSource":
        from .sources import VideoSource

        return VideoSource
    # Processors
    elif name == "Resize":
        from .processors import Resize

        return Resize
    elif name == "Annotate":
        from .processors import Annotate

        return Annotate
    elif name == "Label":
        from .processors import Label

        return Label
    # Sinks
    elif name == "DisplaySink":
        from .sinks import DisplaySink

        return DisplaySink
    elif name == "CallbackSink":
        from .sinks import CallbackSink

        return CallbackSink
    elif name == "FFmpegVideoSink":
        from .sinks import FFmpegVideoSink

        return FFmpegVideoSink

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def get_scripts_dir() -> Path:
    """
    获取已安装的 scripts 目录路径
    Get the path to the installed scripts directory

    Returns:
        Path: scripts 目录的绝对路径 / Absolute path to scripts directory

    Examples:
        >>> scripts_dir = get_scripts_dir()
        >>> print(scripts_dir)
        /path/to/site-packages/scripts
    """
    import sys

    # 尝试多个可能的位置
    # 1. 开发模式（pip install -e .）：项目根目录/scripts
    package_dir = Path(__file__).parent
    # src/jupiter_stream -> src -> project_root -> scripts
    dev_scripts_dir = package_dir.parent.parent / "scripts"
    if dev_scripts_dir.exists() and dev_scripts_dir.is_dir():
        return dev_scripts_dir

    # 2. 安装模式（pip install wheel）：sys.prefix/scripts
    installed_scripts_dir = Path(sys.prefix) / "scripts"
    if installed_scripts_dir.exists() and installed_scripts_dir.is_dir():
        return installed_scripts_dir

    # 3. 虚拟环境或用户安装：多个可能的位置
    for base_path in [Path(sys.prefix), Path(sys.base_prefix)]:
        for subdir in ["scripts", "share/scripts", "lib/scripts"]:
            candidate = base_path / subdir
            if candidate.exists() and candidate.is_dir():
                return candidate

    # 4. 如果都找不到，返回期望的位置（即使不存在）
    return installed_scripts_dir


def get_script_path(script_name: str) -> Path:
    """
    获取特定脚本的路径
    Get the path to a specific script file

    Args:
        script_name: 脚本文件名 / Script filename (e.g., 'install_network_permissions.sh')

    Returns:
        Path: 脚本文件的绝对路径 / Absolute path to the script file

    Raises:
        FileNotFoundError: 如果脚本文件不存在 / If the script file doesn't exist

    Examples:
        >>> script = get_script_path('install_network_permissions.sh')
        >>> print(script)
        /path/to/site-packages/scripts/install_network_permissions.sh

        >>> # 在安装脚本中使用 / Usage in installation scripts
        >>> import subprocess
        >>> script = get_script_path('install_network_permissions.sh')
        >>> subprocess.run(['bash', str(script), 'username'])
    """
    script_path = get_scripts_dir() / script_name
    if not script_path.exists():
        raise FileNotFoundError(
            f"Script not found: {script_name}\n"
            f"Expected location: {script_path}\n"
            f"Available scripts in {get_scripts_dir()}: "
            f"{[f.name for f in get_scripts_dir().iterdir() if f.is_file()] if get_scripts_dir().exists() else 'directory not found'}"
        )
    return script_path
