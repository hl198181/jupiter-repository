"""Video file sink for saving processed frames as video."""

from __future__ import annotations

from pathlib import Path

try:
    import cv2
except ImportError:
    cv2 = None

from jupiter_stream.core import Frame, Sink
from jupiter_stream.core.pipeline.registry import register_sink


@register_sink("VideoSink")
class VideoSink(Sink):
    """
    视频文件输出

    将处理后的帧保存为视频文件。
    Save processed frames as a video file.

    Args:
        output_path: 输出视频文件路径 / Output video file path
        fps: 帧率，默认 30.0 / Frame rate (default: 30.0)
        fourcc: 视频编码器（默认：'mp4v'）/ Video codec (default: 'mp4v')
        enabled: 是否启用输出 / Whether to enable output

    Examples:
        >>> from jupiter_stream import Pipeline, VideoSource
        >>> from jupiter_stream.sinks import VideoSink
        >>>
        >>> pipeline = (
        ...     Pipeline()
        ...     .add_source(VideoSource("input.mp4"))
        ...     .add_sink(VideoSink("output.mp4", fps=30))
        ... )
        >>> pipeline.run()
    """

    def __init__(
        self,
        output_path: str,
        fps: float = 30.0,
        fourcc: str = "mp4v",
        enabled: bool = True,
    ):
        """初始化视频输出"""
        super().__init__(enabled=enabled)

        if cv2 is None:
            raise ImportError(
                "OpenCV is required for VideoSink. " "Install it with: pip install opencv-python"
            )

        self.output_path = Path(output_path)
        self.fps = fps
        self.fourcc_str = fourcc
        self.writer = None
        self._is_opened = False
        self._frame_size = None

        # 创建输出目录
        self.output_path.parent.mkdir(parents=True, exist_ok=True)

        self.logger.info(f"VideoSink initialized: {output_path}")

    def write(self, frame: Frame):
        """
        写入帧到视频文件

        Args:
            frame: 要写入的帧
        """
        # 第一次写入时初始化 VideoWriter
        if self.writer is None:
            height, width = frame.image.shape[:2]
            self._frame_size = (width, height)

            # 创建 VideoWriter
            fourcc = cv2.VideoWriter_fourcc(*self.fourcc_str)
            self.writer = cv2.VideoWriter(str(self.output_path), fourcc, self.fps, self._frame_size)

            if not self.writer.isOpened():
                raise RuntimeError(f"Failed to open VideoWriter for {self.output_path}")

            self._is_opened = True
            self.logger.info(
                f"VideoWriter opened: {self._frame_size[0]}x{self._frame_size[1]} "
                f"@ {self.fps} FPS, codec: {self.fourcc_str}"
            )

        # 检查帧大小是否一致
        height, width = frame.image.shape[:2]
        if (width, height) != self._frame_size:
            self.logger.warning(
                f"Frame size mismatch: expected {self._frame_size}, "
                f"got ({width}, {height}). Resizing..."
            )
            # 调整大小以匹配
            resized = cv2.resize(frame.image, self._frame_size)
            self.writer.write(resized)
        else:
            self.writer.write(frame.image)

    def is_active(self) -> bool:
        """
        检查视频写入器是否激活

        Returns:
            True（始终返回 True，writer 会在第一次 write() 调用时初始化）
        """
        # Always return True - writer will be initialized on first write() call
        # This avoids a catch-22 where Pipeline won't call write() because is_active()
        # returns False, but is_active() needs write() to be called first to initialize
        return True

    def close(self):
        """关闭视频写入器，释放资源"""
        if self.writer is not None:
            self.writer.release()
            self.writer = None
            self._is_opened = False
            self.logger.info(
                f"VideoSink closed: {self.output_path} " f"({self._output_count} frames written)"
            )
