"""Event-triggered video recording sink."""

from __future__ import annotations

import json
import logging
import time
from collections import deque
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Callable, Deque, List, Optional, Set, TextIO, Tuple

from ..core import Frame, Sink
from ..core.pipeline.registry import register_sink
from ..core.utils import FFmpegEncoder

logger = logging.getLogger(__name__)


class RecordingState(Enum):
    """录制状态 / Recording state"""

    IDLE = "idle"  # 等待触发
    RECORDING = "recording"  # 正在录制
    POST_BUFFER = "post_buffer"  # 后缓冲阶段


@register_sink("EventRecordSink")
class EventRecordSink(Sink):
    """
    基于事件触发的视频录制 Sink

    仅在检测到指定目标时录制视频，支持预录制和后录制缓冲。

    Event-triggered video recording sink.

    Records video only when specified objects are detected, with pre/post buffer support.

    Features:
        - 条件触发：只有检测到指定目标才开始录制
        - 预录制：触发时向前回溯 N 秒（帧缓冲区）
        - 后录制：触发消失后继续录制 M 秒
        - 支持指定目标类别、置信度阈值、自定义条件
        - 自动分段：超过最大时长自动开始新文件

    Examples:
        >>> # 检测到人或车时录制
        >>> sink = EventRecordSink(
        ...     output_dir="./events/",
        ...     trigger_classes=["person", "car"],
        ...     pre_buffer_seconds=5.0,
        ...     post_buffer_seconds=3.0
        ... )

        >>> # 自定义触发条件
        >>> def my_trigger(frame: Frame) -> bool:
        ...     detections = frame.metadata.get("detections", {})
        ...     return detections.get("count", 0) >= 3
        >>> sink = EventRecordSink(
        ...     output_dir="./events/",
        ...     trigger_condition=my_trigger
        ... )

        >>> # Pipeline 中使用
        >>> pipeline = (
        ...     Pipeline(fps=30)
        ...     .add_source(RTSPSource("rtsp://..."))
        ...     .add_processor(YOLODetector(model="yolov8n.pt"))
        ...     .add_sink(EventRecordSink(
        ...         output_dir="./events/",
        ...         trigger_classes=["person"],
        ...         min_confidence=0.6,
        ...     ))
        ... )
    """

    def __init__(
        self,
        output_dir: str,
        output_template: str = "event_{timestamp}_{classes}_{index:04d}.mp4",
        # 触发条件
        trigger_classes: Optional[List[str]] = None,
        min_confidence: float = 0.5,
        min_detections: int = 1,
        trigger_condition: Optional[Callable[[Frame], bool]] = None,
        # 录制时间控制
        pre_buffer_seconds: float = 5.0,
        post_buffer_seconds: float = 3.0,
        max_duration_seconds: float = 300.0,
        # 视频编码参数
        fps: Optional[float] = None,
        vcodec: str = "libx264",
        crf: Optional[int] = 23,
        preset: str = "medium",
        pix_fmt: str = "yuv420p",
        movflags: str = "+faststart",
        loglevel: str = "error",
        enabled: bool = True,
    ):
        """
        初始化 EventRecordSink

        Args:
            output_dir: 输出目录 / Output directory
            output_template: 输出文件名模板，支持 {timestamp}, {classes}, {index} 占位符 /
                           Output filename template with {timestamp}, {classes}, {index}
            trigger_classes: 触发类别名称列表（如 ["person", "car"]）/
                           List of class names to trigger on
            min_confidence: 最低置信度阈值 / Minimum confidence threshold
            min_detections: 最少检测数量 / Minimum number of detections
            trigger_condition: 自定义触发条件函数 / Custom trigger condition function
            pre_buffer_seconds: 预录制秒数 / Pre-buffer seconds
            post_buffer_seconds: 后录制秒数 / Post-buffer seconds
            max_duration_seconds: 单个事件最大录制时长 / Maximum recording duration
            fps: 帧率，None 时自动从输入源获取 / Frame rate, auto-detect from source if None
            vcodec: 视频编码器 / Video codec
            crf: 恒定质量因子 / Constant Rate Factor
            preset: 编码速度预设 / Encoding preset
            pix_fmt: 像素格式 / Pixel format
            movflags: MP4 容器标志 / MP4 container flags
            loglevel: FFmpeg 日志级别 / FFmpeg log level
            enabled: 是否启用 / Whether enabled
        """
        super().__init__(enabled)

        # 输出配置（展开 ~ 为用户目录）
        self.output_dir = Path(output_dir).expanduser()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.output_template = output_template

        # 触发条件配置
        self.trigger_classes: Optional[Set[str]] = set(trigger_classes) if trigger_classes else None
        self.min_confidence = min_confidence
        self.min_detections = min_detections
        self.trigger_condition = trigger_condition

        # 时间控制
        self.pre_buffer_seconds = pre_buffer_seconds
        self.post_buffer_seconds = post_buffer_seconds
        self.max_duration_seconds = max_duration_seconds
        self.fps = fps  # None 表示自动检测

        # 视频编码参数（fps 会在初始化时更新）
        self._encoder_params = {
            "fps": fps if fps else 30.0,  # 临时默认值，会在 _init_fps 中更新
            "vcodec": vcodec,
            "crf": crf,
            "preset": preset,
            "pix_fmt": pix_fmt,
            "movflags": movflags,
            "loglevel": loglevel,
        }

        # 运行时状态
        self._fps_initialized = fps is not None
        # 缓冲区大小会在 fps 确定后初始化
        default_fps = fps if fps else 30.0
        self._buffer_size = max(1, int(pre_buffer_seconds * default_fps))
        self._frame_buffer: Deque[Frame] = deque(maxlen=self._buffer_size)
        self._state = RecordingState.IDLE
        self._recording_start_time: Optional[float] = None
        self._post_buffer_start_time: Optional[float] = None
        self._encoder: Optional[FFmpegEncoder] = None
        self._metadata_file: Optional[TextIO] = None
        self._event_index = 0

        # 统计信息
        self._events_recorded = 0
        self._frames_recorded = 0

        logger.info(
            f"EventRecordSink initialized: {output_dir}, "
            f"trigger_classes={trigger_classes}, min_confidence={min_confidence}, "
            f"pre_buffer={pre_buffer_seconds}s, post_buffer={post_buffer_seconds}s"
        )

    def _evaluate_trigger(self, frame: Frame) -> Tuple[bool, List[str]]:
        """
        评估触发条件

        Args:
            frame: 视频帧

        Returns:
            (是否满足触发条件, 匹配的类别名称列表)
        """
        # 自定义条件优先
        if self.trigger_condition is not None:
            try:
                result = self.trigger_condition(frame)
                logger.debug(
                    f"[TRIGGER] Custom condition evaluated: {result}, " f"frame_id={frame.frame_id}"
                )
                return result, []
            except Exception as e:
                logger.warning(f"Trigger condition error: {e}")
                return False, []

        # 从 metadata 获取检测结果
        detections = frame.metadata.get("detections", {})
        objects = detections.get("objects", [])

        if not objects:
            # 无检测时，每 500 帧输出一次
            if frame.frame_id % 500 == 0:
                logger.debug(
                    f"[TRIGGER] No objects (periodic): frame_id={frame.frame_id}, "
                    f"metadata_keys={list(frame.metadata.keys())}"
                )
            return False, []

        # 过滤满足条件的检测
        matched = []
        matched_classes = set()
        for obj in objects:
            class_name = obj.get("class_name", "unknown")
            confidence = obj.get("confidence", 0)

            # 置信度过滤
            if confidence < self.min_confidence:
                continue

            # 类别过滤
            if self.trigger_classes is not None:
                if class_name not in self.trigger_classes:
                    continue

            matched.append(obj)
            matched_classes.add(class_name)

        result = len(matched) >= self.min_detections

        # 只在触发成功时输出日志（每 100 帧一次，避免日志过多）
        if result and frame.frame_id % 100 == 0:
            matched_info = [f"{o.get('class_name')}({o.get('confidence', 0):.2f})" for o in matched]
            logger.debug(f"[TRIGGER] MATCHED: frame={frame.frame_id}, matched={matched_info}")

        return result, list(matched_classes)

    def _generate_output_path(self, classes: List[str] = None) -> Path:
        """生成输出文件路径

        Args:
            classes: 触发的类别名称列表
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # 类别名称用下划线连接，限制长度避免文件名过长
        classes_str = "_".join(sorted(classes)[:3]) if classes else "unknown"
        filename = self.output_template.format(
            timestamp=timestamp,
            index=self._event_index,
            classes=classes_str,
        )
        return self.output_dir / filename

    def _start_recording(self, classes: List[str] = None):
        """开始新的录制会话

        Args:
            classes: 触发的类别名称列表
        """
        output_path = self._generate_output_path(classes)
        self._event_index += 1

        logger.debug(
            f"[RECORD] Starting new recording session: "
            f"output_path={output_path}, event_index={self._event_index}, "
            f"buffer_frames={len(self._frame_buffer)}"
        )

        self._encoder = FFmpegEncoder(
            output_path=str(output_path),
            **self._encoder_params,
        )
        self._recording_start_time = time.time()

        # 创建 metadata 文件（与视频同名，.jsonl 扩展名）
        metadata_path = output_path.with_suffix(".jsonl")
        self._metadata_file = open(metadata_path, "w", encoding="utf-8")
        logger.debug(f"[RECORD] Metadata file created: {metadata_path}")

        logger.info(f"Recording started: {output_path}")
        logger.debug(
            f"[RECORD] Encoder params: fps={self._encoder_params.get('fps')}, "
            f"vcodec={self._encoder_params.get('vcodec')}, "
            f"crf={self._encoder_params.get('crf')}, "
            f"preset={self._encoder_params.get('preset')}"
        )

    def _stop_recording(self):
        """停止当前录制会话"""
        if self._encoder is not None:
            duration = 0.0
            if self._recording_start_time:
                duration = time.time() - self._recording_start_time

            logger.debug(
                f"[RECORD] Stopping recording: "
                f"output_path={self._encoder.output_path}, "
                f"frames={self._encoder.frame_count}, "
                f"duration={duration:.2f}s"
            )

            self._encoder.close()
            logger.info(
                f"Recording stopped: {self._encoder.output_path} "
                f"({self._encoder.frame_count} frames)"
            )
            self._encoder = None
            self._events_recorded += 1
        else:
            logger.debug("[RECORD] _stop_recording called but encoder is None")

        # 关闭 metadata 文件
        if self._metadata_file is not None:
            self._metadata_file.close()
            self._metadata_file = None
            logger.debug("[RECORD] Metadata file closed")

        self._recording_start_time = None
        self._post_buffer_start_time = None

    def _write_frame_to_encoder(self, frame: Frame):
        """写入帧到编码器"""
        if self._encoder is not None:
            self._encoder.write_frame(frame.image)
            self._frames_recorded += 1

            # 写入 metadata 到 jsonl 文件
            if self._metadata_file is not None:
                metadata_record = {
                    "frame_id": frame.frame_id,
                    "timestamp": frame.timestamp,
                    "source_id": frame.source_id,
                    "metadata": frame.metadata,
                }
                self._metadata_file.write(json.dumps(metadata_record, ensure_ascii=False) + "\n")

            # 每 100 帧输出一次 debug 信息，避免日志过多
            if self._encoder.frame_count % 100 == 0:
                logger.debug(
                    f"[WRITE] Progress: frame_id={frame.frame_id}, "
                    f"encoder_frames={self._encoder.frame_count}, "
                    f"total_recorded={self._frames_recorded}"
                )
        else:
            logger.debug(f"[WRITE] Encoder is None, frame dropped: frame_id={frame.frame_id}")

    def _flush_buffer(self):
        """将缓冲区的帧写入编码器"""
        buffer_size = len(self._frame_buffer)
        logger.debug(f"[BUFFER] Flushing buffer: {buffer_size} frames to encoder")
        for i, buffered_frame in enumerate(self._frame_buffer):
            self._write_frame_to_encoder(buffered_frame)
            if i == 0 or i == buffer_size - 1:
                logger.debug(
                    f"[BUFFER] Writing buffered frame {i+1}/{buffer_size}: "
                    f"frame_id={buffered_frame.frame_id}"
                )
        # 清空缓冲区
        self._frame_buffer.clear()
        logger.debug("[BUFFER] Buffer cleared")

    def _init_fps_from_frame(self, frame: Frame):
        """从帧的 metadata 中自动检测 fps"""
        if self._fps_initialized:
            return

        if frame.stream_fps is not None:
            self.fps = frame.stream_fps
        else:
            # 回退到默认值
            self.fps = 30.0
            logger.warning(f"Could not detect fps from frame, using default: {self.fps}")

        # 更新编码器参数和缓冲区大小
        self._encoder_params["fps"] = self.fps
        self._buffer_size = max(1, int(self.pre_buffer_seconds * self.fps))
        self._frame_buffer = deque(maxlen=self._buffer_size)
        self._fps_initialized = True

        logger.info(
            f"FPS initialized from source: {self.fps}, " f"buffer_size={self._buffer_size} frames"
        )

    def write(self, frame: Frame):
        """
        写入帧（状态机处理）

        Args:
            frame: 视频帧
        """
        # 自动检测 fps（仅第一帧）
        if not self._fps_initialized:
            self._init_fps_from_frame(frame)

        current_time = time.time()

        # 每 500 帧输出一次状态摘要（IDLE 状态时）
        if frame.frame_id % 500 == 0 and self._state == RecordingState.IDLE:
            logger.debug(
                f"[STATE] Periodic: frame={frame.frame_id}, state={self._state.value}, "
                f"buffer={len(self._frame_buffer)}/{self._buffer_size}, "
                f"events={self._events_recorded}"
            )

        # 1. 始终缓冲帧（用于预录制）
        self._frame_buffer.append(frame.copy())

        # 2. 评估触发条件
        triggered, matched_classes = self._evaluate_trigger(frame)

        # 3. 状态机处理
        if self._state == RecordingState.IDLE:
            if triggered:
                logger.debug(
                    f"[STATE] IDLE -> RECORDING: triggered at frame {frame.frame_id}, "
                    f"classes={matched_classes}"
                )
                # 开始录制
                self._start_recording(matched_classes)
                self._flush_buffer()
                self._write_frame_to_encoder(frame)
                self._state = RecordingState.RECORDING
                logger.debug(f"Trigger activated at frame {frame.frame_id}")

        elif self._state == RecordingState.RECORDING:
            self._write_frame_to_encoder(frame)

            # 检查是否超过最大时长
            if self._recording_start_time is not None:
                duration = current_time - self._recording_start_time
                if duration >= self.max_duration_seconds:
                    logger.debug(
                        f"[STATE] RECORDING: max duration reached, "
                        f"duration={duration:.2f}s >= max={self.max_duration_seconds}s"
                    )
                    # 超时，结束当前录制
                    self._stop_recording()
                    if triggered:
                        # 仍然触发，开始新录制
                        logger.debug("[STATE] RECORDING: splitting, still triggered")
                        self._start_recording(matched_classes)
                        self._write_frame_to_encoder(frame)
                    else:
                        self._state = RecordingState.IDLE
                        logger.debug("[STATE] RECORDING -> IDLE: max duration, not triggered")
                    logger.info(f"Max duration reached ({duration:.1f}s), split recording")
                    return

            if not triggered:
                # 触发消失，进入后缓冲阶段
                self._post_buffer_start_time = current_time
                self._state = RecordingState.POST_BUFFER
                logger.debug(
                    f"[STATE] RECORDING -> POST_BUFFER: trigger cleared at frame {frame.frame_id}, "
                    f"post_buffer_seconds={self.post_buffer_seconds}"
                )

        elif self._state == RecordingState.POST_BUFFER:
            self._write_frame_to_encoder(frame)

            if triggered:
                # 重新触发，回到录制状态
                self._post_buffer_start_time = None
                self._state = RecordingState.RECORDING
                logger.debug(
                    f"[STATE] POST_BUFFER -> RECORDING: re-triggered at frame {frame.frame_id}"
                )
            else:
                # 检查后缓冲是否结束
                if self._post_buffer_start_time is not None:
                    elapsed = current_time - self._post_buffer_start_time
                    if elapsed >= self.post_buffer_seconds:
                        # 后缓冲结束，停止录制
                        logger.debug(
                            f"[STATE] POST_BUFFER -> IDLE: post-buffer ended, "
                            f"frame={frame.frame_id}, elapsed={elapsed:.2f}s"
                        )
                        self._stop_recording()
                        self._state = RecordingState.IDLE

    def is_active(self) -> bool:
        """检查是否激活"""
        return True

    def close(self):
        """关闭并释放资源"""
        logger.debug(
            f"[CLOSE] Closing EventRecordSink: state={self._state.value}, "
            f"events={self._events_recorded}, frames={self._frames_recorded}"
        )

        # 如果正在录制，停止录制
        if self._state in (RecordingState.RECORDING, RecordingState.POST_BUFFER):
            logger.debug(f"[CLOSE] Stopping active recording (state={self._state.value})")
            self._stop_recording()

        self._frame_buffer.clear()
        self._state = RecordingState.IDLE

        logger.info(
            f"EventRecordSink closed: {self._events_recorded} events, "
            f"{self._frames_recorded} frames recorded"
        )
        logger.debug("[CLOSE] Cleanup complete")

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "state": self._state.value,
                "events_recorded": self._events_recorded,
                "frames_recorded": self._frames_recorded,
                "buffer_size": len(self._frame_buffer),
                "buffer_capacity": self._buffer_size,
                "trigger_classes": (list(self.trigger_classes) if self.trigger_classes else None),
                "min_confidence": self.min_confidence,
                "is_recording": self._state
                in (RecordingState.RECORDING, RecordingState.POST_BUFFER),
            }
        )
        if self._encoder:
            stats["current_recording"] = {
                "output_path": str(self._encoder.output_path),
                "frame_count": self._encoder.frame_count,
            }
        return stats

    def __repr__(self) -> str:
        return (
            f"EventRecordSink(state={self._state.value}, "
            f"events={self._events_recorded}, "
            f"trigger_classes={self.trigger_classes})"
        )
