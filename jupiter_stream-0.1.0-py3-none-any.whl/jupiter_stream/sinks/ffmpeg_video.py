"""FFmpeg-based video sink for H.264 encoding with advanced parameters."""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Optional

from ..core import Frame, Sink
from ..core.pipeline.registry import register_sink

logger = logging.getLogger(__name__)


@register_sink("FFmpegVideoSink")
class FFmpegVideoSink(Sink):
    """
    FFmpeg 视频输出 Sink - 支持 H.264 编码、高级参数控制和路径自动生成

    使用 FFmpeg 保存视频文件，支持现代浏览器兼容的 H.264 编码，
    提供完整的编码参数控制（CRF、preset、bitrate 等）。
    支持根据输入视频路径自动生成输出文件名。

    FFmpeg-based video sink with H.264 encoding, advanced parameter control,
    and automatic output path generation.

    Uses FFmpeg to save video files with modern browser-compatible H.264 encoding,
    providing full control over encoding parameters (CRF, preset, bitrate, etc.).
    Supports automatic output filename generation based on input video path.

    Examples:
        >>> # 自动生成输出路径（使用默认模板）
        >>> sink = FFmpegVideoSink(fps=30)
        >>> # 生成: input_output.mp4（与源视频同目录）

        >>> # 自定义模板
        >>> sink = FFmpegVideoSink(
        ...     fps=30,
        ...     output_template="{source_stem}_processed_{timestamp}.mp4"
        ... )
        >>> # 生成: input_processed_20250119_143022.mp4

        >>> # 指定输出目录
        >>> sink = FFmpegVideoSink(fps=30, output_dir="./output")
        >>> # 生成: ./output/input_output.mp4

        >>> # FolderSource 批量处理 - 合并模式（默认）
        >>> sink = FFmpegVideoSink(fps=30)
        >>> # 将文件夹中所有视频合并为一个输出文件

        >>> # FolderSource 批量处理 - 分离模式
        >>> sink = FFmpegVideoSink(
        ...     fps=30,
        ...     output_template="{source_stem}_processed.mp4",
        ...     split_by_source=True
        ... )
        >>> # 为每个输入视频生成独立的输出文件
        >>> # video1.mp4 → video1_processed.mp4
        >>> # video2.mp4 → video2_processed.mp4

        >>> # 显式指定输出路径（传统方式，完全兼容）
        >>> sink = FFmpegVideoSink("output.mp4", fps=30)

        >>> # 高质量编码
        >>> sink = FFmpegVideoSink(
        ...     "output.mp4",
        ...     fps=30,
        ...     crf=18,
        ...     preset="slow"
        ... )

        >>> # 固定码率
        >>> sink = FFmpegVideoSink(
        ...     "output.mp4",
        ...     fps=30,
        ...     video_bitrate="4M",
        ...     maxrate="6M",
        ...     bufsize="8M"
        ... )
    """

    def __init__(
        self,
        output_path: Optional[str] = None,
        fps: float = 30.0,
        # 路径自动生成参数
        output_template: str = "{source_stem}_output.mp4",
        output_dir: Optional[str] = None,
        split_by_source: bool = False,
        # 视频编码参数
        vcodec: str = "libx264",
        crf: Optional[int] = 23,
        preset: str = "medium",
        pix_fmt: str = "yuv420p",
        # 码率控制（与 CRF 二选一）
        video_bitrate: Optional[str] = None,
        maxrate: Optional[str] = None,
        bufsize: Optional[str] = None,
        # 音频参数
        acodec: Optional[str] = None,
        audio_bitrate: str = "128k",
        audio_source: Optional[str] = None,
        # 容器优化
        movflags: str = "+faststart",
        # 其他
        loglevel: str = "error",
        enabled: bool = True,
    ):
        """
        初始化 FFmpegVideoSink

        Args:
            output_path: 输出文件路径（可选，如果未提供则自动生成）/
                        Output file path (optional, auto-generated if not provided)
            fps: 帧率 / Frame rate
            output_template: 输出文件名模板，支持占位符：
                           {source_stem}: 输入文件名（不含扩展名）
                           {source_name}: 输入文件名（含扩展名）
                           {source_dir}: 输入文件所在目录
                           {timestamp}: 当前时间戳（格式：20250119_143022）
                           {source_id}: Frame 的 source_id
                           默认: "{source_stem}_output.mp4" /
                           Output filename template with placeholders support
            output_dir: 输出目录（可选，默认为输入文件所在目录或当前目录）/
                       Output directory (optional, defaults to source dir or current dir)
            split_by_source: 是否为每个源视频单独输出文件（仅对 FolderSource 等多视频源有效）。
                           False（默认）: 所有视频合并为一个输出文件
                           True: 为每个输入视频生成独立的输出文件 /
                           Whether to split output by source video (only for FolderSource, etc.)
            vcodec: 视频编码器（默认: libx264）/ Video codec (default: libx264)
            crf: 恒定质量因子 (18=高质量, 28=低质量, 默认: 23) /
                 Constant Rate Factor (18=high quality, 28=low quality, default: 23)
            preset: 编码速度预设 (ultrafast/fast/medium/slow/veryslow, 默认: medium) /
                    Encoding speed preset
            pix_fmt: 像素格式（默认: yuv420p，最广泛兼容）/ Pixel format
            video_bitrate: 视频目标码率（如 "4M"），与 CRF 二选一 /
                          Target video bitrate (e.g. "4M"), mutually exclusive with CRF
            maxrate: 最大码率 / Maximum bitrate
            bufsize: VBV 缓冲区大小 / VBV buffer size
            acodec: 音频编码器（None 表示无音频，"copy" 表示复制，默认: None）/
                    Audio codec (None=no audio, "copy"=copy from source, default: None)
            audio_bitrate: 音频码率（仅当 acodec 不为 None 或 "copy" 时有效）/
                          Audio bitrate
            audio_source: 音频源文件路径（用于复制音频）/ Audio source file path
            movflags: MP4 容器标志（默认: "+faststart" 用于流式播放）/
                     MP4 container flags (default: "+faststart" for streaming)
            loglevel: FFmpeg 日志级别 / FFmpeg log level
            enabled: 是否启用 / Whether to enable

        Raises:
            ImportError: 如果 ffmpeg-python 未安装 / If ffmpeg-python is not installed
            FileNotFoundError: 如果系统未安装 ffmpeg / If ffmpeg is not installed on system
        """
        super().__init__(enabled)

        import importlib.util

        if importlib.util.find_spec("ffmpeg") is None:
            raise ImportError(
                "ffmpeg-python is required for FFmpegVideoSink. "
                "Install with: pip install ffmpeg-python"
            )

        # 检查 ffmpeg 是否安装
        try:
            subprocess.run(
                ["ffmpeg", "-version"],
                capture_output=True,
                check=True,
            )
        except FileNotFoundError:
            raise FileNotFoundError(
                "ffmpeg is not installed on your system. "
                "Please install ffmpeg:\n"
                "  macOS: brew install ffmpeg\n"
                "  Ubuntu/Debian: sudo apt-get install ffmpeg\n"
                "  Windows: Download from https://ffmpeg.org/download.html"
            )

        # 路径配置
        self.output_path = Path(output_path) if output_path else None
        self.output_template = output_template
        self.output_dir = Path(output_dir) if output_dir else None
        self.split_by_source = split_by_source

        # 编码参数
        self.fps = fps
        self.vcodec = vcodec
        self.crf = crf
        self.preset = preset
        self.pix_fmt = pix_fmt
        self.video_bitrate = video_bitrate
        self.maxrate = maxrate
        self.bufsize = bufsize
        self.acodec = acodec
        self.audio_bitrate = audio_bitrate
        self.audio_source = audio_source
        self.movflags = movflags
        self.loglevel = loglevel

        # 运行时状态
        self.process = None
        self._frame_size = None
        self._is_opened = False
        self._current_video_index = None  # 追踪当前处理的视频索引（用于 split_by_source）

        # 如果显式提供了 output_path，立即创建输出目录
        if self.output_path:
            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info(
                f"FFmpegVideoSink initialized: {self.output_path.name}, "
                f"codec={self.vcodec}, crf={self.crf}, preset={self.preset}"
            )
        else:
            logger.info(
                f"FFmpegVideoSink initialized with auto-generated path, "
                f"template={self.output_template}, codec={self.vcodec}, crf={self.crf}, preset={self.preset}"
            )

    def _generate_output_path(self, frame: Frame) -> Path:
        """
        根据模板和帧信息生成输出路径

        Generate output path from template and frame information

        Args:
            frame: 视频帧 / Video frame

        Returns:
            生成的输出路径 / Generated output path
        """
        from datetime import datetime

        # 优先使用 FolderSource 提供的 video_stem（用于 split_by_source 模式）
        if "video_stem" in frame.metadata:
            source_stem = frame.metadata["video_stem"]
            source_name = frame.metadata.get("video_name", f"{source_stem}.mp4")
            video_path = frame.metadata.get("video_path")
            if video_path:
                source_dir = Path(video_path).parent
            else:
                source_dir = Path(frame.metadata.get("folder_path", Path.cwd()))
        # 其次尝试从 frame.metadata 获取视频路径
        elif "video_path" in frame.metadata:
            video_path = frame.metadata["video_path"]
            source_path = Path(video_path)
            source_stem = source_path.stem
            source_name = source_path.name
            source_dir = source_path.parent
        else:
            # 如果没有 video_path，从 source_id 生成
            source_id = frame.source_id or "unknown"
            # 移除可能的前缀（如 "video:"）
            if ":" in source_id:
                source_id = source_id.split(":", 1)[1]
            source_stem = Path(source_id).stem if source_id != "unknown" else "output"
            source_name = Path(source_id).name if source_id != "unknown" else "output"
            source_dir = Path.cwd()

        # 生成时间戳
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # 填充模板
        filename = self.output_template.format(
            source_stem=source_stem,
            source_name=source_name,
            source_dir=str(source_dir),
            timestamp=timestamp,
            source_id=frame.source_id or "unknown",
        )

        # 确定输出目录
        if self.output_dir:
            output_path = self.output_dir / filename
        elif video_path:
            # 使用源视频所在目录
            output_path = source_dir / filename
        else:
            # 使用当前工作目录
            output_path = Path.cwd() / filename

        # 创建输出目录
        output_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info(f"Auto-generated output path: {output_path}")
        return output_path

    def write(self, frame: Frame):
        """
        写入一帧视频

        Write a video frame

        Args:
            frame: 视频帧 / Video frame
        """
        import ffmpeg

        # 检测视频切换（仅在 split_by_source=True 时）
        current_video_index = frame.metadata.get("video_index")
        if self.split_by_source and current_video_index is not None:
            if (
                self._current_video_index is not None
                and current_video_index != self._current_video_index
            ):
                # 检测到新视频，关闭当前进程并重置状态
                logger.info(
                    f"Detected video switch: {self._current_video_index} -> {current_video_index}, "
                    f"closing current output file"
                )
                self.close()
                # 重置状态以便为新视频创建新文件
                self.output_path = None
                self.process = None
                self._frame_size = None
                self._is_opened = False

            # 更新当前视频索引
            self._current_video_index = current_video_index

        # 第一次写入时初始化输出路径（如果未提供）
        if self.output_path is None:
            self.output_path = self._generate_output_path(frame)

        # 第一次写入时初始化 FFmpeg 进程
        if self.process is None:
            height, width = frame.image.shape[:2]
            self._frame_size = (width, height)

            # 构建 FFmpeg 输入管道
            input_args = {
                "format": "rawvideo",
                "pix_fmt": "bgr24",
                "s": f"{width}x{height}",
                "r": self.fps,
            }

            stream = ffmpeg.input("pipe:", **input_args)

            # 构建输出参数
            output_args = {
                "vcodec": self.vcodec,
                "pix_fmt": self.pix_fmt,
                "preset": self.preset,
            }

            # 添加质量控制参数（CRF 或 bitrate）
            if self.video_bitrate:
                # 使用固定码率模式
                output_args["video_bitrate"] = self.video_bitrate
                if self.maxrate:
                    output_args["maxrate"] = self.maxrate
                if self.bufsize:
                    output_args["bufsize"] = self.bufsize
            elif self.crf is not None:
                # 使用 CRF 模式（恒定质量）
                output_args["crf"] = self.crf

            # 添加音频参数
            if self.acodec:
                if self.acodec == "copy" and self.audio_source:
                    # 从源视频复制音频
                    audio_input = ffmpeg.input(self.audio_source)
                    stream = ffmpeg.output(
                        stream,
                        audio_input.audio,
                        str(self.output_path),
                        **output_args,
                        acodec="copy",
                    )
                else:
                    # 使用指定的音频编码器
                    output_args["acodec"] = self.acodec
                    output_args["audio_bitrate"] = self.audio_bitrate
                    stream = ffmpeg.output(stream, str(self.output_path), **output_args)
            else:
                # 无音频
                stream = ffmpeg.output(stream, str(self.output_path), **output_args)

            # 添加 movflags（如 faststart）
            if self.movflags:
                stream = stream.global_args("-movflags", self.movflags)

            # 覆盖现有文件
            stream = stream.overwrite_output()

            # 启动 FFmpeg 进程
            try:
                self.process = stream.run_async(
                    pipe_stdin=True,
                    pipe_stderr=True,
                    quiet=(self.loglevel == "quiet"),
                )
                self._is_opened = True
                logger.info(f"FFmpeg process started: {width}x{height}, {self.fps:.2f} fps")
            except ffmpeg.Error as e:
                error_msg = e.stderr.decode() if e.stderr else str(e)
                logger.error(f"Failed to start FFmpeg: {error_msg}")
                raise RuntimeError(f"Failed to start FFmpeg process: {error_msg}")

        # 写入帧数据到 FFmpeg
        try:
            # 确保帧大小一致
            if frame.image.shape[:2] != (self._frame_size[1], self._frame_size[0]):
                import cv2

                frame.image = cv2.resize(
                    frame.image,
                    self._frame_size,
                    interpolation=cv2.INTER_LINEAR,
                )
                logger.debug(f"Frame resized to {self._frame_size} to match video dimensions")

            self.process.stdin.write(frame.image.tobytes())
        except BrokenPipeError:
            logger.error("FFmpeg process terminated unexpectedly")
            raise RuntimeError("FFmpeg process terminated unexpectedly")
        except Exception as e:
            logger.error(f"Failed to write frame: {e}")
            raise

    def is_active(self) -> bool:
        """
        检查 FFmpeg 进程是否激活

        Check if FFmpeg process is active

        Returns:
            True 如果进程已启动 / True if process is started
        """
        return True  # 总是返回 True，允许第一帧初始化进程

    def close(self):
        """关闭 FFmpeg 进程，完成视频文件写入 / Close FFmpeg process and finalize video"""
        if self.process is not None:
            try:
                # 关闭标准输入，通知 FFmpeg 没有更多数据
                self.process.stdin.close()

                # 等待进程结束
                stderr_output = self.process.stderr.read()
                self.process.wait()

                # 检查是否有错误
                if self.process.returncode != 0:
                    error_msg = stderr_output.decode() if stderr_output else "Unknown error"
                    logger.error(f"FFmpeg process failed: {error_msg}")
                else:
                    logger.info(f"Video saved successfully: {self.output_path}")

                self._is_opened = False
                self.process = None

            except Exception as e:
                logger.error(f"Error closing FFmpeg process: {e}")
                if self.process:
                    self.process.kill()
                    self.process = None
