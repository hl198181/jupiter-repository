"""Display sink implementation."""

from __future__ import annotations

from ..core import Frame, Sink
from ..core.pipeline.registry import register_sink


@register_sink("DisplaySink")
class DisplaySink(Sink):
    """
    窗口显示输出器

    在 OpenCV 窗口中显示处理后的帧。

    Examples:
        >>> sink = DisplaySink(window_name="Output")
        >>> sink(frame)

        >>> # 等待按键退出
        >>> sink = DisplaySink(wait_key=1)
    """

    def __init__(
        self,
        window_name: str = "Jupiter-Stream",
        wait_key: int = 1,
        auto_close: bool = True,
        enabled: bool = True,
    ):
        """
        初始化 DisplaySink

        Args:
            window_name: 窗口名称
            wait_key: 等待按键时间（毫秒），0 表示一直等待
            auto_close: 是否自动关闭窗口
            enabled: 是否启用

        Raises:
            ImportError: 如果 OpenCV 未安装
        """
        super().__init__(enabled)

        import importlib.util

        if importlib.util.find_spec("cv2") is None:
            raise ImportError(
                "OpenCV is required for DisplaySink. "
                "Install with: pip install jupiter-stream[cv]"
            )

        self.window_name = window_name
        self.wait_key = wait_key
        self.auto_close = auto_close
        self._window_created = False

    def write(self, frame: Frame):
        """显示帧"""
        import cv2

        if not self._window_created:
            cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)
            self._window_created = True

        cv2.imshow(self.window_name, frame.image)

        # 等待按键
        key = cv2.waitKey(self.wait_key)

        # 按 'q' 或 ESC 退出
        if key == ord("q") or key == 27:
            self.logger.info("User requested exit")
            self.close()

    def is_active(self) -> bool:
        """检查窗口是否激活"""
        if not self._window_created:
            return True

        try:
            import cv2

            # 检查窗口是否存在
            return cv2.getWindowProperty(self.window_name, cv2.WND_PROP_VISIBLE) >= 1
        except Exception:
            return False

    def close(self):
        """关闭显示窗口"""
        if self._window_created and self.auto_close:
            try:
                import cv2

                cv2.destroyWindow(self.window_name)
                self.logger.info(f"Closed window: {self.window_name}")
            except Exception as e:
                self.logger.error(f"Error closing window: {e}")
            finally:
                self._window_created = False
