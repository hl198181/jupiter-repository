"""Image file sink for saving processed frames as images."""

from __future__ import annotations

from pathlib import Path

try:
    import cv2
except ImportError:
    cv2 = None

from jupiter_stream.core import Frame, Sink
from jupiter_stream.core.pipeline.registry import register_sink


@register_sink("ImageSaveSink")
class ImageSaveSink(Sink):
    """
    图片文件输出

    将处理后的帧保存为图片文件。
    Save processed frames as image files.

    Args:
        output_dir: 输出目录 / Output directory
        filename_template: 文件名模板，支持占位符：
                          {frame_id}, {timestamp}, {source_id}
                          默认：frame_{frame_id:06d}.jpg
        format: 图片格式（jpg, png, bmp等）/ Image format (default: jpg)
        quality: JPEG 质量（1-100，仅 jpg 格式）/ JPEG quality (1-100, jpg only)
        enabled: 是否启用输出 / Whether to enable output

    Examples:
        >>> from jupiter_stream import Pipeline, VideoSource
        >>> from jupiter_stream.sinks import ImageSaveSink
        >>>
        >>> # 基本使用
        >>> pipeline = (
        ...     Pipeline()
        ...     .add_source(VideoSource("input.mp4"))
        ...     .add_sink(ImageSaveSink("output_frames/"))
        ... )
        >>>
        >>> # 自定义文件名模板
        >>> pipeline = (
        ...     Pipeline()
        ...     .add_source(VideoSource("input.mp4"))
        ...     .add_sink(ImageSaveSink(
        ...         "output_frames/",
        ...         filename_template="video_{source_id}_frame_{frame_id:08d}.png",
        ...         format="png"
        ...     ))
        ... )
        >>> pipeline.run()
    """

    def __init__(
        self,
        output_dir: str,
        filename_template: str = "frame_{frame_id:06d}.jpg",
        format: str = "jpg",
        quality: int = 95,
        enabled: bool = True,
    ):
        """初始化图片输出"""
        super().__init__(enabled=enabled)

        if cv2 is None:
            raise ImportError(
                "OpenCV is required for ImageSaveSink. "
                "Install it with: pip install opencv-python"
            )

        self.output_dir = Path(output_dir)
        self.filename_template = filename_template
        self.format = format.lower()
        self.quality = quality

        # 创建输出目录
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 设置 imwrite 参数
        self.imwrite_params = []
        if self.format == "jpg" or self.format == "jpeg":
            self.imwrite_params = [cv2.IMWRITE_JPEG_QUALITY, self.quality]
        elif self.format == "png":
            # PNG 压缩级别 (0-9)
            self.imwrite_params = [cv2.IMWRITE_PNG_COMPRESSION, 3]

        self.logger.info(
            f"ImageSaveSink initialized: {output_dir}, "
            f"template={filename_template}, format={format}"
        )

    def write(self, frame: Frame):
        """
        写入帧为图片文件

        Args:
            frame: 要写入的帧
        """
        # 格式化文件名
        try:
            filename = self.filename_template.format(
                frame_id=frame.frame_id,
                timestamp=frame.timestamp,
                source_id=frame.source_id,
            )
        except KeyError as e:
            self.logger.error(
                f"Invalid placeholder in filename_template: {e}. " f"Using default naming."
            )
            filename = f"frame_{frame.frame_id:06d}.{self.format}"

        # 确保文件扩展名正确
        if not filename.endswith(f".{self.format}"):
            filename += f".{self.format}"

        output_path = self.output_dir / filename

        # 保存图片
        success = cv2.imwrite(str(output_path), frame.image, self.imwrite_params)

        if not success:
            self.logger.error(f"Failed to save image: {output_path}")
        else:
            if self._output_count % 100 == 0:  # 每 100 帧打印一次
                self.logger.debug(f"Saved frame {frame.frame_id} to {output_path}")

    def is_active(self) -> bool:
        """
        检查图片保存是否激活

        Returns:
            True（图片保存总是激活的）
        """
        return True

    def close(self):
        """关闭图片输出（无需特殊操作）"""
        self.logger.info(
            f"ImageSaveSink closed: {self.output_dir} " f"({self._output_count} frames saved)"
        )
