"""Frame sinks (outputs) for jupiter-stream."""

from __future__ import annotations

from .callback import CallbackSink
from .display import DisplaySink
from .ffmpeg_video import FFmpegVideoSink
from .image import ImageSaveSink
from .rtsp_sink import RTSPSink
from .video import VideoSink

__all__ = [
    "DisplaySink",
    "CallbackSink",
    "VideoSink",
    "FFmpegVideoSink",
    "ImageSaveSink",
    "RTSPSink",
]
