"""Frame sinks (outputs) for jupiter-stream."""

from __future__ import annotations

from .display import DisplaySink
from .callback import CallbackSink
from .video import VideoSink
from .ffmpeg_video import FFmpegVideoSink
from .image import ImageSaveSink
from .rtsp_sink import RTSPSink

__all__ = [
    "DisplaySink",
    "CallbackSink",
    "VideoSink",
    "FFmpegVideoSink",
    "ImageSaveSink",
    "RTSPSink",
]
