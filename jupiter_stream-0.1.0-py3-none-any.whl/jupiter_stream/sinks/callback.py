"""Callback sink implementation."""

from __future__ import annotations

from typing import Callable

from ..core import Frame, Sink
from ..core.pipeline.registry import register_sink


@register_sink("CallbackSink")
class CallbackSink(Sink):
    """
    回调函数输出器

    将帧传递给用户定义的回调函数。

    Examples:
        >>> def my_callback(frame: Frame):
        ...     print(f"Received frame {frame.frame_id}")
        >>>
        >>> sink = CallbackSink(my_callback)
        >>> sink(frame)

        >>> # 使用 lambda
        >>> sink = CallbackSink(lambda f: print(f"FPS: {1 / (time.time() - f.timestamp)}"))
    """

    def __init__(self, callback: Callable[[Frame], None], enabled: bool = True):
        """
        初始化 CallbackSink

        Args:
            callback: 回调函数，接收 Frame 参数
            enabled: 是否启用

        Raises:
            TypeError: 如果 callback 不可调用
        """
        super().__init__(enabled)

        if not callable(callback):
            raise TypeError(f"callback must be callable, got {type(callback)}")

        self.callback = callback

    def write(self, frame: Frame):
        """调用回调函数"""
        try:
            self.callback(frame)
        except Exception as e:
            self.logger.error(f"Error in callback: {e}")
            raise

    def is_active(self) -> bool:
        """回调函数始终激活"""
        return True

    def close(self):
        """无需清理"""
        pass
