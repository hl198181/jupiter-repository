"""RTSP streaming sink for pushing frames to MediaMTX or other RTSP servers."""

from __future__ import annotations

import logging
import select
import subprocess
import threading
import time
from typing import Optional

from ..core import Frame, Sink
from ..core.pipeline.registry import register_sink

logger = logging.getLogger(__name__)


@register_sink("RTSPSink")
class RTSPSink(Sink):
    """
    RTSP 推流 Sink - 将视频帧推送到 RTSP 服务器（如 MediaMTX）

    使用 FFmpeg 将处理后的视频流以 H.264 编码推送到 RTSP 服务器，
    支持低延迟配置和多路并发推流。

    RTSP streaming sink for pushing processed video frames to RTSP servers.

    Uses FFmpeg to push H.264 encoded video stream to RTSP servers (like MediaMTX),
    with support for low-latency configuration and concurrent multi-stream pushing.

    Examples:
        >>> # 基本用法 - 推流到 MediaMTX
        >>> sink = RTSPSink("rtsp://39.108.184.91:8554/test", fps=30)

        >>> # 低延迟配置
        >>> sink = RTSPSink(
        ...     "rtsp://39.108.184.91:8554/stream1",
        ...     fps=30,
        ...     preset="ultrafast",
        ...     bitrate="2M"
        ... )

        >>> # 自定义 GOP 和传输协议
        >>> sink = RTSPSink(
        ...     "rtsp://39.108.184.91:8554/device/cam001",
        ...     fps=30,
        ...     gop=60,
        ...     transport="udp"
        ... )

        >>> # 在 Pipeline 中使用
        >>> from jupiter_stream import Pipeline, VideoSource
        >>> pipeline = (
        ...     Pipeline(fps=30)
        ...     .add_source(VideoSource("input.mp4", loop=True))
        ...     .add_sink(RTSPSink("rtsp://39.108.184.91:8554/test"))
        ... )
        >>> pipeline.run()
    """

    def __init__(
        self,
        rtsp_url: str,
        fps: Optional[float] = None,
        # 视频编码参数
        vcodec: str = "libx264",
        preset: str = "ultrafast",
        tune: str = "zerolatency",
        pix_fmt: str = "yuv420p",
        # 码率控制
        bitrate: str = "2M",
        maxrate: Optional[str] = None,
        bufsize: Optional[str] = None,
        # GOP 控制
        gop: Optional[int] = None,
        # RTSP 参数
        transport: str = "tcp",
        # 重连参数
        auto_reconnect: bool = True,
        max_reconnect_attempts: int = 0,  # 0 = 无限重连
        reconnect_interval: float = 3.0,  # 初始重连间隔（秒）
        reconnect_backoff: float = 1.5,  # 指数退避因子
        max_reconnect_interval: float = 30.0,  # 最大重连间隔（秒）
        # 启动控制
        auto_start: bool = False,  # False = 等待 start() 后才推流, True = 立即推流
        # 其他
        loglevel: str = "error",
        enabled: bool = True,
    ):
        """
        初始化 RTSPSink

        Args:
            rtsp_url: RTSP 推流地址 / RTSP streaming URL
                     例如: rtsp://39.108.184.91:8554/test
            fps: 帧率，None 时自动从输入源获取 / Frame rate, auto-detect from source if None
            vcodec: 视频编码器（默认: libx264）/ Video codec (default: libx264)
            preset: 编码速度预设 (ultrafast/fast/medium/slow, 默认: ultrafast) /
                    Encoding speed preset (default: ultrafast for low latency)
            tune: 编码调优（默认: zerolatency，用于低延迟流媒体）/
                  Encoding tune (default: zerolatency for low-latency streaming)
            pix_fmt: 像素格式（默认: yuv420p，最广泛兼容）/ Pixel format
            bitrate: 视频目标码率（默认: "2M"）/ Target video bitrate (default: "2M")
            maxrate: 最大码率（默认: None，使用 bitrate 值）/ Maximum bitrate
            bufsize: VBV 缓冲区大小（默认: None，使用 bitrate*2）/ VBV buffer size
            gop: GOP 大小，关键帧间隔（默认: fps*2）/ GOP size, keyframe interval
            transport: RTSP 传输协议 (tcp/udp，默认: tcp) /
                      RTSP transport protocol (tcp/udp, default: tcp)
            auto_reconnect: 是否自动重连（默认: True）/ Auto reconnect on error
            max_reconnect_attempts: 最大重连次数（0=无限，默认: 0）/ Max reconnect attempts
            reconnect_interval: 初始重连间隔秒数（默认: 3.0）/ Initial reconnect interval
            reconnect_backoff: 重连间隔指数退避因子（默认: 1.5）/ Reconnect backoff factor
            max_reconnect_interval: 最大重连间隔秒数（默认: 30.0）/ Max reconnect interval
            auto_start: 是否自动启动推流（默认: False）/
                       Whether to start streaming automatically (default: False)
                       False = 等待 start() 后才推流 / Wait for start() before streaming
                       True = Pipeline 启动时立即推流 / Start streaming when pipeline starts
            loglevel: FFmpeg 日志级别 / FFmpeg log level
            enabled: 是否启用 / Whether to enable

        Raises:
            ImportError: 如果 ffmpeg-python 未安装 / If ffmpeg-python is not installed
            FileNotFoundError: 如果系统未安装 ffmpeg / If ffmpeg is not installed on system
            ValueError: 如果 rtsp_url 格式无效 / If rtsp_url format is invalid
        """
        super().__init__(enabled)

        try:
            import ffmpeg  # noqa: F401
        except ImportError:
            raise ImportError(
                "ffmpeg-python is required for RTSPSink. " "Install with: pip install ffmpeg-python"
            )

        # 检查 ffmpeg 是否安装
        try:
            subprocess.run(
                ["ffmpeg", "-version"],
                capture_output=True,
                check=True,
            )
        except FileNotFoundError:
            raise FileNotFoundError(
                "ffmpeg is not installed on your system. "
                "Please install ffmpeg:\n"
                "  macOS: brew install ffmpeg\n"
                "  Ubuntu/Debian: sudo apt-get install ffmpeg\n"
                "  Windows: Download from https://ffmpeg.org/download.html"
            )

        # 验证 RTSP URL 格式
        if not rtsp_url.startswith("rtsp://"):
            raise ValueError(f"Invalid RTSP URL: {rtsp_url}. " "URL must start with 'rtsp://'")

        self.rtsp_url = rtsp_url
        self.fps = fps  # None 表示自动检测
        self._fps_initialized = fps is not None
        self._gop_config = gop  # 保存用户配置的 gop，延迟计算
        self.vcodec = vcodec
        self.preset = preset
        self.tune = tune
        self.pix_fmt = pix_fmt
        self.bitrate = bitrate
        self.maxrate = maxrate or bitrate  # 如果未指定，使用 bitrate
        self.bufsize = bufsize or f"{int(bitrate[:-1]) * 2}M"  # 默认 bitrate*2
        self.gop = gop  # 延迟计算，在 fps 确定后设置
        self.transport = transport
        self.loglevel = loglevel

        # 重连参数
        self.auto_reconnect = auto_reconnect
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_interval = reconnect_interval
        self.reconnect_backoff = reconnect_backoff
        self.max_reconnect_interval = max_reconnect_interval

        # 启动控制
        self.auto_start = auto_start
        self._started = auto_start  # 是否已启动推流

        # 运行时状态
        self.process = None
        self._frame_size = None
        self._is_opened = False
        self._first_frame_written = False  # 标记是否已写入首帧

        # 重连状态
        self._reconnect_count = 0
        self._last_reconnect_time = 0.0
        self._current_reconnect_interval = reconnect_interval

        # stderr 监控
        self._stderr_thread = None
        self._stderr_error = None  # 存储检测到的错误信息
        self._stop_monitoring = False

        # 提取 URL 中的路径用于日志（不包含敏感信息）
        self._log_url = self._sanitize_url(rtsp_url)

        logger.info(
            f"RTSPSink initialized: {self._log_url}, "
            f"codec={self.vcodec}, preset={self.preset}, bitrate={self.bitrate}"
        )

    def _sanitize_url(self, url: str) -> str:
        """
        隐藏 URL 中的敏感信息（用户名/密码）

        Hide sensitive information (username/password) in URL

        Args:
            url: 原始 URL / Original URL

        Returns:
            清理后的 URL / Sanitized URL
        """
        from urllib.parse import urlparse

        parsed = urlparse(url)
        if parsed.username or parsed.password:
            # 隐藏认证信息
            netloc = f"***:***@{parsed.hostname}"
            if parsed.port:
                netloc += f":{parsed.port}"
            return f"{parsed.scheme}://{netloc}{parsed.path}"
        return url

    # 可恢复错误关键词（网络问题等，可以重连）
    _RECOVERABLE_ERRORS = [
        "connection refused",
        "connection reset",
        "broken pipe",
        "conversion failed",
        "network is unreachable",
        "connection timed out",
        "no route to host",
        "temporarily unavailable",
    ]

    # 不可恢复错误关键词（配置问题，不应重连）
    _FATAL_ERRORS = [
        "invalid",
        "not configured",
        "rejected",
        "denied",
        "unknown encoder",
        "no such file",
        "permission denied",
    ]

    def _init_fps_from_frame(self, frame: Frame):
        """
        从 Frame 自动检测 fps

        Auto-detect fps from Frame metadata

        Args:
            frame: 视频帧 / Video frame
        """
        if frame.stream_fps is not None:
            self.fps = frame.stream_fps
        else:
            # 回退到默认值
            self.fps = 30.0
            logger.warning(f"Could not detect fps from frame, using default: {self.fps}")

        # 计算 GOP（如果用户未指定）
        if self._gop_config is None:
            self.gop = int(self.fps * 2)  # 默认 2 秒一个关键帧
        else:
            self.gop = self._gop_config

        self._fps_initialized = True
        logger.info(f"FPS initialized from source: {self.fps}, GOP: {self.gop}")

    def _is_recoverable_error(self, error_msg: str) -> bool:
        """
        判断错误是否可恢复

        Check if error is recoverable

        Args:
            error_msg: 错误消息 / Error message

        Returns:
            True 如果可恢复 / True if recoverable
        """
        if not error_msg:
            return True  # 未知错误默认可恢复

        error_lower = error_msg.lower()

        # 先检查是否是致命错误
        if any(kw in error_lower for kw in self._FATAL_ERRORS):
            return False

        # 再检查是否是可恢复错误，或默认为可恢复
        return True

    def _cleanup_process(self):
        """
        清理 FFmpeg 进程和相关资源

        Cleanup FFmpeg process and related resources
        """
        # 停止 stderr 监控线程
        self._stop_monitoring = True
        if self._stderr_thread and self._stderr_thread.is_alive():
            self._stderr_thread.join(timeout=1.0)

        # 终止进程
        if self.process is not None:
            try:
                self.process.kill()
                self.process.wait(timeout=2.0)
            except Exception:
                pass
            self.process = None

        self._is_opened = False
        self._stderr_error = None

    def start(self):
        """
        启动推流

        Start streaming. The actual FFmpeg process will be created on the next write() call.

        Examples:
            >>> sink = RTSPSink("rtsp://server/stream")
            >>> sink.start()  # 启动推流
            >>> # ... pipeline 运行中 ...
            >>> sink.stop()   # 停止推流
            >>> sink.start()  # 再次启动
        """
        if self._started:
            logger.debug(f"RTSPSink already started: {self._log_url}")
            return

        self._started = True
        # 重置重连状态，允许新的连接尝试
        self._reconnect_count = 0
        self._current_reconnect_interval = self.reconnect_interval
        logger.info(f"RTSPSink started: {self._log_url}")

    def stop(self):
        """
        停止推流并释放资源

        Stop streaming and release resources. Can be restarted with start().

        Examples:
            >>> sink.stop()   # 停止推流，释放 FFmpeg 进程
            >>> sink.start()  # 可以再次启动
        """
        if not self._started and self.process is None:
            logger.debug(f"RTSPSink already stopped: {self._log_url}")
            return

        self._started = False
        self._cleanup_process()
        logger.info(f"RTSPSink stopped: {self._log_url}")

    def _try_reconnect(self) -> bool:
        """
        尝试重连

        Try to reconnect

        Returns:
            True 如果允许重连（进入重连流程）/ True if reconnect is allowed
        """
        now = time.time()

        # 检查是否在冷却期
        time_since_last = now - self._last_reconnect_time
        if time_since_last < self._current_reconnect_interval:
            # 还在冷却期，静默丢弃帧
            return False

        # 检查重连次数限制
        if self.max_reconnect_attempts > 0 and self._reconnect_count >= self.max_reconnect_attempts:
            logger.error(
                f"RTSP reconnect failed: max attempts ({self.max_reconnect_attempts}) reached"
            )
            raise RuntimeError(
                f"RTSP reconnect failed: max attempts ({self.max_reconnect_attempts}) reached"
            )

        # 清理旧进程
        self._cleanup_process()

        # 更新重连状态
        self._reconnect_count += 1
        self._last_reconnect_time = now

        logger.info(
            f"RTSP reconnecting to {self._log_url} "
            f"(attempt {self._reconnect_count}, next retry in {self._current_reconnect_interval:.1f}s)"
        )

        # 指数退避
        self._current_reconnect_interval = min(
            self._current_reconnect_interval * self.reconnect_backoff,
            self.max_reconnect_interval,
        )

        return True

    def _on_connect_success(self):
        """
        连接成功后重置重连状态

        Reset reconnect state after successful connection
        """
        if self._reconnect_count > 0:
            logger.info(
                f"RTSP reconnected successfully to {self._log_url} "
                f"after {self._reconnect_count} attempt(s)"
            )
        self._reconnect_count = 0
        self._current_reconnect_interval = self.reconnect_interval

    def _get_stderr_output(self, timeout: float = 0.5) -> str:
        """
        安全地读取 FFmpeg stderr 输出

        Safely read FFmpeg stderr output

        Args:
            timeout: 读取超时（秒）/ Read timeout in seconds

        Returns:
            错误输出文本 / Error output text
        """
        if not self.process or not self.process.stderr:
            return ""

        try:
            # 尝试读取 stderr（可能阻塞）
            # 注意：这里简化实现，直接读取已有的 stderr 内容
            data = self.process.stderr.read()
            if data:
                return data.decode("utf-8", errors="ignore")
        except Exception as e:
            logger.debug(f"Failed to read stderr: {e}")

        return ""

    def _monitor_stderr(self):
        """
        后台线程：持续监控 FFmpeg stderr 输出

        Background thread: continuously monitor FFmpeg stderr output

        使用 select.select() 添加超时机制，避免 readline() 永久阻塞。
        当 FFmpeg 与 RTSP 服务器连接断开但进程未退出时，stderr 可能没有输出，
        此时 readline() 会无限期阻塞。通过 select 超时可以检测这种情况。
        """
        error_keywords = [
            "error",
            "failed",
            "refused",
            "not configured",
            "connection refused",
            "invalid",
            "rejected",
            "denied",
            "could not",
            "cannot",
            "unable to",
            "broken pipe",  # FFmpeg 输出管道断开错误
            "connection reset",
            "network is unreachable",
            "no route to host",
        ]

        # stderr 读取超时时间（秒）
        stderr_timeout = 10.0
        # 连续超时计数（用于检测长时间无输出）
        consecutive_timeouts = 0
        # 最大连续超时次数，超过后认为连接可能已断开
        max_consecutive_timeouts = 3  # 10秒 * 3 = 30秒

        try:
            while not self._stop_monitoring and self.process and self.process.poll() is None:
                try:
                    # 使用 select 检查 stderr 是否有数据可读，带超时
                    ready, _, _ = select.select([self.process.stderr], [], [], stderr_timeout)

                    if ready:
                        # 有数据可读，重置超时计数
                        consecutive_timeouts = 0

                        line = self.process.stderr.readline()
                        if not line:
                            break

                        text = line.decode("utf-8", errors="ignore").strip()
                        if text:
                            logger.debug(f"FFmpeg stderr: {text}")

                            # 检测错误关键词
                            text_lower = text.lower()
                            if any(keyword in text_lower for keyword in error_keywords):
                                self._stderr_error = text
                                logger.error(f"FFmpeg error detected in stderr: {text}")
                                break
                    else:
                        # select 超时，stderr 没有输出
                        consecutive_timeouts += 1

                        if consecutive_timeouts >= max_consecutive_timeouts:
                            # 长时间没有 stderr 输出，可能连接已断开
                            logger.warning(
                                f"FFmpeg stderr 长时间无输出 "
                                f"({consecutive_timeouts * stderr_timeout:.0f}秒)，"
                                f"RTSP 连接可能已断开"
                            )
                            self._stderr_error = "FFmpeg stderr timeout - connection may be lost"
                            break

                except Exception as e:
                    logger.debug(f"Error reading stderr line: {e}")
                    break

        except Exception as e:
            logger.debug(f"stderr monitoring thread error: {e}")
        finally:
            # 检查进程是否已退出，如果是且没有设置错误信息，则设置一个默认错误
            # 这样 write() 方法可以检测到进程已退出并触发重连
            if self.process and self.process.poll() is not None and not self._stderr_error:
                exit_code = self.process.returncode
                self._stderr_error = f"FFmpeg process exited unexpectedly (exit code: {exit_code})"
                logger.warning(f"FFmpeg process exited with code {exit_code}, will trigger reconnect")
            logger.debug("stderr monitoring thread stopped")

    def write(self, frame: Frame):
        """
        写入一帧视频到 RTSP 流

        Write a video frame to RTSP stream

        Args:
            frame: 视频帧 / Video frame
        """
        # 检查是否已启动推流
        if not self._started:
            return  # 未启动，静默丢弃帧

        # 自动检测 fps（仅第一帧）
        if not self._fps_initialized:
            self._init_fps_from_frame(frame)

        import ffmpeg

        # 第一次写入时初始化 FFmpeg 进程
        if self.process is None:
            # 重置错误状态，确保新进程可以正常创建
            self._stderr_error = None

            # 停止并等待旧的监控线程结束（防止竞争条件）
            self._stop_monitoring = True
            if self._stderr_thread and self._stderr_thread.is_alive():
                self._stderr_thread.join(timeout=1.0)

            height, width = frame.image.shape[:2]
            self._frame_size = (width, height)

            # 构建 FFmpeg 输入管道
            input_args = {
                "format": "rawvideo",
                "pix_fmt": "bgr24",
                "s": f"{width}x{height}",
                "r": self.fps,
            }

            stream = ffmpeg.input("pipe:", **input_args)

            # 构建输出参数
            output_args = {
                "vcodec": self.vcodec,
                "pix_fmt": self.pix_fmt,
                "preset": self.preset,
                "tune": self.tune,
                "g": self.gop,  # GOP size
                "b:v": self.bitrate,
                "maxrate": self.maxrate,
                "bufsize": self.bufsize,
                "format": "rtsp",
                "rtsp_transport": self.transport,
            }

            stream = ffmpeg.output(stream, self.rtsp_url, **output_args)

            # 覆盖输出（如果已存在）
            stream = stream.global_args("-re")  # 实时流模式

            # 启动 FFmpeg 进程
            try:
                cmd = stream.compile()

                self.process = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                )

                # 启动 stderr 监控线程
                self._stop_monitoring = False
                self._stderr_error = None
                self._stderr_thread = threading.Thread(
                    target=self._monitor_stderr, daemon=True, name=f"RTSPSink-stderr-{id(self)}"
                )
                self._stderr_thread.start()

                # 等待连接建立并检查进程状态和 stderr 错误
                # 总等待时间 3 秒，每 0.5 秒检查一次（共 6 次）
                for i in range(6):
                    time.sleep(0.5)

                    # 优先检查 stderr 是否检测到错误
                    if self._stderr_error:
                        logger.error(
                            f"RTSP connection error detected after {(i+1)*0.5:.1f}s: {self._log_url}\n"
                            f"FFmpeg stderr: {self._stderr_error}"
                        )

                        # 停止监控并清理进程
                        self._stop_monitoring = True
                        if self.process:
                            self.process.kill()
                            self.process = None
                        self._is_opened = False

                        raise RuntimeError(
                            f"RTSP server rejected connection: {self.rtsp_url}\n"
                            f"Error: {self._stderr_error}\n"
                            f"Please check:\n"
                            f"  1. RTSP path is configured on the server (e.g., use 'device/*' not 'device1/*')\n"
                            f"  2. RTSP server is accepting connections\n"
                            f"  3. Stream format is compatible with server"
                        )

                    # 检查进程是否已退出（连接失败）
                    if self.process.poll() is not None:
                        # 进程已退出，连接失败
                        error_msg = self._stderr_error or "Process terminated unexpectedly"

                        logger.error(
                            f"RTSP process died after {(i+1)*0.5:.1f}s: {self._log_url}\n"
                            f"Error: {error_msg}"
                        )

                        # 停止监控并清理进程
                        self._stop_monitoring = True
                        self.process = None
                        self._is_opened = False

                        raise RuntimeError(
                            f"Failed to connect to RTSP server: {self.rtsp_url}\n"
                            f"Error: {error_msg}"
                        )

                self._is_opened = True
                self._on_connect_success()
                logger.info(
                    f"FFmpeg RTSP streaming started: {self._log_url}, "
                    f"{width}x{height}, {self.fps:.2f} fps"
                )
            except ffmpeg.Error as e:
                error_msg = e.stderr.decode() if e.stderr else str(e)
                logger.error(f"Failed to start FFmpeg RTSP stream: {error_msg}")
                raise RuntimeError(f"Failed to start FFmpeg RTSP process: {error_msg}")

        # 优先检查 stderr 是否检测到错误
        if self._stderr_error:
            error_msg = self._stderr_error
            logger.error(f"RTSP streaming error from stderr: {error_msg}")

            # 检查是否可以重连
            if self.auto_reconnect and self._is_recoverable_error(error_msg):
                if self._try_reconnect():
                    return  # 重连流程已启动，丢弃当前帧
            else:
                # 不可恢复或不允许重连
                self._cleanup_process()
                raise RuntimeError(
                    f"RTSP streaming error: {error_msg}\n"
                    f"The stream encountered an error during operation."
                )

        # 检查进程状态（每次写入前）
        if self.process.poll() is not None:
            # 进程已退出
            error_msg = self._stderr_error or "Process terminated unexpectedly"
            logger.error(f"FFmpeg RTSP process died unexpectedly: {error_msg}")

            # 检查是否可以重连
            if self.auto_reconnect and self._is_recoverable_error(error_msg):
                if self._try_reconnect():
                    return  # 重连流程已启动，丢弃当前帧
            else:
                # 不可恢复或不允许重连
                self._cleanup_process()
                raise RuntimeError(
                    f"RTSP streaming process terminated unexpectedly\n" f"Error: {error_msg}"
                )

        # 写入帧数据到 FFmpeg
        try:
            # 确保帧大小一致
            if frame.image.shape[:2] != (self._frame_size[1], self._frame_size[0]):
                import cv2

                frame.image = cv2.resize(
                    frame.image,
                    self._frame_size,
                    interpolation=cv2.INTER_LINEAR,
                )
                logger.debug(f"Frame resized to {self._frame_size} to match stream dimensions")

            self.process.stdin.write(frame.image.tobytes())

        except BrokenPipeError:
            # 管道断开，读取错误信息
            error_output = self._get_stderr_output(timeout=0.1)
            error_msg = error_output if error_output else "Broken pipe"
            logger.error(f"FFmpeg RTSP process pipe broken: {error_msg}")

            # 检查是否可以重连
            if self.auto_reconnect and self._is_recoverable_error(error_msg):
                if self._try_reconnect():
                    return  # 重连流程已启动，丢弃当前帧
            else:
                self._cleanup_process()
                raise RuntimeError(f"RTSP streaming pipe broken\nError: {error_msg}")

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Failed to write frame to RTSP stream: {error_msg}")

            # 检查是否可以重连
            if self.auto_reconnect and self._is_recoverable_error(error_msg):
                if self._try_reconnect():
                    return  # 重连流程已启动，丢弃当前帧
            else:
                self._cleanup_process()
                raise

    def is_active(self) -> bool:
        """
        检查 RTSP 推流进程是否激活

        Check if RTSP streaming process is active

        Returns:
            True 如果进程已启动或允许初始化 / True if process is started or allows initialization
        """
        if self.process is None:
            return True  # 允许第一帧初始化进程

        # 检查进程是否还在运行
        return self.process.poll() is None

    def close(self):
        """关闭 RTSP 推流进程 / Close RTSP streaming process"""
        self._started = False

        # 停止 stderr 监控线程
        self._stop_monitoring = True
        if self._stderr_thread and self._stderr_thread.is_alive():
            self._stderr_thread.join(timeout=1.0)

        if self.process is not None:
            try:
                # 关闭标准输入，通知 FFmpeg 没有更多数据
                self.process.stdin.close()

                # 等待进程结束（带超时保护）
                try:
                    self.process.wait(timeout=5.0)
                except subprocess.TimeoutExpired:
                    logger.warning("FFmpeg process did not exit gracefully, killing...")
                    self.process.kill()
                    self.process.wait(timeout=2.0)

                # 读取 stderr 输出（进程已结束，不会阻塞）
                stderr_output = self.process.stderr.read()

                # 检查返回码
                # 0 = 正常退出, 255 = 被信号中断 (如 Ctrl+C)
                returncode = self.process.returncode
                if returncode == 0 or returncode == 255 or returncode == -2:
                    # 正常关闭或被中断
                    logger.info(f"RTSP stream closed: {self._log_url}")
                else:
                    error_msg = stderr_output.decode().strip() if stderr_output else ""
                    if error_msg:
                        logger.warning(f"FFmpeg exited with code {returncode}: {error_msg}")
                    else:
                        logger.warning(f"FFmpeg exited with code {returncode}")

                self._is_opened = False
                self.process = None

            except Exception as e:
                logger.error(f"Error closing FFmpeg RTSP process: {e}")
                if self.process:
                    try:
                        self.process.kill()
                        self.process.wait(timeout=2.0)
                    except Exception:
                        pass
                    self.process = None
                self._is_opened = False

    def get_stats(self) -> dict:
        """
        获取推流统计信息

        Get streaming statistics

        Returns:
            统计信息字典 / Statistics dictionary
        """
        stats = super().get_stats()
        stats.update(
            {
                "rtsp_url": self._log_url,
                "fps": self.fps,
                "frame_size": self._frame_size,
                "is_streaming": self._is_opened,
                "started": self._started,
                "auto_start": self.auto_start,
                "codec": self.vcodec,
                "preset": self.preset,
                "bitrate": self.bitrate,
                "auto_reconnect": self.auto_reconnect,
                "reconnect_count": self._reconnect_count,
                "current_reconnect_interval": self._current_reconnect_interval,
            }
        )
        return stats
