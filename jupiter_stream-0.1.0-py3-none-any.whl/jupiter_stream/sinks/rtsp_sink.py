"""RTSP streaming sink for pushing frames to MediaMTX or other RTSP servers."""

from __future__ import annotations

import logging
import subprocess
import threading
import time
from typing import Optional

from ..core import Frame, Sink
from ..core.pipeline.registry import register_sink

logger = logging.getLogger(__name__)


@register_sink("RTSPSink")
class RTSPSink(Sink):
    """
    RTSP 推流 Sink - 将视频帧推送到 RTSP 服务器（如 MediaMTX）

    使用 FFmpeg 将处理后的视频流以 H.264 编码推送到 RTSP 服务器，
    支持低延迟配置和多路并发推流。

    RTSP streaming sink for pushing processed video frames to RTSP servers.

    Uses FFmpeg to push H.264 encoded video stream to RTSP servers (like MediaMTX),
    with support for low-latency configuration and concurrent multi-stream pushing.

    Examples:
        >>> # 基本用法 - 推流到 MediaMTX
        >>> sink = RTSPSink("rtsp://39.108.184.91:8554/test", fps=30)

        >>> # 低延迟配置
        >>> sink = RTSPSink(
        ...     "rtsp://39.108.184.91:8554/stream1",
        ...     fps=30,
        ...     preset="ultrafast",
        ...     bitrate="2M"
        ... )

        >>> # 自定义 GOP 和传输协议
        >>> sink = RTSPSink(
        ...     "rtsp://39.108.184.91:8554/device/cam001",
        ...     fps=30,
        ...     gop=60,
        ...     transport="udp"
        ... )

        >>> # 在 Pipeline 中使用
        >>> from jupiter_stream import Pipeline, VideoSource
        >>> pipeline = (
        ...     Pipeline(fps=30)
        ...     .add_source(VideoSource("input.mp4", loop=True))
        ...     .add_sink(RTSPSink("rtsp://39.108.184.91:8554/test"))
        ... )
        >>> pipeline.run()
    """

    def __init__(
        self,
        rtsp_url: str,
        fps: float = 30.0,
        # 视频编码参数
        vcodec: str = "libx264",
        preset: str = "ultrafast",
        tune: str = "zerolatency",
        pix_fmt: str = "yuv420p",
        # 码率控制
        bitrate: str = "2M",
        maxrate: Optional[str] = None,
        bufsize: Optional[str] = None,
        # GOP 控制
        gop: Optional[int] = None,
        # RTSP 参数
        transport: str = "tcp",
        # 其他
        loglevel: str = "error",
        enabled: bool = True,
    ):
        """
        初始化 RTSPSink

        Args:
            rtsp_url: RTSP 推流地址 / RTSP streaming URL
                     例如: rtsp://39.108.184.91:8554/test
            fps: 帧率 / Frame rate
            vcodec: 视频编码器（默认: libx264）/ Video codec (default: libx264)
            preset: 编码速度预设 (ultrafast/fast/medium/slow, 默认: ultrafast) /
                    Encoding speed preset (default: ultrafast for low latency)
            tune: 编码调优（默认: zerolatency，用于低延迟流媒体）/
                  Encoding tune (default: zerolatency for low-latency streaming)
            pix_fmt: 像素格式（默认: yuv420p，最广泛兼容）/ Pixel format
            bitrate: 视频目标码率（默认: "2M"）/ Target video bitrate (default: "2M")
            maxrate: 最大码率（默认: None，使用 bitrate 值）/ Maximum bitrate
            bufsize: VBV 缓冲区大小（默认: None，使用 bitrate*2）/ VBV buffer size
            gop: GOP 大小，关键帧间隔（默认: fps*2）/ GOP size, keyframe interval
            transport: RTSP 传输协议 (tcp/udp，默认: tcp) /
                      RTSP transport protocol (tcp/udp, default: tcp)
            loglevel: FFmpeg 日志级别 / FFmpeg log level
            enabled: 是否启用 / Whether to enable

        Raises:
            ImportError: 如果 ffmpeg-python 未安装 / If ffmpeg-python is not installed
            FileNotFoundError: 如果系统未安装 ffmpeg / If ffmpeg is not installed on system
            ValueError: 如果 rtsp_url 格式无效 / If rtsp_url format is invalid
        """
        super().__init__(enabled)

        try:
            import ffmpeg  # noqa: F401
        except ImportError:
            raise ImportError(
                "ffmpeg-python is required for RTSPSink. " "Install with: pip install ffmpeg-python"
            )

        # 检查 ffmpeg 是否安装
        try:
            subprocess.run(
                ["ffmpeg", "-version"],
                capture_output=True,
                check=True,
            )
        except FileNotFoundError:
            raise FileNotFoundError(
                "ffmpeg is not installed on your system. "
                "Please install ffmpeg:\n"
                "  macOS: brew install ffmpeg\n"
                "  Ubuntu/Debian: sudo apt-get install ffmpeg\n"
                "  Windows: Download from https://ffmpeg.org/download.html"
            )
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode("utf-8", errors="ignore") if e.stderr else ""
            raise RuntimeError(
                f"ffmpeg check failed (exit code {e.returncode}): {stderr}\n"
                "Please ensure ffmpeg is properly installed and functional."
            )

        # 验证 RTSP URL 格式
        if not rtsp_url.startswith("rtsp://"):
            raise ValueError(f"Invalid RTSP URL: {rtsp_url}. " "URL must start with 'rtsp://'")

        self.rtsp_url = rtsp_url
        self.fps = fps
        self.vcodec = vcodec
        self.preset = preset
        self.tune = tune
        self.pix_fmt = pix_fmt
        self.bitrate = bitrate
        self.maxrate = maxrate or bitrate  # 如果未指定，使用 bitrate
        self.bufsize = bufsize or f"{int(bitrate[:-1]) * 2}M"  # 默认 bitrate*2
        self.gop = gop or int(fps * 2)  # 默认 2 秒一个关键帧
        self.transport = transport
        self.loglevel = loglevel

        # 运行时状态
        self.process = None
        self._frame_size = None
        self._is_opened = False
        self._first_frame_written = False  # 标记是否已写入首帧

        # stderr 监控
        self._stderr_thread = None
        self._stderr_error = None  # 存储检测到的错误信息
        self._stop_monitoring = False

        # 提取 URL 中的路径用于日志（不包含敏感信息）
        self._log_url = self._sanitize_url(rtsp_url)

        logger.info(
            f"RTSPSink initialized: {self._log_url}, "
            f"codec={self.vcodec}, preset={self.preset}, bitrate={self.bitrate}"
        )

    def _sanitize_url(self, url: str) -> str:
        """
        隐藏 URL 中的敏感信息（用户名/密码）

        Hide sensitive information (username/password) in URL

        Args:
            url: 原始 URL / Original URL

        Returns:
            清理后的 URL / Sanitized URL
        """
        from urllib.parse import urlparse

        parsed = urlparse(url)
        if parsed.username or parsed.password:
            # 隐藏认证信息
            netloc = f"***:***@{parsed.hostname}"
            if parsed.port:
                netloc += f":{parsed.port}"
            return f"{parsed.scheme}://{netloc}{parsed.path}"
        return url

    def _get_stderr_output(self, timeout: float = 0.5) -> str:
        """
        安全地读取 FFmpeg stderr 输出

        Safely read FFmpeg stderr output

        Args:
            timeout: 读取超时（秒）/ Read timeout in seconds

        Returns:
            错误输出文本 / Error output text
        """
        if not self.process or not self.process.stderr:
            return ""

        try:
            # 尝试读取 stderr（可能阻塞）
            # 注意：这里简化实现，直接读取已有的 stderr 内容
            data = self.process.stderr.read()
            if data:
                return data.decode("utf-8", errors="ignore")
        except Exception as e:
            logger.debug(f"Failed to read stderr: {e}")

        return ""

    def _monitor_stderr(self):
        """
        后台线程：持续监控 FFmpeg stderr 输出

        Background thread: continuously monitor FFmpeg stderr output
        """
        error_keywords = [
            "error",
            "failed",
            "refused",
            "not configured",
            "connection refused",
            "invalid",
            "rejected",
            "denied",
            "could not",
            "cannot",
            "unable to",
        ]

        try:
            while not self._stop_monitoring and self.process and self.process.poll() is None:
                try:
                    # 读取一行 stderr 输出
                    line = self.process.stderr.readline()
                    if not line:
                        break

                    text = line.decode("utf-8", errors="ignore").strip()
                    if text:
                        logger.debug(f"FFmpeg stderr: {text}")

                        # 检测错误关键词
                        text_lower = text.lower()
                        if any(keyword in text_lower for keyword in error_keywords):
                            self._stderr_error = text
                            logger.error(f"FFmpeg error detected in stderr: {text}")
                            break

                except Exception as e:
                    logger.debug(f"Error reading stderr line: {e}")
                    break

        except Exception as e:
            logger.debug(f"stderr monitoring thread error: {e}")
        finally:
            logger.debug("stderr monitoring thread stopped")

    def write(self, frame: Frame):
        """
        写入一帧视频到 RTSP 流

        Write a video frame to RTSP stream

        Args:
            frame: 视频帧 / Video frame
        """
        import ffmpeg

        # 第一次写入时初始化 FFmpeg 进程
        if self.process is None:
            # 重置错误状态，确保新进程可以正常创建
            self._stderr_error = None

            # 停止并等待旧的监控线程结束（防止竞争条件）
            self._stop_monitoring = True
            if self._stderr_thread and self._stderr_thread.is_alive():
                self._stderr_thread.join(timeout=1.0)

            height, width = frame.image.shape[:2]
            self._frame_size = (width, height)

            # 构建 FFmpeg 输入管道
            input_args = {
                "format": "rawvideo",
                "pix_fmt": "bgr24",
                "s": f"{width}x{height}",
                "r": self.fps,
            }

            stream = ffmpeg.input("pipe:", **input_args)

            # 构建输出参数
            output_args = {
                "vcodec": self.vcodec,
                "pix_fmt": self.pix_fmt,
                "preset": self.preset,
                "tune": self.tune,
                "g": self.gop,  # GOP size
                "b:v": self.bitrate,
                "maxrate": self.maxrate,
                "bufsize": self.bufsize,
                "format": "rtsp",
                "rtsp_transport": self.transport,
            }

            stream = ffmpeg.output(stream, self.rtsp_url, **output_args)

            # 覆盖输出（如果已存在）
            stream = stream.global_args("-re")  # 实时流模式

            # 启动 FFmpeg 进程
            try:
                self.process = stream.run_async(
                    pipe_stdin=True,
                    pipe_stderr=True,
                    quiet=(self.loglevel == "quiet"),
                )

                # 启动 stderr 监控线程
                self._stop_monitoring = False
                self._stderr_error = None
                self._stderr_thread = threading.Thread(
                    target=self._monitor_stderr, daemon=True, name=f"RTSPSink-stderr-{id(self)}"
                )
                self._stderr_thread.start()

                # 等待连接建立并检查进程状态和 stderr 错误
                # 总等待时间 3 秒，每 0.5 秒检查一次（共 6 次）
                for i in range(6):
                    time.sleep(0.5)

                    # 优先检查 stderr 是否检测到错误
                    if self._stderr_error:
                        logger.error(
                            f"RTSP connection error detected after {(i+1)*0.5:.1f}s: {self._log_url}\n"
                            f"FFmpeg stderr: {self._stderr_error}"
                        )

                        # 停止监控并清理进程
                        self._stop_monitoring = True
                        if self.process:
                            self.process.kill()
                            self.process = None
                        self._is_opened = False

                        raise RuntimeError(
                            f"RTSP server rejected connection: {self.rtsp_url}\n"
                            f"Error: {self._stderr_error}\n"
                            f"Please check:\n"
                            f"  1. RTSP path is configured on the server (e.g., use 'device/*' not 'device1/*')\n"
                            f"  2. RTSP server is accepting connections\n"
                            f"  3. Stream format is compatible with server"
                        )

                    # 检查进程是否已退出（连接失败）
                    if self.process.poll() is not None:
                        # 进程已退出，连接失败
                        error_msg = self._stderr_error or "Process terminated unexpectedly"

                        logger.error(
                            f"RTSP process died after {(i+1)*0.5:.1f}s: {self._log_url}\n"
                            f"Error: {error_msg}"
                        )

                        # 停止监控并清理进程
                        self._stop_monitoring = True
                        self.process = None
                        self._is_opened = False

                        raise RuntimeError(
                            f"Failed to connect to RTSP server: {self.rtsp_url}\n"
                            f"Error: {error_msg}"
                        )

                self._is_opened = True
                logger.info(
                    f"FFmpeg RTSP streaming started: {self._log_url}, "
                    f"{width}x{height}, {self.fps:.2f} fps"
                )
            except ffmpeg.Error as e:
                error_msg = e.stderr.decode() if e.stderr else str(e)
                logger.error(f"Failed to start FFmpeg RTSP stream: {error_msg}")
                raise RuntimeError(f"Failed to start FFmpeg RTSP process: {error_msg}")

        # 优先检查 stderr 是否检测到错误
        if self._stderr_error:
            logger.error(f"RTSP streaming error from stderr: {self._stderr_error}")

            # 停止监控并清理进程
            self._stop_monitoring = True
            if self.process:
                self.process.kill()
                self.process = None
            self._is_opened = False

            raise RuntimeError(
                f"RTSP streaming error: {self._stderr_error}\n"
                f"The stream encountered an error during operation."
            )

        # 检查进程状态（每次写入前）
        if self.process.poll() is not None:
            # 进程已退出
            error_msg = self._stderr_error or "Process terminated unexpectedly"

            logger.error(f"FFmpeg RTSP process died unexpectedly\n" f"Error: {error_msg}")

            # 停止监控并清理状态
            self._stop_monitoring = True
            self.process = None
            self._is_opened = False

            raise RuntimeError(
                f"RTSP streaming process terminated unexpectedly\n" f"Error: {error_msg}"
            )

        # 写入帧数据到 FFmpeg
        try:
            # 确保帧大小一致
            if frame.image.shape[:2] != (self._frame_size[1], self._frame_size[0]):
                import cv2

                frame.image = cv2.resize(
                    frame.image,
                    self._frame_size,
                    interpolation=cv2.INTER_LINEAR,
                )
                logger.debug(f"Frame resized to {self._frame_size} to match stream dimensions")

            self.process.stdin.write(frame.image.tobytes())

        except BrokenPipeError:
            # 管道断开，读取错误信息
            error_output = self._get_stderr_output(timeout=0.1)
            error_msg = error_output if error_output else "Broken pipe"

            logger.error(f"FFmpeg RTSP process pipe broken\nError: {error_msg}")

            # 完整清理：停止监控线程 + 终止进程
            self._stop_monitoring = True
            if self.process:
                try:
                    self.process.kill()
                    self.process.wait(timeout=2.0)
                except Exception:
                    pass
                self.process = None
            self._is_opened = False

            raise RuntimeError(f"RTSP streaming pipe broken\nError: {error_msg}")
        except Exception as e:
            logger.error(f"Failed to write frame to RTSP stream: {e}")
            # 清理资源
            self._stop_monitoring = True
            if self.process:
                try:
                    self.process.kill()
                    self.process.wait(timeout=2.0)
                except Exception:
                    pass
                self.process = None
            self._is_opened = False
            raise

    def is_active(self) -> bool:
        """
        检查 RTSP 推流进程是否激活

        Check if RTSP streaming process is active

        Returns:
            True 如果进程已启动或允许初始化 / True if process is started or allows initialization
        """
        if self.process is None:
            return True  # 允许第一帧初始化进程

        # 检查进程是否还在运行
        return self.process.poll() is None

    def close(self):
        """关闭 RTSP 推流进程 / Close RTSP streaming process"""
        # 停止 stderr 监控线程
        self._stop_monitoring = True
        if self._stderr_thread and self._stderr_thread.is_alive():
            self._stderr_thread.join(timeout=1.0)

        if self.process is not None:
            try:
                # 关闭标准输入，通知 FFmpeg 没有更多数据
                self.process.stdin.close()

                # 等待进程结束（带超时保护）
                try:
                    self.process.wait(timeout=5.0)
                except subprocess.TimeoutExpired:
                    logger.warning("FFmpeg process did not exit gracefully, killing...")
                    self.process.kill()
                    self.process.wait(timeout=2.0)

                # 读取 stderr 输出（进程已结束，不会阻塞）
                stderr_output = self.process.stderr.read()

                # 检查返回码
                # 0 = 正常退出, 255 = 被信号中断 (如 Ctrl+C)
                returncode = self.process.returncode
                if returncode == 0 or returncode == 255 or returncode == -2:
                    # 正常关闭或被中断
                    logger.info(f"RTSP stream closed: {self._log_url}")
                else:
                    error_msg = stderr_output.decode().strip() if stderr_output else ""
                    if error_msg:
                        logger.warning(f"FFmpeg exited with code {returncode}: {error_msg}")
                    else:
                        logger.warning(f"FFmpeg exited with code {returncode}")

                self._is_opened = False
                self.process = None

            except Exception as e:
                logger.error(f"Error closing FFmpeg RTSP process: {e}")
                if self.process:
                    try:
                        self.process.kill()
                        self.process.wait(timeout=2.0)
                    except Exception:
                        pass
                    self.process = None
                self._is_opened = False

    def get_stats(self) -> dict:
        """
        获取推流统计信息

        Get streaming statistics

        Returns:
            统计信息字典 / Statistics dictionary
        """
        stats = super().get_stats()
        stats.update(
            {
                "rtsp_url": self._log_url,
                "fps": self.fps,
                "frame_size": self._frame_size,
                "is_streaming": self._is_opened,
                "codec": self.vcodec,
                "preset": self.preset,
                "bitrate": self.bitrate,
            }
        )
        return stats
