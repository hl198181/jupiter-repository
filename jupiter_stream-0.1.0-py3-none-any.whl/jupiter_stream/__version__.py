"""Version information for jupiter-stream."""

__version__ = "0.1.0"
__author__ = "Jupiter Team"
__license__ = "MIT"
