"""Time utilities for parsing various time formats."""

from __future__ import annotations

import datetime
import re
from typing import Optional, Tuple, Union


def parse_time(time_str: Union[str, int, float, datetime.time, datetime.datetime]) -> float:
    """
    Parse time string in various formats to seconds.

    Supported formats:
    - Seconds (float/int): 10, 10.5, 65.2
    - MM:SS: "01:30", "1:30"
    - HH:MM:SS: "1:30:45", "01:30:45"
    - HH:MM:SS.mmm: "1:30:45.500", "0:01:30.250"

    Args:
        time_str: Time in various formats

    Returns:
        Time in seconds as float

    Raises:
        ValueError: If time format is invalid

    Examples:
        >>> parse_time(10.5)
        10.5
        >>> parse_time("1:30")
        90.0
        >>> parse_time("01:30:45")
        5445.0
        >>> parse_time("1:30:45.500")
        5445.5
    """
    # 处理 datetime.time 对象（YAML 解析可能产生）
    if isinstance(time_str, datetime.time):
        # 转换为总秒数
        return (
            time_str.hour * 3600
            + time_str.minute * 60
            + time_str.second
            + time_str.microsecond / 1_000_000
        )

    # 处理 datetime.datetime 对象
    if isinstance(time_str, datetime.datetime):
        # 使用时间部分，忽略日期
        return (
            time_str.hour * 3600
            + time_str.minute * 60
            + time_str.second
            + time_str.microsecond / 1_000_000
        )

    # 如果已经是数字，直接返回
    if isinstance(time_str, (int, float)):
        if time_str < 0:
            raise ValueError(f"Time cannot be negative: {time_str}")
        return float(time_str)

    # 确保是字符串
    if not isinstance(time_str, str):
        raise ValueError(f"Invalid time format: {time_str}")

    time_str = time_str.strip()

    # 尝试解析为纯数字（秒）
    try:
        seconds = float(time_str)
        if seconds < 0:
            raise ValueError(f"Time cannot be negative: {time_str}")
        return seconds
    except ValueError:
        pass

    # 匹配 HH:MM:SS.mmm 或 HH:MM:SS 或 MM:SS 格式
    # 支持可选的小时和毫秒部分
    pattern = r"^(?:(?:(\d+):)?(\d{1,2}):)?(\d{1,2})(?:\.(\d+))?$"
    match = re.match(pattern, time_str)

    if not match:
        raise ValueError(
            f"Invalid time format: '{time_str}'. "
            f"Expected formats: seconds (10.5), MM:SS (1:30), "
            f"HH:MM:SS (1:30:45), or HH:MM:SS.mmm (1:30:45.500)"
        )

    groups = match.groups()

    # 解析各个部分
    hours = int(groups[0]) if groups[0] else 0
    minutes = int(groups[1]) if groups[1] else 0
    seconds = int(groups[2]) if groups[2] else 0
    milliseconds = float(f"0.{groups[3]}") if groups[3] else 0

    # 验证分钟和秒的范围
    if minutes >= 60:
        raise ValueError(f"Minutes must be less than 60: {minutes} in '{time_str}'")
    if seconds >= 60:
        raise ValueError(f"Seconds must be less than 60: {seconds} in '{time_str}'")

    # 计算总秒数
    total_seconds = hours * 3600 + minutes * 60 + seconds + milliseconds

    return total_seconds


def format_time(seconds: float, format_type: str = "auto") -> str:
    """
    Format seconds to time string.

    Args:
        seconds: Time in seconds
        format_type: Format type ("auto", "hms", "ms", "seconds")
            - "auto": Automatically choose best format
            - "hms": Always use HH:MM:SS.mmm format
            - "ms": Use MM:SS.mmm format
            - "seconds": Use seconds with decimal

    Returns:
        Formatted time string

    Examples:
        >>> format_time(90.5)
        "1:30.500"
        >>> format_time(3665.25, "hms")
        "1:01:05.250"
        >>> format_time(45.5, "seconds")
        "45.500s"
    """
    if seconds < 0:
        raise ValueError(f"Time cannot be negative: {seconds}")

    if format_type == "seconds":
        return f"{seconds:.3f}s"

    # 计算时分秒
    hours = int(seconds // 3600)
    remaining = seconds % 3600
    minutes = int(remaining // 60)
    secs = remaining % 60

    # 分离整秒和毫秒
    whole_secs = int(secs)
    milliseconds = int((secs - whole_secs) * 1000)

    if format_type == "hms" or (format_type == "auto" and hours > 0):
        # HH:MM:SS.mmm 格式
        if milliseconds > 0:
            return f"{hours}:{minutes:02d}:{whole_secs:02d}.{milliseconds:03d}"
        else:
            return f"{hours}:{minutes:02d}:{whole_secs:02d}"
    elif format_type == "ms" or format_type == "auto":
        # MM:SS.mmm 格式
        total_minutes = hours * 60 + minutes
        if milliseconds > 0:
            return f"{total_minutes}:{whole_secs:02d}.{milliseconds:03d}"
        else:
            return f"{total_minutes}:{whole_secs:02d}"
    else:
        raise ValueError(f"Invalid format_type: {format_type}")


def parse_time_range(
    start: Union[str, int, float, datetime.time, Optional[datetime.datetime]],
    end: Union[str, int, float, datetime.time, Optional[datetime.datetime]],
) -> Tuple[float, float]:
    """
    Parse time range with validation.

    Args:
        start: Start time (various formats) or None
        end: End time (various formats) or None

    Returns:
        Tuple of (start_seconds, end_seconds), None if not specified

    Raises:
        ValueError: If end time is before start time
    """
    start_seconds = parse_time(start) if start is not None else None
    end_seconds = parse_time(end) if end is not None else None

    # 验证范围
    if start_seconds is not None and end_seconds is not None:
        if end_seconds <= start_seconds:
            raise ValueError(
                f"End time ({format_time(end_seconds)}) must be after "
                f"start time ({format_time(start_seconds)})"
            )

    return start_seconds, end_seconds
