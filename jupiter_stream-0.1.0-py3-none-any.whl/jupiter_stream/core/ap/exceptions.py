"""AP 模块异常

AP module exceptions.

提供完整的异常层次结构：
- APError: 基础异常
- APConfigError: 配置错误
- HostapdError: hostapd 相关错误
- DnsmasqError: dnsmasq 相关错误
- PortalError: Portal 服务器错误
- InterfaceError: 网络接口错误

Provides complete exception hierarchy for AP module.
"""

from __future__ import annotations


class APError(Exception):
    """AP 模块基础异常

    Base exception for AP module.

    所有 AP 模块的异常都继承自此类。
    """

    pass


class APConfigError(APError):
    """配置错误

    Configuration error.

    当配置文件格式错误、缺少必需字段或参数无效时抛出。
    """

    pass


class HostapdError(APError):
    """hostapd 错误

    hostapd error.

    当 hostapd 启动失败、进程异常退出时抛出。
    可能的原因：
    - hostapd 未安装
    - 配置文件错误
    - 接口不支持 AP 模式
    - 权限不足
    """

    pass


class DnsmasqError(APError):
    """dnsmasq 错误

    dnsmasq error.

    当 dnsmasq 启动失败、进程异常退出时抛出。
    可能的原因：
    - dnsmasq 未安装
    - 配置文件错误
    - 端口被占用
    - 权限不足
    """

    pass


class PortalError(APError):
    """Portal 服务器错误

    Portal server error.

    当 Portal 服务器启动失败、运行异常时抛出。
    可能的原因：
    - Flask 未安装
    - 端口被占用
    - 路由注册错误
    """

    pass


class InterfaceError(APError):
    """网络接口错误

    Network interface error.

    当网络接口配置失败时抛出。
    可能的原因：
    - 接口不存在
    - IP 地址配置失败
    - 接口状态切换失败
    - 权限不足
    """

    pass
