"""Portal 服务器

Portal server with route registration support.

提供 Portal Web 服务器功能：
- Flask HTTP 服务器
- 动态路由注册
- Captive Portal HTTP 重定向

Provides Portal server with dynamic route registration.
"""

from __future__ import annotations

import logging
import subprocess
import threading
from typing import Callable, Dict, List, Optional

from .config import PortalConfig
from .exceptions import PortalError

logger = logging.getLogger(__name__)


class PortalServer:
    """Portal 服务器

    Portal server.

    提供 Web 配置门户，支持动态路由注册。
    需要 Flask 依赖。
    """

    def __init__(self, config: PortalConfig):
        """初始化 Portal 服务器

        Initialize Portal server.

        Args:
            config: Portal 配置
        """
        self._config = config
        self._app: Optional[object] = None  # Flask app
        self._routes: Dict[str, dict] = {}
        self._running = False
        self._server_thread: Optional[threading.Thread] = None

    def register_route(self, path: str, handler: Callable, methods: List[str] = None):
        """注册页面路由

        Register page route.

        Args:
            path: URL 路径（如 '/', '/wifi'）
            handler: 路由处理函数 (request) -> Response
            methods: HTTP 方法列表，默认 ['GET']
        """
        if methods is None:
            methods = ["GET"]

        self._routes[path] = {"handler": handler, "methods": methods}
        logger.debug(f"Route registered: {path} {methods}")

    def start(self, interface: str = "wlan0") -> None:
        """启动服务器

        Start server.

        Args:
            interface: 网络接口名称（用于 iptables 重定向）

        Raises:
            PortalError: 启动失败
        """
        if self._running:
            logger.warning("Portal server is already running")
            return

        try:
            # 导入 Flask
            try:
                from flask import Flask
            except ImportError:
                raise PortalError(
                    "Flask is required for Portal server. " "Install with: pip install flask"
                )

            # 创建 Flask app
            self._app = Flask(__name__)

            # 注册 Captive Portal 检测路由（必须在用户路由之前）
            self._register_captive_detection_routes()

            # 注册所有路由
            for path, route_info in self._routes.items():
                self._app.add_url_rule(
                    path,
                    view_func=route_info["handler"],
                    methods=route_info["methods"],
                )

            # 启动服务器线程
            self._server_thread = threading.Thread(target=self._run_server, daemon=True)
            self._server_thread.start()

            # 设置 Captive Portal 重定向
            if self._config.enable_captive_redirect:
                self._setup_captive_redirect(interface)

            self._running = True
            logger.info(f"Portal server started on port {self._config.port}")

        except Exception as e:
            raise PortalError(f"Failed to start Portal server: {e}") from e

    def stop(self, interface: str = "wlan0") -> None:
        """停止服务器

        Stop server.

        Args:
            interface: 网络接口名称（用于清理 iptables）
        """
        if not self._running:
            logger.debug("Portal server is not running")
            return

        try:
            logger.info("Stopping Portal server...")

            # 移除 Captive Portal 重定向
            if self._config.enable_captive_redirect:
                self._remove_captive_redirect(interface)

            self._running = False
            # Flask 会在 daemon 线程中自动清理

            logger.info("Portal server stopped")

        except Exception as e:
            logger.error(f"Failed to stop Portal server: {e}")

    def _run_server(self):
        """运行 Flask 服务器"""
        try:
            self._app.run(host="0.0.0.0", port=self._config.port, debug=False)
        except Exception as e:
            logger.error(f"Portal server error: {e}")

    def _register_captive_detection_routes(self):
        """注册 Captive Portal 检测路由

        Register Captive Portal detection routes.

        各操作系统在连接 WiFi 后会自动请求特定 URL 来检测是否有 Captive Portal：
        - iOS/macOS: /hotspot-detect.html, /library/test/success.html
        - Android: /generate_204, /gen_204
        - Windows: /connecttest.txt, /ncsi.txt

        这些路由返回重定向到主页，触发操作系统弹出 Portal 页面。
        """
        from flask import redirect

        # iOS/macOS Captive Portal 检测
        @self._app.route("/hotspot-detect.html")
        @self._app.route("/library/test/success.html")
        def apple_captive_portal():
            logger.debug("iOS/macOS captive portal detection triggered")
            return redirect("/")

        # Android Captive Portal 检测
        @self._app.route("/generate_204")
        @self._app.route("/gen_204")
        def android_captive_portal():
            logger.debug("Android captive portal detection triggered")
            return redirect("/")

        # Windows Captive Portal 检测
        @self._app.route("/connecttest.txt")
        @self._app.route("/ncsi.txt")
        def windows_captive_portal():
            logger.debug("Windows captive portal detection triggered")
            return redirect("/")

        logger.info("Captive Portal detection routes registered")

    def _setup_captive_redirect(self, interface: str):
        """设置 Captive Portal HTTP 重定向"""
        try:
            logger.info(f"Setting up Captive Portal redirect on {interface}...")

            # 清除旧规则
            subprocess.run(
                [
                    "sudo",
                    "iptables",
                    "-t",
                    "nat",
                    "-D",
                    "PREROUTING",
                    "-i",
                    interface,
                    "-p",
                    "tcp",
                    "--dport",
                    "80",
                    "-j",
                    "REDIRECT",
                    "--to-port",
                    str(self._config.port),
                ],
                capture_output=True,
                timeout=5,
            )

            # 添加新规则
            result = subprocess.run(
                [
                    "sudo",
                    "iptables",
                    "-t",
                    "nat",
                    "-A",
                    "PREROUTING",
                    "-i",
                    interface,
                    "-p",
                    "tcp",
                    "--dport",
                    "80",
                    "-j",
                    "REDIRECT",
                    "--to-port",
                    str(self._config.port),
                ],
                capture_output=True,
                timeout=5,
            )

            if result.returncode == 0:
                logger.info("Captive Portal redirect configured")
            else:
                logger.warning("iptables redirect failed (not critical)")

        except Exception as e:
            logger.warning(f"Failed to setup Captive Portal redirect: {e}")

    def _remove_captive_redirect(self, interface: str):
        """移除 Captive Portal HTTP 重定向"""
        try:
            subprocess.run(
                [
                    "sudo",
                    "iptables",
                    "-t",
                    "nat",
                    "-D",
                    "PREROUTING",
                    "-i",
                    interface,
                    "-p",
                    "tcp",
                    "--dport",
                    "80",
                    "-j",
                    "REDIRECT",
                    "--to-port",
                    str(self._config.port),
                ],
                capture_output=True,
                timeout=5,
            )
            logger.debug("Captive Portal redirect removed")
        except Exception as e:
            logger.debug(f"Failed to remove redirect: {e}")
