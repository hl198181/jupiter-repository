"""AP 模块配置

AP module configuration models using Pydantic.

提供 AP 模块的配置数据模型：
- HostapdConfig: hostapd 配置
- DnsmasqConfig: dnsmasq 配置
- PortalConfig: Portal 服务器配置
- APConfig: AP 模式总配置

Provides configuration models for AP module.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

try:
    from pydantic import BaseModel, Field
except ImportError:
    raise ImportError("pydantic is required for AP module. " "Install with: pip install pydantic")


class HostapdConfig(BaseModel):
    """hostapd 配置

    hostapd configuration.

    配置 WiFi AP 热点参数。
    """

    interface: str = "wlan0"
    """WiFi 接口名称"""

    ssid_template: str = "Jupiter-{last4}"
    """SSID 模板（{last4} 会被替换为设备序列号后4位）"""

    ssid: str = ""
    """实际 SSID（如果为空则从 template 生成）"""

    password: str = ""
    """WiFi 密码（为空则开放网络，至少8位才启用加密）"""

    channel: int = 6
    """WiFi 信道（1-13）"""

    hw_mode: str = "g"
    """硬件模式（a=5GHz, b/g=2.4GHz）"""


class DnsmasqConfig(BaseModel):
    """dnsmasq 配置

    dnsmasq configuration.

    配置 DHCP 服务器和 DNS 功能。
    """

    interface: str = "wlan0"
    """绑定的网络接口"""

    ip_address: str = "192.168.4.1"
    """AP 的 IP 地址"""

    netmask: str = "255.255.255.0"
    """子网掩码"""

    dhcp_range_start: str = "192.168.4.100"
    """DHCP 起始地址"""

    dhcp_range_end: str = "192.168.4.200"
    """DHCP 结束地址"""

    lease_time: str = "12h"
    """DHCP 租约时间"""

    enable_captive_portal: bool = True
    """启用 Captive Portal DNS 劫持"""

    captive_portal_mode: str = "specific"
    """Captive Portal 模式: 'specific' 或 'all'"""

    captive_domains: List[str] = Field(
        default_factory=lambda: [
            # iOS/macOS
            "captive.apple.com",
            "www.apple.com",
            # Android
            "connectivitycheck.gstatic.com",
            "clients3.google.com",
            # Windows
            "www.msftconnecttest.com",
            "www.msftncsi.com",
            # Linux
            "connectivity-check.ubuntu.com",
            "nmcheck.gnome.org",
        ]
    )
    """Captive Portal DNS 劫持域名列表"""


class PortalConfig(BaseModel):
    """Portal 服务器配置

    Portal server configuration.

    配置 Web 配置门户。
    """

    enabled: bool = True
    """是否启用 Portal 服务器"""

    port: int = 8080
    """HTTP 服务端口"""

    enable_captive_redirect: bool = True
    """启用 Captive Portal HTTP 重定向（需要 iptables）"""


class APConfig(BaseModel):
    """AP 模式总配置

    AP mode configuration.

    完整的 AP 模式配置，包括 hostapd、dnsmasq、portal 配置。
    """

    hostapd: HostapdConfig = Field(default_factory=HostapdConfig)
    """hostapd 配置"""

    dnsmasq: DnsmasqConfig = Field(default_factory=DnsmasqConfig)
    """dnsmasq 配置"""

    portal: PortalConfig = Field(default_factory=PortalConfig)
    """Portal 服务器配置"""

    @classmethod
    def from_dict(cls, config_dict: dict) -> APConfig:
        """从字典创建配置

        Create configuration from dictionary.

        Args:
            config_dict: 配置字典

        Returns:
            APConfig 实例
        """
        return cls(**config_dict)

    @classmethod
    def from_yaml(cls, file_path: str) -> APConfig:
        """从 YAML 文件加载配置

        Load configuration from YAML file.

        Args:
            file_path: YAML 配置文件路径

        Returns:
            APConfig 实例
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load YAML config. " "Install with: pip install pyyaml"
            )

        with open(file_path, encoding="utf-8") as f:
            config_dict = yaml.safe_load(f)

        # 支持顶层 'ap' 键或直接配置
        if "ap" in config_dict:
            config_dict = config_dict["ap"]

        return cls(**config_dict)

    @classmethod
    def from_json(cls, file_path: str) -> APConfig:
        """从 JSON 文件加载配置

        Load configuration from JSON file.

        Args:
            file_path: JSON 配置文件路径

        Returns:
            APConfig 实例
        """
        import json

        with open(file_path, encoding="utf-8") as f:
            config_dict = json.load(f)

        # 支持顶层 'ap' 键或直接配置
        if "ap" in config_dict:
            config_dict = config_dict["ap"]

        return cls(**config_dict)

    @classmethod
    def from_file(cls, file_path: str) -> APConfig:
        """从文件加载配置（自动检测格式）

        Load configuration from file (auto-detect format).

        Args:
            file_path: 配置文件路径

        Returns:
            APConfig 实例
        """
        file_path = Path(file_path)
        suffix = file_path.suffix.lower()

        if suffix in [".yaml", ".yml"]:
            return cls.from_yaml(str(file_path))
        elif suffix == ".json":
            return cls.from_json(str(file_path))
        else:
            raise ValueError(f"Unsupported config file format: {suffix}")
