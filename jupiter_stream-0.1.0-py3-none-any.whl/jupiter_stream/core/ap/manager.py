"""AP 管理器

AP manager for WiFi Access Point mode.

提供 AP 模式管理功能：
- 启动/停止 AP 模式
- 协调 hostapd、dnsmasq、Portal
- 路由注册接口

完全独立，无业务逻辑，由 App 层决定何时启动/停止。

Provides AP mode management (completely independent).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from .config import APConfig
from .dnsmasq import DnsmasqController
from .exceptions import APConfigError, APError
from .hostapd import HostapdController
from .portal import PortalServer

logger = logging.getLogger(__name__)


class APManager:
    """AP 模式管理器（完全独立，纯工具类）

    AP mode manager (completely independent, pure utility).

    职责：
    - 启动/停止 AP 模式
    - 管理 hostapd、dnsmasq、Portal
    - 提供路由注册接口

    不包含：
    - ❌ 网络状态监控
    - ❌ 自动触发逻辑
    - ❌ 事件订阅

    所有业务逻辑（何时启动、何时停止）由 App 层决定。
    """

    def __init__(self, config: APConfig):
        """初始化 AP 管理器

        Initialize AP manager.

        Args:
            config: AP 配置
        """
        self._config = config

        # 组件
        self._hostapd = HostapdController(config.hostapd)
        self._dnsmasq = DnsmasqController(config.dnsmasq)
        self._portal = PortalServer(config.portal) if config.portal.enabled else None

    # ===== 核心 API =====

    def start(self) -> bool:
        """启动 AP 模式（纯粹的启动操作）

        Start AP mode (pure start operation).

        Returns:
            True 如果启动成功

        Raises:
            APError: 启动失败
        """
        try:
            logger.info("Starting AP mode...")

            # 1. 启动 hostapd
            self._hostapd.start()

            # 2. 启动 dnsmasq（传入 IP 地址用于 DNS 劫持）
            self._dnsmasq.start(ip_address=self._config.dnsmasq.ip_address)

            # 3. 启动 Portal 服务器（如果启用）
            if self._portal:
                self._portal.start(interface=self._config.hostapd.interface)

            logger.info(
                f"AP mode started successfully: "
                f"SSID={self._config.hostapd.ssid}, "
                f"IP={self._config.dnsmasq.ip_address}"
            )
            return True

        except Exception as e:
            logger.error(f"Failed to start AP mode: {e}")
            # 清理已启动的组件
            self.stop()
            raise APError(f"Failed to start AP mode: {e}") from e

    def stop(self) -> None:
        """停止 AP 模式（纯粹的停止操作）

        Stop AP mode (pure stop operation).
        """
        try:
            logger.info("Stopping AP mode...")

            # 按相反顺序停止组件
            if self._portal:
                self._portal.stop(interface=self._config.hostapd.interface)

            self._dnsmasq.stop()
            self._hostapd.stop()

            logger.info("AP mode stopped successfully")

        except Exception as e:
            logger.error(f"Error stopping AP mode: {e}")

    def is_active(self) -> bool:
        """检查 AP 是否运行中

        Check if AP is active.

        Returns:
            True 如果 hostapd 正在运行
        """
        return self._hostapd.is_running()

    # ===== 路由注册 API =====

    def register_route(self, path: str, handler: Callable, methods: List[str] = None) -> None:
        """注册门户页面路由（供 App 层使用）

        Register portal page route (for App layer).

        Args:
            path: URL 路径（如 '/', '/wifi', '/activation'）
            handler: 路由处理函数 (request) -> Response
            methods: HTTP 方法列表，默认 ['GET']

        Example:
            >>> def wifi_config_page():
            ...     return render_template('wifi_config.html')
            >>> ap_manager.register_route('/', wifi_config_page)
        """
        if not self._portal:
            logger.warning("Portal server is disabled, route registration ignored")
            return

        self._portal.register_route(path, handler, methods)

    # ===== 配置加载 =====

    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> APManager:
        """从配置文件创建管理器

        Create manager from configuration file.

        Args:
            config_path: 配置文件路径（YAML 或 JSON）

        Returns:
            APManager 实例

        Raises:
            APConfigError: 配置加载失败
        """
        try:
            config = APConfig.from_file(str(config_path))
            return cls(config)
        except Exception as e:
            raise APConfigError(f"Failed to load config from {config_path}: {e}")

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> APManager:
        """从字典创建管理器

        Create manager from dictionary.

        Args:
            config_dict: 配置字典

        Returns:
            APManager 实例
        """
        config = APConfig.from_dict(config_dict)
        return cls(config)

    # ===== 配置访问 =====

    def get_ssid(self) -> str:
        """获取 AP 的 SSID

        Get AP SSID.

        Returns:
            SSID 字符串
        """
        return self._config.hostapd.ssid

    def get_ip_address(self) -> str:
        """获取 AP 的 IP 地址

        Get AP IP address.

        Returns:
            IP 地址字符串
        """
        return self._config.dnsmasq.ip_address

    def get_portal_url(self) -> Optional[str]:
        """获取 Portal 访问 URL

        Get Portal access URL.

        Returns:
            Portal URL，如果未启用返回 None
        """
        if not self._portal:
            return None

        return f"http://{self._config.dnsmasq.ip_address}:{self._config.portal.port}"
