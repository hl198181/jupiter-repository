"""hostapd 控制器

hostapd controller for AP mode management.

提供 hostapd 进程管理功能：
- 启动/停止 hostapd
- 配置文件生成
- 网络接口配置
- 进程状态监控

Provides hostapd process management.
"""

from __future__ import annotations

import logging
import subprocess
import time
from pathlib import Path
from typing import Optional

from .config import HostapdConfig
from .exceptions import HostapdError, InterfaceError

logger = logging.getLogger(__name__)


class HostapdController:
    """hostapd 控制器

    hostapd controller.

    管理 hostapd 进程的生命周期。
    完全独立，无外部模块依赖。
    """

    def __init__(self, config: HostapdConfig):
        """初始化 hostapd 控制器

        Initialize hostapd controller.

        Args:
            config: hostapd 配置
        """
        self._config = config
        self._process: Optional[subprocess.Popen] = None
        self._conf_path = "/tmp/hostapd_jupiter.conf"
        self._pid_file = "/tmp/hostapd_jupiter.pid"

        # 生成实际的 SSID
        if not self._config.ssid:
            self._config.ssid = self._generate_ssid()

    def start(self) -> None:
        """启动 hostapd

        Start hostapd.

        Raises:
            HostapdError: 启动失败
            InterfaceError: 接口配置失败
        """
        if self.is_running():
            logger.warning("hostapd is already running")
            return

        try:
            logger.info(f"Starting hostapd on {self._config.interface}...")

            # 0. 清理可能遗留的旧进程
            self._cleanup_old_processes()

            # 1. 配置网络接口
            self._configure_interface()

            # 2. 生成配置文件
            conf_content = self._generate_config()
            with open(self._conf_path, "w") as f:
                f.write(conf_content)

            # 3. 启动 hostapd
            self._process = subprocess.Popen(
                ["sudo", "hostapd", self._conf_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            logger.debug(f"hostapd process started with PID: {self._process.pid}")

            # 保存 PID 到文件
            try:
                with open(self._pid_file, "w") as f:
                    f.write(str(self._process.pid))
                logger.debug(f"PID {self._process.pid} saved to {self._pid_file}")
            except Exception as e:
                logger.warning(f"Failed to save PID file: {e}")

            # 4. 等待启动
            time.sleep(2)

            # 5. 检查进程状态
            if self._process.poll() is not None:
                stderr = self._process.stderr.read().decode("utf-8", errors="ignore")
                raise HostapdError(
                    f"hostapd failed to start (exit code: {self._process.returncode})\n"
                    f"stderr: {stderr}"
                )

            logger.info(
                f"hostapd started successfully: SSID={self._config.ssid}, PID={self._process.pid}"
            )

        except subprocess.SubprocessError as e:
            raise HostapdError(f"Failed to start hostapd: {e}") from e
        except OSError as e:
            raise HostapdError(f"Failed to write hostapd config: {e}") from e

    def stop(self) -> None:
        """停止 hostapd

        Stop hostapd.
        """
        if not self._process:
            logger.debug("hostapd is not running")
            return

        try:
            pid = self._process.pid
            logger.info(f"Stopping hostapd (PID: {pid})...")

            # 使用 sudo kill 因为进程是用 sudo 启动的
            try:
                subprocess.run(
                    ["sudo", "kill", "-TERM", str(pid)],
                    timeout=2,
                    capture_output=True,
                    check=True,
                )
                # 等待进程退出
                self._process.wait(timeout=5)
                logger.info(f"hostapd stopped (PID: {pid})")
            except subprocess.TimeoutExpired:
                logger.warning(f"hostapd did not stop gracefully, killing (PID: {pid})...")
                subprocess.run(
                    ["sudo", "kill", "-9", str(pid)],
                    timeout=2,
                    capture_output=True,
                )
                self._process.wait()
                logger.info(f"hostapd killed (PID: {pid})")
        except Exception as e:
            logger.error(f"Failed to stop hostapd: {e}")
        finally:
            self._process = None

            # 删除 PID 文件
            try:
                if Path(self._pid_file).exists():
                    Path(self._pid_file).unlink()
                    logger.debug(f"PID file removed: {self._pid_file}")
            except Exception as e:
                logger.debug(f"Failed to remove PID file: {e}")

            self._cleanup_interface()

    def is_running(self) -> bool:
        """检查 hostapd 是否运行中

        Check if hostapd is running.

        Returns:
            True 如果运行中
        """
        return self._process is not None and self._process.poll() is None

    def _configure_interface(self) -> None:
        """配置网络接口

        Configure network interface for AP mode.

        Raises:
            InterfaceError: 接口配置失败
        """
        interface = self._config.interface

        try:
            logger.info(f"Configuring interface {interface} for AP mode...")

            # 0. 确保 WiFi 射频未被阻塞
            try:
                result = subprocess.run(
                    ["sudo", "rfkill", "unblock", "wifi"],
                    timeout=5,
                    capture_output=True,
                )
                if result.returncode == 0:
                    logger.debug("WiFi radio unblocked")
                else:
                    logger.debug("rfkill unblock returned non-zero (may not be needed)")
            except Exception as e:
                logger.debug(f"rfkill unblock failed (may not be needed): {e}")

            # 1. 停止 NetworkManager 管理
            subprocess.run(
                ["sudo", "nmcli", "device", "set", interface, "managed", "no"],
                check=True,
                timeout=5,
                capture_output=True,
            )
            time.sleep(1)

            # 2. 关闭接口
            subprocess.run(
                ["sudo", "ip", "link", "set", interface, "down"],
                timeout=5,
                capture_output=True,
            )

            # 3. 清空 IP 地址
            subprocess.run(
                ["sudo", "ip", "addr", "flush", "dev", interface],
                timeout=5,
                capture_output=True,
            )

            # 4. 启动接口
            subprocess.run(
                ["sudo", "ip", "link", "set", interface, "up"],
                check=True,
                timeout=5,
                capture_output=True,
            )

            logger.info(f"Interface {interface} configured successfully")

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode("utf-8", errors="ignore") if e.stderr else ""
            raise InterfaceError(f"Failed to configure interface {interface}: {stderr}") from e
        except subprocess.TimeoutExpired as e:
            raise InterfaceError(f"Interface configuration timed out: {e}") from e

    def _cleanup_interface(self) -> None:
        """清理网络接口配置

        Clean up network interface configuration.
        """
        interface = self._config.interface

        try:
            logger.info(f"Cleaning up interface {interface}...")

            # 清空 IP 地址
            result = subprocess.run(
                ["sudo", "ip", "addr", "flush", "dev", interface],
                timeout=5,
                capture_output=True,
            )
            if result.returncode == 0:
                logger.debug(f"Flushed IP addresses from {interface}")
            else:
                logger.debug(f"Failed to flush IP addresses (may be ok): {result.stderr.decode()}")

            # 关闭接口
            result = subprocess.run(
                ["sudo", "ip", "link", "set", interface, "down"],
                timeout=5,
                capture_output=True,
            )
            if result.returncode == 0:
                logger.debug(f"Interface {interface} set to DOWN")
            else:
                logger.debug(f"Failed to set interface down: {result.stderr.decode()}")

            # 恢复 NetworkManager 管理
            result = subprocess.run(
                ["sudo", "nmcli", "device", "set", interface, "managed", "yes"],
                timeout=5,
                capture_output=True,
            )
            if result.returncode == 0:
                logger.debug(f"NetworkManager management restored for {interface}")
            else:
                logger.debug(f"Failed to restore NetworkManager: {result.stderr.decode()}")

            logger.info(f"Interface {interface} cleaned up successfully")

        except Exception as e:
            logger.warning(f"Failed to cleanup interface: {e}")

    def _generate_config(self) -> str:
        """生成 hostapd 配置文件

        Generate hostapd configuration file.

        Returns:
            配置文件内容
        """
        config = f"""# hostapd configuration
interface={self._config.interface}
driver=nl80211
ssid={self._config.ssid}
hw_mode={self._config.hw_mode}
channel={self._config.channel}
ieee80211n=1
wmm_enabled=1
"""

        # 如果设置了密码（至少8位），启用 WPA2
        if self._config.password and len(self._config.password) >= 8:
            config += f"""auth_algs=1
wpa=2
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
wpa_passphrase={self._config.password}
"""
            logger.info("AP mode with WPA2 encryption")
        else:
            logger.warning("AP mode without encryption (open network)")

        return config

    def _generate_ssid(self) -> str:
        """生成 SSID

        Generate SSID from template.

        Returns:
            生成的 SSID
        """
        # 尝试从 /proc/cpuinfo 读取序列号
        serial = "0000"
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("Serial"):
                        serial = line.split(":")[1].strip()
                        break
        except Exception:
            pass

        last4 = serial[-4:] if len(serial) >= 4 else "0000"
        return self._config.ssid_template.format(last4=last4, serial=serial)

    def _cleanup_old_processes(self) -> None:
        """清理可能遗留的旧 hostapd 进程

        Clean up any old hostapd processes from previous runs.
        使用 PID 文件跟踪旧进程，避免误杀新启动的进程。
        """
        try:
            logger.debug(f"Checking for old hostapd processes (PID file: {self._pid_file})...")

            # 检查 PID 文件是否存在
            if not Path(self._pid_file).exists():
                logger.debug("No PID file found, no cleanup needed")
                return

            # 读取旧进程的 PID
            try:
                with open(self._pid_file) as f:
                    old_pid = f.read().strip()
                logger.debug(f"Found PID file with PID: {old_pid}")
            except Exception as e:
                logger.warning(f"Failed to read PID file: {e}")
                # 删除损坏的 PID 文件
                try:
                    Path(self._pid_file).unlink()
                    logger.debug("Removed corrupted PID file")
                except OSError:
                    pass
                return

            # 检查进程是否仍在运行
            result = subprocess.run(
                ["ps", "-p", old_pid],
                capture_output=True,
                timeout=2,
            )

            if result.returncode == 0:
                # 进程存在，需要清理
                logger.warning(f"Found old hostapd process (PID: {old_pid}), killing...")
                try:
                    subprocess.run(
                        ["sudo", "kill", "-9", old_pid],
                        timeout=2,
                        capture_output=True,
                    )
                    logger.info(f"Old hostapd process (PID: {old_pid}) killed")
                    time.sleep(0.5)
                except Exception as e:
                    logger.warning(f"Failed to kill old process (PID: {old_pid}): {e}")
            else:
                logger.debug(f"Old PID {old_pid} is not running (stale PID file)")

            # 删除 PID 文件
            try:
                Path(self._pid_file).unlink()
                logger.debug(f"Removed old PID file: {self._pid_file}")
            except Exception as e:
                logger.debug(f"Failed to remove old PID file: {e}")

        except Exception as e:
            logger.warning(f"Error during old process cleanup: {e}")
