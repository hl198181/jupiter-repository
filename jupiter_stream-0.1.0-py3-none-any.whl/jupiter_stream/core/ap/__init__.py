"""AP 模式管理模块

AP (Access Point) mode management module.

提供完全独立的 WiFi AP 模式管理功能：
- hostapd WiFi 热点
- dnsmasq DHCP/DNS 服务
- Portal Web 配置页面
- Captive Portal 支持

完全独立设计，无自动触发逻辑，所有业务逻辑由 App 层决定。

Provides completely independent WiFi AP mode management.
All business logic (when to start/stop) is handled by App layer.

Example:
    >>> from jupiter_stream.core.ap import APManager, APConfig
    >>>
    >>> # 从配置文件加载
    >>> ap = APManager.from_config("ap_config.yaml")
    >>>
    >>> # 注册自定义页面
    >>> def wifi_config_page():
    ...     return render_template("wifi_config.html")
    >>> ap.register_route("/", wifi_config_page)
    >>>
    >>> # 启动 AP 模式（App 层决定何时启动）
    >>> ap.start()
    >>>
    >>> # 停止 AP 模式（App 层决定何时停止）
    >>> ap.stop()
"""

from __future__ import annotations

# 配置模型
from .config import APConfig, DnsmasqConfig, HostapdConfig, PortalConfig

# 异常
from .exceptions import (
    APConfigError,
    APError,
    DnsmasqError,
    HostapdError,
    InterfaceError,
    PortalError,
)

# 核心管理器
from .manager import APManager

__all__ = [
    # 管理器
    "APManager",
    # 配置
    "APConfig",
    "HostapdConfig",
    "DnsmasqConfig",
    "PortalConfig",
    # 异常
    "APError",
    "APConfigError",
    "HostapdError",
    "DnsmasqError",
    "PortalError",
    "InterfaceError",
]
