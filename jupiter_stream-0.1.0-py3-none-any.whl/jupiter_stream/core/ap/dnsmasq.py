"""dnsmasq 控制器

dnsmasq controller for DHCP and DNS services.

提供 dnsmasq 进程管理功能：
- 启动/停止 dnsmasq
- DHCP 服务器配置
- DNS 劫持（Captive Portal）
- 进程状态监控

Provides dnsmasq process management.
"""

from __future__ import annotations

import logging
import subprocess
import time
from pathlib import Path
from typing import Optional

from .config import DnsmasqConfig
from .exceptions import DnsmasqError

logger = logging.getLogger(__name__)


class DnsmasqController:
    """dnsmasq 控制器

    dnsmasq controller.

    管理 dnsmasq 进程的生命周期。
    完全独立，无外部模块依赖。
    """

    def __init__(self, config: DnsmasqConfig):
        """初始化 dnsmasq 控制器

        Initialize dnsmasq controller.

        Args:
            config: dnsmasq 配置
        """
        self._config = config
        self._process: Optional[subprocess.Popen] = None
        self._conf_path = "/tmp/dnsmasq_jupiter.conf"
        self._pid_file = "/tmp/dnsmasq_jupiter.pid"

    def start(self, ip_address: Optional[str] = None) -> None:
        """启动 dnsmasq

        Start dnsmasq.

        Args:
            ip_address: AP 的 IP 地址（用于 Captive Portal DNS 劫持）

        Raises:
            DnsmasqError: 启动失败
        """
        if self.is_running():
            logger.warning("dnsmasq is already running")
            return

        try:
            logger.info(f"Starting dnsmasq on {self._config.interface}...")

            # 0. 清理可能遗留的旧进程
            self._cleanup_old_processes()

            # 1. 配置接口 IP 地址
            self._configure_ip_address(ip_address or self._config.ip_address)

            # 2. 生成配置文件
            conf_content = self._generate_config(ip_address or self._config.ip_address)
            with open(self._conf_path, "w") as f:
                f.write(conf_content)

            # 3. 启动 dnsmasq
            self._process = subprocess.Popen(
                ["sudo", "dnsmasq", "-C", self._conf_path, "--no-daemon"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            logger.debug(f"dnsmasq process started with PID: {self._process.pid}")

            # 保存 PID 到文件
            try:
                with open(self._pid_file, "w") as f:
                    f.write(str(self._process.pid))
                logger.debug(f"PID {self._process.pid} saved to {self._pid_file}")
            except Exception as e:
                logger.warning(f"Failed to save PID file: {e}")

            # 4. 等待启动
            time.sleep(1)

            # 5. 检查进程状态
            if self._process.poll() is not None:
                stderr = self._process.stderr.read().decode("utf-8", errors="ignore")
                raise DnsmasqError(
                    f"dnsmasq failed to start (exit code: {self._process.returncode})\n"
                    f"stderr: {stderr}"
                )

            logger.info(
                f"dnsmasq started successfully: DHCP {self._config.dhcp_range_start}-{self._config.dhcp_range_end}, PID={self._process.pid}"
            )

        except subprocess.SubprocessError as e:
            raise DnsmasqError(f"Failed to start dnsmasq: {e}") from e
        except OSError as e:
            raise DnsmasqError(f"Failed to write dnsmasq config: {e}") from e

    def stop(self) -> None:
        """停止 dnsmasq

        Stop dnsmasq.
        """
        if not self._process:
            logger.debug("dnsmasq is not running")
            return

        try:
            pid = self._process.pid
            logger.info(f"Stopping dnsmasq (PID: {pid})...")

            # 使用 sudo kill 因为进程是用 sudo 启动的
            try:
                subprocess.run(
                    ["sudo", "kill", "-TERM", str(pid)],
                    timeout=2,
                    capture_output=True,
                    check=True,
                )
                # 等待进程退出
                self._process.wait(timeout=5)
                logger.info(f"dnsmasq stopped (PID: {pid})")
            except subprocess.TimeoutExpired:
                logger.warning(f"dnsmasq did not stop gracefully, killing (PID: {pid})...")
                subprocess.run(
                    ["sudo", "kill", "-9", str(pid)],
                    timeout=2,
                    capture_output=True,
                )
                self._process.wait()
                logger.info(f"dnsmasq killed (PID: {pid})")
        except Exception as e:
            logger.error(f"Failed to stop dnsmasq: {e}")
        finally:
            self._process = None

            # 删除 PID 文件
            try:
                if Path(self._pid_file).exists():
                    Path(self._pid_file).unlink()
                    logger.debug(f"PID file removed: {self._pid_file}")
            except Exception as e:
                logger.debug(f"Failed to remove PID file: {e}")

    def is_running(self) -> bool:
        """检查 dnsmasq 是否运行中

        Check if dnsmasq is running.

        Returns:
            True 如果运行中
        """
        return self._process is not None and self._process.poll() is None

    def _configure_ip_address(self, ip_address: str) -> None:
        """配置接口 IP 地址

        Configure interface IP address.

        Args:
            ip_address: IP 地址

        Raises:
            DnsmasqError: IP 配置失败
        """
        interface = self._config.interface

        try:
            logger.info(f"Configuring IP address {ip_address} on {interface}...")

            # 计算 CIDR 前缀长度
            netmask = self._config.netmask
            cidr = netmask.count("255") * 8

            # 配置 IP 地址
            subprocess.run(
                [
                    "sudo",
                    "ip",
                    "addr",
                    "add",
                    f"{ip_address}/{cidr}",
                    "dev",
                    interface,
                ],
                check=True,
                timeout=5,
                capture_output=True,
            )

            logger.info(f"IP address {ip_address} configured")

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode("utf-8", errors="ignore") if e.stderr else ""
            # IP 可能已存在，忽略错误
            if "File exists" in stderr or "RTNETLINK answers" in stderr:
                logger.debug(f"IP address already configured: {stderr}")
            else:
                raise DnsmasqError(f"Failed to configure IP address: {stderr}") from e
        except subprocess.TimeoutExpired as e:
            raise DnsmasqError(f"IP configuration timed out: {e}") from e

    def _generate_config(self, ip_address: str) -> str:
        """生成 dnsmasq 配置文件

        Generate dnsmasq configuration file.

        Args:
            ip_address: AP 的 IP 地址

        Returns:
            配置文件内容
        """
        config = f"""# dnsmasq configuration
interface={self._config.interface}
bind-interfaces
dhcp-range={self._config.dhcp_range_start},{self._config.dhcp_range_end},{self._config.netmask},{self._config.lease_time}
dhcp-option=3,{ip_address}
dhcp-option=6,{ip_address}
server=8.8.8.8
log-queries
log-dhcp
"""

        # Captive Portal DNS 劫持
        if self._config.enable_captive_portal:
            if self._config.captive_portal_mode == "all":
                # 劫持所有 DNS 查询
                logger.info("Captive Portal: ALL DNS queries hijacked")
                config += f"address=/#/{ip_address}\n"
            else:
                # 劫持特定域名（推荐）
                logger.info("Captive Portal: Specific domains hijacked")
                for domain in self._config.captive_domains:
                    config += f"address=/{domain}/{ip_address}\n"

        return config

    def _cleanup_old_processes(self) -> None:
        """清理可能遗留的旧 dnsmasq 进程

        Clean up any old dnsmasq processes from previous runs.
        使用 PID 文件跟踪旧进程，避免误杀新启动的进程。
        """
        try:
            logger.debug(f"Checking for old dnsmasq processes (PID file: {self._pid_file})...")

            # 检查 PID 文件是否存在
            if not Path(self._pid_file).exists():
                logger.debug("No PID file found, no cleanup needed")
                return

            # 读取旧进程的 PID
            try:
                with open(self._pid_file) as f:
                    old_pid = f.read().strip()
                logger.debug(f"Found PID file with PID: {old_pid}")
            except Exception as e:
                logger.warning(f"Failed to read PID file: {e}")
                # 删除损坏的 PID 文件
                try:
                    Path(self._pid_file).unlink()
                    logger.debug("Removed corrupted PID file")
                except OSError:
                    pass
                return

            # 检查进程是否仍在运行
            result = subprocess.run(
                ["ps", "-p", old_pid],
                capture_output=True,
                timeout=2,
            )

            if result.returncode == 0:
                # 进程存在，需要清理
                logger.warning(f"Found old dnsmasq process (PID: {old_pid}), killing...")
                try:
                    subprocess.run(
                        ["sudo", "kill", "-9", old_pid],
                        timeout=2,
                        capture_output=True,
                    )
                    logger.info(f"Old dnsmasq process (PID: {old_pid}) killed")
                    time.sleep(0.5)
                except Exception as e:
                    logger.warning(f"Failed to kill old process (PID: {old_pid}): {e}")
            else:
                logger.debug(f"Old PID {old_pid} is not running (stale PID file)")

            # 删除 PID 文件
            try:
                Path(self._pid_file).unlink()
                logger.debug(f"Removed old PID file: {self._pid_file}")
            except Exception as e:
                logger.debug(f"Failed to remove old PID file: {e}")

        except Exception as e:
            logger.warning(f"Error during old process cleanup: {e}")
