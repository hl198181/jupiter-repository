"""
Core abstractions and modules for jupiter-stream.

核心模块组织：
- pipeline: Pipeline 处理流程核心组件
- mqtt: MQTT 协议集成（待添加）
- http: HTTP 协议集成（待添加）
- network: 网络管理（待添加）
"""

# 从 pipeline 模块导出所有核心接口（保持向后兼容）
from .pipeline import (
    ComponentFactory,
    ComponentRegistry,
    Frame,
    ManagedPipeline,
    Pipeline,
    PipelineBuilder,
    PipelineManager,
    Processor,
    ProcessorChain,
    Sink,
    Source,
    create_frame,
    register_processor,
    register_sink,
    register_source,
)

__all__ = [
    # Pipeline 核心
    "Frame",
    "create_frame",
    "Source",
    "Processor",
    "ProcessorChain",
    "Sink",
    "Pipeline",
    "PipelineManager",
    "ManagedPipeline",
    # 工厂和注册
    "ComponentFactory",
    "ComponentRegistry",
    "register_source",
    "register_processor",
    "register_sink",
    "PipelineBuilder",
]
