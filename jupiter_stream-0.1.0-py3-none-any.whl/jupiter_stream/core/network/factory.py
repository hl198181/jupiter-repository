"""Strategy Factory

工厂模式：根据接口特征创建最佳策略链
"""

from __future__ import annotations

import logging
from typing import List

from .strategy import (
    DetectionStrategy,
    IPAddressStrategy,
    NetworkManagerStrategy,
    StrategyChain,
)

logger = logging.getLogger(__name__)


class StrategyFactory:
    """策略工厂

    根据接口名称和特征，创建最适合的策略链
    """

    @staticmethod
    def create_chain_for_interface(interface: str) -> StrategyChain:
        """为指定接口创建策略链

        策略优先级：
        1. NetworkManager (如果 NM 管理此接口)
        2. IPAddress (通用 fallback)

        Args:
            interface: 接口名称

        Returns:
            StrategyChain 实例
        """
        strategies: List[DetectionStrategy] = []

        # 策略 1: NetworkManager (优先)
        strategies.append(NetworkManagerStrategy())

        # 策略 2: IPAddress (通用 fallback)
        strategies.append(IPAddressStrategy())

        logger.debug(f"Created strategy chain for {interface}: " f"{[s.name for s in strategies]}")

        return StrategyChain(strategies)


class InterfaceDetector:
    """接口检测器

    检测接口的特征（是否受 NM 管理、是否 RNDIS 等）
    用于优化策略链创建
    """

    @staticmethod
    def detect(interface: str) -> dict:
        """检测接口特征

        Args:
            interface: 接口名称

        Returns:
            特征字典：
            {
                "nm_managed": bool,      # 是否受 NetworkManager 管理
                "is_rndis": bool,        # 是否 RNDIS 设备
                "interface_type": str,   # "wifi" | "ethernet" | "modem"
            }
        """
        features = {
            "nm_managed": InterfaceDetector._check_nm_managed(interface),
            "is_rndis": InterfaceDetector._check_is_rndis(interface),
            "interface_type": InterfaceDetector._guess_interface_type(interface),
        }

        logger.debug(f"Detected features for {interface}: {features}")
        return features

    @staticmethod
    def _check_nm_managed(interface: str) -> bool:
        """检查接口是否受 NetworkManager 管理

        Args:
            interface: 接口名称

        Returns:
            True if managed by NetworkManager
        """
        try:
            adapter = NetworkManagerStrategy()._adapter
            adapter.get_device_info(interface)
            return True
        except Exception:
            return False

    @staticmethod
    def _check_is_rndis(interface: str) -> bool:
        """检查接口是否是 RNDIS 设备

        通过读取 /sys/class/net/{interface}/device/driver 判断

        Args:
            interface: 接口名称

        Returns:
            True if RNDIS device
        """
        import os

        driver_path = f"/sys/class/net/{interface}/device/driver"
        try:
            if os.path.islink(driver_path):
                driver = os.path.basename(os.readlink(driver_path))
                return "rndis" in driver.lower()
        except OSError:
            pass

        return False

    @staticmethod
    def _guess_interface_type(interface: str) -> str:
        """根据接口名称推测类型

        Args:
            interface: 接口名称

        Returns:
            "wifi" | "ethernet" | "modem"
        """
        if interface.startswith("wlan"):
            return "wifi"
        elif interface.startswith("ppp"):
            return "modem"
        elif interface.startswith("eth") or interface.startswith("usb"):
            return "ethernet"
        else:
            return "unknown"
