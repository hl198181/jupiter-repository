"""Network Interface (重构版)

简化的网络接口实现，使用策略模式
"""

from __future__ import annotations

import logging
from typing import Optional

from .config import InterfaceConfig
from .factory import StrategyFactory
from .strategy import StrategyChain

logger = logging.getLogger(__name__)


class NetworkInterface:
    """网络接口基类

    使用策略链进行接口检测，自动选择最佳检测方法并 fallback
    """

    def __init__(
        self, name: str, config: InterfaceConfig, strategy_chain: Optional[StrategyChain] = None
    ):
        """初始化网络接口

        Args:
            name: 接口名称（如 eth0, wlan0）
            config: 接口配置
            strategy_chain: 检测策略链（可选，默认自动创建）
        """
        self.name = name
        self.config = config

        # 自动创建策略链
        if strategy_chain is None:
            strategy_chain = StrategyFactory.create_chain_for_interface(name)

        self._strategy_chain = strategy_chain

    def is_connected(self) -> bool:
        """检测接口是否已连接

        委托给策略链执行，自动选择最佳检测方法

        Returns:
            True if interface is connected
        """
        try:
            return self._strategy_chain.is_connected(self.name)
        except Exception as e:
            logger.error(f"Failed to check connection for {self.name}: {e}")
            return False

    def get_ip_address(self) -> Optional[str]:
        """获取接口 IP 地址

        委托给策略链执行

        Returns:
            IP 地址字符串，如果未连接则返回 None
        """
        try:
            return self._strategy_chain.get_ip_address(self.name)
        except Exception as e:
            logger.warning(f"Failed to get IP address for {self.name}: {e}", exc_info=True)
            return None

    def __repr__(self) -> str:
        return f"<NetworkInterface {self.name}>"


class WiFiInterface(NetworkInterface):
    """WiFi 接口

    提供 WiFi 特有的功能：SSID、信号强度等
    """

    def __init__(
        self, name: str, config: InterfaceConfig, strategy_chain: Optional[StrategyChain] = None
    ):
        super().__init__(name, config, strategy_chain)

        # WiFi 特有功能使用 NetworkManager 适配器
        from .adapter import NetworkManagerAdapter

        self._nm_adapter = NetworkManagerAdapter()

    def get_ssid(self) -> Optional[str]:
        """获取当前连接的 WiFi SSID

        Returns:
            SSID 字符串，如果未连接则返回 None
        """
        try:
            if not self._nm_adapter.is_available():
                return None

            info = self._nm_adapter.get_device_info(self.name)
            return info.get("extra", {}).get("ssid")
        except Exception as e:
            logger.debug(f"Failed to get SSID for {self.name}: {e}")
            return None

    def get_signal_strength(self) -> int:
        """获取 WiFi 信号强度

        Returns:
            信号强度百分比（0-100），如果未连接则返回 0
        """
        try:
            if not self._nm_adapter.is_available():
                return 0

            info = self._nm_adapter.get_device_info(self.name)
            return info.get("extra", {}).get("signal_strength", 0)
        except Exception as e:
            logger.debug(f"Failed to get signal strength for {self.name}: {e}")
            return 0
