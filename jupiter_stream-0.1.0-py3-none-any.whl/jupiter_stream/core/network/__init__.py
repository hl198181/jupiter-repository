"""Network 核心模块

Network core module for Jupiter-Stream.

提供优雅的网络管理功能：
- 多接口自动切换（Ethernet > WiFi > 4G）
- 事件驱动的网络监控
- 网络就绪等待机制
- 路由优先级管理

Provides elegant network management features:
- Multi-interface automatic failover
- Event-driven network monitoring
- Network readiness waiting
- Route priority management

Examples:
    >>> from jupiter_stream.core.network import NetworkManager
    >>>
    >>> # 从配置创建管理器
    >>> manager = NetworkManager.from_config("network.yaml")
    >>>
    >>> # 启动并等待网络就绪
    >>> manager.start()
    >>> if manager.wait_for_network(timeout=30):
    ...     print("Network ready!")
    >>>
    >>> # 注册回调
    >>> def on_switch(old, new):
    ...     print(f"Switched: {old} -> {new}")
    >>> manager.on_interface_switched(on_switch)
    >>>
    >>> # 获取状态
    >>> status = manager.get_status()
    >>> print(f"Current: {status['current_interface']}")
"""

from __future__ import annotations

import importlib.util

# 导入检查
if importlib.util.find_spec("pydantic") is None:
    raise ImportError(
        "pydantic is required for Network module. "
        "Install with: pip install jupiter-stream[network]"
    )

# 核心类
# 配置
from .config import (
    ConnectivityCheckConfig,
    ConnectivityTarget,
    InterfaceConfig,
    NetworkConfig,
    RoutingConfig,
)

# 检测器
from .detector import NetworkDetector

# 异常
from .exceptions import (
    ModemError,
    ModemRegistrationError,
    ModemSignalError,
    ModemSIMError,
    NetworkConfigError,
    NetworkDBusError,
    NetworkDetectorError,
    NetworkError,
    NetworkInterfaceError,
    NetworkRouteError,
    WiFiAuthError,
    WiFiError,
    WiFiNotFoundError,
    WiFiTimeoutError,
)

# 接口
from .interface import (
    NetworkInterface,
    WiFiInterface,
)
from .manager import NetworkManager

# 工具
from .utils import RouteManager, get_interface_type
from .wifi_manager import WiFiConfigManager

__all__ = [
    # 核心类
    "NetworkManager",
    # 配置
    "NetworkConfig",
    "InterfaceConfig",
    "RoutingConfig",
    "ConnectivityCheckConfig",
    "ConnectivityTarget",
    # 接口
    "NetworkInterface",
    "WiFiInterface",
    # 检测器
    "NetworkDetector",
    # 异常
    "NetworkError",
    "NetworkConfigError",
    "NetworkDetectorError",
    "NetworkInterfaceError",
    "WiFiError",
    "WiFiAuthError",
    "WiFiTimeoutError",
    "WiFiNotFoundError",
    "ModemError",
    "ModemSIMError",
    "ModemSignalError",
    "ModemRegistrationError",
    "NetworkRouteError",
    "NetworkDBusError",
    # 工具
    "RouteManager",
    "get_interface_type",
    "WiFiConfigManager",
]
