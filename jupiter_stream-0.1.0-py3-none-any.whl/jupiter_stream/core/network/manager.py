"""Network Manager (重构版)

网络管理器，支持：
- 多接口管理和优先级切换
- D-Bus 事件驱动监控
- 健康检查机制（解决非 NM 管理接口的事件盲区）
- 竞态条件保护（防止并发切换、防抖动、容错期）
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from .config import NetworkConfig
from .detector import NetworkDetector
from .exceptions import NetworkConfigError
from .interface import NetworkInterface, WiFiInterface
from .utils import RouteManager

logger = logging.getLogger(__name__)


class NetworkManager:
    """网络管理器

    核心功能：
    - 多接口管理（Ethernet, WiFi, 4G）
    - 基于优先级的自动切换
    - D-Bus 事件驱动监控
    - 健康检查机制
    - 竞态条件保护
    """

    def __init__(self, config: NetworkConfig):
        """初始化网络管理器

        Args:
            config: 网络配置
        """
        self._config = config

        # 接口管理
        self._interfaces: Dict[str, NetworkInterface] = {}
        self._current_interface: Optional[str] = None

        # 事件回调
        self._callbacks: Dict[str, List[Callable]] = {
            "interface_switched": [],
            "network_connected": [],
            "network_disconnected": [],
        }

        # 线程锁（递归锁，允许同线程重入）
        self._lock = threading.RLock()

        # 竞态条件保护机制
        self._switching = False  # 切换中标记
        self._last_switch_time = 0.0  # 上次切换时间戳
        self._switch_debounce_time = 3.0  # 防抖动时间窗口（秒）
        self._health_check_grace_period = 10.0  # 容错期（秒）

        # 健康检查
        self._health_check_interval = config.health_check_interval
        self._health_check_thread: Optional[threading.Thread] = None
        self._health_check_stop_event = threading.Event()

        # 组件
        self._detector: Optional[NetworkDetector] = None
        self._route_manager: Optional[RouteManager] = None

        # 整体网络状态缓存
        self._last_any_connected: Optional[bool] = None

    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> NetworkManager:
        """工厂方法：从配置文件创建

        Args:
            config_path: YAML/JSON 配置文件路径

        Returns:
            NetworkManager 实例
        """
        try:
            config = NetworkConfig.from_file(str(config_path))
            return cls(config)
        except Exception as e:
            raise NetworkConfigError(f"Failed to load config from {config_path}: {e}")

    def start(self) -> None:
        """启动网络管理器"""
        # 1. 创建接口实例
        self._initialize_interfaces()

        # 2. 启动路由管理器
        self._initialize_route_manager()

        # 3. 启动 D-Bus 事件监控
        self._start_detector()

        # 4. 选择初始接口
        self._select_initial_interface()

        # 5. 启动健康检查
        self._start_health_check()

        logger.info("NetworkManager started")

    def stop(self) -> None:
        """停止网络管理器"""
        # 停止健康检查
        if self._health_check_thread:
            self._health_check_stop_event.set()
            self._health_check_thread.join(timeout=5)
            logger.info("Health check stopped")

        # 停止 D-Bus 监控
        if self._detector:
            self._detector.stop()
            logger.info("Network detector stopped")

        logger.info("NetworkManager stopped")

    def _initialize_interfaces(self) -> None:
        """创建接口实例"""
        for interface_name in self._config.interface_priority:
            config = self._config.interfaces.get(interface_name)
            if not config or not config.enabled:
                continue

            # 根据类型创建接口实例
            if interface_name.startswith("wlan"):
                iface = WiFiInterface(interface_name, config)
            else:
                iface = NetworkInterface(interface_name, config)

            self._interfaces[interface_name] = iface
            logger.info(f"Created interface: {interface_name}")

    def _initialize_route_manager(self) -> None:
        """初始化路由管理器"""
        if self._config.routing.auto_adjust_metric:
            try:
                self._route_manager = RouteManager(self._config.routing)
                logger.info("Route manager initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize route manager: {e}")

    def _start_detector(self) -> None:
        """启动 D-Bus 事件监控"""
        try:
            self._detector = NetworkDetector()
            self._detector.on_device_state_changed(self._on_device_state_changed)
            self._detector.start()
            logger.info("Network detector started")
        except Exception as e:
            logger.warning(f"Failed to start network detector: {e}")

    def _select_initial_interface(self) -> None:
        """选择初始接口"""
        self._switch_to_best_available(reason="initial_selection")

    def _start_health_check(self) -> None:
        """启动健康检查后台线程"""
        if self._health_check_interval <= 0:
            logger.info("Health check disabled (interval <= 0)")
            return

        self._health_check_stop_event.clear()
        self._health_check_thread = threading.Thread(
            target=self._health_check_loop, daemon=True, name="NetworkHealthCheck"
        )
        self._health_check_thread.start()
        logger.info(f"Health check started (interval: {self._health_check_interval}s)")

    def _health_check_loop(self) -> None:
        """健康检查循环"""
        while not self._health_check_stop_event.wait(self._health_check_interval):
            self._check_current_interface_health()

    def _check_current_interface_health(self) -> None:
        """检查当前接口健康状态（带多重保护）"""
        with self._lock:
            # 保护 1: 切换中跳过
            if self._switching:
                logger.debug("Health check skipped: switch in progress")
                return

            # 保护 2: 容错期
            time_since_last_switch = time.time() - self._last_switch_time
            if time_since_last_switch < self._health_check_grace_period:
                grace_remaining = self._health_check_grace_period - time_since_last_switch
                logger.debug(
                    f"Health check skipped: in grace period " f"(remaining: {grace_remaining:.1f}s)"
                )
                return

            # 保护 3: 无当前接口
            if not self._current_interface:
                return

            current = self._current_interface
            iface = self._interfaces.get(current)

        # 释放锁后检查（避免阻塞）
        if iface:
            if not iface.is_connected():
                logger.warning(
                    f"Health check failed: {current} is disconnected "
                    f"({time_since_last_switch:.1f}s since switch), "
                    f"switching to backup"
                )
                self._switch_to_best_available(reason="health_check_failed")
            else:
                # 检查通过，记录日志
                logger.info(
                    f"Health check: {current} OK " f"(uptime: {time_since_last_switch:.1f}s)"
                )

    def _get_default_routes(self) -> List[str]:
        """获取当前默认路由列表

        Returns:
            路由列表，每行一条路由
        """
        import subprocess

        try:
            result = subprocess.run(
                ["ip", "route", "show", "default"], capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0:
                routes = [
                    line.strip() for line in result.stdout.strip().split("\n") if line.strip()
                ]
                return routes
            return []
        except Exception as e:
            logger.debug(f"Error getting default routes: {e}")
            return []

    def _wait_for_route_stability(
        self,
        interface: str,
        max_wait: float = 5.0,
        check_interval: float = 0.5,
        stable_count_needed: int = 2,
    ) -> bool:
        """等待路由表稳定

        在接口激活后，DHCP 客户端会异步配置路由。
        此方法轮询检查路由表，直到连续多次检查结果一致，才认为稳定。

        Args:
            interface: 接口名称（用于日志）
            max_wait: 最长等待时间（秒）
            check_interval: 检查间隔（秒）
            stable_count_needed: 需要连续多少次一致才认为稳定

        Returns:
            True if stabilized, False if timeout
        """
        logger.info(f"Waiting for route table to stabilize after {interface} activation...")

        start_time = time.time()
        last_routes = None
        stable_count = 0
        check_num = 0

        max_checks = int(max_wait / check_interval)

        while check_num < max_checks:
            check_num += 1
            current_routes = self._get_default_routes()

            logger.info(f"Route check {check_num}: {len(current_routes)} default routes")

            if current_routes == last_routes:
                stable_count += 1
                if stable_count >= stable_count_needed:
                    elapsed = time.time() - start_time
                    logger.info(
                        f"Route table stabilized after {elapsed:.1f}s "
                        f"({stable_count} consecutive matches)"
                    )
                    return True
                else:
                    logger.debug(
                        f"Routes unchanged ({stable_count}/{stable_count_needed} for stability)"
                    )
            else:
                # 路由发生变化
                if last_routes is not None:
                    # 计算差异
                    added = set(current_routes) - set(last_routes)
                    removed = set(last_routes) - set(current_routes)

                    changes = []
                    if added:
                        for route in added:
                            changes.append(f"+{route}")
                    if removed:
                        for route in removed:
                            changes.append(f"-{route}")

                    logger.info(
                        f"Route changes detected: {', '.join(changes[:3])}"
                    )  # 只显示前3条变化

                stable_count = 0  # 重置稳定计数

            last_routes = current_routes
            time.sleep(check_interval)

        # 超时
        elapsed = time.time() - start_time
        logger.warning(
            f"Route table did not stabilize after {elapsed:.1f}s "
            f"(max wait: {max_wait}s), proceeding anyway"
        )
        return False

    def _switch_to_interface(self, interface: str, reason: str) -> bool:
        """切换到指定接口（带完整竞态保护）

        Args:
            interface: 目标接口名称
            reason: 切换原因

        Returns:
            True if switch succeeded
        """
        with self._lock:
            # 保护 1: 防止并发切换
            if self._switching:
                logger.debug(
                    f"Switch to {interface} skipped: " f"another switch already in progress"
                )
                return False

            # 保护 2: 防抖动
            now = time.time()
            time_since_last_switch = now - self._last_switch_time
            if time_since_last_switch < self._switch_debounce_time:
                logger.debug(
                    f"Switch to {interface} debounced: "
                    f"only {time_since_last_switch:.1f}s since last switch "
                    f"(min: {self._switch_debounce_time}s)"
                )
                return False

            # 保护 3: 检查是否已是当前接口
            if self._current_interface == interface:
                logger.debug(f"Already on {interface}, no switch needed")
                return False

            self._switching = True  # 标记切换开始
            old_interface = self._current_interface

        try:
            # 执行切换逻辑（不持有锁，避免长时间阻塞）
            logger.info(f"Switching from {old_interface} to {interface} ({reason})")

            # 等待路由表稳定（DHCP 客户端异步配置路由）
            self._wait_for_route_stability(interface)

            # 调整路由 metric
            if self._route_manager:
                self._route_manager.adjust_all_metrics(interface, self._interfaces)

            # 更新当前接口
            with self._lock:
                self._current_interface = interface
                self._last_switch_time = time.time()  # 记录切换时间

            # 触发回调
            self._trigger_interface_switched(old_interface, interface)

            logger.info(f"Successfully switched to {interface}")
            return True

        except Exception as e:
            logger.error(f"Switch to {interface} failed: {e}")
            return False

        finally:
            # 无论成功失败都清除标记
            with self._lock:
                self._switching = False

    def _switch_to_best_available(self, reason: str) -> None:
        """切换到最佳可用接口（按优先级）

        Args:
            reason: 切换原因
        """
        for interface in self._config.interface_priority:
            if interface in self._interfaces:
                if self._interfaces[interface].is_connected():
                    if self._switch_to_interface(interface, reason):
                        return

        # 无可用接口
        with self._lock:
            old_interface = self._current_interface
            self._current_interface = None

        if old_interface:
            logger.warning("No available interfaces, network disconnected")
            self._trigger_network_disconnected()

    def _on_device_state_changed(
        self, interface: str, new_state: int, old_state: int, reason: int
    ) -> None:
        """处理设备状态变化事件（D-Bus 回调）

        Args:
            interface: 接口名称
            new_state: 新状态
            old_state: 旧状态
            reason: 变化原因
        """
        if interface not in self._interfaces:
            return

        # NetworkManager 状态常量
        state_activated = 100

        # 记录状态变化
        state_names = {
            0: "UNKNOWN",
            10: "UNMANAGED",
            20: "UNAVAILABLE",
            30: "DISCONNECTED",
            40: "PREPARE",
            50: "CONFIG",
            60: "NEED_AUTH",
            70: "IP_CONFIG",
            80: "IP_CHECK",
            90: "SECONDARIES",
            100: "ACTIVATED",
            110: "DEACTIVATING",
            120: "FAILED",
        }
        old_state_name = state_names.get(old_state, f"UNKNOWN({old_state})")
        new_state_name = state_names.get(new_state, f"UNKNOWN({new_state})")
        logger.info(f"Interface {interface} state changed: {old_state_name} -> {new_state_name}")

        # 连接/断开事件
        # 只有状态真正改变时才触发事件
        if new_state == state_activated and old_state != state_activated:
            self._on_interface_connected(interface)
        elif old_state == state_activated and new_state != state_activated:
            self._on_interface_disconnected(interface)

    def _on_interface_connected(self, interface: str) -> None:
        """处理接口连接事件

        Args:
            interface: 接口名称
        """
        logger.info(f"Interface {interface} connected")

        # 检查是否需要切换到更高优先级接口
        if self._should_switch_to(interface):
            self._switch_to_interface(interface, reason="higher_priority_available")

        # 检查整体网络状态变化
        self._check_overall_network_state()

    def _on_interface_disconnected(self, interface: str) -> None:
        """处理接口断开事件

        Args:
            interface: 接口名称
        """
        logger.info(f"Interface {interface} disconnected")

        # 如果是当前接口断开，切换到备用接口
        if interface == self._current_interface:
            logger.warning(f"Current interface {interface} disconnected, switching to backup")
            self._switch_to_best_available(reason="current_interface_disconnected")

        # 检查整体网络状态变化
        self._check_overall_network_state()

    def _should_switch_to(self, interface: str) -> bool:
        """判断是否应该切换到指定接口

        Args:
            interface: 接口名称

        Returns:
            True if should switch
        """
        if not self._current_interface:
            return True  # 当前无接口，应该切换

        # 获取优先级（索引越小优先级越高）
        try:
            current_priority = self._config.interface_priority.index(self._current_interface)
            new_priority = self._config.interface_priority.index(interface)
            return new_priority < current_priority  # 新接口优先级更高
        except ValueError:
            return False

    def _check_overall_network_state(self) -> None:
        """检查整体网络状态变化，触发相应回调"""
        any_connected = self._current_interface is not None

        if self._last_any_connected is None:
            self._last_any_connected = any_connected
            return

        # 状态变化
        if any_connected and not self._last_any_connected:
            self._trigger_network_connected()
        elif not any_connected and self._last_any_connected:
            self._trigger_network_disconnected()

        self._last_any_connected = any_connected

    def _trigger_interface_switched(self, old_interface: Optional[str], new_interface: str) -> None:
        """触发接口切换回调

        Args:
            old_interface: 旧接口
            new_interface: 新接口
        """
        for callback in self._callbacks["interface_switched"]:
            try:
                callback(old_interface, new_interface)
            except Exception as e:
                logger.error(f"Error in switch callback: {e}")

    def _trigger_network_connected(self) -> None:
        """触发网络连接回调"""
        logger.info("Network connected")
        for callback in self._callbacks["network_connected"]:
            try:
                callback()
            except Exception as e:
                logger.error(f"Error in connected callback: {e}")

    def _trigger_network_disconnected(self) -> None:
        """触发网络断开回调"""
        logger.warning("Network disconnected")
        for callback in self._callbacks["network_disconnected"]:
            try:
                callback()
            except Exception as e:
                logger.error(f"Error in disconnected callback: {e}")

    # ==================== Public API ====================

    def on_interface_switched(self, callback: Callable[[Optional[str], str], None]) -> None:
        """注册接口切换回调

        Args:
            callback: 回调函数 (old_interface, new_interface) -> None
        """
        self._callbacks["interface_switched"].append(callback)

    def on_network_connected(self, callback: Callable[[], None]) -> None:
        """注册网络连接回调

        Args:
            callback: 回调函数 () -> None
        """
        self._callbacks["network_connected"].append(callback)

    def on_network_disconnected(self, callback: Callable[[], None]) -> None:
        """注册网络断开回调

        Args:
            callback: 回调函数 () -> None
        """
        self._callbacks["network_disconnected"].append(callback)

    def get_current_interface(self) -> Optional[str]:
        """获取当前使用的接口名称

        Returns:
            接口名称或 None
        """
        with self._lock:
            return self._current_interface

    def get_status(self) -> Dict[str, Any]:
        """获取网络状态

        Returns:
            状态字典
        """
        # 先获取接口列表（在锁内）
        with self._lock:
            current = self._current_interface
            interfaces_dict = dict(self._interfaces)  # 复制引用
            last_switch = self._last_switch_time

        # 查询接口状态（在锁外，避免阻塞）
        current_ip = None
        if current and current in interfaces_dict:
            current_ip = interfaces_dict[current].get_ip_address()

        # 收集所有接口状态
        interfaces_status = {}
        for name, iface in interfaces_dict.items():
            try:
                connected = iface.is_connected()
                ip = iface.get_ip_address()
            except Exception as e:
                logger.debug(f"Error getting status for {name}: {e}")
                connected = False
                ip = None

            interfaces_status[name] = {
                "connected": connected,
                "ip_address": ip,  # 使用 ip_address 键以兼容 demo
            }

        return {
            "current_interface": current,
            "current_ip": current_ip,
            "any_connected": current is not None,
            "all_interfaces": list(interfaces_dict.keys()),
            "interfaces": interfaces_status,
            "last_switch_time": last_switch,
        }

    def is_network_ready(self, interface: Optional[str] = None) -> bool:
        """检查网络是否就绪（接口连接 + 互联网连通性）

        Args:
            interface: 指定接口（可选）

        Returns:
            True if network ready
        """
        # 1. 检查接口连接状态
        with self._lock:
            if interface:
                if self._current_interface != interface:
                    return False
            else:
                if not self._current_interface:
                    return False

        # 2. 检查互联网连通性
        return self.check_internet_connectivity()

    def wait_for_network(self, interface: Optional[str] = None, timeout: float = 30) -> bool:
        """等待网络就绪（接口连接 + 互联网连通性）

        Args:
            interface: 指定接口（可选）
            timeout: 超时时间（秒）

        Returns:
            True if network ready
        """
        start_time = time.time()
        retry_interval = self._config.connectivity_check.retry_interval

        logger.debug(f"wait_for_network: starting (timeout={timeout}s, interval={retry_interval}s)")

        while time.time() - start_time < timeout:
            # 1. 检查接口连接状态（快速获取锁，不在锁内 sleep）
            with self._lock:
                current = self._current_interface
                if interface:
                    interface_ok = current == interface
                else:
                    interface_ok = bool(current)

            # 如果接口未就绪，等待后重试
            if not interface_ok:
                logger.debug(
                    f"wait_for_network: interface not ready (current={current}), waiting..."
                )
                time.sleep(retry_interval)
                continue

            # 2. 检查互联网连通性
            logger.debug(f"wait_for_network: checking connectivity (interface={current})...")
            if self.check_internet_connectivity():
                logger.debug("wait_for_network: connectivity OK, returning True")
                return True

            logger.debug("wait_for_network: connectivity check failed, retrying...")
            time.sleep(retry_interval)

        logger.debug(f"wait_for_network: timeout after {timeout}s")
        return False

    def check_internet_connectivity(self) -> bool:
        """检查互联网连通性

        根据配置的方法和目标检查互联网连接

        Returns:
            True if internet is accessible
        """
        if not self._config.connectivity_check.enabled:
            # 未启用连通性检查，只要接口连接即认为就绪
            return True

        method = self._config.connectivity_check.method
        targets = self._config.connectivity_check.targets

        if not targets:
            logger.warning("No connectivity check targets configured")
            return True

        # 按顺序尝试目标，任意一个成功即可
        for target in targets:
            try:
                if method == "http":
                    # HTTP 方法（推荐）
                    if self._check_http_connectivity(target):
                        logger.info(f"Internet connectivity OK: {target.url}")
                        return True
                elif method == "ping":
                    # Ping 方法
                    if self._check_ping_connectivity(target):
                        host = target.host or target.url
                        logger.info(f"Internet connectivity OK: ping {host}")
                        return True
                else:
                    logger.warning(f"Unknown connectivity check method: {method}")
                    return True

            except Exception as e:
                logger.warning(f"Connectivity check failed for {target}: {e}")
                continue

        logger.warning("All connectivity checks failed - no internet access")
        return False

    def _check_http_connectivity(self, target) -> bool:
        """HTTP 连通性检查

        Args:
            target: ConnectivityTarget 配置

        Returns:
            True if check passed
        """
        try:
            import urllib.error
            import urllib.request

            req = urllib.request.Request(
                target.url, headers={"User-Agent": "Jupiter-Stream-NetworkManager/1.0"}
            )

            with urllib.request.urlopen(req, timeout=target.timeout) as response:
                # 2xx 或 204 (No Content) 都认为成功
                if 200 <= response.status < 300 or response.status == 204:
                    return True

        except urllib.error.HTTPError as e:
            # 某些 captive portal 检测 URL 可能返回特定错误码也算成功
            if e.code == 204:
                return True
        except Exception:
            pass  # 失败信息由主函数记录

        return False

    def _check_ping_connectivity(self, target) -> bool:
        """Ping 连通性检查

        Args:
            target: ConnectivityTarget 配置

        Returns:
            True if check passed
        """
        try:
            import subprocess

            host = target.host or target.url
            if not host:
                logger.warning(f"No host specified for ping target: {target}")
                return False

            # 移除 URL scheme
            if "://" in host:
                host = host.split("://", 1)[1].split("/")[0]

            result = subprocess.run(
                ["ping", "-c", "1", "-W", str(target.timeout), host],
                capture_output=True,
                timeout=target.timeout + 1,
            )

            if result.returncode == 0:
                return True

        except subprocess.TimeoutExpired:
            pass  # 失败信息由主函数记录
        except Exception:
            pass  # 失败信息由主函数记录

        return False

    def __enter__(self) -> NetworkManager:
        """上下文管理器入口"""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.stop()
