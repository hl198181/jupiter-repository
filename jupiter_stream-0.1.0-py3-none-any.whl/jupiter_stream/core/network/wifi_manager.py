"""WiFi 配置管理工具

WiFi configuration management utility.

提供 WiFi 网络的添加、删除、连接功能。
注意：这是扩展工具类，不属于核心监控模块。

Provides WiFi network add, remove, and connect functionality.
Note: This is an extension utility, not part of the core monitoring module.
"""

from __future__ import annotations

import logging
import time
from typing import Dict, List, Optional, Tuple

from .exceptions import (
    NetworkDBusError,
    WiFiAuthError,
    WiFiNotFoundError,
    WiFiTimeoutError,
)

logger = logging.getLogger(__name__)


class WiFiConfigManager:
    """WiFi 配置管理工具

    WiFi configuration management utility.

    提供 WiFi 网络的添加、删除、连接功能。
    注意：这是扩展工具类，不属于核心监控模块。

    Examples:
        >>> wifi_mgr = WiFiConfigManager()
        >>> networks = wifi_mgr.list_available_networks()
        >>> for net in networks:
        ...     print(f"{net['ssid']}: {net['signal_strength']}%")
        >>> success, msg = wifi_mgr.add_and_connect('MyNetwork', 'password')
    """

    def __init__(self):
        """初始化 WiFi 配置管理器

        Initialize WiFi configuration manager.

        Raises:
            NetworkDBusError: D-Bus 连接失败
        """
        try:
            import dbus

            self.bus = dbus.SystemBus()
            self.nm_proxy = self.bus.get_object(
                "org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager"
            )
            self.nm = dbus.Interface(self.nm_proxy, "org.freedesktop.NetworkManager")
        except Exception as e:
            raise NetworkDBusError(f"Failed to connect to NetworkManager: {e}")

    def add_and_connect(
        self, ssid: str, password: str, autoconnect: bool = True, priority: int = 0
    ) -> Tuple[bool, Optional[str]]:
        """添加 WiFi 网络并连接

        Add WiFi network and connect.

        Args:
            ssid: WiFi SSID
            password: WiFi password
            autoconnect: 是否自动连接
            priority: 连接优先级（0-999，数值越大优先级越高）

        Returns:
            (success, message): 连接结果和消息

        Raises:
            WiFiAuthError: 密码错误
            WiFiTimeoutError: 连接超时
            WiFiNotFoundError: SSID 未找到
        """
        import dbus

        try:
            # 1. 创建连接配置
            connection = {
                "connection": {
                    "id": ssid,
                    "type": "802-11-wireless",
                    "autoconnect": autoconnect,
                    "autoconnect-priority": priority,
                },
                "802-11-wireless": {
                    "ssid": dbus.ByteArray(ssid.encode("utf-8")),
                    "mode": "infrastructure",
                },
                "802-11-wireless-security": {
                    "key-mgmt": "wpa-psk",
                    "psk": password,
                },
                "ipv4": {"method": "auto"},
                "ipv6": {"method": "auto"},
            }

            # 2. 添加连接
            settings_proxy = self.bus.get_object(
                "org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager/Settings"
            )
            settings = dbus.Interface(settings_proxy, "org.freedesktop.NetworkManager.Settings")
            connection_path = settings.AddConnection(connection)

            # 3. 激活连接
            device_path = self._get_wifi_device()
            if not device_path:
                raise WiFiNotFoundError("No WiFi device found")

            active_conn = self.nm.ActivateConnection(
                connection_path, device_path, dbus.ObjectPath("/")
            )

            # 4. 等待连接建立
            success, ip_address = self._wait_for_activation(active_conn, timeout=60)

            if success:
                logger.info(f"✓ Connected to {ssid} with IP {ip_address}")
                return True, f"Connected to {ssid} with IP {ip_address}"
            else:
                raise WiFiTimeoutError(f"Connection to {ssid} timeout")

        except dbus.exceptions.DBusException as e:
            error_msg = str(e).lower()
            if "secrets were required" in error_msg or "password" in error_msg:
                raise WiFiAuthError(f"Authentication failed for {ssid}: wrong password")
            elif "not found" in error_msg or "no network" in error_msg:
                raise WiFiNotFoundError(f"SSID {ssid} not found")
            else:
                raise WiFiTimeoutError(f"Failed to connect: {e}")

    def remove_network(self, ssid: str) -> bool:
        """删除已保存的 WiFi 网络

        Remove saved WiFi network.

        Args:
            ssid: WiFi SSID

        Returns:
            True if removed successfully
        """
        import dbus

        try:
            settings_proxy = self.bus.get_object(
                "org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager/Settings"
            )
            settings = dbus.Interface(settings_proxy, "org.freedesktop.NetworkManager.Settings")

            # 查找连接
            connections = settings.ListConnections()
            for conn_path in connections:
                conn_proxy = self.bus.get_object("org.freedesktop.NetworkManager", conn_path)
                conn = dbus.Interface(
                    conn_proxy, "org.freedesktop.NetworkManager.Settings.Connection"
                )
                settings_dict = conn.GetSettings()

                if settings_dict.get("connection", {}).get("id") == ssid:
                    conn.Delete()
                    logger.info(f"✓ Removed network {ssid}")
                    return True

            logger.warning(f"Network {ssid} not found in saved connections")
            return False

        except Exception as e:
            logger.error(f"Failed to remove network {ssid}: {e}")
            return False

    def list_known_networks(self) -> List[Dict[str, any]]:
        """列出已保存的 WiFi 网络

        List saved WiFi networks.

        Returns:
            List of saved networks with SSID and priority
        """
        import dbus

        networks = []
        try:
            settings_proxy = self.bus.get_object(
                "org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager/Settings"
            )
            settings = dbus.Interface(settings_proxy, "org.freedesktop.NetworkManager.Settings")

            connections = settings.ListConnections()
            for conn_path in connections:
                conn_proxy = self.bus.get_object("org.freedesktop.NetworkManager", conn_path)
                conn = dbus.Interface(
                    conn_proxy, "org.freedesktop.NetworkManager.Settings.Connection"
                )
                settings_dict = conn.GetSettings()

                # 仅保留 WiFi 连接
                if settings_dict.get("connection", {}).get("type") == "802-11-wireless":
                    ssid_bytes = settings_dict.get("802-11-wireless", {}).get("ssid")
                    if ssid_bytes:
                        ssid = bytes(ssid_bytes).decode("utf-8", errors="ignore")
                        priority = settings_dict.get("connection", {}).get(
                            "autoconnect-priority", 0
                        )
                        autoconnect = settings_dict.get("connection", {}).get("autoconnect", True)
                        networks.append(
                            {
                                "ssid": ssid,
                                "priority": int(priority),
                                "autoconnect": bool(autoconnect),
                            }
                        )

            return networks

        except Exception as e:
            logger.error(f"Failed to list known networks: {e}")
            return networks

    def list_available_networks(self) -> List[Dict[str, any]]:
        """列出所有可用的 WiFi 网络

        List all available WiFi networks.

        Returns:
            List of networks with SSID and signal strength
        """
        import dbus

        networks = []
        try:
            device_path = self._get_wifi_device()
            if not device_path:
                logger.warning("No WiFi device found")
                return networks

            device_proxy = self.bus.get_object("org.freedesktop.NetworkManager", device_path)
            device = dbus.Interface(device_proxy, "org.freedesktop.NetworkManager.Device.Wireless")

            # 请求扫描
            logger.info("Scanning for WiFi networks...")
            device.RequestScan({})
            time.sleep(2)  # 等待扫描完成

            # 获取接入点
            access_points = device.GetAccessPoints()
            for ap_path in access_points:
                ap_proxy = self.bus.get_object("org.freedesktop.NetworkManager", ap_path)
                props = dbus.Interface(ap_proxy, "org.freedesktop.DBus.Properties")

                ssid_bytes = props.Get("org.freedesktop.NetworkManager.AccessPoint", "Ssid")
                strength = props.Get("org.freedesktop.NetworkManager.AccessPoint", "Strength")

                ssid = bytes(ssid_bytes).decode("utf-8", errors="ignore")
                if ssid:  # 跳过隐藏网络
                    networks.append({"ssid": ssid, "signal_strength": int(strength)})

            # 按信号强度排序
            networks.sort(key=lambda x: x["signal_strength"], reverse=True)
            logger.info(f"Found {len(networks)} WiFi networks")
            return networks

        except Exception as e:
            logger.error(f"Failed to list available networks: {e}")
            return networks

    def connect_to_network(self, ssid: str, timeout: int = 60) -> Tuple[bool, Optional[str]]:
        """连接到已保存的 WiFi 网络

        Connect to saved WiFi network.

        Args:
            ssid: WiFi SSID
            timeout: 连接超时时间（秒）

        Returns:
            (success, message): 连接结果和消息

        Raises:
            WiFiNotFoundError: SSID 未找到
            WiFiTimeoutError: 连接超时
        """
        import dbus

        try:
            # 1. 查找连接
            settings_proxy = self.bus.get_object(
                "org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager/Settings"
            )
            settings = dbus.Interface(settings_proxy, "org.freedesktop.NetworkManager.Settings")

            connection_path = None
            connections = settings.ListConnections()
            for conn_path in connections:
                conn_proxy = self.bus.get_object("org.freedesktop.NetworkManager", conn_path)
                conn = dbus.Interface(
                    conn_proxy, "org.freedesktop.NetworkManager.Settings.Connection"
                )
                settings_dict = conn.GetSettings()

                if settings_dict.get("connection", {}).get("id") == ssid:
                    connection_path = conn_path
                    break

            if not connection_path:
                raise WiFiNotFoundError(f"SSID {ssid} not found in saved connections")

            # 2. 激活连接
            device_path = self._get_wifi_device()
            if not device_path:
                raise WiFiNotFoundError("No WiFi device found")

            active_conn = self.nm.ActivateConnection(
                connection_path, device_path, dbus.ObjectPath("/")
            )

            # 3. 等待连接建立
            success, ip_address = self._wait_for_activation(active_conn, timeout=timeout)

            if success:
                logger.info(f"✓ Connected to {ssid} with IP {ip_address}")
                return True, f"Connected to {ssid} with IP {ip_address}"
            else:
                raise WiFiTimeoutError(f"Connection to {ssid} timeout")

        except dbus.exceptions.DBusException as e:
            error_msg = str(e).lower()
            if "not found" in error_msg:
                raise WiFiNotFoundError(f"SSID {ssid} not found")
            else:
                raise WiFiTimeoutError(f"Failed to connect: {e}")

    def _get_wifi_device(self) -> Optional[str]:
        """获取 WiFi 设备路径

        Get WiFi device path.

        Returns:
            WiFi device D-Bus path or None
        """
        import dbus

        try:
            devices = self.nm.GetDevices()
            for device_path in devices:
                device_proxy = self.bus.get_object("org.freedesktop.NetworkManager", device_path)
                props = dbus.Interface(device_proxy, "org.freedesktop.DBus.Properties")
                device_type = props.Get("org.freedesktop.NetworkManager.Device", "DeviceType")
                # DeviceType 2 = WiFi
                if device_type == 2:
                    return device_path
            return None
        except Exception as e:
            logger.error(f"Failed to get WiFi device: {e}")
            return None

    def _wait_for_activation(
        self, active_conn_path: str, timeout: int = 60
    ) -> Tuple[bool, Optional[str]]:
        """等待连接激活

        Wait for connection activation.

        Args:
            active_conn_path: 活动连接 D-Bus 路径
            timeout: 超时时间（秒）

        Returns:
            (success, ip_address)
        """
        import dbus

        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                conn_proxy = self.bus.get_object("org.freedesktop.NetworkManager", active_conn_path)
                props = dbus.Interface(conn_proxy, "org.freedesktop.DBus.Properties")
                state = props.Get("org.freedesktop.NetworkManager.Connection.Active", "State")

                # State 2 = Activated
                if state == 2:
                    # 获取 IP 地址
                    ip4_config = props.Get(
                        "org.freedesktop.NetworkManager.Connection.Active", "Ip4Config"
                    )
                    if ip4_config != "/":
                        ip_proxy = self.bus.get_object("org.freedesktop.NetworkManager", ip4_config)
                        ip_props = dbus.Interface(ip_proxy, "org.freedesktop.DBus.Properties")
                        addresses = ip_props.Get(
                            "org.freedesktop.NetworkManager.IP4Config", "AddressData"
                        )
                        if addresses:
                            ip_address = addresses[0]["address"]
                            return True, ip_address
                    return True, None

                # State 4 = Deactivated (failed)
                elif state == 4:
                    logger.warning("Connection deactivated (failed)")
                    return False, None

            except Exception as e:
                logger.warning(f"Error checking activation state: {e}")

            time.sleep(0.5)

        logger.warning(f"Connection timeout after {timeout}s")
        return False, None
