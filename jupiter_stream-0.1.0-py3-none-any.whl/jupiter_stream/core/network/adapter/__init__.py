"""Adapter Layer

适配器层：统一不同数据源的接口
"""

from .base import DataSourceAdapter
from .nm_adapter import NetworkManagerAdapter
from .system_adapter import SystemCommandAdapter

__all__ = [
    "DataSourceAdapter",
    "NetworkManagerAdapter",
    "SystemCommandAdapter",
]
