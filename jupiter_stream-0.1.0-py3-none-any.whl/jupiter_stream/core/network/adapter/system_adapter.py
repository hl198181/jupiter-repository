"""System Command Adapter

通过系统命令（ip, ifconfig）获取接口信息
"""

from __future__ import annotations

import logging
import re
import subprocess
from typing import Any, Dict, Optional

from .base import DataSourceAdapter

logger = logging.getLogger(__name__)


class SystemCommandAdapter(DataSourceAdapter):
    """系统命令适配器

    通过 ip/ifconfig 命令获取接口状态和 IP 地址
    """

    def is_available(self) -> bool:
        """检查 ip 命令是否可用"""
        try:
            subprocess.run(["ip", "link"], capture_output=True, timeout=1)
            return True
        except Exception:
            return False

    def get_device_info(self, interface: str) -> Dict[str, Any]:
        """获取设备信息

        Args:
            interface: 接口名称

        Returns:
            设备信息字典

        Raises:
            Exception: 命令执行失败或接口不存在
        """
        # 检查接口是否存在且UP
        state = self._check_interface_state(interface)

        # 获取 IP 地址
        ip_address = None
        if state == "connected":
            ip_address = self._get_ip_address(interface)

        return {"state": state, "ip_address": ip_address, "extra": {}}

    def _check_interface_state(self, interface: str) -> str:
        """检查接口状态

        Args:
            interface: 接口名称

        Returns:
            "connected" | "disconnected" | "unavailable"
        """
        try:
            result = subprocess.run(
                ["ip", "link", "show", interface], capture_output=True, text=True, timeout=2
            )

            if result.returncode != 0:
                return "unavailable"

            # 检查接口是否 UP
            output = result.stdout
            if "state UP" in output or "LOWER_UP" in output:
                return "connected"
            else:
                return "disconnected"

        except subprocess.TimeoutExpired:
            logger.warning(f"Timeout checking interface {interface} state")
            return "unavailable"
        except Exception as e:
            logger.debug(f"Failed to check interface {interface} state: {e}")
            return "unavailable"

    def _get_ip_address(self, interface: str) -> Optional[str]:
        """获取接口 IP 地址

        Args:
            interface: 接口名称

        Returns:
            IP 地址字符串或 None
        """
        try:
            result = subprocess.run(
                ["ip", "addr", "show", interface], capture_output=True, text=True, timeout=2
            )

            if result.returncode != 0:
                return None

            # 解析 IP 地址（inet 192.168.1.100/24 ...）
            output = result.stdout
            match = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)", output)
            if match:
                return match.group(1)

        except subprocess.TimeoutExpired:
            logger.warning(f"Timeout getting IP address for {interface}")
        except Exception as e:
            logger.debug(f"Failed to get IP address for {interface}: {e}")

        return None
