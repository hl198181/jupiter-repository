"""Adapter Layer 基类

适配器模式：统一不同数据源（D-Bus, subprocess）的接口
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict


class DataSourceAdapter(ABC):
    """数据源适配器抽象基类

    将不同底层数据源（NetworkManager D-Bus, ModemManager D-Bus, 系统命令）
    适配为统一的接口，返回标准格式的设备信息。
    """

    @abstractmethod
    def get_device_info(self, interface: str) -> Dict[str, Any]:
        """获取网络接口的设备信息

        Args:
            interface: 接口名称（如 eth0, wlan0）

        Returns:
            设备信息字典，标准格式：
            {
                "state": str,           # "connected" | "disconnected" | "unavailable"
                "ip_address": Optional[str],  # IP 地址或 None
                "extra": dict          # 额外信息（SSID、信号强度等）
            }

        Raises:
            Exception: 数据源不可用或查询失败
        """
        pass

    def is_available(self) -> bool:
        """检查数据源是否可用

        Returns:
            True if data source is available
        """
        return True
