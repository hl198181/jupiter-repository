"""NetworkManager D-Bus Adapter

通过 D-Bus 查询 NetworkManager 获取设备信息
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .base import DataSourceAdapter

logger = logging.getLogger(__name__)


class NetworkManagerAdapter(DataSourceAdapter):
    """NetworkManager 适配器

    通过 D-Bus 查询 NetworkManager 获取设备状态、IP 地址等信息
    """

    # NetworkManager 设备状态常量
    NM_DEVICE_STATE_ACTIVATED = 100

    def __init__(self):
        self._bus = None
        self._nm_proxy = None
        self._initialized = False

    def _init_dbus(self):
        """初始化 D-Bus 连接（延迟加载）"""
        if self._initialized:
            return

        try:
            import dbus

            self._bus = dbus.SystemBus()
            self._nm_proxy = self._bus.get_object(
                "org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager"
            )
            self._initialized = True
            logger.debug("NetworkManager D-Bus initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize NetworkManager D-Bus: {e}")
            raise

    def is_available(self) -> bool:
        """检查 NetworkManager D-Bus 是否可用"""
        try:
            self._init_dbus()
            return True
        except Exception:
            return False

    def get_device_info(self, interface: str) -> Dict[str, Any]:
        """获取设备信息

        Args:
            interface: 接口名称

        Returns:
            设备信息字典

        Raises:
            Exception: D-Bus 不可用或设备未找到
        """
        self._init_dbus()

        # 查找设备
        device_path = self._find_device(interface)
        if not device_path:
            raise Exception(f"Interface {interface} not found in NetworkManager")

        # 获取设备属性
        import dbus

        device_proxy = self._bus.get_object("org.freedesktop.NetworkManager", device_path)
        props = dbus.Interface(device_proxy, "org.freedesktop.DBus.Properties")

        # 读取状态
        state = props.Get("org.freedesktop.NetworkManager.Device", "State")

        # 提取 IP 地址
        ip_address = None
        if state == self.NM_DEVICE_STATE_ACTIVATED:
            ip_address = self._extract_ip(device_proxy, props)

        # 提取额外信息（WiFi SSID、信号强度等）
        extra = self._extract_extra_info(device_proxy, props, interface)

        return {
            "state": "connected" if state == self.NM_DEVICE_STATE_ACTIVATED else "disconnected",
            "ip_address": ip_address,
            "extra": extra,
        }

    def _find_device(self, interface: str) -> Optional[str]:
        """查找设备路径

        Args:
            interface: 接口名称

        Returns:
            设备 D-Bus 路径或 None
        """
        import dbus

        nm = dbus.Interface(self._nm_proxy, "org.freedesktop.NetworkManager")
        devices = nm.GetDevices()

        for device_path in devices:
            device_proxy = self._bus.get_object("org.freedesktop.NetworkManager", device_path)
            props = dbus.Interface(device_proxy, "org.freedesktop.DBus.Properties")
            iface = props.Get("org.freedesktop.NetworkManager.Device", "Interface")

            if iface == interface:
                return device_path

        return None

    def _extract_ip(self, device_proxy, props) -> Optional[str]:
        """提取 IP 地址

        Args:
            device_proxy: 设备 D-Bus 代理
            props: 属性接口

        Returns:
            IP 地址字符串或 None
        """
        try:
            import dbus

            ip4_config_path = props.Get("org.freedesktop.NetworkManager.Device", "Ip4Config")

            if ip4_config_path == "/":
                return None

            ip4_config_proxy = self._bus.get_object(
                "org.freedesktop.NetworkManager", ip4_config_path
            )
            ip4_props = dbus.Interface(ip4_config_proxy, "org.freedesktop.DBus.Properties")
            address_data = ip4_props.Get("org.freedesktop.NetworkManager.IP4Config", "AddressData")

            if address_data:
                return address_data[0].get("address")

        except Exception as e:
            logger.debug(f"Failed to extract IP address: {e}")

        return None

    def _extract_extra_info(self, device_proxy, props, interface: str) -> Dict[str, Any]:
        """提取额外信息（WiFi SSID、信号强度等）

        Args:
            device_proxy: 设备 D-Bus 代理
            props: 属性接口
            interface: 接口名称

        Returns:
            额外信息字典
        """
        extra = {}

        # 检查是否是 WiFi 设备
        if interface.startswith("wlan"):
            extra.update(self._extract_wifi_info(device_proxy, props))

        return extra

    def _extract_wifi_info(self, device_proxy, props) -> Dict[str, Any]:
        """提取 WiFi 信息

        Args:
            device_proxy: 设备 D-Bus 代理
            props: 属性接口

        Returns:
            WiFi 信息字典
        """
        wifi_info = {}

        try:
            import dbus

            # 获取活动的 AccessPoint
            active_ap_path = props.Get(
                "org.freedesktop.NetworkManager.Device.Wireless", "ActiveAccessPoint"
            )

            if active_ap_path and active_ap_path != "/":
                ap_proxy = self._bus.get_object("org.freedesktop.NetworkManager", active_ap_path)
                ap_props = dbus.Interface(ap_proxy, "org.freedesktop.DBus.Properties")

                # SSID
                ssid_bytes = ap_props.Get("org.freedesktop.NetworkManager.AccessPoint", "Ssid")
                ssid = bytes(ssid_bytes).decode("utf-8", errors="ignore")
                wifi_info["ssid"] = ssid

                # 信号强度
                strength = ap_props.Get("org.freedesktop.NetworkManager.AccessPoint", "Strength")
                wifi_info["signal_strength"] = int(strength)

        except Exception as e:
            logger.debug(f"Failed to extract WiFi info: {e}")

        return wifi_info
