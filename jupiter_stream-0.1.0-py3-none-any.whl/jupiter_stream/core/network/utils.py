"""Network 工具函数

Network utility functions including route management.

提供路由管理和网络工具函数：
- RouteManager: 路由 metric 管理
- 辅助工具函数

Provides route management and utility functions.
"""

from __future__ import annotations

import logging
import subprocess
from typing import Dict, List, Optional

from .config import RoutingConfig
from .interface import NetworkInterface

logger = logging.getLogger(__name__)


class RouteManager:
    """路由管理器

    Route manager for adjusting interface metrics.

    功能：
    - 调整接口路由 metric
    - 确保活动接口具有最低 metric（最高优先级）
    """

    def __init__(self, config: RoutingConfig):
        """初始化路由管理器

        Args:
            config: 路由配置
        """
        self.config = config
        self._permission_warning_shown = False  # 避免重复警告

    def set_route_metric(self, interface: str, metric: int) -> bool:
        """智能设置接口路由 metric

        Set route metric for interface with intelligent cleanup.

        策略：
        1. 查询接口的所有默认路由
        2. 保留 DHCP 路由（proto dhcp）
        3. 删除所有其他手动路由（旧的 metric）
        4. 添加新的目标 metric 路由

        Args:
            interface: 接口名称
            metric: 目标 metric 值

        Returns:
            True if successful, False otherwise
        """
        if not self.config.auto_adjust_metric:
            logger.debug("Auto adjust metric disabled, skipping")
            return True

        try:
            # 1. 获取该接口的网关
            gateway = self._get_interface_gateway(interface)
            if not gateway:
                logger.warning(f"No default route found for {interface}, cannot adjust metric")
                logger.warning(f"Interface {interface} may not have internet connectivity")
                logger.warning("Check NetworkManager configuration for this interface")
                return True  # 返回 True，不阻塞流程

            # 2. 获取该接口所有默认路由
            all_routes = self._get_interface_routes(interface)

            # 3. 清理旧的手动路由（保留 DHCP）
            cleaned_count = 0
            for route in all_routes:
                if "proto dhcp" not in route:
                    # 这是手动路由，删除它
                    if self._delete_route(route):
                        cleaned_count += 1

            if cleaned_count > 0:
                logger.info(f"Cleaned {cleaned_count} old manual route(s) for {interface}")

            # 4. 添加新的 metric 路由
            replace_cmd = [
                "sudo",
                "-n",  # non-interactive mode
                "/usr/sbin/ip",  # 使用完整路径
                "route",
                "replace",
                "default",
                "via",
                gateway,
                "dev",
                interface,
                "metric",
                str(metric),
            ]

            logger.info(f"Setting route: {interface} metric {metric} (via {gateway})")
            result = subprocess.run(replace_cmd, capture_output=True, text=True, timeout=5)

            if result.returncode == 0:
                logger.info(f"✓ Set route metric for {interface}: {metric}")
                return True

            # 处理错误
            stderr = result.stderr.lower()

            # 情况 1: 权限问题
            if "operation not permitted" in stderr or "permission denied" in stderr:
                if not self._permission_warning_shown:
                    self._show_permission_warning(result.stderr)
                    self._permission_warning_shown = True
                    # 自动禁用路由调整
                    self.config.auto_adjust_metric = False
                return False

            # 情况 2: 其他错误
            else:
                logger.warning(
                    f"Failed to set route metric for {interface}: {result.stderr.strip()}"
                )
                return False

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout setting route metric for {interface}")
            return False
        except Exception as e:
            logger.error(f"Error setting route metric for {interface}: {e}")
            return False

    def _get_interface_routes(self, interface: str) -> List[str]:
        """获取接口的所有默认路由

        Get all default routes for interface.

        Args:
            interface: 接口名称

        Returns:
            路由列表，每个元素是完整的路由字符串
            例如：["default via 192.168.1.1 dev wlan0 metric 10", ...]
        """
        try:
            result = subprocess.run(
                ["ip", "route", "show", "default", "dev", interface],
                capture_output=True,
                text=True,
                timeout=2,
            )

            if result.returncode == 0 and result.stdout.strip():
                routes = [
                    line.strip() for line in result.stdout.strip().split("\n") if line.strip()
                ]
                logger.debug(f"Found {len(routes)} route(s) for {interface}")
                return routes
            return []

        except Exception as e:
            logger.debug(f"Error getting routes for {interface}: {e}")
            return []

    def _delete_route(self, route_str: str) -> bool:
        """删除指定的路由

        Delete a specific route.

        Args:
            route_str: 完整的路由字符串
                      例如 "default via 192.168.1.1 dev wlan0 metric 10"

        Returns:
            True if successful
        """
        try:
            # 解析路由字符串为命令参数
            parts = route_str.split()

            del_cmd = ["sudo", "-n", "/usr/sbin/ip", "route", "del"] + parts

            logger.debug(f"Deleting route: {route_str}")
            result = subprocess.run(del_cmd, capture_output=True, text=True, timeout=2)

            return result.returncode == 0

        except Exception as e:
            logger.debug(f"Failed to delete route: {e}")
            return False

    def _get_interface_gateway(self, interface: str) -> Optional[str]:
        """获取接口的网关地址

        Get gateway address for interface.

        Args:
            interface: 接口名称

        Returns:
            网关 IP 地址，如果没有则返回 None
        """
        try:
            # 查询该接口的默认路由
            cmd = ["ip", "route", "show", "default", "dev", interface]
            logger.debug(f"Getting gateway for {interface}: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=2,
            )

            # 详细记录命令执行结果
            logger.debug(f"Command return code: {result.returncode}")
            logger.debug(f"Command stdout: '{result.stdout}'")
            logger.debug(f"Command stderr: '{result.stderr}'")

            if result.returncode == 0 and result.stdout.strip():
                # 解析输出：default via 192.168.1.1 dev eth0 proto dhcp metric 100
                logger.debug(f"Parsing route output for {interface}")
                for line in result.stdout.strip().split("\n"):
                    logger.debug(f"Processing line: '{line}'")
                    if "via" in line:
                        parts = line.split()
                        logger.debug(f"Line parts: {parts}")
                        via_index = parts.index("via")
                        if via_index + 1 < len(parts):
                            gateway = parts[via_index + 1]
                            logger.info(f"✓ Found gateway {gateway} for {interface}")
                            return gateway

            logger.warning(
                f"No gateway found for {interface} (returncode={result.returncode}, stdout='{result.stdout.strip()}')"
            )
            return None

        except Exception as e:
            logger.warning(f"Error getting gateway for {interface}: {e}")
            return None

    def _show_permission_warning(self, error_msg: str) -> None:
        """显示权限警告信息

        Show permission warning message.

        Args:
            error_msg: 错误消息
        """
        logger.warning("=" * 70)
        logger.warning("⚠️  Network 模块权限不足，路由调整功能已自动禁用")
        logger.warning("=" * 70)
        logger.warning("当前配置启用了 routing.auto_adjust_metric，但无 sudo 权限")
        logger.warning("Network 模块将以监控模式运行（只监控状态，不控制系统流量）")
        logger.warning("")
        logger.warning("要启用完整的网络控制功能，请配置权限：")
        logger.warning("")
        logger.warning("【方案 1】应用开发者集成（推荐）")
        logger.warning("在应用的 install.sh 中添加：")
        logger.warning("")
        logger.warning(
            '  SCRIPT=$(python3 -c "import jupiter_stream; '
            "from pathlib import Path; "
            "print(Path(jupiter_stream.__file__).parent.parent / "
            "'scripts/install_network_permissions.sh')\")"
        )
        logger.warning('  sudo bash "$SCRIPT" $TARGET_USER')
        logger.warning("")
        logger.warning("【方案 2】手动配置")
        logger.warning("找到 jupiter-stream 安装目录并运行：")
        logger.warning("  sudo ./scripts/install_network_permissions.sh")
        logger.warning("")
        logger.warning("【方案 3】禁用路由调整（仅监控模式）")
        logger.warning("在配置文件中设置：")
        logger.warning("  routing:")
        logger.warning("    auto_adjust_metric: false")
        logger.warning("")
        logger.warning(f"错误详情: {error_msg.strip()}")
        logger.warning("=" * 70)

    def adjust_all_metrics(
        self, active_interface: str, interfaces: Dict[str, NetworkInterface]
    ) -> None:
        """调整所有接口的 metric

        Adjust metrics for all interfaces.

        Args:
            active_interface: 当前活动接口
            interfaces: 所有接口字典
        """
        if not self.config.auto_adjust_metric:
            return

        try:
            # 1. 活动接口使用最低 metric
            if active_interface and active_interface in interfaces:
                self.set_route_metric(active_interface, self.config.active_metric)

            # 2. 其他配置的接口使用配置的 metric
            for name, iface in interfaces.items():
                if name != active_interface:
                    metric = iface.config.route_metric
                    self.set_route_metric(name, metric)

            # 3. 将所有未配置的接口 metric 调高，避免干扰
            self._suppress_unconfigured_interfaces(interfaces)

        except Exception as e:
            logger.error(f"Error adjusting metrics: {e}")

    def _suppress_unconfigured_interfaces(
        self, configured_interfaces: Dict[str, NetworkInterface]
    ) -> None:
        """将未配置的接口 metric 调高

        Suppress unconfigured interfaces by setting high metric.

        系统中可能存在未在配置文件中列出的网络接口（如 usb0, rndis0 等），
        这些接口可能有较低的 metric，干扰已配置接口的优先级。
        此方法将这些接口的 metric 调整为 900，确保它们不会被优先使用。

        Args:
            configured_interfaces: 已配置的接口字典
        """
        try:
            # 获取系统中所有有默认路由的接口
            result = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True,
                text=True,
                timeout=2,
            )

            if result.returncode != 0:
                return

            # 解析所有默认路由的接口名
            # 输出格式：default via 192.168.1.1 dev eth0 proto dhcp metric 100
            system_interfaces = set()
            for line in result.stdout.strip().split("\n"):
                if "dev" in line:
                    parts = line.split()
                    try:
                        dev_index = parts.index("dev")
                        if dev_index + 1 < len(parts):
                            iface_name = parts[dev_index + 1]
                            system_interfaces.add(iface_name)
                    except (ValueError, IndexError):
                        continue

            # 找出未配置的接口
            configured_names = set(configured_interfaces.keys())
            unconfigured = system_interfaces - configured_names

            if unconfigured:
                logger.info(f"Found unconfigured interfaces with default routes: {unconfigured}")
                logger.info("Adjusting their metrics to 900 to avoid interference")

                for iface in unconfigured:
                    # 跳过特殊接口
                    if iface in ("lo", "docker0", "virbr0"):
                        continue

                    # 调整为高 metric
                    self.set_route_metric(iface, 900)

        except Exception as e:
            logger.debug(f"Failed to suppress unconfigured interfaces: {e}")


# 辅助工具函数


def get_interface_type(interface_name: str) -> str:
    """获取接口类型

    Get interface type from name.

    Args:
        interface_name: 接口名称

    Returns:
        'ethernet', 'wifi', 'modem', or 'unknown'
    """
    if interface_name.startswith("eth"):
        return "ethernet"
    elif interface_name.startswith("wlan") or interface_name.startswith("wl"):
        return "wifi"
    elif interface_name.startswith("usb") or interface_name.startswith("wwan"):
        return "modem"
    else:
        return "unknown"
