"""NetworkManager Detection Strategy

使用 NetworkManager D-Bus 检测接口状态
"""

from __future__ import annotations

import logging
from typing import Optional

from ..adapter import NetworkManagerAdapter
from .base import DetectionStrategy

logger = logging.getLogger(__name__)


class NetworkManagerStrategy(DetectionStrategy):
    """NetworkManager 检测策略

    通过 NetworkManager D-Bus API 检测接口状态
    适用于受 NetworkManager 管理的接口（wlan0, eth0, ppp0）
    """

    def __init__(self):
        super().__init__("NetworkManager")
        self._adapter = NetworkManagerAdapter()

    def can_handle(self, interface: str) -> bool:
        """检查 NetworkManager 是否能处理此接口

        Args:
            interface: 接口名称

        Returns:
            True if NetworkManager can handle this interface
        """
        if not self._adapter.is_available():
            return False

        try:
            # 尝试获取设备信息，如果成功说明 NM 管理此接口
            self._adapter.get_device_info(interface)
            return True
        except Exception as e:
            logger.debug(f"NetworkManager cannot handle {interface}: {e}")
            return False

    def is_connected(self, interface: str) -> bool:
        """检测接口是否已连接

        Args:
            interface: 接口名称

        Returns:
            True if connected

        Raises:
            Exception: 检测失败
        """
        info = self._adapter.get_device_info(interface)
        is_conn = info["state"] == "connected"
        logger.debug(f"[{self.name}] {interface} is_connected: {is_conn}")
        return is_conn

    def get_ip_address(self, interface: str) -> Optional[str]:
        """获取接口 IP 地址

        Args:
            interface: 接口名称

        Returns:
            IP 地址或 None

        Raises:
            Exception: 检测失败
        """
        info = self._adapter.get_device_info(interface)
        ip = info["ip_address"]
        logger.debug(f"[{self.name}] {interface} IP: {ip}")
        return ip
