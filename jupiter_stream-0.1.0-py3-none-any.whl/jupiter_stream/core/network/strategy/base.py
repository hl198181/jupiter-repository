"""Strategy Layer 基类

策略模式：封装不同的接口检测方法
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Optional

logger = logging.getLogger(__name__)


class DetectionStrategy(ABC):
    """接口检测策略抽象基类

    每个策略封装一种检测方法（NetworkManager D-Bus, IP 地址检测等）
    """

    def __init__(self, name: str):
        """初始化策略

        Args:
            name: 策略名称（用于日志）
        """
        self.name = name

    @abstractmethod
    def can_handle(self, interface: str) -> bool:
        """判断此策略是否能处理指定接口

        Args:
            interface: 接口名称

        Returns:
            True if this strategy can handle the interface
        """
        pass

    @abstractmethod
    def is_connected(self, interface: str) -> bool:
        """检测接口是否已连接

        Args:
            interface: 接口名称

        Returns:
            True if interface is connected

        Raises:
            Exception: 检测失败
        """
        pass

    @abstractmethod
    def get_ip_address(self, interface: str) -> Optional[str]:
        """获取接口 IP 地址

        Args:
            interface: 接口名称

        Returns:
            IP 地址字符串，如果未连接则返回 None

        Raises:
            Exception: 检测失败
        """
        pass
