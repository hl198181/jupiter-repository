"""IP Address Detection Strategy

使用系统命令检测接口 IP 地址
"""

from __future__ import annotations

import logging
from typing import Optional

from ..adapter import SystemCommandAdapter
from .base import DetectionStrategy

logger = logging.getLogger(__name__)


class IPAddressStrategy(DetectionStrategy):
    """IP 地址检测策略

    通过 ip 命令检测接口状态和 IP 地址
    作为最后的 fallback 策略，适用于所有接口
    """

    def __init__(self):
        super().__init__("IPAddress")
        self._adapter = SystemCommandAdapter()

    def can_handle(self, interface: str) -> bool:
        """检查是否能处理此接口

        IPAddressStrategy 是通用策略，总是返回 True

        Args:
            interface: 接口名称

        Returns:
            True (always)
        """
        return self._adapter.is_available()

    def is_connected(self, interface: str) -> bool:
        """检测接口是否已连接

        检查条件：
        1. 接口存在
        2. 接口状态为 UP
        3. 接口有 IP 地址

        Args:
            interface: 接口名称

        Returns:
            True if connected

        Raises:
            Exception: 检测失败
        """
        info = self._adapter.get_device_info(interface)

        # 接口必须是 connected 状态且有 IP 地址
        is_conn = info["state"] == "connected" and info["ip_address"] is not None

        logger.debug(
            f"[{self.name}] {interface} is_connected: {is_conn} "
            f"(state={info['state']}, ip={info['ip_address']})"
        )
        return is_conn

    def get_ip_address(self, interface: str) -> Optional[str]:
        """获取接口 IP 地址

        Args:
            interface: 接口名称

        Returns:
            IP 地址或 None

        Raises:
            Exception: 检测失败
        """
        info = self._adapter.get_device_info(interface)
        ip = info["ip_address"]
        logger.debug(f"[{self.name}] {interface} IP: {ip}")
        return ip
