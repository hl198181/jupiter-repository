"""Strategy Chain

责任链模式：自动选择最佳检测策略并 fallback
"""

from __future__ import annotations

import logging
from typing import List, Optional

from .base import DetectionStrategy

logger = logging.getLogger(__name__)


class StrategyChain:
    """策略责任链

    按优先级依次尝试多个检测策略，直到找到能处理的策略。
    缓存成功的策略以提高后续检测性能。
    """

    def __init__(self, strategies: List[DetectionStrategy]):
        """初始化策略链

        Args:
            strategies: 策略列表，按优先级排序（高优先级在前）
        """
        self._strategies = strategies
        self._active_strategy: Optional[DetectionStrategy] = None

    def is_connected(self, interface: str) -> bool:
        """检测接口是否已连接

        按策略优先级依次尝试，直到成功。
        缓存成功的策略以优化后续调用。

        Args:
            interface: 接口名称

        Returns:
            True if connected

        Raises:
            Exception: 所有策略都失败
        """
        # 优先尝试缓存的策略
        if self._active_strategy:
            try:
                if self._active_strategy.can_handle(interface):
                    return self._active_strategy.is_connected(interface)
                else:
                    logger.debug(
                        f"Active strategy {self._active_strategy.name} "
                        f"can no longer handle {interface}, falling back"
                    )
                    self._active_strategy = None
            except Exception as e:
                logger.warning(
                    f"Active strategy {self._active_strategy.name} failed: {e}, "
                    f"falling back to next strategy"
                )
                self._active_strategy = None

        # 依次尝试所有策略
        for strategy in self._strategies:
            try:
                if not strategy.can_handle(interface):
                    logger.debug(f"Strategy {strategy.name} cannot handle {interface}, skipping")
                    continue

                result = strategy.is_connected(interface)
                self._active_strategy = strategy  # 缓存成功的策略
                logger.debug(f"Strategy {strategy.name} succeeded for {interface}")
                return result

            except Exception as e:
                logger.warning(
                    f"Strategy {strategy.name} failed for {interface}: {e}, "
                    f"trying next strategy"
                )
                continue

        # 所有策略都失败
        strategies_tried = ", ".join(s.name for s in self._strategies)
        raise Exception(f"All strategies failed for {interface}. Tried: {strategies_tried}")

    def get_ip_address(self, interface: str) -> Optional[str]:
        """获取接口 IP 地址

        使用与 is_connected() 相同的策略选择逻辑

        Args:
            interface: 接口名称

        Returns:
            IP 地址或 None

        Raises:
            Exception: 所有策略都失败
        """
        # 优先尝试缓存的策略
        if self._active_strategy:
            try:
                if self._active_strategy.can_handle(interface):
                    return self._active_strategy.get_ip_address(interface)
                else:
                    self._active_strategy = None
            except Exception as e:
                logger.warning(f"Active strategy {self._active_strategy.name} failed: {e}")
                self._active_strategy = None

        # 依次尝试所有策略
        for strategy in self._strategies:
            try:
                if not strategy.can_handle(interface):
                    continue

                result = strategy.get_ip_address(interface)
                self._active_strategy = strategy
                return result

            except Exception as e:
                logger.warning(f"Strategy {strategy.name} failed for {interface}: {e}")
                continue

        # 所有策略都失败
        strategies_tried = ", ".join(s.name for s in self._strategies)
        raise Exception(f"All strategies failed for {interface}. Tried: {strategies_tried}")
