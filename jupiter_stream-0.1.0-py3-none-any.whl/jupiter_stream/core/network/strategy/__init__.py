"""Strategy Layer

策略层：封装不同的接口检测方法
"""

from .base import DetectionStrategy
from .chain import StrategyChain
from .ip_strategy import IPAddressStrategy
from .nm_strategy import NetworkManagerStrategy

__all__ = [
    "DetectionStrategy",
    "NetworkManagerStrategy",
    "IPAddressStrategy",
    "StrategyChain",
]
