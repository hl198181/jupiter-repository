"""Network 模块异常类

Network module exception hierarchy.

提供网络模块的异常层次结构，包括：
- 基础异常
- 配置错误
- D-Bus 通信错误
- 接口错误（WiFi、Modem 等）
- 路由管理错误

Provides exception hierarchy for network module.
"""

from __future__ import annotations


class NetworkError(Exception):
    """Network 基础异常

    Base exception for network module.
    """

    pass


class NetworkConfigError(NetworkError):
    """配置错误

    Configuration error.
    """

    pass


class NetworkDetectorError(NetworkError):
    """D-Bus 监听器错误

    Detector error.
    """

    pass


class NetworkInterfaceError(NetworkError):
    """网络接口错误

    Interface error.
    """

    pass


class WiFiError(NetworkInterfaceError):
    """WiFi 接口错误

    WiFi interface error.
    """

    pass


class WiFiAuthError(WiFiError):
    """WiFi 认证失败（密码错误）

    WiFi authentication failed (wrong password).
    """

    pass


class WiFiTimeoutError(WiFiError):
    """WiFi 连接超时

    WiFi connection timeout.
    """

    pass


class WiFiNotFoundError(WiFiError):
    """SSID 未找到

    SSID not found.
    """

    pass


class ModemError(NetworkInterfaceError):
    """Modem 接口错误

    Modem interface error.
    """

    pass


class ModemSIMError(ModemError):
    """SIM 卡错误（未插入或未识别）

    SIM card error (missing or unrecognized).
    """

    pass


class ModemSignalError(ModemError):
    """信号错误（无信号或信号太弱）

    Signal error (no signal or too weak).
    """

    pass


class ModemRegistrationError(ModemError):
    """网络注册失败

    Network registration failed.
    """

    pass


class NetworkRouteError(NetworkError):
    """路由管理错误

    Route management error.
    """

    pass


class NetworkDBusError(NetworkError):
    """D-Bus 通信错误

    D-Bus communication error.
    """

    pass
