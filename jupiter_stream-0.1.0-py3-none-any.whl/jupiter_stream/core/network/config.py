"""Network 模块配置

Network module configuration models using Pydantic.

提供网络模块的配置数据模型：
- InterfaceConfig: 接口配置
- RoutingConfig: 路由管理配置
- ConnectivityCheckConfig: 连通性检查配置
- NetworkConfig: 网络管理器总配置

Provides configuration models for network module.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

try:
    from pydantic import BaseModel, Field, field_validator
except ImportError:
    raise ImportError(
        "pydantic is required for Network module. "
        "Install with: pip install jupiter-stream[network]"
    )


class ConnectivityTarget(BaseModel):
    """连通性检查目标

    Connectivity check target configuration.
    """

    url: Optional[str] = None
    """HTTP(S) URL for connectivity check"""

    host: Optional[str] = None
    """Host for ping check (only used when method=ping)"""

    timeout: int = 5
    """Timeout in seconds"""

    @field_validator("url", "host")
    @classmethod
    def validate_target(cls, v, info):
        """验证至少有一个目标配置"""
        # Pydantic v2 compatibility
        if info.field_name == "host" and v is None:
            # 如果 host 为 None，检查 url 是否有值（在完整验证时）
            return v
        return v


class ConnectivityCheckConfig(BaseModel):
    """连通性检查配置

    Connectivity check configuration.

    用于验证网络是否真正可用（能访问互联网）。
    """

    enabled: bool = True
    """是否启用连通性检查（False 时只检查接口连接状态）"""

    method: Literal["http", "ping"] = "http"
    """检查方法: http（推荐）或 ping"""

    retry_interval: int = 2
    """重试间隔（秒），用于 wait_for_network"""

    targets: List[ConnectivityTarget] = Field(
        default_factory=lambda: [
            ConnectivityTarget(url="https://www.google.com/generate_204", timeout=5),
        ]
    )
    """目标服务器列表（按顺序尝试，任意成功即可）"""


class InterfaceConfig(BaseModel):
    """网络接口配置

    Network interface configuration.
    """

    name: str
    """接口名称（如 'eth0', 'wlan0', 'usb0'）"""

    enabled: bool = True
    """是否启用此接口"""

    route_metric: int = 100
    """路由 metric 值（数值越小优先级越高）"""

    modem_device: Optional[str] = None
    """Modem 设备路径（仅用于 4G 接口，如 'ttyUSB2'）"""


class RoutingConfig(BaseModel):
    """路由管理配置

    Routing management configuration.
    """

    auto_adjust_metric: bool = True
    """是否自动调整路由 metric"""

    active_metric: int = 50
    """活动接口强制使用的 metric 值"""


class NetworkConfig(BaseModel):
    """网络管理器配置

    NetworkManager configuration.

    完整的网络管理器配置，包括：
    - 接口优先级列表
    - 接口详细配置
    - 监控配置
    - 路由管理
    - 连通性检查
    """

    interface_priority: List[str] = Field(default_factory=lambda: ["eth0", "wlan0", "usb0"])
    """接口优先级列表（数组顺序即优先级，越前越高）"""

    interfaces: Dict[str, InterfaceConfig] = Field(default_factory=dict)
    """接口详细配置字典"""

    monitoring: Dict[str, Any] = Field(
        default_factory=lambda: {
            "event_driven": True,
            "health_check_interval": 30.0,
        }
    )
    """监控配置"""

    routing: RoutingConfig = Field(default_factory=RoutingConfig)
    """路由管理配置"""

    connectivity_check: ConnectivityCheckConfig = Field(default_factory=ConnectivityCheckConfig)
    """连通性检查配置"""

    @field_validator("interfaces", mode="before")
    @classmethod
    def convert_interfaces(cls, v):
        """转换接口配置格式

        支持从字典自动创建 InterfaceConfig 对象
        """
        if isinstance(v, dict):
            result = {}
            for name, config in v.items():
                if isinstance(config, InterfaceConfig):
                    result[name] = config
                elif isinstance(config, dict):
                    # 自动添加 name 字段
                    config_with_name = {"name": name, **config}
                    result[name] = InterfaceConfig(**config_with_name)
                else:
                    raise ValueError(f"Invalid interface config for {name}")
            return result
        return v

    @classmethod
    def from_dict(cls, config_dict: dict) -> NetworkConfig:
        """从字典创建配置

        Create configuration from dictionary.

        Args:
            config_dict: 配置字典

        Returns:
            NetworkConfig 实例
        """
        return cls(**config_dict)

    def get_enabled_interfaces(self) -> List[str]:
        """获取已启用的接口列表

        Get list of enabled interfaces in priority order.

        Returns:
            已启用接口名称列表（按优先级排序）
        """
        enabled = []
        for iface_name in self.interface_priority:
            # 检查接口是否在配置中且已启用
            if iface_name in self.interfaces:
                if self.interfaces[iface_name].enabled:
                    enabled.append(iface_name)
            else:
                # 接口不在详细配置中，默认启用
                enabled.append(iface_name)
        return enabled

    @property
    def health_check_interval(self) -> float:
        """获取健康检查间隔

        Get health check interval from monitoring config.

        Returns:
            健康检查间隔（秒）
        """
        return self.monitoring.get("health_check_interval", 30.0)

    def get_interface_config(self, name: str) -> InterfaceConfig:
        """获取接口配置

        Get configuration for specific interface.

        Args:
            name: 接口名称

        Returns:
            InterfaceConfig 实例（如果不存在则使用默认值）
        """
        if name in self.interfaces:
            return self.interfaces[name]

        # 返回默认配置
        return InterfaceConfig(
            name=name,
            enabled=True,
            route_metric=100,
        )

    @classmethod
    def from_yaml(cls, file_path: str) -> NetworkConfig:
        """从 YAML 文件加载配置

        Load configuration from YAML file.

        Args:
            file_path: YAML 配置文件路径

        Returns:
            NetworkConfig 实例
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load YAML config. " "Install with: pip install pyyaml"
            )

        with open(file_path, encoding="utf-8") as f:
            config_dict = yaml.safe_load(f)

        # 支持顶层 'network' 键或直接配置
        if "network" in config_dict:
            config_dict = config_dict["network"]

        return cls(**config_dict)

    @classmethod
    def from_json(cls, file_path: str) -> NetworkConfig:
        """从 JSON 文件加载配置

        Load configuration from JSON file.

        Args:
            file_path: JSON 配置文件路径

        Returns:
            NetworkConfig 实例
        """
        import json

        with open(file_path, encoding="utf-8") as f:
            config_dict = json.load(f)

        # 支持顶层 'network' 键或直接配置
        if "network" in config_dict:
            config_dict = config_dict["network"]

        return cls(**config_dict)

    @classmethod
    def from_file(cls, file_path: str) -> NetworkConfig:
        """从文件加载配置（自动检测格式）

        Load configuration from file (auto-detect format).

        Args:
            file_path: 配置文件路径

        Returns:
            NetworkConfig 实例
        """
        from pathlib import Path

        file_path = Path(file_path)
        suffix = file_path.suffix.lower()

        if suffix in [".yaml", ".yml"]:
            return cls.from_yaml(str(file_path))
        elif suffix == ".json":
            return cls.from_json(str(file_path))
        else:
            raise ValueError(f"Unsupported config file format: {suffix}")
