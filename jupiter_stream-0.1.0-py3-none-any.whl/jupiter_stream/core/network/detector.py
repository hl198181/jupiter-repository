"""Network 事件检测器

Network event detector using D-Bus signals.

提供基于 D-Bus 的网络事件监听功能：
- NetworkManager 设备状态变化监听
- ModemManager Modem 添加/移除监听
- 后台线程运行

Provides D-Bus-based network event listening.
"""

from __future__ import annotations

import logging
import threading
from typing import Callable, Dict, List, Optional

from .exceptions import NetworkDetectorError

logger = logging.getLogger(__name__)


class NetworkDetector:
    """D-Bus 事件监听器（观察者模式）

    D-Bus event listener for NetworkManager and ModemManager.

    事件类型:
    - device_state_changed: 设备状态变化
    - modem_added: 4G Modem 添加
    - modem_removed: 4G Modem 移除
    """

    # NetworkManager 设备状态常量
    STATE_UNKNOWN = 0
    STATE_UNMANAGED = 10
    STATE_UNAVAILABLE = 20
    STATE_DISCONNECTED = 30
    STATE_PREPARE = 40
    STATE_CONFIG = 50
    STATE_NEED_AUTH = 60
    STATE_IP_CONFIG = 70
    STATE_IP_CHECK = 80
    STATE_SECONDARIES = 90
    STATE_ACTIVATED = 100
    STATE_DEACTIVATING = 110
    STATE_FAILED = 120

    def __init__(self):
        """初始化事件监听器"""
        self._callbacks: Dict[str, List[Callable]] = {
            "device_state_changed": [],
            "modem_added": [],
            "modem_removed": [],
        }

        self._bus = None
        self._main_loop = None
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def on_device_state_changed(self, callback: Callable[[str, int, int, int], None]) -> None:
        """注册设备状态变化回调

        Register callback for device state change events.

        Args:
            callback: 回调函数 (interface, new_state, old_state, reason) -> None
        """
        self._callbacks["device_state_changed"].append(callback)

    def on_modem_added(self, callback: Callable[[str], None]) -> None:
        """注册 Modem 添加回调

        Register callback for modem added events.

        Args:
            callback: 回调函数 (modem_path) -> None
        """
        self._callbacks["modem_added"].append(callback)

    def on_modem_removed(self, callback: Callable[[str], None]) -> None:
        """注册 Modem 移除回调

        Register callback for modem removed events.

        Args:
            callback: 回调函数 (modem_path) -> None
        """
        self._callbacks["modem_removed"].append(callback)

    def start(self) -> None:
        """启动事件监听（后台线程）

        Start event listening in background thread.
        """
        if self._running:
            logger.warning("NetworkDetector already running")
            return

        try:
            # 尝试连接 D-Bus
            import dbus
            from dbus.mainloop.glib import DBusGMainLoop
            from gi.repository import GLib

            DBusGMainLoop(set_as_default=True)
            self._bus = dbus.SystemBus()

            # 注册 NetworkManager 信号
            # 使用 path_keyword 获取信号源的路径
            self._bus.add_signal_receiver(
                self._on_device_state_changed_signal,
                dbus_interface="org.freedesktop.NetworkManager.Device",
                signal_name="StateChanged",
                path_keyword="device_path",  # 将设备路径作为关键字参数传递
            )

            # 注册 ModemManager 信号
            try:
                self._bus.add_signal_receiver(
                    self._on_modem_added_signal,
                    dbus_interface="org.freedesktop.ModemManager1",
                    signal_name="ObjectAdded",
                )
                self._bus.add_signal_receiver(
                    self._on_modem_removed_signal,
                    dbus_interface="org.freedesktop.ModemManager1",
                    signal_name="ObjectRemoved",
                )
            except Exception as e:
                logger.debug(f"Failed to register ModemManager signals: {e}")

            # 创建主循环
            self._main_loop = GLib.MainLoop()

            # 启动后台线程
            self._running = True
            self._thread = threading.Thread(target=self._run_loop, daemon=True)
            self._thread.start()

            logger.info("NetworkDetector started")

        except ImportError as e:
            raise NetworkDetectorError(
                f"D-Bus dependencies not available: {e}. "
                "Install with: pip install dbus-python PyGObject"
            )
        except Exception as e:
            raise NetworkDetectorError(f"Failed to start NetworkDetector: {e}")

    def stop(self) -> None:
        """停止事件监听

        Stop event listening.
        """
        if not self._running:
            return

        self._running = False

        if self._main_loop:
            self._main_loop.quit()

        if self._thread:
            self._thread.join(timeout=2.0)

        logger.info("NetworkDetector stopped")

    def _run_loop(self) -> None:
        """运行 GLib 主循环（后台线程中）"""
        try:
            self._main_loop.run()
        except Exception as e:
            logger.error(f"Error in NetworkDetector main loop: {e}")
        finally:
            self._running = False

    def _on_device_state_changed_signal(
        self, new_state: int, old_state: int, reason: int, device_path: str = None
    ) -> None:
        """处理 NetworkManager 设备状态变化信号

        Args:
            new_state: 新状态
            old_state: 旧状态
            reason: 变化原因
            device_path: D-Bus 设备路径（由 path_keyword 提供）
        """
        try:
            import dbus

            if not device_path:
                logger.warning("No device path in StateChanged signal")
                return

            # 查询设备的 Interface 属性
            interface = None
            try:
                device_proxy = self._bus.get_object("org.freedesktop.NetworkManager", device_path)
                props = dbus.Interface(device_proxy, "org.freedesktop.DBus.Properties")
                interface = props.Get("org.freedesktop.NetworkManager.Device", "Interface")
            except dbus.exceptions.DBusException as e:
                # 设备对象可能已被删除（临时设备、P2P 设备等）
                # 常见错误：UnknownMethod (设备不存在), UnknownObject (对象已删除)
                error_name = e.get_dbus_name() if hasattr(e, "get_dbus_name") else str(e)
                if "UnknownMethod" in error_name or "UnknownObject" in error_name:
                    logger.debug(f"Device at {device_path} no longer exists, ignoring signal")
                    return
                # 其他 D-Bus 错误也记录后忽略（无法获取 interface 则无法处理）
                logger.warning(f"Failed to get interface for {device_path}: {e}")
                return

            # 确保获取到了有效的接口名
            if not interface:
                logger.warning(f"Got empty interface name for {device_path}")
                return

            logger.debug(
                f"Device state changed: {interface} {old_state} -> {new_state} (reason: {reason})"
            )

            # 触发所有注册的回调
            for callback in self._callbacks["device_state_changed"]:
                try:
                    callback(interface, new_state, old_state, reason)
                except Exception as e:
                    logger.error(f"Error in device_state_changed callback: {e}")

        except Exception as e:
            logger.error(f"Error handling device state changed signal: {e}")

    def _on_modem_added_signal(self, modem_path: str) -> None:
        """处理 ModemManager Modem 添加信号"""
        try:
            for callback in self._callbacks["modem_added"]:
                try:
                    callback(modem_path)
                except Exception as e:
                    logger.error(f"Error in modem_added callback: {e}")

        except Exception as e:
            logger.error(f"Error handling modem added signal: {e}")

    def _on_modem_removed_signal(self, modem_path: str) -> None:
        """处理 ModemManager Modem 移除信号"""
        try:
            for callback in self._callbacks["modem_removed"]:
                try:
                    callback(modem_path)
                except Exception as e:
                    logger.error(f"Error in modem_removed callback: {e}")

        except Exception as e:
            logger.error(f"Error handling modem removed signal: {e}")
