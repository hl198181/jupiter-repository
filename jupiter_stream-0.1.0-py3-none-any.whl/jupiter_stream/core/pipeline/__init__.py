"""
Pipeline 领域核心模块

包含 Pipeline 处理流程的所有核心组件：
- 数据结构：Frame
- 抽象基类：Source, Processor, Sink
- 核心逻辑：Pipeline, PipelineManager
- 工厂系统：ComponentFactory, ComponentRegistry
- 构建器：PipelineBuilder
"""

from .builder import PipelineBuilder
from .factory import ComponentFactory
from .frame import Frame, create_frame
from .manager import ManagedPipeline, PipelineManager
from .pipeline import Pipeline
from .processor import Processor, ProcessorChain
from .registry import (
    ComponentRegistry,
    register_processor,
    register_sink,
    register_source,
)
from .sink import Sink
from .source import Source

__all__ = [
    # 数据结构
    "Frame",
    "create_frame",
    # 抽象基类
    "Source",
    "Processor",
    "ProcessorChain",
    "Sink",
    # 核心逻辑
    "Pipeline",
    "PipelineManager",
    "ManagedPipeline",
    # 工厂系统
    "ComponentFactory",
    "ComponentRegistry",
    "register_source",
    "register_processor",
    "register_sink",
    # 构建器
    "PipelineBuilder",
]
