"""Abstract base class for frame sinks (outputs)."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod

from .frame import Frame


class Sink(ABC):
    """
    帧输出抽象基类

    Sink 定义了统一的帧输出接口，用于将处理后的帧输出到各种目标：
    - 显示窗口
    - 文件
    - 流媒体服务器
    - 回调函数

    Attributes:
        name: Sink 名称（用于查找）
        enabled: 是否启用输出
        logger: 日志记录器
        _output_count: 已输出的帧数

    Examples:
        >>> class MySink(Sink):
        ...     def write(self, frame: Frame):
        ...         print(f"Output frame {frame.frame_id}")
        ...
        ...     def is_active(self) -> bool:
        ...         return True
        ...
        ...     def close(self):
        ...         pass
    """

    def __init__(self, enabled: bool = True):
        """
        初始化输出

        Args:
            enabled: 是否启用输出（默认启用）
        """
        self.name: str | None = None  # 由 factory 设置
        self.enabled = enabled
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._output_count = 0

    @abstractmethod
    def write(self, frame: Frame):
        """
        写入帧

        Args:
            frame: 要输出的帧

        Note:
            子类必须实现此方法
        """
        pass

    @abstractmethod
    def is_active(self) -> bool:
        """
        检查输出是否激活

        Returns:
            如果输出正常工作则返回 True，否则返回 False

        Note:
            子类必须实现此方法
        """
        pass

    @abstractmethod
    def close(self):
        """
        关闭输出，释放资源

        Note:
            子类必须实现此方法
        """
        pass

    def __call__(self, frame: Frame):
        """
        调用输出（支持函数式调用）

        Args:
            frame: 要输出的帧

        Examples:
            >>> sink = MySink()
            >>> sink(frame)
        """
        if not self.enabled:
            return

        try:
            self.write(frame)
            self._output_count += 1
        except Exception as e:
            self.logger.error(f"Error writing frame {frame.frame_id}: {e}")

    def enable(self):
        """启用输出"""
        self.enabled = True
        self.logger.info(f"{self.__class__.__name__} enabled")

    def disable(self):
        """禁用输出"""
        self.enabled = False
        self.logger.info(f"{self.__class__.__name__} disabled")

    def __enter__(self) -> Sink:
        """上下文管理器：进入"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器：退出"""
        self.close()

    def __repr__(self) -> str:
        status = "enabled" if self.enabled else "disabled"
        name_str = f", name='{self.name}'" if self.name else ""
        return f"{self.__class__.__name__}({status}{name_str})"

    def get_stats(self) -> dict:
        """
        获取统计信息

        Returns:
            包含统计信息的字典
        """
        return {
            "sink": self.__class__.__name__,
            "name": self.name,
            "enabled": self.enabled,
            "output_count": self._output_count,
            "is_active": self.is_active(),
        }
