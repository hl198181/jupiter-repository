"""组件注册表 / Component Registry

使用注册表模式实现组件的自动发现和管理。
Component auto-discovery and management using Registry Pattern.
"""

from __future__ import annotations

import logging
from typing import Callable, Dict, List

logger = logging.getLogger(__name__)


class ComponentRegistry:
    """组件注册表 / Component Registry

    全局单例，管理所有可用的 Source、Processor、Sink 组件。
    Global singleton managing all available components.
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._sources: Dict[str, type] = {}
        self._processors: Dict[str, type] = {}
        self._sinks: Dict[str, type] = {}
        self._templates: Dict[str, Callable] = {}
        self._initialized = True

        logger.debug("ComponentRegistry initialized")

    # ========== 注册方法 ==========

    def register_source(self, name: str, cls: type) -> None:
        """注册 Source 类

        Args:
            name: 组件名称（在配置文件中使用）
            cls: Source 类
        """
        self._sources[name] = cls
        logger.debug(f"Registered source: {name} -> {cls}")

    def register_processor(self, name: str, cls: type) -> None:
        """注册 Processor 类

        Args:
            name: 组件名称（在配置文件中使用）
            cls: Processor 类
        """
        self._processors[name] = cls
        logger.debug(f"Registered processor: {name} -> {cls}")

    def register_sink(self, name: str, cls: type) -> None:
        """注册 Sink 类

        Args:
            name: 组件名称（在配置文件中使用）
            cls: Sink 类
        """
        self._sinks[name] = cls
        logger.debug(f"Registered sink: {name} -> {cls}")

    def register_template(self, name: str, func: Callable) -> None:
        """注册模板函数

        Args:
            name: 模板名称（在配置文件中使用）
            func: 模板函数
        """
        self._templates[name] = func
        logger.debug(f"Registered template: {name} -> {func}")

    # ========== 获取方法 ==========

    def get_source(self, name: str) -> type:
        """获取 Source 类

        Args:
            name: 组件名称

        Returns:
            Source 类

        Raises:
            KeyError: 如果组件未注册
        """
        if name not in self._sources:
            raise KeyError(
                f"Unknown source type: {name}. " f"Available: {list(self._sources.keys())}"
            )
        return self._sources[name]

    def get_processor(self, name: str) -> type:
        """获取 Processor 类

        Args:
            name: 组件名称

        Returns:
            Processor 类

        Raises:
            KeyError: 如果组件未注册
        """
        if name not in self._processors:
            raise KeyError(
                f"Unknown processor type: {name}. " f"Available: {list(self._processors.keys())}"
            )
        return self._processors[name]

    def get_sink(self, name: str) -> type:
        """获取 Sink 类

        Args:
            name: 组件名称

        Returns:
            Sink 类

        Raises:
            KeyError: 如果组件未注册
        """
        if name not in self._sinks:
            raise KeyError(f"Unknown sink type: {name}. " f"Available: {list(self._sinks.keys())}")
        return self._sinks[name]

    def get_template(self, name: str) -> Callable:
        """获取模板函数

        Args:
            name: 模板名称

        Returns:
            模板函数

        Raises:
            KeyError: 如果模板未注册
        """
        if name not in self._templates:
            raise KeyError(
                f"Unknown template: {name}. " f"Available: {list(self._templates.keys())}"
            )
        return self._templates[name]

    # ========== 列出所有组件 ==========

    def list_sources(self) -> List[str]:
        """列出所有已注册的 Source 类型"""
        return list(self._sources.keys())

    def list_processors(self) -> List[str]:
        """列出所有已注册的 Processor 类型"""
        return list(self._processors.keys())

    def list_sinks(self) -> List[str]:
        """列出所有已注册的 Sink 类型"""
        return list(self._sinks.keys())

    def list_templates(self) -> List[str]:
        """列出所有已注册的模板函数"""
        return list(self._templates.keys())

    # ========== 清理方法（用于测试）==========

    def clear(self) -> None:
        """清空所有注册（仅用于测试）"""
        self._sources.clear()
        self._processors.clear()
        self._sinks.clear()
        self._templates.clear()
        logger.debug("ComponentRegistry cleared")


# 全局单例实例
registry = ComponentRegistry()


# ========== 装饰器语法糖 ==========


def register_source(name: str):
    """装饰器：注册 Source 类

    Example:
        @register_source("VideoSource")
        class VideoSource(Source):
            pass
    """

    def decorator(cls):
        registry.register_source(name, cls)
        return cls

    return decorator


def register_processor(name: str):
    """装饰器：注册 Processor 类

    Example:
        @register_processor("Resize")
        class Resize(Processor):
            pass
    """

    def decorator(cls):
        registry.register_processor(name, cls)
        return cls

    return decorator


def register_sink(name: str):
    """装饰器：注册 Sink 类

    Example:
        @register_sink("DisplaySink")
        class DisplaySink(Sink):
            pass
    """

    def decorator(cls):
        registry.register_sink(name, cls)
        return cls

    return decorator


def register_template(name: str):
    """装饰器：注册模板函数

    Example:
        @register_template("frame_counter")
        def frame_counter(frame):
            return f"Frame: {frame.frame_id}"
    """

    def decorator(func):
        registry.register_template(name, func)
        return func

    return decorator


# ========== 自动注册内置组件 ==========


def auto_register_components():
    """自动注册所有内置组件

    这个函数在模块导入时自动调用，注册所有内置组件。
    如果某个组件导入失败（例如缺少可选依赖），会记录详细错误信息。
    """
    # 延迟导入，避免循环依赖
    # Sources
    from ..sources import FolderSource, ImageFolderSource, ImageSource, VideoSource

    registry.register_source("VideoSource", VideoSource)
    registry.register_source("ImageSource", ImageSource)
    registry.register_source("ImageFolderSource", ImageFolderSource)
    registry.register_source("FolderSource", FolderSource)

    # Processors
    from ..processors import Annotate, Label, Resize, YOLODetector

    registry.register_processor("Resize", Resize)
    registry.register_processor("Annotate", Annotate)
    registry.register_processor("Label", Label)
    registry.register_processor("YOLODetector", YOLODetector)

    # Sinks
    from ..sinks import CallbackSink, DisplaySink, FFmpegVideoSink, ImageSaveSink, VideoSink

    registry.register_sink("DisplaySink", DisplaySink)
    registry.register_sink("CallbackSink", CallbackSink)
    registry.register_sink("VideoSink", VideoSink)
    registry.register_sink("FFmpegVideoSink", FFmpegVideoSink)
    registry.register_sink("ImageSaveSink", ImageSaveSink)

    logger.debug("Auto-registered built-in components")
