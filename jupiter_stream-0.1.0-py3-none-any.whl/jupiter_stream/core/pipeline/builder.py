"""Pipeline 建造者抽象基类 / Pipeline Builder ABC

使用建造者模式统一 Pipeline 构建流程。
Unified Pipeline construction using Builder Pattern.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from .pipeline import Pipeline
    from .processor import Processor
    from .sink import Sink
    from .source import Source


class PipelineBuilder(ABC):
    """Pipeline 建造者抽象基类 / Pipeline Builder ABC

    定义统一的 Pipeline 构建接口，支持多种构建方式：
    - CodePipelineBuilder: 代码链式调用构建
    - ConfigPipelineBuilder: 配置文件驱动构建

    这个类使用 Builder Pattern（建造者模式）来：
    1. 分离 Pipeline 的构建逻辑和表示
    2. 提供统一的构建接口
    3. 支持不同的构建策略
    """

    def __init__(self, fps: Optional[float] = None):
        """初始化 Builder

        Args:
            fps: Pipeline 目标帧率（None 表示使用源的原始帧率）
        """
        self.fps = fps
        self._pipeline: Optional[Pipeline] = None

    @abstractmethod
    def set_source(self, *args, **kwargs) -> PipelineBuilder:
        """设置 Source（抽象方法，由子类实现）

        Returns:
            self (支持链式调用)
        """
        pass

    @abstractmethod
    def add_processor(self, *args, **kwargs) -> PipelineBuilder:
        """添加 Processor（抽象方法，由子类实现）

        Returns:
            self (支持链式调用)
        """
        pass

    @abstractmethod
    def add_sink(self, *args, **kwargs) -> PipelineBuilder:
        """添加 Sink（抽象方法，由子类实现）

        Returns:
            self (支持链式调用)
        """
        pass

    @abstractmethod
    def build(self) -> Pipeline:
        """构建 Pipeline 实例（抽象方法，由子类实现）

        Returns:
            配置好的 Pipeline 实例

        Raises:
            ValueError: 如果配置不完整或无效
        """
        pass

    def reset(self) -> None:
        """重置 Builder 状态

        清空所有已配置的组件，允许重新构建新的 Pipeline。
        """
        self._pipeline = None

    def validate(self) -> bool:
        """验证配置是否有效

        子类可以覆盖此方法添加自定义验证逻辑。

        Returns:
            是否有效
        """
        return True

    def get_pipeline(self) -> Optional[Pipeline]:
        """获取已构建的 Pipeline 实例

        Returns:
            已构建的 Pipeline，如果尚未构建则返回 None
        """
        return self._pipeline


class FluentPipelineBuilder(PipelineBuilder):
    """流式 Pipeline 建造者基类 / Fluent Pipeline Builder Base

    提供流式接口（Fluent Interface）的基类，支持链式调用。
    子类可以继承此类获得更好的链式调用支持。
    """

    def __init__(self, fps: Optional[float] = None):
        super().__init__(fps)
        self._source: Optional[Source] = None
        self._processors: List[Processor] = []
        self._sinks: List[Sink] = []

    def with_fps(self, fps: Optional[float]) -> FluentPipelineBuilder:
        """设置帧率（流式接口）

        Args:
            fps: 目标帧率

        Returns:
            self (支持链式调用)
        """
        self.fps = fps
        return self

    def clear_processors(self) -> FluentPipelineBuilder:
        """清除所有已添加的处理器

        Returns:
            self (支持链式调用)
        """
        self._processors.clear()
        return self

    def clear_sinks(self) -> FluentPipelineBuilder:
        """清除所有已添加的输出

        Returns:
            self (支持链式调用)
        """
        self._sinks.clear()
        return self

    def reset(self) -> None:
        """重置 Builder 状态"""
        super().reset()
        self._source = None
        self._processors.clear()
        self._sinks.clear()

    def validate(self) -> bool:
        """验证配置是否有效

        Returns:
            是否有效
        """
        if self._source is None:
            return False
        # 至少需要一个输出（除非是测试）
        # 但不强制，因为可能只是处理不输出
        return True
