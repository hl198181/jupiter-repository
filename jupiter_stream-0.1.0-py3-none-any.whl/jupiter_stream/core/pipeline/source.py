"""Abstract base class for frame sources."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Iterator, Optional

from .frame import Frame


class Source(ABC):
    """
    帧源抽象基类

    Source 定义了统一的帧获取接口，支持任意类型的帧源：
    - 视频文件
    - 网络摄像头
    - 图像序列
    - RTSP/RTMP 流
    - 自定义生成器

    Attributes:
        source_id: 数据源唯一标识符
        logger: 日志记录器
        _frame_count: 已生成的帧数

    Examples:
        >>> class MySource(Source):
        ...     def __init__(self, source_id: str = "my_source"):
        ...         super().__init__(source_id)
        ...
        ...     def read(self) -> Optional[Frame]:
        ...         # 实现帧读取逻辑
        ...         return frame
        ...
        ...     def is_opened(self) -> bool:
        ...         return True
        ...
        ...     def close(self):
        ...         pass
    """

    def __init__(self, source_id: str = "source"):
        """
        初始化帧源

        Args:
            source_id: 数据源唯一标识符
        """
        self.source_id = source_id
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._frame_count = 0

    @abstractmethod
    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        Returns:
            Frame 对象，如果流结束或出错则返回 None

        Note:
            子类必须实现此方法
        """
        pass

    @abstractmethod
    def is_opened(self) -> bool:
        """
        检查帧源是否打开

        Returns:
            如果帧源正常打开则返回 True，否则返回 False

        Note:
            子类必须实现此方法
        """
        pass

    @abstractmethod
    def close(self):
        """
        关闭帧源，释放资源

        Note:
            子类必须实现此方法
        """
        pass

    def __iter__(self) -> Iterator[Frame]:
        """
        支持迭代器协议

        Yields:
            Frame 对象

        Examples:
            >>> source = VideoSource("input.mp4")
            >>> for frame in source:
            ...     process(frame)
        """
        while self.is_opened():
            frame = self.read()
            if frame is None:
                break
            yield frame

    def __enter__(self) -> Source:
        """上下文管理器：进入"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器：退出"""
        self.close()

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(source_id={self.source_id})"

    def get_stats(self) -> dict:
        """
        获取统计信息

        Returns:
            包含统计信息的字典
        """
        return {
            "source_id": self.source_id,
            "frame_count": self._frame_count,
            "is_opened": self.is_opened(),
        }
