"""组件工厂 / Component Factory

使用工厂模式创建组件实例，处理参数转换和验证。
Create component instances using Factory Pattern with parameter handling.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .registry import registry

logger = logging.getLogger(__name__)


class ComponentFactory:
    """组件工厂 / Component Factory

    负责创建 Source、Processor、Sink 实例，处理参数验证和转换。
    Creates component instances with parameter validation and conversion.
    """

    @staticmethod
    def create_source(source_type: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """创建 Source 实例

        Args:
            source_type: Source 类型名称（如 "VideoSource"）
            params: 构造参数字典

        Returns:
            Source 实例

        Raises:
            KeyError: 如果 source_type 未注册
            ValueError: 如果创建失败
        """
        source_class = registry.get_source(source_type)
        params = params or {}
        processed_params = ComponentFactory._process_params(params, source_type)

        try:
            instance = source_class(**processed_params)
            logger.info(f"Created {source_type} with params: {processed_params}")
            return instance
        except Exception as e:
            raise ValueError(f"Failed to create {source_type}: {e}")

    @staticmethod
    def create_processor(processor_type: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """创建 Processor 实例

        Args:
            processor_type: Processor 类型名称（如 "Resize"）
            params: 构造参数字典

        Returns:
            Processor 实例

        Raises:
            KeyError: 如果 processor_type 未注册
            ValueError: 如果创建失败
        """
        processor_class = registry.get_processor(processor_type)
        params = params or {}
        processed_params = ComponentFactory._process_params(params, processor_type)

        try:
            instance = processor_class(**processed_params)
            logger.info(f"Created {processor_type} with params: {processed_params}")
            return instance
        except Exception as e:
            raise ValueError(f"Failed to create {processor_type}: {e}")

    @staticmethod
    def create_sink(sink_type: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """创建 Sink 实例

        Args:
            sink_type: Sink 类型名称（如 "DisplaySink"）
            params: 构造参数字典（可包含 name 字段用于设置 sink 名称）

        Returns:
            Sink 实例

        Raises:
            KeyError: 如果 sink_type 未注册
            ValueError: 如果创建失败
        """
        import uuid

        sink_class = registry.get_sink(sink_type)
        params = params or {}

        # 提取 name 参数（创建后设置，避免子类 __init__ 不支持）
        sink_name = params.pop("name", None) if isinstance(params, dict) else None

        processed_params = ComponentFactory._process_params(params, sink_type)

        try:
            instance = sink_class(**processed_params)
            # 设置 sink 名称（如果未指定则生成随机名称）
            if sink_name is not None:
                instance.name = sink_name
            else:
                instance.name = f"{sink_type}_{uuid.uuid4().hex[:8]}"
            logger.info(f"Created {sink_type} with params: {processed_params}")
            return instance
        except Exception as e:
            raise ValueError(f"Failed to create {sink_type}: {e}")

    @staticmethod
    def _process_params(params: Dict[str, Any], component_type: str) -> Dict[str, Any]:
        """处理参数，进行类型转换和特殊处理

        自动转换：
        - list -> tuple（用于颜色、坐标等参数）
        - 字符串模板名 -> 模板函数（用于 text_func 等）

        Args:
            params: 原始参数字典
            component_type: 组件类型（用于特殊处理）

        Returns:
            处理后的参数字典
        """
        if not params:
            return {}

        processed = {}
        for key, value in params.items():
            # 1. 列表转元组（常见于颜色、位置参数）
            if key in {
                "position",
                "color",
                "background_color",
                "text_color",
                "box_color",
                "label_bg_color",
                "size",
                "padding",
            }:
                if isinstance(value, list):
                    processed[key] = tuple(value)
                else:
                    processed[key] = value

            # 2. 模板函数处理
            elif key in {"text_func", "template"}:
                if isinstance(value, str):
                    # 尝试从注册表获取模板函数
                    try:
                        func = registry.get_template(value)
                        processed[key] = func
                        logger.debug(f"Resolved template '{value}' to function {func}")
                    except KeyError:
                        # 如果不是注册的模板，可能是特殊格式
                        from ..templates import get_template_function

                        func = get_template_function(value)
                        if func:
                            processed[key] = func
                        else:
                            logger.warning(f"Unknown template: {value}, ignoring parameter")
                            continue
                else:
                    processed[key] = value

            # 3. 回调函数（配置文件不支持，跳过）
            elif key == "callback":
                logger.warning("Callback functions not supported in config files, skipping")
                continue

            # 4. 其他参数直接传递
            else:
                processed[key] = value

        return processed

    @staticmethod
    def validate_params(
        component_type: str, component_category: str, params: Dict[str, Any]
    ) -> bool:
        """验证组件参数

        Args:
            component_type: 组件类型名称
            component_category: 组件类别（"source", "processor", "sink"）
            params: 参数字典

        Returns:
            是否有效
        """
        # TODO: 可以添加更详细的参数验证逻辑
        # 比如检查必需参数、类型验证等
        return True


# 便捷函数
factory = ComponentFactory()


def create_component(component_type: str, params: Optional[Dict[str, Any]] = None) -> Any:
    """通用组件创建函数

    自动判断组件类别并创建实例。

    Args:
        component_type: 组件类型名称
        params: 构造参数字典

    Returns:
        组件实例

    Raises:
        ValueError: 如果组件类型未知或创建失败
    """
    params = params or {}

    # 尝试各个类别
    try:
        return factory.create_source(component_type, params)
    except KeyError:
        pass

    try:
        return factory.create_processor(component_type, params)
    except KeyError:
        pass

    try:
        return factory.create_sink(component_type, params)
    except KeyError:
        pass

    raise ValueError(f"Unknown component type: {component_type}")
