"""Abstract base class for frame processors."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import List, Optional

from .frame import Frame


class Processor(ABC):
    """
    帧处理器抽象基类

    Processor 定义了统一的帧处理接口，用于构建处理管道。
    每个处理器接收一个 Frame，处理后返回一个 Frame（可以是同一个对象或新对象）。

    Attributes:
        enabled: 是否启用处理器
        logger: 日志记录器
        _processed_count: 已处理的帧数

    Examples:
        >>> class MyProcessor(Processor):
        ...     def process(self, frame: Frame) -> Frame:
        ...         # 处理逻辑
        ...         frame.metadata['processed'] = True
        ...         return frame
        >>>
        >>> processor = MyProcessor()
        >>> processed_frame = processor(frame)  # 调用 __call__
    """

    def __init__(self, enabled: bool = True):
        """
        初始化处理器

        Args:
            enabled: 是否启用处理器（默认启用）
        """
        self.enabled = enabled
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._processed_count = 0

    @abstractmethod
    def process(self, frame: Frame) -> Frame:
        """
        处理单帧

        Args:
            frame: 输入帧

        Returns:
            处理后的帧

        Note:
            子类必须实现此方法
            可以原地修改 frame，也可以返回新的 Frame 对象
        """
        pass

    def __call__(self, frame: Frame) -> Frame:
        """
        调用处理器（支持函数式调用）

        Args:
            frame: 输入帧

        Returns:
            处理后的帧（如果 enabled=False 则直接返回原帧）

        Examples:
            >>> processor = MyProcessor()
            >>> output = processor(input_frame)
        """
        if not self.enabled:
            return frame

        try:
            processed = self.process(frame)
            self._processed_count += 1
            return processed
        except Exception as e:
            self.logger.error(f"Error processing frame {frame.frame_id}: {e}")
            # 出错时返回原帧
            return frame

    def enable(self):
        """启用处理器"""
        self.enabled = True
        self.logger.info(f"{self.__class__.__name__} enabled")

    def disable(self):
        """禁用处理器"""
        self.enabled = False
        self.logger.info(f"{self.__class__.__name__} disabled")

    def reset(self):
        """
        重置处理器状态（可选实现）

        子类可以覆盖此方法以重置内部状态
        """
        self._processed_count = 0

    def get_activity_level(self, frame: Frame) -> Optional[float]:
        """
        获取活动度水平（可选实现）

        用于自适应 FPS 等场景。

        Args:
            frame: 当前帧

        Returns:
            活动度水平 (0.0-1.0) 或 None（如果不提供）

        Note:
            子类可以覆盖此方法以提供活动度信息
            例如：运动检测器可以返回运动强度
        """
        return None

    def __repr__(self) -> str:
        status = "enabled" if self.enabled else "disabled"
        return f"{self.__class__.__name__}({status})"

    def get_stats(self) -> dict:
        """
        获取统计信息

        Returns:
            包含统计信息的字典
        """
        return {
            "processor": self.__class__.__name__,
            "enabled": self.enabled,
            "processed_count": self._processed_count,
        }


class ProcessorChain:
    """
    处理器链

    将多个处理器串联成一个处理链。

    Examples:
        >>> chain = ProcessorChain([
        ...     ResizeProcessor(640, 480),
        ...     AnnotateProcessor("Processing..."),
        ...     BlurProcessor(kernel_size=5)
        ... ])
        >>> output = chain(input_frame)
    """

    def __init__(self, processors: List[Processor]):
        """
        初始化处理器链

        Args:
            processors: 处理器列表（按顺序应用）
        """
        self.processors = processors
        self.logger = logging.getLogger(f"{__name__}.ProcessorChain")

    def __call__(self, frame: Frame) -> Frame:
        """
        应用处理器链

        Args:
            frame: 输入帧

        Returns:
            处理后的帧
        """
        for processor in self.processors:
            if processor.enabled:
                frame = processor(frame)
        return frame

    def add(self, processor: Processor):
        """添加处理器到链末尾"""
        self.processors.append(processor)

    def __repr__(self) -> str:
        return f"ProcessorChain({len(self.processors)} processors)"
