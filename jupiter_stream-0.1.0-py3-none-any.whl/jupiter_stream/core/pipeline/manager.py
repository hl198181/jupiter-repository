"""Multi-pipeline manager for concurrent execution."""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .pipeline import Pipeline

logger = logging.getLogger(__name__)


@dataclass
class ManagedPipeline:
    """
    Pipeline 包装类，添加管理元数据

    用于在 PipelineManager 中跟踪 Pipeline 的状态、统计信息和生命周期。

    Attributes:
        name: Pipeline 唯一标识符
        pipeline: Pipeline 实例
        config: Pipeline 配置字典
        state: 当前状态（idle/running/stopped/error）
        thread: 运行线程
        created_at: 创建时间戳
        started_at: 启动时间戳
        stopped_at: 停止时间戳
        last_error: 最后一次异常
        restart_count: 重启次数
    """

    name: str
    pipeline: Pipeline
    config: Dict[str, Any]

    # 状态管理
    state: str = "idle"  # idle, running, stopped, error
    thread: Optional[threading.Thread] = None

    # 统计信息
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    stopped_at: Optional[float] = None
    last_error: Optional[Exception] = None
    restart_count: int = 0

    # 健康检查
    _last_frame_count: int = 0
    _stale_count: int = 0

    def start(self) -> bool:
        """
        启动 Pipeline（在独立线程中）

        Returns:
            是否启动成功
        """
        if self.state == "running":
            logger.warning(f"Pipeline '{self.name}' is already running")
            return False

        self.thread = threading.Thread(
            target=self._run_wrapper, name=f"Pipeline-{self.name}", daemon=True
        )
        self.thread.start()
        self.started_at = time.time()
        self.state = "running"

        logger.info(f"Pipeline '{self.name}' started")
        return True

    def stop(self, timeout: float = 5.0) -> bool:
        """
        停止 Pipeline（优雅关闭）

        Args:
            timeout: 等待超时（秒）

        Returns:
            是否成功停止
        """
        if self.state != "running":
            logger.warning(f"Pipeline '{self.name}' is not running (state={self.state})")
            return False

        # 停止 Pipeline
        self.pipeline.stop()

        # 等待线程结束
        if self.thread:
            self.thread.join(timeout=timeout)
            if self.thread.is_alive():
                logger.warning(f"Pipeline '{self.name}' did not stop within {timeout}s timeout")
                return False

        self.state = "stopped"
        self.stopped_at = time.time()

        logger.info(f"Pipeline '{self.name}' stopped")
        return True

    def _run_wrapper(self):
        """Pipeline 运行包装器，捕获异常"""
        try:
            self.pipeline.run()
            # 正常结束
            self.state = "stopped"
            self.stopped_at = time.time()
        except Exception as e:
            # 异常终止
            self.last_error = e
            self.state = "error"
            self.stopped_at = time.time()
            logger.error(f"Pipeline '{self.name}' crashed: {e}", exc_info=True)

    @property
    def uptime(self) -> float:
        """
        获取运行时长（秒）

        Returns:
            运行时长（秒）
        """
        if self.started_at is None:
            return 0.0

        end_time = self.stopped_at if self.stopped_at else time.time()
        return end_time - self.started_at

    @property
    def is_alive(self) -> bool:
        """
        检查线程是否存活

        Returns:
            线程是否存活
        """
        return self.thread is not None and self.thread.is_alive()

    def get_status(self) -> Dict[str, Any]:
        """
        获取 Pipeline 状态信息

        Returns:
            状态字典
        """
        stats = self.pipeline.stats if hasattr(self.pipeline, "stats") else {}

        return {
            "name": self.name,
            "state": self.state,
            "uptime": self.uptime,
            "is_alive": self.is_alive,
            "stats": stats,
            "last_error": str(self.last_error) if self.last_error else None,
            "restart_count": self.restart_count,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "stopped_at": self.stopped_at,
        }


class PipelineManager:
    """
    多 Pipeline 管理器

    管理多个 Pipeline 的生命周期，支持配置加载、动态管理、健康监控。

    特性：
    - 从配置文件/目录加载多个 Pipeline
    - 动态 CRUD 操作（创建/启动/停止/删除）
    - 并发执行（每个 Pipeline 独立线程）
    - 健康检查和自动重启
    - 状态查询和统计

    Examples:
        >>> # 从配置文件加载
        >>> manager = PipelineManager()
        >>> manager.load_from_config("config.yaml")
        >>> manager.start_all()

        >>> # 动态添加 Pipeline
        >>> config = {
        ...     "pipeline": {"fps": 30},
        ...     "source": {"type": "RTSPSource", "params": {"url": "rtsp://..."}},
        ...     "processors": [...],
        ...     "sinks": [...]
        ... }
        >>> manager.add_pipeline("camera_1", config, auto_start=True)

        >>> # 查询状态
        >>> status = manager.get_status()
        >>> print(status)

        >>> # 优雅关闭
        >>> manager.stop_all()
    """

    def __init__(self, config_dir: Optional[str] = None):
        """
        初始化 Pipeline 管理器

        Args:
            config_dir: 配置文件目录（可选，支持延迟加载）
        """
        self._pipelines: Dict[str, ManagedPipeline] = {}
        self._lock = threading.Lock()
        self._running = False

        # 健康检查
        self._health_check_enabled = False
        self._health_check_thread: Optional[threading.Thread] = None
        self._health_check_interval = 10.0
        self._health_check_auto_restart = False
        self._health_check_stop_event = threading.Event()

        self.logger = logging.getLogger(f"{__name__}.PipelineManager")

        # 如果提供了配置目录，立即加载
        if config_dir:
            if Path(config_dir).is_dir():
                self.load_from_directory(config_dir)
            else:
                self.load_from_config(config_dir)

    # === 配置加载 ===

    def load_from_config(self, config_path: Union[str, Path]) -> int:
        """
        从配置文件加载 Pipeline(s)

        支持三种模式：
        1. 单文件多 Pipeline: config.yaml 包含 pipelines: [] 数组
        2. 单文件单 Pipeline: config.yaml 包含 pipeline/source/processors/sinks
        3. 目录模式: 扫描目录下所有 .yaml/.json 文件

        Args:
            config_path: 配置文件或目录路径

        Returns:
            加载的 Pipeline 数量

        Raises:
            FileNotFoundError: 如果文件不存在
            ValueError: 如果配置格式无效
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Config path not found: {config_path}")

        # 如果是目录，递归加载
        if config_path.is_dir():
            return self.load_from_directory(config_path)

        # 加载配置文件
        from ...loaders import AutoConfigLoader

        loader = AutoConfigLoader()
        config = loader.load(config_path)

        # 检测配置格式
        if "pipelines" in config:
            # 多 Pipeline 模式
            return self._load_multiple_pipelines(config, config_path)
        else:
            # 单 Pipeline 模式
            return self._load_single_pipeline(config, config_path)

    def load_from_directory(self, directory: Union[str, Path]) -> int:
        """
        扫描目录加载所有配置文件

        Args:
            directory: 配置文件目录

        Returns:
            加载的 Pipeline 数量
        """
        directory = Path(directory)

        if not directory.is_dir():
            raise NotADirectoryError(f"Not a directory: {directory}")

        self.logger.info(f"Scanning directory for config files: {directory}")

        # 扫描 .yaml 和 .json 文件
        config_files = (
            list(directory.glob("*.yaml"))
            + list(directory.glob("*.yml"))
            + list(directory.glob("*.json"))
        )

        if not config_files:
            self.logger.warning(f"No config files found in {directory}")
            return 0

        total_loaded = 0
        for config_file in config_files:
            try:
                count = self.load_from_config(config_file)
                total_loaded += count
            except Exception as e:
                self.logger.error(f"Failed to load config file {config_file}: {e}")

        self.logger.info(
            f"Loaded {total_loaded} pipeline(s) from {len(config_files)} config file(s)"
        )
        return total_loaded

    def _load_multiple_pipelines(self, config: Dict[str, Any], source_path: Path) -> int:
        """
        从多 Pipeline 配置加载

        Args:
            config: 配置字典（包含 pipelines 数组）
            source_path: 配置文件路径（用于日志）

        Returns:
            加载的 Pipeline 数量
        """
        from ...builders import ConfigPipelineBuilder

        pipelines_config = config["pipelines"]

        if not isinstance(pipelines_config, list):
            raise ValueError("'pipelines' must be a list")

        loaded_count = 0
        for pipeline_config in pipelines_config:
            if not isinstance(pipeline_config, dict):
                self.logger.error(f"Invalid pipeline config: {pipeline_config}")
                continue

            if "name" not in pipeline_config:
                self.logger.error("Pipeline config missing 'name' field")
                continue

            name = pipeline_config["name"]

            # 提取实际的 pipeline 配置（移除 name 字段）
            actual_config = {k: v for k, v in pipeline_config.items() if k != "name"}

            try:
                # 构建 Pipeline
                builder = ConfigPipelineBuilder(actual_config)
                pipeline = builder.build()

                # 添加到管理器
                self._add_managed_pipeline(name, pipeline, actual_config)
                loaded_count += 1

                self.logger.info(f"Loaded pipeline '{name}' from {source_path}")

            except Exception as e:
                self.logger.error(f"Failed to load pipeline '{name}': {e}", exc_info=True)

        return loaded_count

    def _load_single_pipeline(self, config: Dict[str, Any], source_path: Path) -> int:
        """
        从单 Pipeline 配置加载

        Args:
            config: 配置字典
            source_path: 配置文件路径（用作 Pipeline 名称）

        Returns:
            加载的 Pipeline 数量（0 或 1）
        """
        from ...builders import ConfigPipelineBuilder

        # 使用文件名（不含扩展名）作为 Pipeline 名称
        name = source_path.stem

        try:
            # 构建 Pipeline
            builder = ConfigPipelineBuilder(config)
            pipeline = builder.build()

            # 添加到管理器
            self._add_managed_pipeline(name, pipeline, config)

            self.logger.info(f"Loaded pipeline '{name}' from {source_path}")
            return 1

        except Exception as e:
            self.logger.error(f"Failed to load pipeline '{name}': {e}", exc_info=True)
            return 0

    def _add_managed_pipeline(self, name: str, pipeline: Pipeline, config: Dict[str, Any]):
        """
        添加 ManagedPipeline 到管理器

        Args:
            name: Pipeline 名称
            pipeline: Pipeline 实例
            config: 配置字典
        """
        with self._lock:
            if name in self._pipelines:
                raise ValueError(f"Pipeline '{name}' already exists")

            managed = ManagedPipeline(name=name, pipeline=pipeline, config=config)

            self._pipelines[name] = managed

    # === 动态管理 ===

    def add_pipeline(self, name: str, config: Dict[str, Any], auto_start: bool = True) -> bool:
        """
        运行时添加新 Pipeline

        Args:
            name: Pipeline 唯一标识符
            config: Pipeline 配置字典
            auto_start: 是否自动启动（默认 True）

        Returns:
            是否添加成功

        Raises:
            ValueError: 如果 Pipeline 名称已存在
        """
        from ...builders import ConfigPipelineBuilder

        try:
            # 构建 Pipeline
            builder = ConfigPipelineBuilder(config)
            pipeline = builder.build()

            # 添加到管理器
            self._add_managed_pipeline(name, pipeline, config)

            self.logger.info(f"Added pipeline '{name}'")

            # 自动启动
            if auto_start:
                self.start_pipeline(name)

            return True

        except Exception as e:
            self.logger.error(f"Failed to add pipeline '{name}': {e}", exc_info=True)
            return False

    def remove_pipeline(self, name: str, force: bool = False) -> bool:
        """
        删除 Pipeline

        Args:
            name: Pipeline 名称
            force: 强制删除（即使正在运行，默认 False）

        Returns:
            是否删除成功
        """
        with self._lock:
            if name not in self._pipelines:
                self.logger.warning(f"Pipeline '{name}' not found")
                return False

            managed = self._pipelines[name]

            # 检查是否正在运行
            if managed.state == "running" and not force:
                self.logger.error(f"Pipeline '{name}' is running. Stop it first or use force=True")
                return False

            # 如果正在运行，先停止
            if managed.state == "running":
                self.logger.warning(f"Force stopping pipeline '{name}'...")
                managed.stop(timeout=2.0)

            # 删除
            del self._pipelines[name]

            self.logger.info(f"Removed pipeline '{name}'")
            return True

    def start_pipeline(self, name: str) -> bool:
        """
        启动指定 Pipeline

        Args:
            name: Pipeline 名称

        Returns:
            是否启动成功
        """
        with self._lock:
            if name not in self._pipelines:
                self.logger.error(f"Pipeline '{name}' not found")
                return False

            managed = self._pipelines[name]
            return managed.start()

    def stop_pipeline(self, name: str, timeout: float = 5.0) -> bool:
        """
        停止指定 Pipeline

        Args:
            name: Pipeline 名称
            timeout: 等待超时（秒）

        Returns:
            是否停止成功
        """
        with self._lock:
            if name not in self._pipelines:
                self.logger.error(f"Pipeline '{name}' not found")
                return False

            managed = self._pipelines[name]
            return managed.stop(timeout=timeout)

    def restart_pipeline(self, name: str) -> bool:
        """
        重启 Pipeline

        Args:
            name: Pipeline 名称

        Returns:
            是否重启成功
        """
        self.logger.info(f"Restarting pipeline '{name}'...")

        # 停止
        if not self.stop_pipeline(name, timeout=5.0):
            self.logger.error(f"Failed to stop pipeline '{name}' for restart")
            return False

        # 等待一小段时间
        time.sleep(0.5)

        # 启动
        if not self.start_pipeline(name):
            self.logger.error(f"Failed to start pipeline '{name}' after restart")
            return False

        with self._lock:
            if name in self._pipelines:
                self._pipelines[name].restart_count += 1

        self.logger.info(f"Pipeline '{name}' restarted successfully")
        return True

    # === 批量操作 ===

    def start_all(self) -> Dict[str, bool]:
        """
        启动所有 Pipeline

        Returns:
            {pipeline_name: 是否成功}
        """
        results = {}
        with self._lock:
            names = list(self._pipelines.keys())

        for name in names:
            results[name] = self.start_pipeline(name)

        return results

    def stop_all(self, timeout: float = 10.0) -> Dict[str, bool]:
        """
        停止所有 Pipeline

        Args:
            timeout: 每个 Pipeline 的等待超时（秒）

        Returns:
            {pipeline_name: 是否成功}
        """
        results = {}
        with self._lock:
            names = list(self._pipelines.keys())

        for name in names:
            results[name] = self.stop_pipeline(name, timeout=timeout)

        return results

    # === 状态查询 ===

    def get_status(self, name: Optional[str] = None) -> Union[dict, List[dict]]:
        """
        获取 Pipeline 状态

        Args:
            name: Pipeline 名称（None 表示获取所有）

        Returns:
            状态字典（单个）或状态列表（所有）
        """
        with self._lock:
            if name is not None:
                if name not in self._pipelines:
                    raise KeyError(f"Pipeline '{name}' not found")
                return self._pipelines[name].get_status()
            else:
                return [mp.get_status() for mp in self._pipelines.values()]

    def list_pipelines(self) -> List[str]:
        """
        列出所有 Pipeline 名称

        Returns:
            Pipeline 名称列表
        """
        with self._lock:
            return list(self._pipelines.keys())

    # === 健康监控 ===

    def enable_health_check(self, interval: float = 10.0, auto_restart: bool = True):
        """
        启用健康检查

        Args:
            interval: 检查间隔（秒，默认 10）
            auto_restart: 检测到异常时自动重启（默认 True）
        """
        if self._health_check_enabled:
            self.logger.warning("Health check is already enabled")
            return

        self._health_check_interval = interval
        self._health_check_auto_restart = auto_restart
        self._health_check_enabled = True
        self._health_check_stop_event.clear()

        # 启动健康检查线程
        self._health_check_thread = threading.Thread(
            target=self._health_check_loop, name="HealthCheck", daemon=True
        )
        self._health_check_thread.start()

        self.logger.info(
            f"Health check enabled (interval={interval}s, auto_restart={auto_restart})"
        )

    def disable_health_check(self):
        """禁用健康检查"""
        if not self._health_check_enabled:
            return

        self._health_check_enabled = False
        self._health_check_stop_event.set()

        if self._health_check_thread:
            self._health_check_thread.join(timeout=self._health_check_interval + 1)

        self.logger.info("Health check disabled")

    def _health_check_loop(self):
        """健康检查循环"""
        while self._health_check_enabled:
            try:
                self._perform_health_check()
            except Exception as e:
                self.logger.error(f"Health check error: {e}", exc_info=True)

            # 等待间隔或停止信号
            self._health_check_stop_event.wait(self._health_check_interval)

    def _perform_health_check(self):
        """执行健康检查"""
        with self._lock:
            pipelines = list(self._pipelines.items())

        for name, managed in pipelines:
            # 检查1: 线程是否存活
            if managed.state == "running" and not managed.is_alive:
                self.logger.warning(
                    f"Pipeline '{name}' thread died unexpectedly (state={managed.state})"
                )
                if self._health_check_auto_restart:
                    self.restart_pipeline(name)

            # 检查2: 是否长时间无新帧（可能卡死）
            if managed.state == "running" and hasattr(managed.pipeline, "stats"):
                current_count = managed.pipeline.stats.get("frame_count", 0)

                if current_count == managed._last_frame_count:
                    managed._stale_count += 1

                    # 6 次检查都无新帧（60秒无新帧）
                    if managed._stale_count >= 6:
                        self.logger.warning(
                            f"Pipeline '{name}' appears stale "
                            f"(no new frames for {managed._stale_count * self._health_check_interval}s)"
                        )
                        if self._health_check_auto_restart:
                            self.restart_pipeline(name)
                            managed._stale_count = 0  # 重置计数
                else:
                    # 有新帧，重置计数
                    managed._stale_count = 0
                    managed._last_frame_count = current_count

    # === 上下文管理器 ===

    def __enter__(self):
        """上下文管理器：进入"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器：退出"""
        self.stop_all(timeout=10.0)

    def __repr__(self) -> str:
        """字符串表示"""
        with self._lock:
            count = len(self._pipelines)
            running = sum(1 for mp in self._pipelines.values() if mp.state == "running")

        return f"PipelineManager(total={count}, running={running})"
