"""Pipeline orchestrator for video stream processing."""

from __future__ import annotations

import logging
import time
from pathlib import Path
from threading import Event, Thread
from typing import Callable, List, Optional, Union

from .frame import Frame
from .processor import Processor
from .sink import Sink
from .source import Source


class Pipeline:
    """
    处理管道编排器

    Pipeline 将 Source、Processor 和 Sink 组合成一个完整的处理流程：
    Source → Processor1 → Processor2 → ... → Sink

    支持多种使用模式：
    - 链式调用
    - 上下文管理器
    - 手动控制

    Attributes:
        source: 帧源
        processors: 处理器列表
        sinks: 输出列表
        fps: 目标帧率（None 表示不限制）
        logger: 日志记录器

    Examples:
        >>> # 链式调用
        >>> pipeline = (
        ...     Pipeline()
        ...     .add_source(VideoSource("input.mp4"))
        ...     .add_processor(Resize(640, 480))
        ...     .add_sink(DisplaySink())
        ... )
        >>> pipeline.run()

        >>> # 上下文管理器
        >>> with Pipeline() as p:
        ...     p.add_source(VideoSource("input.mp4"))
        ...     p.add_processor(Resize(640, 480))
        ...     p.add_sink(DisplaySink())
        ...     p.run()
    """

    def __init__(self, fps: Optional[float] = None):
        """
        初始化管道

        Args:
            fps: 目标帧率（None 表示不限制，使用源的原始帧率）
        """
        self.source: Optional[Source] = None
        self.processors: List[Processor] = []
        self.sinks: List[Sink] = []
        self.fps = fps

        self.logger = logging.getLogger(f"{__name__}.Pipeline")

        # 运行时状态
        self._running = False
        self._thread: Optional[Thread] = None
        self._stop_event = Event()

        # 统计信息
        self._frame_count = 0
        self._error_count = 0
        self._start_time: Optional[float] = None

    def add_source(self, source: Source) -> Pipeline:
        """
        设置帧源

        Args:
            source: Source 对象

        Returns:
            self (支持链式调用)
        """
        self.source = source
        self.logger.info(f"Added source: {source}")
        return self

    def add_processor(self, processor: Processor) -> Pipeline:
        """
        添加处理器

        Args:
            processor: Processor 对象

        Returns:
            self (支持链式调用)
        """
        self.processors.append(processor)
        self.logger.info(f"Added processor: {processor}")
        return self

    def add_sink(self, sink: Sink) -> Pipeline:
        """
        添加输出

        Args:
            sink: Sink 对象

        Returns:
            self (支持链式调用)
        """
        self.sinks.append(sink)
        self.logger.info(f"Added sink: {sink}")
        return self

    def on_frame(self, callback: Callable[[Frame], None]) -> Pipeline:
        """
        添加帧回调函数（便捷方法）

        Args:
            callback: 回调函数，接收 Frame 参数

        Returns:
            self (支持链式调用)
        """
        from ..sinks.callback import CallbackSink

        return self.add_sink(CallbackSink(callback))

    def run(self, threaded: bool = False):
        """
        运行管道

        Args:
            threaded: 是否在后台线程运行（默认 False，阻塞运行）

        Raises:
            RuntimeError: 如果未设置 source
        """
        if self.source is None:
            raise RuntimeError("Source not set. Call add_source() first.")

        if threaded:
            self._start_thread()
        else:
            self._run_loop()

    def _start_thread(self):
        """在后台线程启动管道"""
        if self._running:
            self.logger.warning("Pipeline already running")
            return

        self._running = True
        self._stop_event.clear()
        self._thread = Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self.logger.info("Pipeline started in background thread")

    def _run_loop(self):
        """主处理循环"""
        self._running = True
        self._frame_count = 0
        self._error_count = 0
        self._start_time = time.time()

        frame_interval = 1.0 / self.fps if self.fps else 0

        self.logger.info("Pipeline started")

        try:
            for frame in self.source:
                if self._stop_event.is_set():
                    break

                loop_start = time.time()

                try:
                    # 应用处理器链
                    for processor in self.processors:
                        if processor.enabled:
                            frame = processor(frame)

                    # 输出到所有 sink
                    for sink in self.sinks:
                        if sink.enabled and sink.is_active():
                            sink(frame)

                    self._frame_count += 1

                except Exception as e:
                    self.logger.error(f"Error processing frame {frame.frame_id}: {e}")
                    self._error_count += 1

                # FPS 控制
                if self.fps:
                    elapsed = time.time() - loop_start
                    sleep_time = max(0, frame_interval - elapsed)
                    if sleep_time > 0:
                        time.sleep(sleep_time)

        except KeyboardInterrupt:
            self.logger.info("Pipeline interrupted by user")

        except Exception as e:
            self.logger.error(f"Pipeline error: {e}", exc_info=True)

        finally:
            self._cleanup()

    def stop(self):
        """停止管道"""
        if not self._running:
            return

        self.logger.info("Stopping pipeline...")
        self._stop_event.set()

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5.0)

        self._running = False
        self.logger.info("Pipeline stopped")

    def _cleanup(self):
        """清理资源"""
        self.logger.info("Cleaning up...")

        # 关闭 source
        if self.source:
            self.source.close()

        # 关闭所有 sink
        for sink in self.sinks:
            sink.close()

        self._running = False
        self.logger.info("Cleanup complete")

    def __enter__(self) -> Pipeline:
        """上下文管理器：进入"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器：退出"""
        self.stop()

    def get_stats(self) -> dict:
        """
        获取统计信息

        Returns:
            包含统计信息的字典
        """
        elapsed = time.time() - self._start_time if self._start_time else 0
        current_fps = self._frame_count / elapsed if elapsed > 0 else 0

        return {
            "running": self._running,
            "frame_count": self._frame_count,
            "error_count": self._error_count,
            "elapsed_time": elapsed,
            "current_fps": current_fps,
            "target_fps": self.fps,
            "processors": len(self.processors),
            "sinks": len(self.sinks),
        }

    def __repr__(self) -> str:
        status = "running" if self._running else "stopped"
        return (
            f"Pipeline({status}, "
            f"processors={len(self.processors)}, "
            f"sinks={len(self.sinks)})"
        )

    # ========== 新增：配置文件支持（核心功能）==========

    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> Pipeline:
        """从配置文件创建 Pipeline（核心 API）

        这是架构重设计的核心功能，将配置文件支持提升为一等公民。
        This is the core API for config-based Pipeline creation.

        Args:
            config_path: 配置文件路径（支持 .yaml, .yml, .json）

        Returns:
            配置好的 Pipeline 实例

        Raises:
            FileNotFoundError: 配置文件不存在
            ValueError: 配置格式错误或组件创建失败

        Example:
            >>> # 最简单的使用方式 / Simplest usage
            >>> pipeline = Pipeline.from_config("config.yaml")
            >>> pipeline.run()

            >>> # 加载后继续添加组件 / Add more components after loading
            >>> pipeline = Pipeline.from_config("config.yaml")
            >>> pipeline.add_processor(CustomProcessor())
            >>> pipeline.run()
        """

        # 延迟导入，避免循环依赖
        from ...builders.config_builder import ConfigPipelineBuilder
        from ...loaders.auto_loader import AutoConfigLoader

        # 加载配置
        loader = AutoConfigLoader()
        config = loader.load(config_path)

        # 构建 Pipeline
        builder = ConfigPipelineBuilder(config)
        return builder.build()

    @classmethod
    def from_dict(cls, config: dict) -> Pipeline:
        """从配置字典创建 Pipeline

        Args:
            config: 配置字典

        Returns:
            配置好的 Pipeline 实例

        Raises:
            ValueError: 配置格式错误或组件创建失败

        Example:
            >>> config = {
            ...     "source": {"type": "VideoSource", "params": {"video_path": "input.mp4"}},
            ...     "processors": [{"type": "Resize", "params": {"width": 640}}],
            ...     "sinks": [{"type": "DisplaySink", "params": {}}]
            ... }
            >>> pipeline = Pipeline.from_dict(config)
            >>> pipeline.run()
        """
        # 延迟导入，避免循环依赖
        from ...builders.config_builder import ConfigPipelineBuilder

        builder = ConfigPipelineBuilder(config)
        return builder.build()
