"""Frame data model for video stream processing."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, Tuple

import numpy as np


@dataclass
class Frame:
    """
    视频帧数据模型

    Frame 是整个处理管道中传递的核心数据对象，包含图像数据和相关元数据。

    Attributes:
        image: 图像数据 (numpy array，格式通常为 BGR)
        timestamp: 帧时间戳（Unix 时间戳）
        frame_id: 帧ID（从 0 开始的递增序列号）
        source_id: 数据源标识符
        metadata: 任意元数据字典

    Examples:
        >>> frame = Frame(
        ...     image=np.zeros((480, 640, 3), dtype=np.uint8),
        ...     timestamp=time.time(),
        ...     frame_id=0,
        ...     source_id="camera_0"
        ... )
        >>> frame.metadata['processed'] = True
        >>> new_frame = frame.copy()
    """

    image: np.ndarray
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    source_id: str = "unknown"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """验证数据有效性"""
        if not isinstance(self.image, np.ndarray):
            raise TypeError(f"image must be numpy.ndarray, got {type(self.image)}")

        if self.image.size == 0:
            raise ValueError("image cannot be empty")

    @property
    def shape(self) -> tuple:
        """返回图像形状 (height, width, channels)"""
        return self.image.shape

    @property
    def width(self) -> int:
        """返回图像宽度"""
        return self.image.shape[1]

    @property
    def height(self) -> int:
        """返回图像高度"""
        return self.image.shape[0]

    @property
    def channels(self) -> int:
        """返回图像通道数"""
        return self.image.shape[2] if len(self.image.shape) == 3 else 1

    @property
    def stream_fps(self) -> float | None:
        """
        返回流的帧率（从 Source 读取，存储在 metadata）

        Returns stream frame rate from Source (stored in metadata).

        Returns:
            帧率值，如果未设置或无效则返回 None /
            Frame rate value, or None if not set or invalid
        """
        fps = self.metadata.get("stream_fps")
        if fps is not None and fps > 0:
            return float(fps)
        return None

    @property
    def pipeline_fps(self) -> float | None:
        """
        返回 Pipeline 配置的目标帧率（从 metadata 获取）

        Returns Pipeline configured target frame rate from metadata.

        Returns:
            帧率值，如果未设置或无效则返回 None /
            Frame rate value, or None if not set or invalid
        """
        fps = self.metadata.get("pipeline_fps")
        if fps is not None and fps > 0:
            return float(fps)
        return None

    @property
    def effective_fps(self) -> float:
        """
        获取有效帧率（统一入口）

        Get effective frame rate (unified entry point).

        优先级 / Priority:
        1. pipeline_fps - 用户在 Pipeline 中配置的目标帧率
        2. stream_fps - Source 自动检测的流帧率
        3. 默认值 30.0

        Returns:
            有效帧率 / Effective frame rate
        """
        if self.pipeline_fps is not None:
            return self.pipeline_fps
        if self.stream_fps is not None:
            return self.stream_fps
        return 30.0

    def copy(self) -> Frame:
        """
        创建帧的深拷贝

        Returns:
            新的 Frame 对象，包含复制的图像和元数据
        """
        return Frame(
            image=self.image.copy(),
            timestamp=self.timestamp,
            frame_id=self.frame_id,
            source_id=self.source_id,
            metadata=self.metadata.copy(),
        )

    def annotate(
        self,
        text: str,
        position: Tuple[int, int] = (10, 30),
        color: Tuple[int, int, int] = (0, 255, 0),
        font_scale: float = 0.6,
        thickness: int = 2,
    ) -> Frame:
        """
        在帧上添加文本标注（需要 OpenCV）

        Args:
            text: 标注文本
            position: 文本位置 (x, y)
            color: 文本颜色 (B, G, R)
            font_scale: 字体大小
            thickness: 线条粗细

        Returns:
            标注后的 Frame 对象（原地修改）

        Raises:
            ImportError: 如果 OpenCV 未安装
        """
        try:
            import cv2
        except ImportError:
            raise ImportError(
                "OpenCV is required for annotation. " "Install with: pip install jupiter-stream[cv]"
            )

        cv2.putText(
            self.image,
            text,
            position,
            cv2.FONT_HERSHEY_SIMPLEX,
            font_scale,
            color,
            thickness,
            cv2.LINE_AA,
        )

        return self

    def resize(self, width: int, height: int) -> Frame:
        """
        调整帧大小（需要 OpenCV）

        Args:
            width: 目标宽度
            height: 目标高度

        Returns:
            调整大小后的 Frame 对象（原地修改）

        Raises:
            ImportError: 如果 OpenCV 未安装
        """
        try:
            import cv2
        except ImportError:
            raise ImportError(
                "OpenCV is required for resizing. " "Install with: pip install jupiter-stream[cv]"
            )

        self.image = cv2.resize(self.image, (width, height))
        return self

    def __repr__(self) -> str:
        return (
            f"Frame(id={self.frame_id}, "
            f"shape={self.shape}, "
            f"source={self.source_id}, "
            f"timestamp={self.timestamp:.3f})"
        )


def create_frame(image: np.ndarray, source_id: str = "unknown", **metadata: Any) -> Frame:
    """
    便捷函数：创建 Frame 对象

    Args:
        image: 图像数据
        source_id: 数据源标识符
        **metadata: 任意元数据键值对

    Returns:
        Frame 对象

    Examples:
        >>> frame = create_frame(
        ...     image=np.zeros((480, 640, 3)),
        ...     source_id="camera_0",
        ...     fps=30,
        ...     exposure=10
        ... )
    """
    frame = Frame(
        image=image, timestamp=time.time(), frame_id=0, source_id=source_id, metadata=metadata
    )
    return frame
