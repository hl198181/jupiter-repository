#!/usr/bin/env python3
"""
OTA Manager

Main class for managing OTA updates using the handler registry system.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from .config import OTAConfig
from .exceptions import OTAError, OTAHandlerError
from .handler import HandlerType, OTAHandler
from .models import UpdateResult, UpdateStatus
from .registry import HandlerRegistry
from .state import OTAStateMachine
from .version import VersionManager

logger = logging.getLogger(__name__)


class OTAManager:
    """
    Main OTA manager class.

    Coordinates OTA updates using registered handlers.
    """

    def __init__(self, config: Optional[OTAConfig] = None):
        """
        Initialize OTA manager.

        Args:
            config: OTA configuration (uses defaults if not provided)
        """
        self.config = config or OTAConfig()
        self.registry = HandlerRegistry()
        self.state_machine = OTAStateMachine()
        self.version_manager = VersionManager(self.config.install_dir)

        # Progress tracking
        self._progress_callback: Optional[Callable] = None
        self._start_time: Optional[datetime] = None

        # Load default handlers if configured
        if self.config.use_defaults:
            self._load_default_handlers()

    def _load_default_handlers(self) -> None:
        """Load default handlers if not already registered"""
        try:
            from .defaults import (
                FileUpdateHandler,
                ProcessHealthChecker,
                SimpleHttpDownloader,
                SystemdServiceController,
                TarBackupHandler,
            )

            # Only register if not already present
            if not self.registry.has(HandlerType.DOWNLOAD):
                self.register_handler(SimpleHttpDownloader(self.config.temp_dir))

            if not self.registry.has(HandlerType.BACKUP):
                self.register_handler(TarBackupHandler(self.config.handlers.backup.backup_dir))

            if not self.registry.has(HandlerType.UPDATE):
                self.register_handler(FileUpdateHandler())

            if not self.registry.has(HandlerType.SERVICE):
                self.register_handler(SystemdServiceController())

            if not self.registry.has(HandlerType.HEALTH):
                self.register_handler(ProcessHealthChecker())

            logger.info("Default handlers loaded")

        except ImportError as e:
            logger.warning(f"Failed to load default handlers: {e}")

    def register_handler(self, handler: OTAHandler, primary: bool = False) -> None:
        """
        Register a handler.

        Args:
            handler: Handler instance to register
            primary: Whether to set as primary handler for its type
        """
        self.registry.register(handler, primary)
        logger.info(f"Registered {handler.name} handler")

    def register_handlers(self, *handlers: OTAHandler) -> None:
        """
        Register multiple handlers.

        Args:
            handlers: Handler instances to register
        """
        for handler in handlers:
            self.register_handler(handler)

    async def check_update(self, url: str, version: str, checksum: str) -> bool:
        """
        Check if update is needed.

        Args:
            url: Update package URL
            version: Target version
            checksum: Package checksum

        Returns:
            True if update should proceed
        """
        try:
            self.state_machine.transition(UpdateStatus.CHECKING)

            # Check version
            should_update = self.version_manager.should_update(
                version, force=self.config.force_update, allow_downgrade=self.config.allow_downgrade
            )

            if should_update:
                logger.info(f"Update available: {version}")
            else:
                logger.info(f"No update needed, already at {version}")

            self.state_machine.transition(UpdateStatus.IDLE)
            return should_update

        except Exception:
            self.state_machine.transition(UpdateStatus.FAILED)
            raise

    async def perform_update(
        self,
        url: str,
        version: str,
        checksum: str,
        checksum_type: str = "md5",
        progress_callback: Optional[Callable] = None,
        **kwargs,
    ) -> UpdateResult:
        """
        Perform OTA update.

        Args:
            url: Update package URL
            version: Target version
            checksum: Package checksum
            checksum_type: Type of checksum
            progress_callback: Progress callback function
            **kwargs: Additional parameters for handlers

        Returns:
            Update result

        Raises:
            OTAError: If update fails
        """
        self._progress_callback = progress_callback
        self._start_time = datetime.now()

        # Create update context
        context = {
            "url": url,
            "version": version,
            "checksum": checksum,
            "checksum_type": checksum_type,
            "config": self.config,
            "install_dir": self.config.install_dir,
            **kwargs,
        }

        try:
            # Check if update is needed
            if not await self.check_update(url, version, checksum):
                return UpdateResult(
                    status=UpdateStatus.COMPLETED,
                    version=version,
                    message="Already at target version",
                    start_time=self._start_time,
                    end_time=datetime.now(),
                )

            # Execute update steps
            await self._execute_download(context)
            await self._execute_backup(context)
            await self._execute_update(context)
            await self._execute_verify(context)
            await self._execute_restart(context)
            await self._execute_health_check(context)

            # Update complete
            self.state_machine.transition(UpdateStatus.COMPLETED)
            self._report_progress(UpdateStatus.COMPLETED, "Update completed successfully", 100)

            # Record update history
            self.version_manager.record_update(
                context.get("current_version"), version, success=True
            )

            return UpdateResult(
                status=UpdateStatus.COMPLETED,
                version=version,
                message="Update completed successfully",
                start_time=self._start_time,
                end_time=datetime.now(),
                stages_completed=self.state_machine.state_history,
                backup_path=context.get("backup_path"),
            )

        except Exception as e:
            logger.error(f"Update failed: {e}")
            self.state_machine.transition(UpdateStatus.FAILED)

            # Attempt rollback if configured
            if self.config.rollback_on_failure and context.get("backup_path"):
                await self._execute_rollback(context)

            # Record failure
            self.version_manager.record_update(
                context.get("current_version"), version, success=False, metadata={"error": str(e)}
            )

            return UpdateResult(
                status=UpdateStatus.FAILED,
                version=version,
                message=str(e),
                start_time=self._start_time,
                end_time=datetime.now(),
                stages_completed=self.state_machine.state_history,
                error={"message": str(e), "type": type(e).__name__},
                rollback_performed=context.get("rollback_performed", False),
            )

    async def _execute_download(self, context: Dict[str, Any]) -> None:
        """Execute download step"""
        handler = self.registry.get(HandlerType.DOWNLOAD)
        if not handler:
            raise OTAHandlerError(
                "DownloadHandler", HandlerType.DOWNLOAD, "No download handler registered"
            )

        self.state_machine.transition(UpdateStatus.DOWNLOADING)
        self._report_progress(UpdateStatus.DOWNLOADING, "Downloading update package", 10)

        # Add progress callback
        def download_progress(downloaded, total, percent):
            self._report_progress(
                UpdateStatus.DOWNLOADING,
                f"Downloading: {downloaded}/{total} bytes",
                10 + (percent * 0.2),  # 10-30%
            )

        context["progress_callback"] = download_progress

        # Execute download
        package_path = await handler.execute(context)
        context["package_path"] = package_path
        logger.info(f"Downloaded to {package_path}")

    async def _execute_backup(self, context: Dict[str, Any]) -> None:
        """Execute backup step"""
        if not self.config.create_backup:
            logger.info("Backup disabled, skipping")
            return

        handler = self.registry.get(HandlerType.BACKUP)
        if not handler:
            logger.warning("No backup handler registered, skipping backup")
            return

        self.state_machine.transition(UpdateStatus.BACKING_UP)
        self._report_progress(UpdateStatus.BACKING_UP, "Creating backup", 35)

        # Get current version
        current = self.version_manager.get_current_version()
        context["current_version"] = current.version if current else "unknown"
        context["source_dir"] = self.config.install_dir

        # Execute backup
        backup_path = await handler.execute(context)
        context["backup_path"] = backup_path
        logger.info(f"Backup created at {backup_path}")

    async def _execute_update(self, context: Dict[str, Any]) -> None:
        """Execute update application step"""
        handler = self.registry.get(HandlerType.UPDATE)
        if not handler:
            raise OTAHandlerError(
                "UpdateHandler", HandlerType.UPDATE, "No update handler registered"
            )

        self.state_machine.transition(UpdateStatus.APPLYING)
        self._report_progress(UpdateStatus.APPLYING, "Applying update", 50)

        context["target_dir"] = self.config.install_dir

        # Execute update
        success = await handler.execute(context)
        if not success:
            raise OTAError("Failed to apply update")

        logger.info("Update applied successfully")

    async def _execute_verify(self, context: Dict[str, Any]) -> None:
        """Execute verification step"""
        if not self.config.verify_update:
            logger.info("Verification disabled, skipping")
            return

        handler = self.registry.get(HandlerType.VERIFY)
        if not handler:
            logger.info("No verify handler registered, skipping verification")
            return

        self.state_machine.transition(UpdateStatus.VERIFYING)
        self._report_progress(UpdateStatus.VERIFYING, "Verifying update", 65)

        # Execute verification
        verified = await handler.execute(context)
        if not verified:
            raise OTAError("Update verification failed")

        logger.info("Update verified successfully")

    async def _execute_restart(self, context: Dict[str, Any]) -> None:
        """Execute service restart step"""
        handler = self.registry.get(HandlerType.SERVICE)
        if not handler:
            logger.info("No service handler registered, skipping restart")
            return

        self.state_machine.transition(UpdateStatus.RESTARTING)
        self._report_progress(UpdateStatus.RESTARTING, "Restarting service", 75)

        context["service_name"] = self.config.handlers.service.service_name
        context["action"] = "restart"
        context["delay"] = self.config.handlers.service.restart_delay

        # Execute restart
        await handler.execute(context)
        logger.info("Service restart initiated")

    async def _execute_health_check(self, context: Dict[str, Any]) -> None:
        """Execute health check step"""
        if not self.config.handlers.health.enabled:
            logger.info("Health check disabled, skipping")
            return

        handler = self.registry.get(HandlerType.HEALTH)
        if not handler:
            logger.info("No health handler registered, skipping health check")
            return

        self.state_machine.transition(UpdateStatus.HEALTH_CHECKING)
        self._report_progress(UpdateStatus.HEALTH_CHECKING, "Checking service health", 90)

        context["service_name"] = self.config.handlers.service.service_name
        context["timeout"] = self.config.handlers.health.timeout

        # Execute health check
        healthy = await handler.execute(context)
        if not healthy:
            raise OTAError("Health check failed")

        logger.info("Health check passed")

    async def _execute_rollback(self, context: Dict[str, Any]) -> None:
        """Execute rollback step"""
        backup_path = context.get("backup_path")
        if not backup_path:
            logger.warning("No backup available for rollback")
            return

        handler = self.registry.get(HandlerType.BACKUP)
        if not handler or not hasattr(handler, "restore"):
            logger.warning("Backup handler does not support restore")
            return

        self.state_machine.transition(UpdateStatus.ROLLED_BACK)
        logger.info(f"Rolling back from {backup_path}")

        try:
            await handler.restore(Path(backup_path), self.config.install_dir)
            context["rollback_performed"] = True
            logger.info("Rollback completed")
        except Exception as e:
            logger.error(f"Rollback failed: {e}")

    def _report_progress(self, status: UpdateStatus, message: str, progress: float) -> None:
        """Report progress to callback"""
        if self._progress_callback:
            try:
                self._progress_callback(status, message, progress)
            except Exception as e:
                logger.error(f"Progress callback error: {e}")

    def abort_update(self, reason: str = "User requested") -> None:
        """
        Abort ongoing update.

        Args:
            reason: Abort reason
        """
        if self.state_machine.is_running():
            self.state_machine.abort(reason)
            logger.info(f"Update aborted: {reason}")

    def get_status(self) -> Dict[str, Any]:
        """
        Get current OTA status.

        Returns:
            Status dictionary
        """
        return {
            "state": self.state_machine.current_state.value,
            "is_running": self.state_machine.is_running(),
            "time_in_state": self.state_machine.time_in_state,
            "registered_handlers": self.registry.list_types(),
            "current_version": self.version_manager.get_current_version(),
            "config": {
                "auto_update": self.config.auto_update,
                "create_backup": self.config.create_backup,
                "verify_update": self.config.verify_update,
                "rollback_on_failure": self.config.rollback_on_failure,
            },
        }
