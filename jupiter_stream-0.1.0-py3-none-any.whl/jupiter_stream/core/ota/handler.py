#!/usr/bin/env python3
"""
OTA Handler Base Classes and Interfaces

This module defines the base classes and interfaces for OTA handlers.
All OTA handlers must inherit from OTAHandler and implement required methods.
"""

import logging
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)


class HandlerType(str, Enum):
    """Standard handler types in OTA process"""

    DOWNLOAD = "download"  # Download update package
    BACKUP = "backup"  # Backup current version
    UPDATE = "update"  # Apply update
    SERVICE = "service"  # Service control (restart/stop/start)
    HEALTH = "health"  # Health check
    VERIFY = "verify"  # Verify update
    NOTIFICATION = "notification"  # Send notifications
    ROLLBACK = "rollback"  # Rollback to previous version
    CLEANUP = "cleanup"  # Clean temporary files
    # Custom types can be added as strings


class OTAHandler(ABC):
    """
    Base class for all OTA handlers.

    All handlers must inherit from this class and implement required methods.
    Handlers are registered with the OTA manager and executed during the update process.
    """

    @property
    @abstractmethod
    def handler_type(self) -> str:
        """
        Return the handler type identifier.

        This can be a HandlerType enum value or a custom string.
        The type is used to register and retrieve handlers from the registry.

        Returns:
            Handler type identifier
        """
        pass

    @property
    def name(self) -> str:
        """
        Return the handler name for logging and identification.

        Default implementation returns the class name.
        Override this to provide a custom name.

        Returns:
            Handler name
        """
        return self.__class__.__name__

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> Any:
        """
        Execute the handler logic.

        This is the main method that performs the handler's operation.
        The context dictionary contains all necessary parameters and state.

        Args:
            context: Execution context with parameters and state

        Returns:
            Execution result (type depends on handler)

        Raises:
            Exception: If execution fails
        """
        pass

    async def validate(self, context: Dict[str, Any]) -> bool:
        """
        Validate execution conditions.

        Override this method to implement validation logic.
        Return False to skip handler execution.

        Args:
            context: Execution context

        Returns:
            True if conditions are met, False otherwise
        """
        return True

    async def cleanup(self, context: Dict[str, Any]) -> None:
        """
        Clean up resources after execution.

        Override this method to implement cleanup logic.
        Called after handler execution (success or failure).

        Args:
            context: Execution context
        """
        pass

    def __repr__(self) -> str:
        """String representation of the handler"""
        return f"{self.name}(type={self.handler_type})"


# Specific handler interfaces for type hints and documentation


class DownloadHandler(OTAHandler):
    """
    Handler for downloading update packages.

    Context should contain:
        - url: Download URL
        - checksum: Expected checksum (MD5/SHA256)
        - checksum_type: Type of checksum (md5/sha256)
        - progress_callback: Optional progress callback
        - timeout: Download timeout in seconds
        - max_retries: Maximum retry attempts
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.DOWNLOAD

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> Path:
        """
        Download update package.

        Returns:
            Path to downloaded file
        """
        pass


class BackupHandler(OTAHandler):
    """
    Handler for creating and restoring backups.

    Context should contain:
        - source_dir: Directory to backup
        - backup_dir: Where to store backup
        - version: Current version string
        - exclude_patterns: Optional list of patterns to exclude
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.BACKUP

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> Path:
        """
        Create backup of current version.

        Returns:
            Path to backup file
        """
        pass

    @abstractmethod
    async def restore(self, backup_path: Path, target_dir: Path) -> bool:
        """
        Restore from backup.

        Args:
            backup_path: Path to backup file
            target_dir: Directory to restore to

        Returns:
            True if successful
        """
        pass


class UpdateHandler(OTAHandler):
    """
    Handler for applying updates.

    Context should contain:
        - package_path: Path to update package
        - target_dir: Installation directory
        - backup_path: Path to backup (for rollback)
        - version: Target version
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.UPDATE

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> bool:
        """
        Apply update package.

        Returns:
            True if successful
        """
        pass

    async def verify_update(self, target_dir: Path, version: str) -> bool:
        """
        Verify update was applied correctly.

        Args:
            target_dir: Installation directory
            version: Expected version

        Returns:
            True if verification passes
        """
        return True


class ServiceHandler(OTAHandler):
    """
    Handler for service control (start/stop/restart).

    Context should contain:
        - service_name: Name of service to control
        - action: Action to perform (start/stop/restart)
        - delay: Optional delay before action
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.SERVICE

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> bool:
        """
        Control service.

        Returns:
            True if successful
        """
        pass

    async def stop_service(self, service_name: str) -> bool:
        """Stop service"""
        context = {"service_name": service_name, "action": "stop"}
        return await self.execute(context)

    async def start_service(self, service_name: str) -> bool:
        """Start service"""
        context = {"service_name": service_name, "action": "start"}
        return await self.execute(context)

    async def restart_service(self, service_name: str) -> bool:
        """Restart service"""
        context = {"service_name": service_name, "action": "restart"}
        return await self.execute(context)


class HealthHandler(OTAHandler):
    """
    Handler for health checks.

    Context should contain:
        - service_name: Service to check
        - timeout: Check timeout in seconds
        - check_interval: Interval between checks
        - max_attempts: Maximum check attempts
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.HEALTH

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> bool:
        """
        Perform health check.

        Returns:
            True if healthy
        """
        pass

    async def get_health_details(self) -> Dict[str, Any]:
        """
        Get detailed health information.

        Returns:
            Health details dictionary
        """
        return {}


class VerifyHandler(OTAHandler):
    """
    Handler for verifying updates.

    Context should contain:
        - target_dir: Installation directory
        - version: Expected version
        - checksums: Optional file checksums to verify
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.VERIFY

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> bool:
        """
        Verify update integrity.

        Returns:
            True if verification passes
        """
        pass


class NotificationHandler(OTAHandler):
    """
    Handler for sending notifications.

    Context should contain:
        - event: Event type (started/progress/completed/failed)
        - message: Notification message
        - details: Additional details
    """

    @property
    def handler_type(self) -> str:
        return HandlerType.NOTIFICATION

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> bool:
        """
        Send notification.

        Returns:
            True if sent successfully
        """
        pass
