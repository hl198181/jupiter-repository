#!/usr/bin/env python3
"""
OTA Handler Registry

This module implements the handler registry for managing OTA handlers.
Supports registering multiple handlers of the same type and setting primary handlers.
"""

import logging
import threading
from collections import defaultdict
from typing import Dict, List, Optional

from .handler import OTAHandler

logger = logging.getLogger(__name__)


class HandlerRegistry:
    """
    Registry for OTA handlers.

    Manages registration, retrieval, and organization of OTA handlers.
    Supports multiple handlers per type and primary handler selection.

    Thread-safe implementation using locks.
    """

    def __init__(self):
        """Initialize the handler registry"""
        # Store all handlers by type (multiple handlers per type)
        self._handlers: Dict[str, List[OTAHandler]] = defaultdict(list)

        # Store primary handler for each type (one per type)
        self._primary_handlers: Dict[str, OTAHandler] = {}

        # Store handler instances by name for quick lookup
        self._handlers_by_name: Dict[str, OTAHandler] = {}

        # Thread lock for thread safety
        self._lock = threading.RLock()

    def register(self, handler: OTAHandler, primary: bool = False) -> None:
        """
        Register a handler.

        Args:
            handler: Handler instance to register
            primary: Whether to set as primary handler for its type

        Raises:
            ValueError: If handler is invalid or name conflicts
        """
        if not isinstance(handler, OTAHandler):
            raise ValueError(f"Handler must be instance of OTAHandler, got {type(handler)}")

        with self._lock:
            handler_type = handler.handler_type
            handler_name = handler.name

            # Check for name conflicts
            if handler_name in self._handlers_by_name:
                existing = self._handlers_by_name[handler_name]
                if existing is not handler:
                    raise ValueError(f"Handler with name '{handler_name}' already registered")
                # Same handler, skip re-registration
                return

            # Add to handlers list for this type
            self._handlers[handler_type].append(handler)

            # Add to name lookup
            self._handlers_by_name[handler_name] = handler

            # Set as primary if requested or if it's the first of its type
            if primary or handler_type not in self._primary_handlers:
                self._primary_handlers[handler_type] = handler
                logger.info(f"Set {handler_name} as primary {handler_type} handler")
            else:
                logger.info(f"Registered {handler_name} as {handler_type} handler")

    def unregister(
        self, handler: Optional[OTAHandler] = None, handler_name: Optional[str] = None
    ) -> bool:
        """
        Unregister a handler.

        Args:
            handler: Handler instance to unregister
            handler_name: Name of handler to unregister

        Returns:
            True if handler was unregistered, False if not found
        """
        with self._lock:
            # Find handler by instance or name
            if handler:
                target = handler
            elif handler_name and handler_name in self._handlers_by_name:
                target = self._handlers_by_name[handler_name]
            else:
                return False

            handler_type = target.handler_type
            handler_name = target.name

            # Remove from type list
            if handler_type in self._handlers:
                try:
                    self._handlers[handler_type].remove(target)
                    if not self._handlers[handler_type]:
                        # Remove empty list
                        del self._handlers[handler_type]
                except ValueError:
                    pass

            # Remove from name lookup
            self._handlers_by_name.pop(handler_name, None)

            # Update primary if necessary
            if self._primary_handlers.get(handler_type) is target:
                # Set new primary from remaining handlers
                if handler_type in self._handlers and self._handlers[handler_type]:
                    self._primary_handlers[handler_type] = self._handlers[handler_type][0]
                    logger.info(
                        f"Set {self._handlers[handler_type][0].name} as new primary {handler_type} handler"
                    )
                else:
                    # No more handlers of this type
                    del self._primary_handlers[handler_type]

            logger.info(f"Unregistered {handler_name} handler")
            return True

    def get(self, handler_type: str) -> Optional[OTAHandler]:
        """
        Get primary handler for a type.

        Args:
            handler_type: Type of handler to get

        Returns:
            Primary handler instance or None if not registered
        """
        with self._lock:
            return self._primary_handlers.get(handler_type)

    def get_by_name(self, handler_name: str) -> Optional[OTAHandler]:
        """
        Get handler by name.

        Args:
            handler_name: Name of handler to get

        Returns:
            Handler instance or None if not found
        """
        with self._lock:
            return self._handlers_by_name.get(handler_name)

    def get_all(self, handler_type: str) -> List[OTAHandler]:
        """
        Get all handlers of a type.

        Args:
            handler_type: Type of handlers to get

        Returns:
            List of handler instances (empty if none registered)
        """
        with self._lock:
            return list(self._handlers.get(handler_type, []))

    def set_primary(self, handler_type: str, handler_name: str) -> bool:
        """
        Set primary handler for a type.

        Args:
            handler_type: Type of handler
            handler_name: Name of handler to set as primary

        Returns:
            True if successful, False if handler not found
        """
        with self._lock:
            handlers = self._handlers.get(handler_type, [])
            for handler in handlers:
                if handler.name == handler_name:
                    self._primary_handlers[handler_type] = handler
                    logger.info(f"Set {handler_name} as primary {handler_type} handler")
                    return True
            return False

    def has(self, handler_type: str) -> bool:
        """
        Check if a handler type is registered.

        Args:
            handler_type: Type to check

        Returns:
            True if at least one handler of this type is registered
        """
        with self._lock:
            return handler_type in self._primary_handlers

    def has_handler(self, handler_name: str) -> bool:
        """
        Check if a specific handler is registered.

        Args:
            handler_name: Name of handler to check

        Returns:
            True if handler is registered
        """
        with self._lock:
            return handler_name in self._handlers_by_name

    def list_types(self) -> List[str]:
        """
        List all registered handler types.

        Returns:
            List of handler type identifiers
        """
        with self._lock:
            return list(self._primary_handlers.keys())

    def list_handlers(self, handler_type: Optional[str] = None) -> List[str]:
        """
        List handler names.

        Args:
            handler_type: Optional type to filter by

        Returns:
            List of handler names
        """
        with self._lock:
            if handler_type:
                return [h.name for h in self._handlers.get(handler_type, [])]
            else:
                return list(self._handlers_by_name.keys())

    def get_stats(self) -> Dict[str, int]:
        """
        Get registry statistics.

        Returns:
            Dictionary with statistics
        """
        with self._lock:
            return {
                "total_handlers": len(self._handlers_by_name),
                "total_types": len(self._handlers),
                "primary_handlers": len(self._primary_handlers),
                **{
                    f"handlers_{type_}": len(handlers) for type_, handlers in self._handlers.items()
                },
            }

    def clear(self, handler_type: Optional[str] = None) -> None:
        """
        Clear handlers from registry.

        Args:
            handler_type: Optional type to clear (None clears all)
        """
        with self._lock:
            if handler_type:
                # Clear specific type
                handlers = self._handlers.pop(handler_type, [])
                for handler in handlers:
                    self._handlers_by_name.pop(handler.name, None)
                self._primary_handlers.pop(handler_type, None)
                logger.info(f"Cleared all {handler_type} handlers")
            else:
                # Clear all
                self._handlers.clear()
                self._primary_handlers.clear()
                self._handlers_by_name.clear()
                logger.info("Cleared all handlers from registry")

    def __repr__(self) -> str:
        """String representation of registry"""
        with self._lock:
            types = ", ".join(self.list_types())
            return f"HandlerRegistry(types=[{types}], handlers={len(self._handlers_by_name)})"

    def __contains__(self, item) -> bool:
        """Check if handler type or name is in registry"""
        with self._lock:
            if isinstance(item, str):
                # Check both type and name
                return item in self._primary_handlers or item in self._handlers_by_name
            elif isinstance(item, OTAHandler):
                # Check if handler instance is registered
                return item in self._handlers_by_name.values()
            return False
