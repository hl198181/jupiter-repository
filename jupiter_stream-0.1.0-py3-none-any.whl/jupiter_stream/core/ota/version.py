#!/usr/bin/env python3
"""
OTA Version Management

This module provides version management utilities for OTA operations.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from .exceptions import OTAVersionError
from .models import VersionInfo

logger = logging.getLogger(__name__)


class VersionManager:
    """
    Manages version information for OTA updates.

    Handles version reading, writing, comparison, and validation.
    """

    def __init__(self, install_dir: Path):
        """
        Initialize version manager.

        Args:
            install_dir: Installation directory
        """
        self.install_dir = Path(install_dir).expanduser().resolve()
        self.version_file = self.install_dir / "version.json"

    def get_current_version(self) -> Optional[VersionInfo]:
        """
        Get current installed version.

        Returns:
            VersionInfo or None if not found
        """
        if not self.version_file.exists():
            # Try alternative locations
            alt_locations = [
                self.install_dir / "app" / "version.json",
                self.install_dir / ".version",
                self.install_dir / "VERSION",
            ]

            for alt_path in alt_locations:
                if alt_path.exists():
                    return self._read_version_file(alt_path)

            logger.warning(f"Version file not found at {self.version_file}")
            return None

        return self._read_version_file(self.version_file)

    def _read_version_file(self, path: Path) -> Optional[VersionInfo]:
        """
        Read version from file.

        Args:
            path: Path to version file

        Returns:
            VersionInfo or None if read fails
        """
        try:
            if path.suffix == ".json":
                with open(path) as f:
                    data = json.load(f)
                    version_str = data.get("version")
                    if version_str:
                        version_info = VersionInfo.parse(version_str)
                        # Add additional metadata if present
                        for key in ["build_date", "commit", "branch"]:
                            if key in data:
                                setattr(version_info, key, data[key])
                        return version_info
            else:
                # Plain text version file
                with open(path) as f:
                    version_str = f.read().strip()
                    if version_str:
                        return VersionInfo.parse(version_str)

        except Exception as e:
            logger.error(f"Failed to read version from {path}: {e}")

        return None

    def write_version(
        self, version: VersionInfo, metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Write version to file.

        Args:
            version: Version to write
            metadata: Additional metadata to include

        Returns:
            True if successful
        """
        try:
            # Ensure directory exists
            self.version_file.parent.mkdir(parents=True, exist_ok=True)

            # Prepare version data
            data = {
                "version": version.version,
                "major": version.major,
                "minor": version.minor,
                "patch": version.patch,
            }

            if version.prerelease:
                data["prerelease"] = version.prerelease
            if version.build:
                data["build"] = version.build

            # Add metadata
            if metadata:
                data.update(metadata)

            # Add timestamp
            from datetime import datetime

            data["updated_at"] = datetime.now().isoformat()

            # Write to file
            with open(self.version_file, "w") as f:
                json.dump(data, f, indent=2)

            logger.info(f"Version {version.version} written to {self.version_file}")
            return True

        except Exception as e:
            logger.error(f"Failed to write version: {e}")
            return False

    def should_update(
        self, target_version: str, force: bool = False, allow_downgrade: bool = False
    ) -> bool:
        """
        Check if update should proceed.

        Args:
            target_version: Target version string
            force: Force update regardless of version
            allow_downgrade: Allow downgrading to older version

        Returns:
            True if update should proceed

        Raises:
            OTAVersionError: If version check fails
        """
        if force:
            logger.info("Force update enabled, skipping version check")
            return True

        current = self.get_current_version()
        target = VersionInfo.parse(target_version)

        if not current:
            logger.info("No current version found, proceeding with update")
            return True

        comparison = current.compare(target)

        if comparison == 0:
            logger.info(f"Already at target version {target_version}")
            return False
        elif comparison > 0:
            # Current version is newer
            if allow_downgrade:
                logger.warning(f"Downgrading from {current.version} to {target.version}")
                return True
            else:
                raise OTAVersionError(
                    current.version,
                    target.version,
                    "Target version is older than current version (downgrade not allowed)",
                )
        else:
            # Current version is older (normal update)
            logger.info(f"Updating from {current.version} to {target.version}")
            return True

    def validate_update_path(self, current_version: str, target_version: str) -> bool:
        """
        Validate if update path is valid.

        Some versions might require intermediate updates.

        Args:
            current_version: Current version string
            target_version: Target version string

        Returns:
            True if update path is valid
        """
        current = VersionInfo.parse(current_version)
        target = VersionInfo.parse(target_version)

        # Example: Check for major version jumps
        if target.major - current.major > 1:
            logger.warning(f"Large version jump detected: {current_version} -> {target_version}")
            # Could implement logic to require intermediate updates
            # For now, just warn but allow
            return True

        return True

    def get_version_history(self) -> list:
        """
        Get version update history.

        Returns:
            List of version history entries
        """
        history_file = self.install_dir / ".ota_history"
        if not history_file.exists():
            return []

        try:
            with open(history_file) as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to read version history: {e}")
            return []

    def record_update(
        self,
        from_version: Optional[str],
        to_version: str,
        success: bool,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Record update in history.

        Args:
            from_version: Previous version (None if fresh install)
            to_version: New version
            success: Whether update was successful
            metadata: Additional metadata to record
        """
        history_file = self.install_dir / ".ota_history"

        # Load existing history
        history = self.get_version_history()

        # Create new entry
        from datetime import datetime

        entry = {
            "from_version": from_version,
            "to_version": to_version,
            "success": success,
            "timestamp": datetime.now().isoformat(),
        }

        if metadata:
            entry["metadata"] = metadata

        # Append to history
        history.append(entry)

        # Keep only last 50 entries
        history = history[-50:]

        # Write back
        try:
            with open(history_file, "w") as f:
                json.dump(history, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to write version history: {e}")

    @staticmethod
    def normalize_version(version_str: str) -> str:
        """
        Normalize version string format.

        Args:
            version_str: Version string to normalize

        Returns:
            Normalized version string
        """
        if not version_str:
            return ""

        # Remove 'v' prefix
        normalized = version_str.lstrip("vV")

        # Ensure basic format (at least major.minor)
        parts = normalized.split(".")
        if len(parts) == 1 and parts[0].isdigit():
            normalized = f"{parts[0]}.0.0"
        elif len(parts) == 2:
            normalized = f"{normalized}.0"

        return normalized

    @staticmethod
    def is_valid_version(version_str: str) -> bool:
        """
        Check if version string is valid.

        Args:
            version_str: Version string to check

        Returns:
            True if valid
        """
        try:
            VersionInfo.parse(version_str)
            return True
        except (ValueError, AttributeError):
            return False
