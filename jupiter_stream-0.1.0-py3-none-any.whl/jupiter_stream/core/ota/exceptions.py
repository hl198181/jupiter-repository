#!/usr/bin/env python3
"""
OTA Exception Classes

This module defines exception classes for OTA operations.
"""


class OTAError(Exception):
    """Base exception for OTA operations"""

    def __init__(self, message: str, details: dict = None):
        """
        Initialize OTA error.

        Args:
            message: Error message
            details: Optional error details
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}


class OTAConfigError(OTAError):
    """Configuration related errors"""

    pass


class OTADownloadError(OTAError):
    """Download related errors"""

    pass


class OTABackupError(OTAError):
    """Backup related errors"""

    pass


class OTAUpdateError(OTAError):
    """Update application related errors"""

    pass


class OTAVerificationError(OTAError):
    """Verification related errors"""

    pass


class OTAHealthCheckError(OTAError):
    """Health check related errors"""

    pass


class OTARollbackError(OTAError):
    """Rollback related errors"""

    pass


class OTAHandlerError(OTAError):
    """Handler execution related errors"""

    def __init__(self, handler_name: str, handler_type: str, message: str, details: dict = None):
        """
        Initialize handler error.

        Args:
            handler_name: Name of the handler
            handler_type: Type of the handler
            message: Error message
            details: Optional error details
        """
        full_message = f"Handler '{handler_name}' ({handler_type}): {message}"
        super().__init__(full_message, details)
        self.handler_name = handler_name
        self.handler_type = handler_type


class OTAStateError(OTAError):
    """State machine related errors"""

    def __init__(self, current_state: str, attempted_transition: str, message: str = None):
        """
        Initialize state error.

        Args:
            current_state: Current state
            attempted_transition: Attempted transition
            message: Optional custom message
        """
        if not message:
            message = f"Invalid state transition from '{current_state}' to '{attempted_transition}'"
        super().__init__(message)
        self.current_state = current_state
        self.attempted_transition = attempted_transition


class OTATimeoutError(OTAError):
    """Timeout related errors"""

    def __init__(self, operation: str, timeout: int):
        """
        Initialize timeout error.

        Args:
            operation: Operation that timed out
            timeout: Timeout value in seconds
        """
        message = f"Operation '{operation}' timed out after {timeout} seconds"
        super().__init__(message, {"operation": operation, "timeout": timeout})
        self.operation = operation
        self.timeout = timeout


class OTAChecksumError(OTAError):
    """Checksum verification errors"""

    def __init__(self, expected: str, actual: str, checksum_type: str = "md5"):
        """
        Initialize checksum error.

        Args:
            expected: Expected checksum
            actual: Actual checksum
            checksum_type: Type of checksum (md5, sha256, etc.)
        """
        message = f"{checksum_type.upper()} checksum mismatch: expected {expected}, got {actual}"
        super().__init__(
            message, {"expected": expected, "actual": actual, "checksum_type": checksum_type}
        )
        self.expected = expected
        self.actual = actual
        self.checksum_type = checksum_type


class OTAVersionError(OTAError):
    """Version related errors"""

    def __init__(self, current_version: str, target_version: str, message: str = None):
        """
        Initialize version error.

        Args:
            current_version: Current version
            target_version: Target version
            message: Optional custom message
        """
        if not message:
            message = f"Version conflict: current={current_version}, target={target_version}"
        super().__init__(
            message, {"current_version": current_version, "target_version": target_version}
        )
        self.current_version = current_version
        self.target_version = target_version


class OTAAbortError(OTAError):
    """Update abort requested"""

    def __init__(self, reason: str):
        """
        Initialize abort error.

        Args:
            reason: Reason for abort
        """
        super().__init__(f"OTA update aborted: {reason}", {"reason": reason})
        self.reason = reason
