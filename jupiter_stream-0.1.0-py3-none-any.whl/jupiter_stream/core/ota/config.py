#!/usr/bin/env python3
"""
OTA Configuration Models

This module defines configuration models for OTA operations using Pydantic v2.
"""

from datetime import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class DownloadConfig(BaseModel):
    """Download handler configuration"""

    timeout: int = Field(default=300, ge=10, le=3600, description="Download timeout in seconds")
    max_retries: int = Field(default=3, ge=0, le=10, description="Maximum retry attempts")
    retry_delays: List[int] = Field(
        default=[0, 5, 10], description="Delays between retries in seconds"
    )
    chunk_size: int = Field(default=8192, ge=1024, description="Download chunk size in bytes")
    verify_ssl: bool = Field(default=True, description="Verify SSL certificates")
    headers: Dict[str, str] = Field(default_factory=dict, description="HTTP headers")
    proxy: Optional[str] = Field(default=None, description="HTTP proxy URL")


class BackupConfig(BaseModel):
    """Backup handler configuration"""

    backup_dir: Path = Field(
        default=Path.home() / ".jupiter" / "ota" / "backup", description="Backup storage directory"
    )
    compression: str = Field(default="gz", description="Compression type (gz, bz2, xz)")
    max_backups: int = Field(
        default=5, ge=1, le=20, description="Maximum number of backups to keep"
    )
    exclude_patterns: List[str] = Field(
        default_factory=lambda: ["*.pyc", "__pycache__", ".git", ".DS_Store", "._*"],
        description="File patterns to exclude from backup",
    )

    @field_validator("compression")
    @classmethod
    def validate_compression(cls, v: str) -> str:
        """Validate compression type"""
        valid = ["gz", "bz2", "xz"]
        if v not in valid:
            raise ValueError(f"Invalid compression type: {v}. Must be one of {valid}")
        return v

    @field_validator("backup_dir")
    @classmethod
    def create_backup_dir(cls, v: Path) -> Path:
        """Ensure backup directory exists"""
        v = Path(v).expanduser().resolve()
        v.mkdir(parents=True, exist_ok=True)
        return v


class ServiceConfig(BaseModel):
    """Service controller configuration"""

    service_name: str = Field(default="jupiter-brt", description="Service name for systemd/docker")
    restart_delay: int = Field(
        default=3, ge=0, le=60, description="Delay before restart in seconds"
    )
    stop_timeout: int = Field(
        default=30, ge=5, le=300, description="Service stop timeout in seconds"
    )
    service_type: str = Field(
        default="systemd", description="Service type (systemd, docker, supervisor)"
    )

    @field_validator("service_type")
    @classmethod
    def validate_service_type(cls, v: str) -> str:
        """Validate service type"""
        valid = ["systemd", "docker", "supervisor", "custom"]
        if v not in valid:
            raise ValueError(f"Invalid service type: {v}. Must be one of {valid}")
        return v


class HealthCheckConfig(BaseModel):
    """Health check configuration"""

    enabled: bool = Field(default=True, description="Enable health checks")
    timeout: int = Field(default=30, ge=5, le=300, description="Total timeout in seconds")
    check_interval: int = Field(default=5, ge=1, le=60, description="Check interval in seconds")
    max_attempts: int = Field(default=6, ge=1, le=20, description="Maximum check attempts")
    check_type: str = Field(
        default="process", description="Check type (process, http, tcp, custom)"
    )
    http_endpoint: Optional[str] = Field(
        default=None, description="HTTP endpoint for health checks (if check_type=http)"
    )
    tcp_port: Optional[int] = Field(
        default=None, ge=1, le=65535, description="TCP port for health checks (if check_type=tcp)"
    )

    @model_validator(mode="after")
    def validate_check_config(self) -> "HealthCheckConfig":
        """Validate check type specific configuration"""
        if self.check_type == "http" and not self.http_endpoint:
            raise ValueError("http_endpoint required when check_type=http")
        if self.check_type == "tcp" and not self.tcp_port:
            raise ValueError("tcp_port required when check_type=tcp")
        return self


class UpdateWindowConfig(BaseModel):
    """Update window configuration"""

    enabled: bool = Field(default=False, description="Enable update window")
    start: time = Field(default=time(2, 0), description="Window start time")
    end: time = Field(default=time(4, 0), description="Window end time")
    timezone: str = Field(default="local", description="Timezone (local or UTC)")
    allow_force: bool = Field(default=True, description="Allow force update outside window")

    @model_validator(mode="after")
    def validate_window(self) -> "UpdateWindowConfig":
        """Validate update window configuration"""
        if self.enabled and self.start == self.end:
            raise ValueError("Update window start and end times cannot be the same")
        return self


class HandlerConfig(BaseModel):
    """Handler specific configuration"""

    download: DownloadConfig = Field(default_factory=DownloadConfig)
    backup: BackupConfig = Field(default_factory=BackupConfig)
    service: ServiceConfig = Field(default_factory=ServiceConfig)
    health: HealthCheckConfig = Field(default_factory=HealthCheckConfig)
    custom: Dict[str, Any] = Field(
        default_factory=dict, description="Custom handler configurations"
    )


class OTAConfig(BaseModel):
    """Main OTA configuration"""

    # Basic settings
    enabled: bool = Field(default=True, description="Enable OTA functionality")
    use_defaults: bool = Field(
        default=True, description="Use default handlers if not explicitly registered"
    )

    # Paths
    install_dir: Path = Field(
        default=Path.home() / "jupiter-stream", description="Installation directory"
    )
    temp_dir: Path = Field(
        default=Path("/tmp") / "jupiter_ota", description="Temporary directory for downloads"
    )
    log_file: Optional[Path] = Field(
        default=Path.home() / ".jupiter" / "ota" / "ota.log", description="OTA log file path"
    )

    # Version management
    check_interval: int = Field(
        default=3600, ge=60, le=86400, description="Update check interval in seconds"
    )
    auto_update: bool = Field(default=False, description="Automatically apply updates")
    allow_downgrade: bool = Field(default=False, description="Allow version downgrade")
    force_update: bool = Field(default=False, description="Force update even if same version")

    # Update behavior
    create_backup: bool = Field(default=True, description="Create backup before update")
    verify_update: bool = Field(default=True, description="Verify update after applying")
    rollback_on_failure: bool = Field(default=True, description="Automatically rollback on failure")
    clean_on_success: bool = Field(default=True, description="Clean temporary files on success")

    # Update window
    update_window: UpdateWindowConfig = Field(default_factory=UpdateWindowConfig)

    # Handler configurations
    handlers: HandlerConfig = Field(default_factory=HandlerConfig)

    # Pending update settings
    pending_check_enabled: bool = Field(
        default=True, description="Check for pending updates on startup"
    )
    pending_max_age: int = Field(
        default=86400, ge=3600, description="Maximum age of pending update in seconds"
    )

    @field_validator("install_dir", "temp_dir", "log_file")
    @classmethod
    def expand_paths(cls, v: Optional[Path]) -> Optional[Path]:
        """Expand user paths"""
        if v is not None:
            v = Path(v).expanduser().resolve()
        return v

    @field_validator("temp_dir")
    @classmethod
    def create_temp_dir(cls, v: Path) -> Path:
        """Ensure temp directory exists"""
        v.mkdir(parents=True, exist_ok=True)
        return v

    @field_validator("log_file")
    @classmethod
    def create_log_dir(cls, v: Optional[Path]) -> Optional[Path]:
        """Ensure log directory exists"""
        if v is not None:
            v.parent.mkdir(parents=True, exist_ok=True)
        return v

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return self.model_dump(mode="json")

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "OTAConfig":
        """Create from dictionary"""
        # Convert string paths to Path objects
        for key in ["install_dir", "temp_dir", "log_file"]:
            if key in data and data[key] is not None:
                data[key] = Path(data[key])

        if "handlers" in data and "backup" in data["handlers"]:
            if "backup_dir" in data["handlers"]["backup"]:
                data["handlers"]["backup"]["backup_dir"] = Path(
                    data["handlers"]["backup"]["backup_dir"]
                )

        return cls(**data)

    @classmethod
    def from_yaml(cls, yaml_path: Path) -> "OTAConfig":
        """Load configuration from YAML file"""
        import yaml

        yaml_path = Path(yaml_path).expanduser().resolve()
        if not yaml_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {yaml_path}")

        with open(yaml_path) as f:
            data = yaml.safe_load(f) or {}

        # Extract OTA section if present
        if "ota" in data:
            data = data["ota"]

        return cls.from_dict(data)

    def save_yaml(self, yaml_path: Path) -> None:
        """Save configuration to YAML file"""
        import yaml

        yaml_path = Path(yaml_path).expanduser().resolve()
        yaml_path.parent.mkdir(parents=True, exist_ok=True)

        data = self.to_dict()

        # Convert Path objects to strings for YAML
        def convert_paths(obj):
            if isinstance(obj, dict):
                return {k: convert_paths(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_paths(item) for item in obj]
            elif isinstance(obj, Path):
                return str(obj)
            return obj

        data = convert_paths(data)

        with open(yaml_path, "w") as f:
            yaml.safe_dump({"ota": data}, f, default_flow_style=False, sort_keys=False)
