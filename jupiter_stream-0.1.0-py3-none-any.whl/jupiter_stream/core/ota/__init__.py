#!/usr/bin/env python3
"""
Jupiter Stream OTA Module

A flexible and extensible Over-The-Air update system with pluggable handlers.

Key Features:
    - Pluggable handler architecture
    - Default handlers for common operations
    - State machine for update flow control
    - Version management and validation
    - Automatic rollback on failure
    - Progress tracking and reporting

Basic Usage:
    ```python
    from jupiter_stream.core.ota import OTAManager, OTAConfig

    # Create manager with default handlers
    config = OTAConfig(use_defaults=True)
    ota_manager = OTAManager(config)

    # Perform update
    result = await ota_manager.perform_update(
        url="https://example.com/update.tar.gz",
        version="1.2.0",
        checksum="abc123..."
    )
    ```

Custom Handler Usage:
    ```python
    from jupiter_stream.core.ota import OTAManager, DownloadHandler

    # Create custom download handler
    class MyDownloadHandler(DownloadHandler):
        async def execute(self, context):
            # Custom download logic
            pass

    # Register custom handler
    ota_manager = OTAManager()
    ota_manager.register_handler(MyDownloadHandler())
    ```
"""

# Core components
from .config import HandlerConfig, OTAConfig, UpdateWindowConfig

# Exceptions
from .exceptions import (
    OTAAbortError,
    OTABackupError,
    OTAChecksumError,
    OTAConfigError,
    OTADownloadError,
    OTAError,
    OTAHandlerError,
    OTAHealthCheckError,
    OTARollbackError,
    OTAStateError,
    OTATimeoutError,
    OTAUpdateError,
    OTAVerificationError,
    OTAVersionError,
)

# Handlers and interfaces
from .handler import (
    BackupHandler,
    DownloadHandler,
    HandlerType,
    HealthHandler,
    NotificationHandler,
    OTAHandler,
    ServiceHandler,
    UpdateHandler,
    VerifyHandler,
)
from .manager import OTAManager

# Data models
from .models import (
    PendingUpdate,
    UpdatePackage,
    UpdateProgress,
    UpdateResult,
    UpdateStage,
    UpdateStatus,
    VersionInfo,
)
from .registry import HandlerRegistry
from .state import OTAStateMachine
from .version import VersionManager

# Version
__version__ = "1.0.0"

__all__ = [
    # Core
    "OTAManager",
    "OTAConfig",
    "UpdateWindowConfig",
    "HandlerConfig",
    "HandlerRegistry",
    "OTAStateMachine",
    "VersionManager",
    # Handlers
    "OTAHandler",
    "HandlerType",
    "DownloadHandler",
    "BackupHandler",
    "UpdateHandler",
    "ServiceHandler",
    "HealthHandler",
    "VerifyHandler",
    "NotificationHandler",
    # Models
    "UpdateStatus",
    "UpdateStage",
    "UpdatePackage",
    "UpdateResult",
    "UpdateProgress",
    "PendingUpdate",
    "VersionInfo",
    # Exceptions
    "OTAError",
    "OTAConfigError",
    "OTADownloadError",
    "OTABackupError",
    "OTAUpdateError",
    "OTAVerificationError",
    "OTAHealthCheckError",
    "OTARollbackError",
    "OTAHandlerError",
    "OTAStateError",
    "OTATimeoutError",
    "OTAChecksumError",
    "OTAVersionError",
    "OTAAbortError",
]
