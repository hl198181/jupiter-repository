#!/usr/bin/env python3
"""
Default OTA Handlers

This module provides default implementations of OTA handlers.
These can be used as-is or replaced with custom implementations.
"""

from .backup import TarBackupHandler
from .download import SimpleHttpDownloader
from .health import HttpHealthChecker, ProcessHealthChecker
from .service import DockerServiceController, SystemdServiceController
from .updater import FileUpdateHandler

__all__ = [
    "SimpleHttpDownloader",
    "TarBackupHandler",
    "FileUpdateHandler",
    "SystemdServiceController",
    "DockerServiceController",
    "ProcessHealthChecker",
    "HttpHealthChecker",
]
