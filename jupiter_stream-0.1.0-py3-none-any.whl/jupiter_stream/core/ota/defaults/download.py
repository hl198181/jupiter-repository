#!/usr/bin/env python3
"""
Default Download Handler

Simple HTTP downloader implementation that doesn't depend on other jupiter-stream modules.
"""

import hashlib
import logging
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from ..exceptions import OTAChecksumError, OTADownloadError
from ..handler import DownloadHandler

logger = logging.getLogger(__name__)


class SimpleHttpDownloader(DownloadHandler):
    """
    Simple HTTP downloader using urllib.

    This is a basic implementation that works without external dependencies.
    For production use, consider using a more robust implementation with
    the jupiter-stream HTTP module or requests library.
    """

    def __init__(self, temp_dir: Optional[Path] = None):
        """
        Initialize downloader.

        Args:
            temp_dir: Temporary directory for downloads
        """
        self.temp_dir = temp_dir or Path("/tmp/jupiter_ota")
        self.temp_dir.mkdir(parents=True, exist_ok=True)

    async def execute(self, context: Dict[str, Any]) -> Path:
        """
        Download update package.

        Args:
            context: Execution context with:
                - url: Download URL
                - checksum: Expected checksum
                - checksum_type: Type of checksum (md5/sha256)
                - progress_callback: Optional progress callback
                - timeout: Download timeout
                - max_retries: Maximum retry attempts
                - retry_delays: Delays between retries

        Returns:
            Path to downloaded file

        Raises:
            OTADownloadError: If download fails
            OTAChecksumError: If checksum verification fails
        """
        url = context["url"]
        checksum = context["checksum"]
        checksum_type = context.get("checksum_type", "md5").lower()
        progress_callback = context.get("progress_callback")
        timeout = context.get("timeout", 300)
        max_retries = context.get("max_retries", 3)
        retry_delays = context.get("retry_delays", [0, 5, 10])

        # Generate filename from URL
        filename = url.split("/")[-1] or f"package_{int(time.time())}.tar.gz"
        file_path = self.temp_dir / filename

        # Attempt download with retries
        last_error = None
        for attempt in range(max_retries):
            if attempt > 0 and attempt - 1 < len(retry_delays):
                delay = retry_delays[attempt - 1]
                logger.info(f"Retry {attempt}/{max_retries} after {delay}s...")
                time.sleep(delay)

            try:
                logger.info(f"Downloading from {url} (attempt {attempt + 1}/{max_retries})")

                # Download file
                self._download_file(url, file_path, timeout, progress_callback)

                # Verify checksum
                logger.info(f"Verifying {checksum_type} checksum...")
                actual_checksum = self._calculate_checksum(file_path, checksum_type)

                if actual_checksum != checksum:
                    raise OTAChecksumError(checksum, actual_checksum, checksum_type)

                logger.info(f"Download completed successfully: {file_path}")
                return file_path

            except Exception as e:
                last_error = e
                logger.warning(f"Download attempt {attempt + 1} failed: {e}")

                # Remove partial file
                if file_path.exists():
                    file_path.unlink()

        # All attempts failed
        raise OTADownloadError(
            f"Failed to download after {max_retries} attempts",
            {"url": url, "last_error": str(last_error)},
        )

    def _download_file(
        self, url: str, file_path: Path, timeout: int, progress_callback: Optional[Callable] = None
    ) -> None:
        """
        Download file from URL.

        Args:
            url: Download URL
            file_path: Destination file path
            timeout: Timeout in seconds
            progress_callback: Optional progress callback(downloaded, total)
        """
        try:
            # Open URL with timeout
            request = urllib.request.Request(url, headers={"User-Agent": "jupiter-stream-ota/1.0"})

            with urllib.request.urlopen(request, timeout=timeout) as response:
                total_size = int(response.headers.get("Content-Length", 0))
                downloaded = 0
                chunk_size = 8192

                with open(file_path, "wb") as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break

                        f.write(chunk)
                        downloaded += len(chunk)

                        if progress_callback and total_size > 0:
                            progress = (downloaded / total_size) * 100
                            progress_callback(downloaded, total_size, progress)

                logger.info(f"Downloaded {downloaded} bytes")

        except urllib.error.URLError as e:
            raise OTADownloadError(f"URL error: {e}")
        except urllib.error.HTTPError as e:
            raise OTADownloadError(f"HTTP error {e.code}: {e.reason}")
        except Exception as e:
            raise OTADownloadError(f"Download failed: {e}")

    def _calculate_checksum(self, file_path: Path, checksum_type: str) -> str:
        """
        Calculate file checksum.

        Args:
            file_path: Path to file
            checksum_type: Type of checksum (md5/sha256)

        Returns:
            Checksum hex string
        """
        if checksum_type == "md5":
            hasher = hashlib.md5()
        elif checksum_type == "sha256":
            hasher = hashlib.sha256()
        else:
            raise ValueError(f"Unsupported checksum type: {checksum_type}")

        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hasher.update(chunk)

        return hasher.hexdigest()

    async def cleanup(self, context: Dict[str, Any]) -> None:
        """Clean up temporary files"""
        # Clean old downloads

        for file in self.temp_dir.glob("package_*.tar.gz"):
            try:
                # Remove files older than 24 hours
                if (time.time() - file.stat().st_mtime) > 86400:
                    file.unlink()
            except Exception as e:
                logger.warning(f"Failed to clean {file}: {e}")
