#!/usr/bin/env python3
"""
OTA Data Models

This module defines data models for OTA operations.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


class UpdateStatus(str, Enum):
    """Update status enumeration"""

    IDLE = "idle"  # No update in progress
    CHECKING = "checking"  # Checking for updates
    DOWNLOADING = "downloading"  # Downloading update package
    VERIFYING = "verifying"  # Verifying checksum
    BACKING_UP = "backing_up"  # Creating backup
    APPLYING = "applying"  # Applying update
    RESTARTING = "restarting"  # Restarting service
    HEALTH_CHECKING = "health_checking"  # Checking health after restart
    COMPLETED = "completed"  # Update completed successfully
    FAILED = "failed"  # Update failed
    ROLLED_BACK = "rolled_back"  # Rolled back to previous version
    ABORTED = "aborted"  # Update aborted by user
    PENDING = "pending"  # Update applied, pending verification


class UpdateStage(str, Enum):
    """Update process stages"""

    PREPARE = "prepare"
    DOWNLOAD = "download"
    BACKUP = "backup"
    UPDATE = "update"
    VERIFY = "verify"
    RESTART = "restart"
    HEALTH = "health"
    CLEANUP = "cleanup"
    ROLLBACK = "rollback"


@dataclass
class UpdatePackage:
    """
    Represents an OTA update package.

    Attributes:
        version: Target version
        url: Download URL
        checksum: Package checksum
        checksum_type: Type of checksum (md5, sha256)
        size: Package size in bytes
        release_date: Release date
        release_notes: Optional release notes
        metadata: Additional metadata
    """

    version: str
    url: str
    checksum: str
    checksum_type: str = "md5"
    size: Optional[int] = None
    release_date: Optional[datetime] = None
    release_notes: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate and normalize data after initialization"""
        # Normalize version (remove 'v' prefix if present)
        if self.version and self.version.startswith("v"):
            self.version = self.version[1:]

        # Validate checksum type
        valid_types = ["md5", "sha256", "sha512"]
        if self.checksum_type not in valid_types:
            raise ValueError(f"Invalid checksum type: {self.checksum_type}")


@dataclass
class UpdateResult:
    """
    Result of an OTA update operation.

    Attributes:
        status: Final status
        version: Version that was attempted
        message: Result message
        start_time: When update started
        end_time: When update ended
        duration: Update duration in seconds
        stages_completed: List of completed stages
        error: Error details if failed
        rollback_performed: Whether rollback was performed
        backup_path: Path to backup if created
        log_file: Path to update log file
        metadata: Additional metadata
    """

    status: UpdateStatus
    version: str
    message: str
    start_time: datetime
    end_time: datetime
    duration: float = 0.0
    stages_completed: List[str] = field(default_factory=list)
    error: Optional[Dict[str, Any]] = None
    rollback_performed: bool = False
    backup_path: Optional[Path] = None
    log_file: Optional[Path] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Calculate duration if not set"""
        if not self.duration and self.start_time and self.end_time:
            self.duration = (self.end_time - self.start_time).total_seconds()

    @property
    def success(self) -> bool:
        """Check if update was successful"""
        return self.status == UpdateStatus.COMPLETED

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "status": self.status.value,
            "version": self.version,
            "message": self.message,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration": self.duration,
            "stages_completed": self.stages_completed,
            "error": self.error,
            "rollback_performed": self.rollback_performed,
            "backup_path": str(self.backup_path) if self.backup_path else None,
            "log_file": str(self.log_file) if self.log_file else None,
            "metadata": self.metadata,
        }


@dataclass
class UpdateProgress:
    """
    Progress information for ongoing update.

    Attributes:
        status: Current status
        stage: Current stage
        progress: Progress percentage (0-100)
        message: Progress message
        bytes_downloaded: Bytes downloaded (for download stage)
        total_bytes: Total bytes to download
        current_file: Current file being processed
        total_files: Total files to process
        metadata: Additional metadata
    """

    status: UpdateStatus
    stage: UpdateStage
    progress: float = 0.0
    message: str = ""
    bytes_downloaded: Optional[int] = None
    total_bytes: Optional[int] = None
    current_file: Optional[str] = None
    total_files: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate progress value"""
        self.progress = max(0.0, min(100.0, self.progress))

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "status": self.status.value,
            "stage": self.stage.value,
            "progress": self.progress,
            "message": self.message,
            "bytes_downloaded": self.bytes_downloaded,
            "total_bytes": self.total_bytes,
            "current_file": self.current_file,
            "total_files": self.total_files,
            "metadata": self.metadata,
        }


@dataclass
class PendingUpdate:
    """
    Information about a pending update that needs verification.

    Attributes:
        update_id: Unique update identifier
        version: Version being updated to
        timestamp: When update was applied
        backup_path: Path to backup
        attempt_count: Number of verification attempts
        max_attempts: Maximum verification attempts
        metadata: Additional metadata (e.g., update_log_id)
    """

    update_id: str
    version: str
    timestamp: datetime
    backup_path: Path
    attempt_count: int = 0
    max_attempts: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)

    def increment_attempt(self) -> bool:
        """
        Increment attempt count.

        Returns:
            True if more attempts available, False if exceeded
        """
        self.attempt_count += 1
        return self.attempt_count < self.max_attempts

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "update_id": self.update_id,
            "version": self.version,
            "timestamp": self.timestamp.isoformat(),
            "backup_path": str(self.backup_path),
            "attempt_count": self.attempt_count,
            "max_attempts": self.max_attempts,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PendingUpdate":
        """Create from dictionary"""
        return cls(
            update_id=data["update_id"],
            version=data["version"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            backup_path=Path(data["backup_path"]),
            attempt_count=data.get("attempt_count", 0),
            max_attempts=data.get("max_attempts", 3),
            metadata=data.get("metadata", {}),
        )


@dataclass
class VersionInfo:
    """
    Version information.

    Attributes:
        version: Version string
        major: Major version number
        minor: Minor version number
        patch: Patch version number
        prerelease: Prerelease identifier (alpha, beta, rc, etc.)
        build: Build metadata
    """

    version: str
    major: int = 0
    minor: int = 0
    patch: int = 0
    prerelease: Optional[str] = None
    build: Optional[str] = None

    @classmethod
    def parse(cls, version_string: str) -> "VersionInfo":
        """
        Parse version string into components.

        Supports semantic versioning format: major.minor.patch[-prerelease][+build]

        Args:
            version_string: Version string to parse

        Returns:
            VersionInfo instance
        """
        # Remove 'v' prefix if present
        version = version_string.lstrip("v")

        # Extract build metadata
        build = None
        if "+" in version:
            version, build = version.split("+", 1)

        # Extract prerelease
        prerelease = None
        if "-" in version:
            version, prerelease = version.split("-", 1)

        # Parse version numbers
        parts = version.split(".")
        major = int(parts[0]) if len(parts) > 0 and parts[0].isdigit() else 0
        minor = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
        patch = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0

        return cls(
            version=version_string,
            major=major,
            minor=minor,
            patch=patch,
            prerelease=prerelease,
            build=build,
        )

    def compare(self, other: "VersionInfo") -> int:
        """
        Compare with another version.

        Returns:
            -1 if self < other
             0 if self == other
             1 if self > other
        """
        # Compare major.minor.patch
        for a, b in [
            (self.major, other.major),
            (self.minor, other.minor),
            (self.patch, other.patch),
        ]:
            if a < b:
                return -1
            elif a > b:
                return 1

        # If versions are equal, compare prerelease
        # No prerelease > prerelease (1.0.0 > 1.0.0-beta)
        if self.prerelease is None and other.prerelease is not None:
            return 1
        elif self.prerelease is not None and other.prerelease is None:
            return -1
        elif self.prerelease and other.prerelease:
            # Simple string comparison for prerelease
            if self.prerelease < other.prerelease:
                return -1
            elif self.prerelease > other.prerelease:
                return 1

        return 0

    def __lt__(self, other: "VersionInfo") -> bool:
        return self.compare(other) < 0

    def __le__(self, other: "VersionInfo") -> bool:
        return self.compare(other) <= 0

    def __gt__(self, other: "VersionInfo") -> bool:
        return self.compare(other) > 0

    def __ge__(self, other: "VersionInfo") -> bool:
        return self.compare(other) >= 0

    def __eq__(self, other: "VersionInfo") -> bool:
        return self.compare(other) == 0
