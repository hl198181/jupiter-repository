#!/usr/bin/env python3
"""
OTA State Machine

This module implements the state machine for OTA operations.
"""

import logging
from datetime import datetime
from typing import Any, Callable, Dict, Optional

from .exceptions import OTAStateError
from .models import UpdateStatus

logger = logging.getLogger(__name__)


class OTAStateMachine:
    """
    State machine for OTA update process.

    Manages state transitions and ensures valid update flow.
    """

    # Valid state transitions
    TRANSITIONS = {
        UpdateStatus.IDLE: [UpdateStatus.CHECKING, UpdateStatus.DOWNLOADING],  # Can skip checking
        UpdateStatus.CHECKING: [
            UpdateStatus.DOWNLOADING,
            UpdateStatus.IDLE,  # No update available
            UpdateStatus.FAILED,
            UpdateStatus.ABORTED,
        ],
        UpdateStatus.DOWNLOADING: [
            UpdateStatus.VERIFYING,
            UpdateStatus.FAILED,
            UpdateStatus.ABORTED,
        ],
        UpdateStatus.VERIFYING: [
            UpdateStatus.BACKING_UP,
            UpdateStatus.APPLYING,  # Can skip backup
            UpdateStatus.FAILED,
            UpdateStatus.ABORTED,
        ],
        UpdateStatus.BACKING_UP: [UpdateStatus.APPLYING, UpdateStatus.FAILED, UpdateStatus.ABORTED],
        UpdateStatus.APPLYING: [
            UpdateStatus.RESTARTING,
            UpdateStatus.HEALTH_CHECKING,  # Can skip restart
            UpdateStatus.COMPLETED,  # Can skip health check
            UpdateStatus.FAILED,
            UpdateStatus.ROLLED_BACK,
        ],
        UpdateStatus.RESTARTING: [
            UpdateStatus.HEALTH_CHECKING,
            UpdateStatus.PENDING,  # Pending verification after restart
            UpdateStatus.FAILED,
        ],
        UpdateStatus.HEALTH_CHECKING: [
            UpdateStatus.COMPLETED,
            UpdateStatus.FAILED,
            UpdateStatus.ROLLED_BACK,
        ],
        UpdateStatus.COMPLETED: [UpdateStatus.IDLE],  # Ready for next update
        UpdateStatus.FAILED: [
            UpdateStatus.ROLLED_BACK,
            UpdateStatus.IDLE,  # Reset without rollback
        ],
        UpdateStatus.ROLLED_BACK: [UpdateStatus.IDLE],  # Ready for retry
        UpdateStatus.ABORTED: [UpdateStatus.IDLE],  # Reset after abort
        UpdateStatus.PENDING: [
            UpdateStatus.HEALTH_CHECKING,  # Resume health check
            UpdateStatus.COMPLETED,
            UpdateStatus.FAILED,
            UpdateStatus.ROLLED_BACK,
        ],
    }

    def __init__(self):
        """Initialize state machine"""
        self._current_state = UpdateStatus.IDLE
        self._previous_state: Optional[UpdateStatus] = None
        self._state_history: list = []
        self._state_data: Dict[str, Any] = {}
        self._transition_callbacks: Dict[UpdateStatus, list] = {}
        self._state_entered_at: Optional[datetime] = None

    @property
    def current_state(self) -> UpdateStatus:
        """Get current state"""
        return self._current_state

    @property
    def previous_state(self) -> Optional[UpdateStatus]:
        """Get previous state"""
        return self._previous_state

    @property
    def state_history(self) -> list:
        """Get state transition history"""
        return self._state_history.copy()

    @property
    def state_data(self) -> Dict[str, Any]:
        """Get state data"""
        return self._state_data.copy()

    @property
    def time_in_state(self) -> float:
        """Get time spent in current state (seconds)"""
        if self._state_entered_at:
            return (datetime.now() - self._state_entered_at).total_seconds()
        return 0.0

    def can_transition(self, to_state: UpdateStatus) -> bool:
        """
        Check if transition is valid.

        Args:
            to_state: Target state

        Returns:
            True if transition is valid
        """
        if self._current_state not in self.TRANSITIONS:
            return False
        return to_state in self.TRANSITIONS[self._current_state]

    def transition(self, to_state: UpdateStatus, data: Optional[Dict[str, Any]] = None) -> None:
        """
        Transition to new state.

        Args:
            to_state: Target state
            data: Optional state data

        Raises:
            OTAStateError: If transition is invalid
        """
        if not self.can_transition(to_state):
            raise OTAStateError(
                self._current_state.value,
                to_state.value,
                f"Invalid transition from {self._current_state.value} to {to_state.value}",
            )

        # Store transition in history
        self._state_history.append(
            {
                "from": self._current_state.value,
                "to": to_state.value,
                "timestamp": datetime.now().isoformat(),
                "data": data,
            }
        )

        # Update states
        self._previous_state = self._current_state
        self._current_state = to_state
        self._state_entered_at = datetime.now()

        # Update state data
        if data:
            self._state_data.update(data)

        logger.info(f"State transition: {self._previous_state.value} -> {to_state.value}")

        # Call transition callbacks
        self._trigger_callbacks(to_state)

    def reset(self) -> None:
        """Reset state machine to idle"""
        self._current_state = UpdateStatus.IDLE
        self._previous_state = None
        self._state_history.clear()
        self._state_data.clear()
        self._state_entered_at = datetime.now()
        logger.info("State machine reset to IDLE")

    def abort(self, reason: str = "User requested") -> None:
        """
        Abort current operation.

        Args:
            reason: Abort reason
        """
        if self._current_state not in [
            UpdateStatus.IDLE,
            UpdateStatus.COMPLETED,
            UpdateStatus.FAILED,
            UpdateStatus.ABORTED,
        ]:
            self.transition(UpdateStatus.ABORTED, {"reason": reason})
        else:
            logger.warning(f"Cannot abort from state: {self._current_state.value}")

    def register_callback(
        self, state: UpdateStatus, callback: Callable[[UpdateStatus, Optional[UpdateStatus]], None]
    ) -> None:
        """
        Register callback for state transition.

        Args:
            state: State to trigger callback
            callback: Callback function(new_state, old_state)
        """
        if state not in self._transition_callbacks:
            self._transition_callbacks[state] = []
        self._transition_callbacks[state].append(callback)

    def unregister_callback(self, state: UpdateStatus, callback: Callable) -> None:
        """
        Unregister callback.

        Args:
            state: State to unregister from
            callback: Callback to remove
        """
        if state in self._transition_callbacks:
            try:
                self._transition_callbacks[state].remove(callback)
            except ValueError:
                pass

    def _trigger_callbacks(self, new_state: UpdateStatus) -> None:
        """
        Trigger callbacks for state transition.

        Args:
            new_state: New state entered
        """
        if new_state in self._transition_callbacks:
            for callback in self._transition_callbacks[new_state]:
                try:
                    callback(new_state, self._previous_state)
                except Exception as e:
                    logger.error(f"Callback error for state {new_state.value}: {e}")

    def set_data(self, key: str, value: Any) -> None:
        """
        Set state data.

        Args:
            key: Data key
            value: Data value
        """
        self._state_data[key] = value

    def get_data(self, key: str, default: Any = None) -> Any:
        """
        Get state data.

        Args:
            key: Data key
            default: Default value if key not found

        Returns:
            Data value or default
        """
        return self._state_data.get(key, default)

    def clear_data(self) -> None:
        """Clear state data"""
        self._state_data.clear()

    def is_running(self) -> bool:
        """Check if update is in progress"""
        return self._current_state not in [
            UpdateStatus.IDLE,
            UpdateStatus.COMPLETED,
            UpdateStatus.FAILED,
            UpdateStatus.ROLLED_BACK,
            UpdateStatus.ABORTED,
        ]

    def is_terminal(self) -> bool:
        """Check if in terminal state"""
        return self._current_state in [
            UpdateStatus.COMPLETED,
            UpdateStatus.FAILED,
            UpdateStatus.ROLLED_BACK,
            UpdateStatus.ABORTED,
        ]

    def get_summary(self) -> Dict[str, Any]:
        """
        Get state machine summary.

        Returns:
            Summary dictionary
        """
        return {
            "current_state": self._current_state.value,
            "previous_state": self._previous_state.value if self._previous_state else None,
            "is_running": self.is_running(),
            "is_terminal": self.is_terminal(),
            "time_in_state": self.time_in_state,
            "history_length": len(self._state_history),
            "data_keys": list(self._state_data.keys()),
        }

    def __repr__(self) -> str:
        """String representation"""
        return f"OTAStateMachine(state={self._current_state.value}, running={self.is_running()})"
