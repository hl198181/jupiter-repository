"""Registry 处理器接口

Registry handler interfaces.

提供可插拔的处理器接口：
- ProvisionHandler: 出厂设置处理器（制造商工具）
- RegistrationHandler: 设备注册处理器（用户工具）
- LocalRegistrationHandler: 本地注册处理器（仅检查本地凭证）

App 层可以实现自定义的 HTTP 处理器。

Provides pluggable handler interfaces for provision and registration.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from .identity import DeviceFingerprint
from .storage import RegistryCredentials


class ProvisionHandler(ABC):
    """出厂设置处理器抽象基类

    Provision handler abstract base class.

    用于制造商工具创建出厂激活码。
    需要制造商凭证进行认证。

    App 层可以实现 HTTPProvisionHandler 使用 HTTP API。
    """

    @abstractmethod
    def create_activation_code(
        self,
        fingerprint: DeviceFingerprint,
        model: str,
        batch: str,
        site: str,
        expires_days: int,
    ) -> Dict[str, Any]:
        """创建激活码

        Create activation code.

        使用设备硬件指纹和制造信息创建激活码。

        Args:
            fingerprint: 设备硬件指纹
            model: 设备型号 UUID
            batch: 制造批次（如 'BATCH-2024-001'）
            site: 制造地点（如 'Factory-A'）
            expires_days: 激活码有效期（天）

        Returns:
            包含以下字段的字典：
            - activation_code: 激活码字符串
            - serial_number: 设备序列号
            - model: 型号名称
            - model_code: 型号代码
            - expires_at: 过期时间
            - qr_code_url: 二维码 URL（可选）
            - message: 附加消息（可选）

        Raises:
            ProvisionError: 创建激活码失败
        """
        pass


class RegistrationHandler(ABC):
    """设备注册处理器抽象基类

    Registration handler abstract base class.

    用于用户工具将设备注册到组织。
    需要用户凭证进行认证。

    App 层可以实现 HTTPRegistrationHandler 使用 HTTP API。
    """

    @abstractmethod
    def register_device(
        self,
        activation_code: str,
        username: str,
        password: str,
        device_id: Optional[str] = None,
        installation_site: Optional[str] = None,
        installation_notes: Optional[str] = None,
    ) -> RegistryCredentials:
        """注册设备

        Register device.

        使用激活码和用户凭证将设备注册到组织。

        Args:
            activation_code: 激活码
            username: 用户账号
            password: 用户密码
            device_id: 自定义设备 ID（可选）
            installation_site: 安装地点（可选）
            installation_notes: 安装备注（可选）

        Returns:
            RegistryCredentials 对象，包含 device_id、device_token 等

        Raises:
            RegistrationError: 注册失败（激活码无效、用户凭证错误等）
        """
        pass

    @abstractmethod
    def check_registration(self, credentials: RegistryCredentials) -> bool:
        """检查注册状态

        Check registration status.

        验证设备注册状态（可选的服务器端验证）。

        Args:
            credentials: 设备凭证

        Returns:
            True 如果设备已注册且状态有效

        Raises:
            RegistrationError: 验证失败
        """
        pass


class LocalRegistrationHandler(RegistrationHandler):
    """本地注册处理器

    Local registration handler.

    仅检查本地凭证是否存在，不进行服务器端验证。
    适用于离线场景或测试环境。
    """

    def register_device(
        self,
        activation_code: str,
        username: str,
        password: str,
        device_id: Optional[str] = None,
        installation_site: Optional[str] = None,
        installation_notes: Optional[str] = None,
    ) -> RegistryCredentials:
        """本地注册（模拟）

        Local registration (mock).

        创建一个模拟的凭证对象，不进行实际的服务器注册。
        仅用于测试或离线场景。

        Args:
            activation_code: 激活码
            username: 用户账号（未使用）
            password: 用户密码（未使用）
            device_id: 自定义设备 ID（可选）
            installation_site: 安装地点（可选）
            installation_notes: 安装备注（可选）

        Returns:
            RegistryCredentials 对象（模拟数据）
        """
        from datetime import datetime

        # 生成模拟的设备 ID 和 token
        mock_device_id = device_id or f"local-device-{activation_code[:8]}"
        mock_token = f"local-token-{activation_code}"

        return RegistryCredentials(
            device_id=mock_device_id,
            device_token=mock_token,
            activation_code=activation_code,
            device_info={
                "installation_site": installation_site,
                "installation_notes": installation_notes,
                "registered_by": username,
            },
            registered_at=datetime.now().isoformat(),
        )

    def check_registration(self, credentials: RegistryCredentials) -> bool:
        """检查注册状态（本地）

        Check registration status (local).

        仅检查凭证对象是否存在，不进行服务器端验证。

        Args:
            credentials: 设备凭证

        Returns:
            True 如果凭证对象不为 None
        """
        return credentials is not None
