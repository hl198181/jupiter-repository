"""Registry 模块异常

Registry module exceptions.

提供完整的异常层次结构：
- RegistryError: 基础异常
- RegistryConfigError: 配置错误
- RegistryStorageError: 存储错误
- DeviceAlreadyRegisteredError: 设备已注册
- DeviceNotRegisteredError: 设备未注册
- ProvisionError: 出厂设置错误
- RegistrationError: 注册错误

Provides complete exception hierarchy for Registry module.
"""

from __future__ import annotations


class RegistryError(Exception):
    """Registry 模块基础异常

    Base exception for Registry module.

    所有 Registry 模块的异常都继承自此类。
    """

    pass


class RegistryConfigError(RegistryError):
    """配置错误

    Configuration error.

    当配置文件格式错误、缺少必需字段或参数无效时抛出。
    """

    pass


class RegistryStorageError(RegistryError):
    """存储错误

    Storage error.

    当凭证文件读写失败时抛出。
    """

    pass


class DeviceAlreadyRegisteredError(RegistryError):
    """设备已注册错误

    Device already registered error.

    当尝试注册一个已经注册过的设备时抛出（除非使用 force=True）。
    """

    pass


class DeviceNotRegisteredError(RegistryError):
    """设备未注册错误

    Device not registered error.

    当需要已注册设备的操作但设备尚未注册时抛出。
    """

    pass


class ProvisionError(RegistryError):
    """出厂设置错误

    Provision error.

    当出厂激活码创建失败时抛出。
    通常是由于：
    - 制造商凭证无效
    - 设备硬件指纹重复
    - API 请求失败
    """

    pass


class RegistrationError(RegistryError):
    """注册错误

    Registration error.

    当设备注册失败时抛出。
    通常是由于：
    - 激活码无效或已使用
    - 用户凭证错误
    - API 请求失败
    """

    pass
