"""Registry 模块配置

Registry module configuration models using Pydantic.

提供 Registry 模块的配置数据模型：
- RegistryConfig: Registry 管理器配置

Provides configuration models for Registry module.
"""

from __future__ import annotations

from pathlib import Path

try:
    from pydantic import BaseModel
except ImportError:
    raise ImportError(
        "pydantic is required for Registry module. "
        "Install with: pip install jupiter-stream[registry]"
    )


class RegistryConfig(BaseModel):
    """Registry 配置

    Registry configuration.

    极简配置，仅包含本地存储路径。
    不包含任何 HTTP/网络配置，这些由 App 层处理。
    """

    storage_path: str = "~/.jupiter/device.json"
    """凭证存储文件路径（支持 ~ 扩展）"""

    @classmethod
    def from_dict(cls, config_dict: dict) -> RegistryConfig:
        """从字典创建配置

        Create configuration from dictionary.

        Args:
            config_dict: 配置字典

        Returns:
            RegistryConfig 实例
        """
        return cls(**config_dict)

    @classmethod
    def from_yaml(cls, file_path: str) -> RegistryConfig:
        """从 YAML 文件加载配置

        Load configuration from YAML file.

        Args:
            file_path: YAML 配置文件路径

        Returns:
            RegistryConfig 实例

        Raises:
            ImportError: PyYAML 未安装
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load YAML config. " "Install with: pip install pyyaml"
            )

        with open(file_path, encoding="utf-8") as f:
            config_dict = yaml.safe_load(f)

        # 支持顶层 'registry' 键或直接配置
        if "registry" in config_dict:
            config_dict = config_dict["registry"]

        return cls(**config_dict)

    @classmethod
    def from_json(cls, file_path: str) -> RegistryConfig:
        """从 JSON 文件加载配置

        Load configuration from JSON file.

        Args:
            file_path: JSON 配置文件路径

        Returns:
            RegistryConfig 实例
        """
        import json

        with open(file_path, encoding="utf-8") as f:
            config_dict = json.load(f)

        # 支持顶层 'registry' 键或直接配置
        if "registry" in config_dict:
            config_dict = config_dict["registry"]

        return cls(**config_dict)

    @classmethod
    def from_file(cls, file_path: str) -> RegistryConfig:
        """从文件加载配置（自动检测格式）

        Load configuration from file (auto-detect format).

        Args:
            file_path: 配置文件路径

        Returns:
            RegistryConfig 实例

        Raises:
            ValueError: 不支持的文件格式
        """
        file_path = Path(file_path)
        suffix = file_path.suffix.lower()

        if suffix in [".yaml", ".yml"]:
            return cls.from_yaml(str(file_path))
        elif suffix == ".json":
            return cls.from_json(str(file_path))
        else:
            raise ValueError(f"Unsupported config file format: {suffix}")
