"""Registry 管理器

Registry manager for device provisioning and registration.

提供设备注册中心的核心管理功能：
- 硬件指纹采集
- 出厂激活码创建
- 用户设备注册
- 凭证管理
- 事件回调

Provides core management for device registry.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

from .config import RegistryConfig
from .exceptions import DeviceAlreadyRegisteredError, RegistryError
from .handlers import ProvisionHandler, RegistrationHandler
from .identity import DeviceFingerprint, DeviceIdentity
from .storage import CredentialStorage, RegistryCredentials

logger = logging.getLogger(__name__)


class RegistryManager:
    """设备注册管理器

    Device registry manager.

    核心功能：
    1. 设备硬件指纹采集
    2. 出厂激活码创建（需注入 ProvisionHandler）
    3. 用户设备注册（需注入 RegistrationHandler）
    4. 凭证本地存储
    5. 注册状态查询
    6. 事件回调

    完全独立，不依赖 Network/HTTP/MQTT 模块。
    通过处理器注入实现功能扩展。
    """

    def __init__(self, config: RegistryConfig):
        """初始化注册管理器

        Initialize registry manager.

        Args:
            config: Registry 配置对象
        """
        self._config = config
        self._storage = CredentialStorage(config.storage_path)

        # 处理器（由 App 层注入）
        self._provision_handler: Optional[ProvisionHandler] = None
        self._registration_handler: Optional[RegistrationHandler] = None

        # 事件回调
        self._callbacks: Dict[str, List[Callable]] = {
            "on_provisioned": [],  # 出厂激活码创建成功
            "on_registered": [],  # 用户注册成功
            "on_deregistered": [],  # 凭证清除
        }

        logger.info(f"RegistryManager initialized with storage: {config.storage_path}")

    # ===== 处理器注入 =====

    def set_provision_handler(self, handler: ProvisionHandler) -> None:
        """设置出厂处理器

        Set provision handler.

        由 App 层调用，注入具体的出厂设置处理器实现。
        例如：HTTPProvisionHandler

        Args:
            handler: 出厂处理器实例
        """
        self._provision_handler = handler
        logger.info(f"Provision handler set: {handler.__class__.__name__}")

    def set_registration_handler(self, handler: RegistrationHandler) -> None:
        """设置注册处理器

        Set registration handler.

        由 App 层调用，注入具体的注册处理器实现。
        例如：HTTPRegistrationHandler

        Args:
            handler: 注册处理器实例
        """
        self._registration_handler = handler
        logger.info(f"Registration handler set: {handler.__class__.__name__}")

    # ===== 硬件指纹 =====

    def get_fingerprint(self) -> DeviceFingerprint:
        """获取设备硬件指纹

        Get device hardware fingerprint.

        采集设备的硬件信息（MAC、CPU序列号、板卡信息）。

        Returns:
            DeviceFingerprint 对象
        """
        return DeviceIdentity.get_device_fingerprint()

    # ===== 出厂设置（制造商工具）=====

    def create_activation_code(
        self, model: str, batch: str, site: str, expires_days: int = 365
    ) -> Dict[str, Any]:
        """创建出厂激活码

        Create factory activation code.

        制造商工具使用，需要已设置 provision_handler。

        Args:
            model: 设备型号 UUID
            batch: 制造批次（如 'BATCH-2024-001'）
            site: 制造地点（如 'Factory-A'）
            expires_days: 激活码有效期（天，默认365）

        Returns:
            包含激活码、序列号、二维码等信息的字典

        Raises:
            RegistryError: 未设置 provision_handler
            ProvisionError: 创建激活码失败
        """
        if not self._provision_handler:
            raise RegistryError(
                "No provision handler set. " "Call set_provision_handler() first in your app code."
            )

        logger.info(f"Creating activation code: model={model}, batch={batch}")

        # 获取设备指纹
        fingerprint = self.get_fingerprint()

        # 调用处理器创建激活码
        result = self._provision_handler.create_activation_code(
            fingerprint=fingerprint,
            model=model,
            batch=batch,
            site=site,
            expires_days=expires_days,
        )

        # 触发事件
        self._emit_event("on_provisioned", result)

        logger.info(f"Activation code created: {result.get('activation_code')}")
        return result

    # ===== 用户注册 =====

    def register(
        self,
        activation_code: str,
        username: str,
        password: str,
        force: bool = False,
        **kwargs,
    ) -> RegistryCredentials:
        """注册设备

        Register device.

        用户工具使用，需要已设置 registration_handler。

        Args:
            activation_code: 激活码
            username: 用户账号
            password: 用户密码
            force: 是否强制重新注册（清除已有凭证）
            **kwargs: 其他参数（device_id, installation_site, installation_notes等）

        Returns:
            RegistryCredentials 对象

        Raises:
            RegistryError: 未设置 registration_handler
            DeviceAlreadyRegisteredError: 设备已注册且未使用 force=True
            RegistrationError: 注册失败
        """
        if not self._registration_handler:
            raise RegistryError(
                "No registration handler set. "
                "Call set_registration_handler() first in your app code."
            )

        # 检查是否已注册
        existing = self._storage.load()
        if existing and not force:
            raise DeviceAlreadyRegisteredError(
                f"Device already registered: {existing.device_id}. "
                f"Use force=True to re-register."
            )

        if existing and force:
            logger.warning(f"Force re-registering device: {existing.device_id}")

        logger.info(f"Registering device with activation code: {activation_code[:8]}***")

        # 调用处理器注册设备
        credentials = self._registration_handler.register_device(
            activation_code=activation_code,
            username=username,
            password=password,
            **kwargs,
        )

        # 保存凭证
        self._storage.save(credentials)
        logger.info(f"Device registered successfully: {credentials.device_id}")

        # 触发事件
        self._emit_event("on_registered", credentials)

        return credentials

    # ===== 状态查询 =====

    def is_registered(self) -> bool:
        """检查是否已注册

        Check if device is registered.

        如果设置了 registration_handler，则进行服务器端验证。
        否则仅检查本地凭证是否存在。

        Returns:
            True 如果设备已注册
        """
        credentials = self._storage.load()
        if not credentials:
            return False

        # 如果有处理器，进行服务器端验证
        if self._registration_handler:
            try:
                return self._registration_handler.check_registration(credentials)
            except Exception as e:
                logger.error(f"Failed to check registration status: {e}")
                # 验证失败时，降级到本地检查
                return True

        # 仅检查本地凭证
        return True

    def get_credentials(self) -> Optional[RegistryCredentials]:
        """获取存储的凭证

        Get stored credentials.

        Returns:
            RegistryCredentials 对象，如果未注册返回 None
        """
        return self._storage.load()

    def get_device_id(self) -> Optional[str]:
        """获取设备 ID

        Get device ID.

        Returns:
            设备 ID 字符串，如果未注册返回 None
        """
        creds = self._storage.load()
        return creds.device_id if creds else None

    def credentials_exist(self) -> bool:
        """检查凭证文件是否存在

        Check if credentials file exists.

        Returns:
            True 如果凭证文件存在
        """
        return self._storage.exists()

    # ===== 凭证管理 =====

    def clear_credentials(self) -> None:
        """清除凭证

        Clear credentials.

        删除本地凭证文件，用于重新注册前清理。

        Raises:
            RegistryStorageError: 文件删除失败
        """
        logger.warning("Clearing device credentials")
        self._storage.clear()

        # 触发事件
        self._emit_event("on_deregistered")

        logger.info("Device credentials cleared")

    # ===== 事件系统 =====

    def register_callback(self, event: str, callback: Callable) -> None:
        """注册事件回调

        Register event callback.

        支持的事件：
        - on_provisioned: 出厂激活码创建成功（参数：result dict）
        - on_registered: 用户注册成功（参数：RegistryCredentials）
        - on_deregistered: 凭证清除（无参数）

        Args:
            event: 事件名称
            callback: 回调函数

        Raises:
            ValueError: 不支持的事件名称
        """
        if event not in self._callbacks:
            raise ValueError(
                f"Unknown event: {event}. " f"Supported events: {list(self._callbacks.keys())}"
            )

        self._callbacks[event].append(callback)
        logger.debug(f"Callback registered for event: {event}")

    def _emit_event(self, event: str, *args, **kwargs) -> None:
        """触发事件

        Emit event.

        调用所有注册的回调函数。

        Args:
            event: 事件名称
            *args: 传递给回调的位置参数
            **kwargs: 传递给回调的关键字参数
        """
        if event not in self._callbacks:
            return

        for callback in self._callbacks[event]:
            try:
                callback(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in callback for event {event}: {e}", exc_info=True)

    # ===== 配置加载 =====

    @classmethod
    def from_config(cls, config_path: str) -> RegistryManager:
        """从配置文件创建管理器

        Create manager from configuration file.

        Args:
            config_path: 配置文件路径（YAML或JSON）

        Returns:
            RegistryManager 实例

        Raises:
            RegistryConfigError: 配置文件加载失败
        """
        config = RegistryConfig.from_file(config_path)
        return cls(config)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> RegistryManager:
        """从字典创建管理器

        Create manager from dictionary.

        Args:
            config_dict: 配置字典

        Returns:
            RegistryManager 实例
        """
        config = RegistryConfig.from_dict(config_dict)
        return cls(config)
