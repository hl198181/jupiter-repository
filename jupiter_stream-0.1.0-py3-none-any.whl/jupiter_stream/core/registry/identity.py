"""设备硬件指纹采集

Device hardware fingerprint collection.

提供设备硬件信息采集功能：
- MAC 地址获取
- CPU 序列号获取（Raspberry Pi/Jetson）
- 板卡信息获取
- 完整设备指纹生成

Provides device hardware information collection.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class DeviceFingerprint:
    """设备硬件指纹

    Device hardware fingerprint.

    包含设备的唯一标识信息：
    - mac_address: 主MAC地址（必需）
    - cpu_serial: CPU序列号（可选，某些平台特有）
    - serial_number: 设备序列号（可选）
    - board_info: 板卡型号信息（必需）
    """

    mac_address: str
    cpu_serial: Optional[str]
    serial_number: Optional[str]
    board_info: str


class DeviceIdentity:
    """设备硬件信息采集

    Device hardware information collector.

    完全独立的静态类，无外部依赖。
    支持多种嵌入式平台：
    - Raspberry Pi
    - NVIDIA Jetson
    - 通用 Linux
    """

    @staticmethod
    def get_mac_address() -> str:
        """获取主要 MAC 地址

        Get primary MAC address.

        优先从 /sys/class/net/ 读取第一个非 lo 网卡的 MAC 地址。
        如果失败，使用 uuid.getnode() 作为备用方案。

        Returns:
            MAC 地址字符串（格式：xx:xx:xx:xx:xx:xx）

        Raises:
            RuntimeError: 无法获取 MAC 地址
        """
        # 方案1: 从 /sys/class/net/ 读取
        net_path = Path("/sys/class/net")
        if net_path.exists():
            for interface in sorted(net_path.iterdir()):
                # 跳过 loopback 和虚拟接口
                if interface.name in ("lo", "docker0", "veth"):
                    continue

                address_file = interface / "address"
                if address_file.exists():
                    try:
                        mac = address_file.read_text().strip()
                        if mac and mac != "00:00:00:00:00:00":
                            return mac
                    except OSError:
                        continue

        # 方案2: 使用 uuid.getnode()
        mac_int = uuid.getnode()
        mac = ":".join([f"{(mac_int >> i) & 0xFF:02x}" for i in range(0, 48, 8)][::-1])
        return mac

    @staticmethod
    def get_cpu_serial() -> Optional[str]:
        """获取 CPU 序列号

        Get CPU serial number.

        支持 Raspberry Pi 和 NVIDIA Jetson 平台。
        尝试以下方法获取序列号：
        1. 从 /proc/cpuinfo 读取 Serial 字段（Raspberry Pi）
        2. 从 /sys/firmware/devicetree/base/serial-number 读取（NVIDIA Jetson）

        Returns:
            CPU 序列号，如果不存在返回 None
        """
        # 方案1: 从 /proc/cpuinfo 读取 Serial 字段（Raspberry Pi）
        cpuinfo_path = Path("/proc/cpuinfo")
        if cpuinfo_path.exists():
            try:
                content = cpuinfo_path.read_text()
                # 查找 Serial 字段
                match = re.search(
                    r"^Serial\s+:\s+([0-9a-f]+)$", content, re.MULTILINE | re.IGNORECASE
                )
                if match:
                    return match.group(1)
            except OSError:
                pass

        # 方案2: 从 devicetree 读取（NVIDIA Jetson）
        dt_serial_path = Path("/sys/firmware/devicetree/base/serial-number")
        if dt_serial_path.exists():
            try:
                serial = dt_serial_path.read_text().strip("\x00").strip()
                if serial:
                    return serial
            except OSError:
                pass

        return None

    @staticmethod
    def get_board_info() -> str:
        """获取板卡信息

        Get board information.

        从以下位置尝试读取板卡型号：
        1. /proc/device-tree/model（优先）
        2. /proc/cpuinfo 的 Model 或 Hardware 字段

        Returns:
            板卡型号信息（如果无法获取返回 'Unknown'）
        """
        # 方案1: 从 /proc/device-tree/model 读取
        model_path = Path("/proc/device-tree/model")
        if model_path.exists():
            try:
                model = model_path.read_text().strip("\x00").strip()
                if model:
                    return model
            except OSError:
                pass

        # 方案2: 从 /proc/cpuinfo 读取
        cpuinfo_path = Path("/proc/cpuinfo")
        if cpuinfo_path.exists():
            try:
                content = cpuinfo_path.read_text()
                # 查找 Model 或 Hardware 字段
                for pattern in [r"^Model\s+:\s+(.+)$", r"^Hardware\s+:\s+(.+)$"]:
                    match = re.search(pattern, content, re.MULTILINE | re.IGNORECASE)
                    if match:
                        return match.group(1).strip()
            except OSError:
                pass

        return "Unknown"

    @staticmethod
    def get_serial_number() -> Optional[str]:
        """获取设备序列号

        Get device serial number.

        对于 Raspberry Pi/Jetson，CPU 序列号即为设备序列号。
        其他平台可能需要从其他位置读取。

        Returns:
            设备序列号，如果不存在返回 None
        """
        # 对于树莓派和 Jetson，CPU 序列号就是设备序列号
        return DeviceIdentity.get_cpu_serial()

    @staticmethod
    def get_device_fingerprint() -> DeviceFingerprint:
        """获取完整的设备指纹

        Get complete device fingerprint.

        采集所有硬件信息并返回 DeviceFingerprint 对象。

        Returns:
            DeviceFingerprint 对象，包含完整硬件信息
        """
        return DeviceFingerprint(
            mac_address=DeviceIdentity.get_mac_address(),
            cpu_serial=DeviceIdentity.get_cpu_serial(),
            serial_number=DeviceIdentity.get_serial_number(),
            board_info=DeviceIdentity.get_board_info(),
        )
