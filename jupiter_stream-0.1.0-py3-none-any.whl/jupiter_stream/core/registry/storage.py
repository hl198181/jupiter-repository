"""设备凭证存储

Device credentials storage.

提供设备注册凭证的本地持久化功能：
- RegistryCredentials: 凭证数据模型
- CredentialStorage: 本地 JSON 存储

Provides local persistence for device registry credentials.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from .exceptions import RegistryStorageError


@dataclass
class RegistryCredentials:
    """设备注册凭证

    Device registry credentials.

    存储设备注册后从服务器获取的凭证信息：
    - device_id: 设备唯一标识
    - device_token: 设备认证令牌
    - activation_code: 激活码（可选）
    - device_info: 服务器返回的设备详情（可选）
    - registered_at: 注册时间（可选）
    """

    device_id: str
    device_token: str
    activation_code: Optional[str] = None
    device_info: Optional[Dict[str, Any]] = None
    registered_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典

        Convert to dictionary.

        Returns:
            字典格式的凭证数据
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> RegistryCredentials:
        """从字典创建

        Create from dictionary.

        Args:
            data: 凭证数据字典

        Returns:
            RegistryCredentials 实例
        """
        return cls(
            device_id=data["device_id"],
            device_token=data["device_token"],
            activation_code=data.get("activation_code"),
            device_info=data.get("device_info"),
            registered_at=data.get("registered_at"),
        )


class CredentialStorage:
    """设备凭证本地存储

    Device credentials local storage.

    使用 JSON 文件持久化存储设备凭证。
    完全独立，无外部依赖。
    """

    def __init__(self, storage_path: str = "~/.jupiter/device.json"):
        """初始化存储

        Initialize storage.

        Args:
            storage_path: JSON 文件路径（支持 ~ 扩展）
        """
        self.storage_path = Path(storage_path).expanduser()

    def save(self, credentials: RegistryCredentials) -> None:
        """保存凭证到文件

        Save credentials to file.

        如果目录不存在会自动创建。
        保存时自动添加 saved_at 时间戳。

        Args:
            credentials: 要保存的凭证对象

        Raises:
            RegistryStorageError: 文件写入失败
        """
        try:
            # 确保目录存在
            self.storage_path.parent.mkdir(parents=True, exist_ok=True)

            # 转换为字典并添加时间戳
            data = credentials.to_dict()
            data["saved_at"] = datetime.now().isoformat()

            # 写入 JSON 文件
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

        except OSError as e:
            raise RegistryStorageError(f"Failed to save credentials: {e}") from e
        except Exception as e:
            raise RegistryStorageError(f"Unexpected error saving credentials: {e}") from e

    def load(self) -> Optional[RegistryCredentials]:
        """从文件加载凭证

        Load credentials from file.

        Returns:
            RegistryCredentials 对象，如果文件不存在返回 None

        Raises:
            RegistryStorageError: 文件读取或解析失败
        """
        if not self.storage_path.exists():
            return None

        try:
            with open(self.storage_path, encoding="utf-8") as f:
                data = json.load(f)

            # 从字典创建凭证对象
            return RegistryCredentials.from_dict(data)

        except json.JSONDecodeError as e:
            raise RegistryStorageError(f"Invalid JSON format in credentials file: {e}") from e
        except OSError as e:
            raise RegistryStorageError(f"Failed to load credentials: {e}") from e
        except KeyError as e:
            raise RegistryStorageError(f"Missing required field in credentials: {e}") from e
        except Exception as e:
            raise RegistryStorageError(f"Unexpected error loading credentials: {e}") from e

    def exists(self) -> bool:
        """检查凭证文件是否存在

        Check if credentials file exists.

        Returns:
            True 如果文件存在
        """
        return self.storage_path.exists()

    def clear(self) -> None:
        """删除凭证文件

        Delete credentials file.

        如果文件不存在则静默忽略。

        Raises:
            RegistryStorageError: 文件删除失败
        """
        if not self.storage_path.exists():
            return

        try:
            self.storage_path.unlink()
        except OSError as e:
            raise RegistryStorageError(f"Failed to clear credentials: {e}") from e
