"""Registry 模块

Registry module for device provisioning and registration.

提供设备注册中心功能：
- 设备硬件指纹采集
- 出厂激活码生成（制造商工具）
- 用户设备注册
- 凭证本地存储
- 注册状态查询

Provides device registry functionality for provisioning and registration.

Examples:
    >>> from jupiter_stream.core.registry import RegistryManager, LocalRegistrationHandler
    >>>
    >>> # 创建注册管理器
    >>> manager = RegistryManager.from_config("registry_config.yaml")
    >>>
    >>> # 获取设备硬件指纹
    >>> fingerprint = manager.get_fingerprint()
    >>> print(f"MAC: {fingerprint.mac_address}")
    >>>
    >>> # 设置本地注册处理器
    >>> handler = LocalRegistrationHandler()
    >>> manager.set_registration_handler(handler)
    >>>
    >>> # 注册设备
    >>> credentials = manager.register(
    ...     activation_code="ABCD-1234",
    ...     username="user@example.com",
    ...     password="password"
    ... )
    >>> print(f"Device ID: {credentials.device_id}")
"""

from __future__ import annotations

# 配置
from .config import RegistryConfig

# 异常
from .exceptions import (
    DeviceAlreadyRegisteredError,
    DeviceNotRegisteredError,
    ProvisionError,
    RegistrationError,
    RegistryConfigError,
    RegistryError,
    RegistryStorageError,
)

# 处理器
from .handlers import (
    LocalRegistrationHandler,
    ProvisionHandler,
    RegistrationHandler,
)

# 硬件指纹
from .identity import DeviceFingerprint, DeviceIdentity

# 核心管理器
from .manager import RegistryManager

# 凭证存储
from .storage import CredentialStorage, RegistryCredentials

__all__ = [
    # 核心管理器
    "RegistryManager",
    # 配置
    "RegistryConfig",
    # 硬件指纹
    "DeviceFingerprint",
    "DeviceIdentity",
    # 凭证存储
    "CredentialStorage",
    "RegistryCredentials",
    # 处理器
    "ProvisionHandler",
    "RegistrationHandler",
    "LocalRegistrationHandler",
    # 异常
    "RegistryError",
    "RegistryConfigError",
    "RegistryStorageError",
    "DeviceAlreadyRegisteredError",
    "DeviceNotRegisteredError",
    "ProvisionError",
    "RegistrationError",
]
