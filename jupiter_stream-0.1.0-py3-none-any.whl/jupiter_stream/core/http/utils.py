"""HTTP 工具函数

HTTP utility functions / HTTP 工具函数
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, Optional, Tuple
from urllib.parse import urljoin, urlparse


def merge_dicts(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """合并字典（override 覆盖 base）

    Merge dictionaries (override overwrites base)

    Args:
        base: 基础字典 / Base dictionary
        override: 覆盖字典 / Override dictionary

    Returns:
        合并后的字典 / Merged dictionary
    """
    result = base.copy()
    result.update(override)
    return result


def extract_path_vars(path: str, kwargs: Dict[str, Any]) -> Tuple[Dict[str, str], Dict[str, Any]]:
    """从 kwargs 中提取路径变量

    Extract path variables from kwargs based on path template

    Args:
        path: 路径模板，如 "/users/{user_id}/posts/{post_id}"
        kwargs: 调用参数字典

    Returns:
        (path_vars, remaining_kwargs) 元组
        - path_vars: 提取出的路径变量
        - remaining_kwargs: 剩余的参数

    Example:
        >>> extract_path_vars("/users/{user_id}", {"user_id": "123", "page": 1})
        ({"user_id": "123"}, {"page": 1})
    """
    # 提取路径中的变量名
    var_pattern = r"\{([^}]+)\}"
    var_names = re.findall(var_pattern, path)

    path_vars = {}
    remaining = kwargs.copy()

    for var_name in var_names:
        if var_name in remaining:
            path_vars[var_name] = str(remaining.pop(var_name))

    return path_vars, remaining


def format_path(path: str, path_params: Optional[Dict[str, str]] = None) -> str:
    """格式化路径，替换路径参数

    Format path with path parameters

    Args:
        path: 路径模板，如 "/user/{user_id}/posts/{post_id}"
        path_params: 路径参数字典

    Returns:
        格式化后的路径

    Example:
        >>> format_path("/user/{user_id}", {"user_id": "123"})
        '/user/123'
    """
    if not path_params:
        return path

    result = path
    for key, value in path_params.items():
        pattern = f"{{{key}}}"
        result = result.replace(pattern, str(value))

    return result


def build_url(base_url: str, path: str, path_params: Optional[Dict[str, str]] = None) -> str:
    """构建完整 URL

    Build full URL from base URL and path

    Args:
        base_url: 基础 URL
        path: 路径
        path_params: 路径参数

    Returns:
        完整 URL
    """
    # 格式化路径参数
    formatted_path = format_path(path, path_params)

    # 确保 base_url 以 / 结尾，path 以 / 开头
    if not base_url.endswith("/"):
        base_url += "/"
    if formatted_path.startswith("/"):
        formatted_path = formatted_path[1:]

    return urljoin(base_url, formatted_path)


def parse_url(url: str) -> Dict[str, str]:
    """解析 URL

    Parse URL into components

    Args:
        url: 完整 URL

    Returns:
        URL 组成部分字典
    """
    parsed = urlparse(url)
    return {
        "scheme": parsed.scheme,
        "netloc": parsed.netloc,
        "path": parsed.path,
        "params": parsed.params,
        "query": parsed.query,
        "fragment": parsed.fragment,
    }


def sanitize_headers(headers: Dict[str, str]) -> Dict[str, str]:
    """清理 headers，移除空值

    Sanitize headers by removing empty values

    Args:
        headers: 原始 headers

    Returns:
        清理后的 headers
    """
    return {k: v for k, v in headers.items() if v is not None and v != ""}


def get_file_size(file_path: str) -> int:
    """获取文件大小

    Get file size in bytes

    Args:
        file_path: 文件路径

    Returns:
        文件大小（字节）
    """
    return os.path.getsize(file_path)


def format_bytes(size: int) -> str:
    """格式化字节大小为可读字符串

    Format bytes to human-readable string

    Args:
        size: 字节大小

    Returns:
        可读字符串，如 "1.5 MB"
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"


def expand_env_vars(value: str) -> str:
    """展开环境变量

    Expand environment variables in string

    支持格式：${VAR_NAME} 或 $VAR_NAME
    Supports formats: ${VAR_NAME} or $VAR_NAME

    Args:
        value: 包含环境变量的字符串

    Returns:
        展开后的字符串

    Example:
        >>> os.environ['TOKEN'] = 'abc123'
        >>> expand_env_vars("Bearer ${TOKEN}")
        'Bearer abc123'
    """
    if not isinstance(value, str):
        return value

    # 替换 ${VAR_NAME} 格式
    pattern = r"\$\{([^}]+)\}"
    matches = re.findall(pattern, value)
    for var_name in matches:
        env_value = os.environ.get(var_name, "")
        value = value.replace(f"${{{var_name}}}", env_value)

    # 替换 $VAR_NAME 格式（不在 {} 中）
    pattern = r"\$([A-Z_][A-Z0-9_]*)"
    matches = re.findall(pattern, value)
    for var_name in matches:
        env_value = os.environ.get(var_name, "")
        value = value.replace(f"${var_name}", env_value)

    return value
