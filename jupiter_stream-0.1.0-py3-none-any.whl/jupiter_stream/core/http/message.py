"""HTTP 消息数据模型

HTTP message data models / HTTP 消息数据模型
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class Request:
    """HTTP 请求数据模型

    HTTP Request data model
    """

    method: str
    url: str
    headers: Dict[str, str]
    params: Optional[Dict[str, Any]] = None
    json_data: Optional[Dict[str, Any]] = None
    data: Optional[Any] = None
    files: Optional[Dict[str, Any]] = None
    timeout: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典

        Convert to dictionary
        """
        return {
            "method": self.method,
            "url": self.url,
            "headers": self.headers,
            "params": self.params,
            "json": self.json_data,
            "data": self.data,
            "files": self.files,
            "timeout": self.timeout,
        }


@dataclass
class Response:
    """HTTP 响应数据模型

    HTTP Response data model
    """

    status_code: int
    headers: Dict[str, str]
    content: bytes
    text: str
    json_data: Optional[Dict[str, Any]] = None
    url: str = ""
    elapsed: float = 0.0

    def json(self) -> Dict[str, Any]:
        """获取 JSON 数据

        Get JSON data
        """
        if self.json_data is None:
            import json

            self.json_data = json.loads(self.text)
        return self.json_data

    def is_success(self) -> bool:
        """判断请求是否成功

        Check if request was successful
        """
        return 200 <= self.status_code < 300

    def is_error(self) -> bool:
        """判断请求是否失败

        Check if request failed
        """
        return self.status_code >= 400
