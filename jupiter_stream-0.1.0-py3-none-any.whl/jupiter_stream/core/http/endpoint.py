"""HTTP Endpoint 管理

HTTP Endpoint management for URL failover and API organization
"""

from __future__ import annotations

import logging
import threading
from typing import Dict, List, Optional

from .config import APIConfig, EndpointConfig
from .exceptions import HTTPAPINotFoundError, HTTPConfigError

logger = logging.getLogger(__name__)


class URLManager:
    """URL 管理器（主备切换）

    URL manager for primary/backup URL switching
    """

    def __init__(self, base_url: str, backup_urls: List[str]):
        """初始化

        Args:
            base_url: 主 URL
            backup_urls: 备用 URL 列表
        """
        self.primary_url = base_url
        self.backup_urls = backup_urls
        self.all_urls = [base_url] + backup_urls
        self.current_url = base_url
        self.current_index = 0
        self.failure_counts: Dict[str, int] = {url: 0 for url in self.all_urls}
        self._lock = threading.RLock()

    def get_current_url(self) -> str:
        """获取当前 URL

        Get current URL
        """
        with self._lock:
            return self.current_url

    def mark_failure(self, url: str, threshold: int) -> None:
        """标记 URL 失败

        Mark URL as failed

        Args:
            url: 失败的 URL
            threshold: 故障转移阈值
        """
        with self._lock:
            if url in self.failure_counts:
                self.failure_counts[url] += 1

                if self.failure_counts[url] >= threshold:
                    logger.warning(
                        f"URL {url} failed {self.failure_counts[url]} times, switching to backup"
                    )
                    self._switch_to_next()

    def mark_success(self, url: str) -> None:
        """标记 URL 成功

        Mark URL as successful (reset failure count)

        Args:
            url: 成功的 URL
        """
        with self._lock:
            if url in self.failure_counts:
                self.failure_counts[url] = 0

    def _switch_to_next(self) -> None:
        """切换到下一个 URL

        Switch to next available URL
        """
        with self._lock:
            # 找到失败次数最少的 URL
            available_urls = [(url, count) for url, count in self.failure_counts.items()]
            available_urls.sort(key=lambda x: x[1])

            if available_urls:
                new_url = available_urls[0][0]
                if new_url != self.current_url:
                    logger.info(f"Switching from {self.current_url} to {new_url}")
                    self.current_url = new_url
                    self.current_index = self.all_urls.index(new_url)

    def reset(self) -> None:
        """重置为主 URL

        Reset to primary URL
        """
        with self._lock:
            self.current_url = self.primary_url
            self.current_index = 0
            self.failure_counts = {url: 0 for url in self.all_urls}
            logger.info("URL manager reset to primary URL")


class EndpointManager:
    """Endpoint 管理器

    Endpoint manager for organizing APIs and managing URLs
    """

    def __init__(self, endpoints: Dict[str, EndpointConfig]):
        """初始化

        Args:
            endpoints: Endpoint 配置字典
        """
        self.endpoints = endpoints
        self.url_managers: Dict[str, URLManager] = {}
        self.current_endpoint_name: Optional[str] = None
        self._lock = threading.RLock()

        # 初始化每个 endpoint 的 URL 管理器
        for name, config in endpoints.items():
            self.url_managers[name] = URLManager(config.base_url, config.backup_urls)

        logger.info(f"EndpointManager initialized with {len(endpoints)} endpoint(s)")

    def use_endpoint(self, name: str) -> None:
        """切换到指定的 endpoint

        Switch to specified endpoint

        Args:
            name: Endpoint 名称

        Raises:
            HTTPConfigError: Endpoint 不存在
        """
        with self._lock:
            if name not in self.endpoints:
                raise HTTPConfigError(f"Endpoint '{name}' not found")
            self.current_endpoint_name = name
            logger.info(f"Switched to endpoint: {name}")

    def get_current_endpoint(self) -> EndpointConfig:
        """获取当前 endpoint 配置

        Get current endpoint configuration

        Returns:
            当前 endpoint 配置

        Raises:
            HTTPConfigError: 没有设置当前 endpoint
        """
        with self._lock:
            if not self.current_endpoint_name:
                raise HTTPConfigError("No endpoint selected")
            return self.endpoints[self.current_endpoint_name]

    def get_current_url(self, endpoint_name: Optional[str] = None) -> str:
        """获取当前 URL

        Get current URL for endpoint

        Args:
            endpoint_name: Endpoint 名称（可选，默认使用当前 endpoint）

        Returns:
            当前 URL
        """
        with self._lock:
            name = endpoint_name or self.current_endpoint_name
            if not name:
                raise HTTPConfigError("No endpoint selected")

            url_manager = self.url_managers.get(name)
            if not url_manager:
                raise HTTPConfigError(f"URL manager not found for endpoint: {name}")

            return url_manager.get_current_url()

    def get_api_config(self, endpoint_name: str, api_name: str) -> APIConfig:
        """获取 API 配置

        Get API configuration

        Args:
            endpoint_name: Endpoint 名称
            api_name: API 名称

        Returns:
            API 配置

        Raises:
            HTTPAPINotFoundError: API 不存在
        """
        endpoint = self.endpoints.get(endpoint_name)
        if not endpoint:
            raise HTTPAPINotFoundError(f"Endpoint '{endpoint_name}' not found")

        for api in endpoint.apis:
            if api.name == api_name:
                return api

        raise HTTPAPINotFoundError(f"API '{api_name}' not found in endpoint '{endpoint_name}'")

    def list_apis(self, endpoint_name: str) -> List[str]:
        """列出 endpoint 下的所有 API

        List all APIs in endpoint

        Args:
            endpoint_name: Endpoint 名称

        Returns:
            API 名称列表
        """
        endpoint = self.endpoints.get(endpoint_name)
        return [api.name for api in endpoint.apis] if endpoint else []

    def list_all_apis(self) -> Dict[str, List[str]]:
        """列出所有 endpoint 及其 API

        List all endpoints and their APIs

        Returns:
            {endpoint_name: [api_names]} 字典
        """
        return {name: self.list_apis(name) for name in self.endpoints.keys()}
