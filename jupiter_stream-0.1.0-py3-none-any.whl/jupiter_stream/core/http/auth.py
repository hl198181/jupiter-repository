"""HTTP 认证管理

HTTP authentication management
"""

from __future__ import annotations

import json
import logging
import threading
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class AuthStrategy(ABC):
    """认证策略基类

    Base class for authentication strategies
    """

    @abstractmethod
    def apply_auth(self, headers: Dict[str, str]) -> Dict[str, str]:
        """应用认证到请求头

        Apply authentication to request headers

        Args:
            headers: 请求头字典

        Returns:
            更新后的请求头
        """
        pass

    @abstractmethod
    def refresh_if_needed(self) -> None:
        """如果需要，刷新认证

        Refresh authentication if needed (e.g., JWT token expired)
        """
        pass

    def get_stats(self) -> dict:
        """获取认证统计信息

        Get authentication statistics
        """
        return {
            "type": self.__class__.__name__,
        }


class DeviceTokenAuth(AuthStrategy):
    """设备令牌认证

    Device token authentication using X-Device-Token header.
    Optionally includes device fingerprint for device identification.
    """

    def __init__(
        self,
        token: str,
        fingerprint_dict: Optional[Dict[str, Any]] = None,
    ):
        """初始化

        Args:
            token: 设备令牌
            fingerprint_dict: 设备指纹字典（可选），包含 mac_address, cpu_serial 等
                             可通过 dataclasses.asdict(DeviceIdentity.get_device_fingerprint()) 获取
        """
        self.token = token
        self.fingerprint_dict = fingerprint_dict
        logger.info("DeviceTokenAuth initialized")

    def apply_auth(self, headers: Dict[str, str]) -> Dict[str, str]:
        """应用认证"""
        headers["X-Device-Token"] = self.token
        if self.fingerprint_dict:
            headers["X-Device-Fingerprint"] = json.dumps(self.fingerprint_dict)

        # 调试日志
        logger.debug(f"DeviceTokenAuth applying headers:")
        logger.debug(f"  X-Device-Token: {self.token}")
        if self.fingerprint_dict:
            logger.debug(f"  X-Device-Fingerprint: {headers['X-Device-Fingerprint']}")
        else:
            logger.debug("  X-Device-Fingerprint: (not set)")

        return headers

    def refresh_if_needed(self) -> None:
        """设备令牌不需要刷新"""
        pass

    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            **super().get_stats(),
            "token_length": len(self.token) if self.token else 0,
            "has_fingerprint": self.fingerprint_dict is not None,
        }


class JWTAuth(AuthStrategy):
    """JWT 认证

    JWT authentication with automatic token refresh support
    """

    def __init__(
        self,
        token: str,
        refresh_token: Optional[str] = None,
        refresh_url: Optional[str] = None,
        expires_at: Optional[float] = None,
    ):
        """初始化

        Args:
            token: JWT token
            refresh_token: 刷新令牌（可选）
            refresh_url: 刷新 URL（可选）
            expires_at: 过期时间戳（可选）
        """
        self.token = token
        self.refresh_token = refresh_token
        self.refresh_url = refresh_url
        self.expires_at = expires_at
        self._lock = threading.RLock()
        self._refresh_count = 0
        logger.info("JWTAuth initialized")

    def apply_auth(self, headers: Dict[str, str]) -> Dict[str, str]:
        """应用认证"""
        with self._lock:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def refresh_if_needed(self) -> None:
        """检查并刷新 JWT token"""
        with self._lock:
            # 检查是否需要刷新
            if not self._should_refresh():
                return

            # 执行刷新
            if self.refresh_token and self.refresh_url:
                try:
                    self._refresh_token()
                except Exception as e:
                    logger.error(f"Failed to refresh JWT token: {e}")

    def _should_refresh(self) -> bool:
        """判断是否需要刷新

        Should refresh token
        """
        if not self.expires_at:
            return False

        # 提前 5 分钟刷新
        current_time = time.time()
        buffer_time = 5 * 60  # 5 minutes
        return current_time + buffer_time >= self.expires_at

    def _refresh_token(self) -> None:
        """刷新 token

        Refresh JWT token

        注意：实际项目中需要调用 refresh_url 接口获取新 token
        Note: In production, should call refresh_url to get new token
        """
        # TODO: 实现实际的 token 刷新逻辑
        # 这里需要向 refresh_url 发送请求，使用 refresh_token 获取新的 token
        logger.warning("JWT token refresh not implemented yet")
        self._refresh_count += 1

    def get_stats(self) -> dict:
        """获取统计信息"""
        with self._lock:
            return {
                **super().get_stats(),
                "refresh_count": self._refresh_count,
                "expires_at": self.expires_at,
                "is_expired": self._should_refresh() if self.expires_at else False,
            }


class CustomAuth(AuthStrategy):
    """自定义认证

    Custom authentication strategy
    """

    def __init__(self, auth_function):
        """初始化

        Args:
            auth_function: 自定义认证函数，接收 headers 字典，返回更新后的 headers
        """
        self.auth_function = auth_function
        logger.info("CustomAuth initialized")

    def apply_auth(self, headers: Dict[str, str]) -> Dict[str, str]:
        """应用认证"""
        return self.auth_function(headers)

    def refresh_if_needed(self) -> None:
        """自定义认证不需要刷新"""
        pass


class AuthManager:
    """认证管理器

    Authentication manager using singleton pattern
    """

    _instance: Optional[AuthManager] = None
    _lock = threading.RLock()

    def __init__(self):
        """初始化"""
        self._auth_strategies: Dict[str, AuthStrategy] = {}
        self._instance_lock = threading.RLock()
        logger.info("AuthManager initialized")

    @classmethod
    def get_instance(cls) -> AuthManager:
        """获取单例实例

        Get singleton instance
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def register_auth(self, name: str, auth: AuthStrategy) -> None:
        """注册认证策略

        Register authentication strategy

        Args:
            name: 认证名称
            auth: 认证策略实例
        """
        with self._instance_lock:
            self._auth_strategies[name] = auth
            logger.info(f"Registered auth strategy: {name} ({auth.__class__.__name__})")

    def get_auth(self, name: str) -> Optional[AuthStrategy]:
        """获取认证策略

        Get authentication strategy by name

        Args:
            name: 认证名称

        Returns:
            认证策略实例，如果不存在返回 None
        """
        with self._instance_lock:
            return self._auth_strategies.get(name)

    def remove_auth(self, name: str) -> bool:
        """移除认证策略

        Remove authentication strategy

        Args:
            name: 认证名称

        Returns:
            是否成功移除
        """
        with self._instance_lock:
            if name in self._auth_strategies:
                del self._auth_strategies[name]
                logger.info(f"Removed auth strategy: {name}")
                return True
            return False

    def list_auth(self) -> List[str]:
        """列出所有已注册的认证名称

        List all registered authentication names

        Returns:
            认证名称列表
        """
        with self._instance_lock:
            return list(self._auth_strategies.keys())

    def clear(self) -> None:
        """清空所有认证

        Clear all authentication strategies
        """
        with self._instance_lock:
            count = len(self._auth_strategies)
            self._auth_strategies.clear()
            logger.info(f"Cleared {count} auth strateg(ies)")

    def get_stats(self) -> dict:
        """获取所有认证的统计信息

        Get statistics for all authentications
        """
        with self._instance_lock:
            return {
                "total_auth": len(self._auth_strategies),
                "auth_names": list(self._auth_strategies.keys()),
                "auth_details": {
                    name: auth.get_stats() for name, auth in self._auth_strategies.items()
                },
            }
