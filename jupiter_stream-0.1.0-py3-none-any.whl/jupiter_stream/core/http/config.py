"""HTTP 配置模型

HTTP configuration models using Pydantic v2
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from .utils import expand_env_vars


class AuthConfig(BaseModel):
    """认证配置

    Authentication configuration
    """

    type: Literal["device_token", "jwt", "custom"]
    token: Optional[str] = None
    refresh_token: Optional[str] = None
    refresh_url: Optional[str] = None
    custom_class: Optional[str] = None  # 自定义认证类路径

    @field_validator("token", "refresh_token", "refresh_url")
    @classmethod
    def expand_environment_variables(cls, v: Optional[str]) -> Optional[str]:
        """展开环境变量

        Expand environment variables in token strings
        """
        if v is None:
            return v
        return expand_env_vars(v)

    @model_validator(mode="after")
    def validate_auth_type(self) -> AuthConfig:
        """验证认证类型配置

        Validate authentication type configuration
        """
        if self.type == "device_token" and not self.token:
            raise ValueError("device_token auth requires 'token' field")
        if self.type == "jwt" and not self.token:
            raise ValueError("jwt auth requires 'token' field")
        if self.type == "custom" and not self.custom_class:
            raise ValueError("custom auth requires 'custom_class' field")
        return self


class APIConfig(BaseModel):
    """API 配置

    Individual API configuration
    """

    name: str
    path: str
    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"] = "GET"
    description: Optional[str] = None

    # 可覆盖的配置
    timeout: Optional[float] = None
    connect_timeout: Optional[float] = None
    read_timeout: Optional[float] = None
    max_retries: Optional[int] = None
    retry_on_timeout: Optional[bool] = None

    # 默认配置
    default_headers: Dict[str, str] = Field(default_factory=dict)
    default_params: Dict[str, Any] = Field(default_factory=dict)
    default_json: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("timeout", "connect_timeout", "read_timeout")
    @classmethod
    def validate_timeout(cls, v: Optional[float]) -> Optional[float]:
        """验证超时时间

        Validate timeout values
        """
        if v is not None and v <= 0:
            raise ValueError("Timeout must be positive")
        return v

    @field_validator("max_retries")
    @classmethod
    def validate_max_retries(cls, v: Optional[int]) -> Optional[int]:
        """验证重试次数

        Validate max retries
        """
        if v is not None and v < 0:
            raise ValueError("max_retries cannot be negative")
        return v


class EndpointConfig(BaseModel):
    """Endpoint 配置

    Endpoint configuration grouping related APIs
    """

    description: Optional[str] = None

    # URL 配置
    base_url: str
    backup_urls: List[str] = Field(default_factory=list)

    # 认证
    auth_name: Optional[str] = None

    # 超时配置
    timeout: float = 30.0
    connect_timeout: float = 10.0
    read_timeout: float = 30.0

    # 重试策略
    max_retries: int = 3
    retry_on_timeout: bool = True
    auto_failover: bool = True
    failover_threshold: int = 3

    # 默认配置（应用于该 endpoint 下所有 API）
    default_headers: Dict[str, str] = Field(default_factory=dict)
    default_params: Dict[str, Any] = Field(default_factory=dict)
    default_json: Dict[str, Any] = Field(default_factory=dict)

    verify_ssl: bool = True

    # APIs
    apis: List[APIConfig] = Field(default_factory=list)

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, v: str) -> str:
        """验证基础 URL

        Validate base URL format
        """
        if not v.startswith(("http://", "https://")):
            raise ValueError("base_url must start with http:// or https://")
        return v

    @field_validator("timeout", "connect_timeout", "read_timeout")
    @classmethod
    def validate_timeout(cls, v: float) -> float:
        """验证超时时间"""
        if v <= 0:
            raise ValueError("Timeout must be positive")
        return v

    @field_validator("max_retries", "failover_threshold")
    @classmethod
    def validate_positive_int(cls, v: int) -> int:
        """验证正整数"""
        if v < 0:
            raise ValueError("Value must be non-negative")
        return v

    def get_api(self, api_name: str) -> Optional[APIConfig]:
        """获取 API 配置

        Get API configuration by name

        Args:
            api_name: API 名称

        Returns:
            API 配置，如果不存在返回 None
        """
        for api in self.apis:
            if api.name == api_name:
                return api
        return None


class HTTPClientConfig(BaseModel):
    """HTTP 客户端配置

    Main HTTP client configuration
    """

    # 认证配置
    auth_configs: Dict[str, AuthConfig] = Field(default_factory=dict)

    # Endpoint 配置
    endpoints: Dict[str, EndpointConfig]

    # 默认 endpoint
    default_endpoint: Optional[str] = None

    # 全局配置
    verify_ssl: bool = True
    default_timeout: float = 30.0

    @model_validator(mode="after")
    def validate_default_endpoint(self) -> HTTPClientConfig:
        """验证默认 endpoint

        Validate default endpoint exists
        """
        if self.default_endpoint and self.default_endpoint not in self.endpoints:
            raise ValueError(f"default_endpoint '{self.default_endpoint}' not found in endpoints")
        return self

    @classmethod
    def from_yaml(cls, file_path: str) -> HTTPClientConfig:
        """从 YAML 文件加载配置

        Load configuration from YAML file

        Args:
            file_path: YAML 配置文件路径

        Returns:
            HTTPClientConfig 实例
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load YAML config. "
                "Install with: pip install jupiter-stream[http,yaml]"
            )

        with open(file_path, encoding="utf-8") as f:
            config_dict = yaml.safe_load(f)

        return cls(**config_dict)

    @classmethod
    def from_json(cls, file_path: str) -> HTTPClientConfig:
        """从 JSON 文件加载配置

        Load configuration from JSON file

        Args:
            file_path: JSON 配置文件路径

        Returns:
            HTTPClientConfig 实例
        """
        import json

        with open(file_path, encoding="utf-8") as f:
            config_dict = json.load(f)

        return cls(**config_dict)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> HTTPClientConfig:
        """从字典加载配置

        Load configuration from dictionary

        Args:
            config_dict: 配置字典

        Returns:
            HTTPClientConfig 实例
        """
        return cls(**config_dict)

    @classmethod
    def from_file(cls, file_path: str) -> HTTPClientConfig:
        """从文件加载配置（自动检测格式）

        Load configuration from file (auto-detect format)

        Args:
            file_path: 配置文件路径

        Returns:
            HTTPClientConfig 实例
        """
        file_path = Path(file_path)
        suffix = file_path.suffix.lower()

        if suffix in [".yaml", ".yml"]:
            return cls.from_yaml(str(file_path))
        elif suffix == ".json":
            return cls.from_json(str(file_path))
        else:
            raise ValueError(f"Unsupported config file format: {suffix}")

    def get_endpoint(self, name: str) -> Optional[EndpointConfig]:
        """获取 endpoint 配置

        Get endpoint configuration by name

        Args:
            name: Endpoint 名称

        Returns:
            Endpoint 配置，如果不存在返回 None
        """
        return self.endpoints.get(name)
