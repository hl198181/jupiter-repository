"""HTTP 文件传输

HTTP file transfer with progress tracking
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

if TYPE_CHECKING:
    from .client import HTTPClient

from .exceptions import HTTPFileTransferError
from .utils import format_bytes, get_file_size

logger = logging.getLogger(__name__)


class FileTransferManager:
    """文件传输管理器

    File transfer manager with progress tracking
    """

    def __init__(self, http_client: HTTPClient):
        """初始化

        Args:
            http_client: HTTP 客户端实例
        """
        self.http_client = http_client

    def upload_file(
        self,
        file_path: str,
        endpoint_path: str,
        endpoint_name: Optional[str] = None,
        field_name: str = "file",
        progress_callback: Optional[Callable[[float], None]] = None,
        **kwargs,
    ):
        """上传文件

        Upload file with progress tracking

        Args:
            file_path: 文件路径
            endpoint_path: API 路径
            endpoint_name: Endpoint 名称
            field_name: 文件字段名
            progress_callback: 进度回调函数 callback(percent)
            **kwargs: 其他请求参数

        Returns:
            HTTP 响应

        Example:
            client.upload_file(
                file_path="video.mp4",
                endpoint_path="/api/file/upload",
                progress_callback=lambda p: print(f"Progress: {p:.1f}%")
            )
        """
        if not os.path.exists(file_path):
            raise HTTPFileTransferError(f"File not found: {file_path}")

        file_size = get_file_size(file_path)
        logger.info(f"Uploading file: {file_path} ({format_bytes(file_size)})")

        try:
            with open(file_path, "rb") as f:
                files = {field_name: f}

                # TODO: 实现进度跟踪
                # httpx 不直接支持上传进度，需要使用流式上传
                response = self.http_client.post(
                    endpoint_path, endpoint_name=endpoint_name, files=files, **kwargs
                )

                if progress_callback:
                    progress_callback(100.0)

                logger.info(f"Upload completed: {file_path}")
                return response

        except Exception as e:
            logger.error(f"Upload failed: {e}")
            raise HTTPFileTransferError(f"Failed to upload file: {e}")

    def download_file(
        self,
        url: str,
        save_path: str,
        endpoint_name: Optional[str] = None,
        progress_callback: Optional[Callable[[float], None]] = None,
        **kwargs,
    ) -> None:
        """下载文件

        Download file with progress tracking

        Args:
            url: 下载 URL
            save_path: 保存路径
            endpoint_name: Endpoint 名称
            progress_callback: 进度回调函数 callback(percent)
            **kwargs: 其他请求参数

        Example:
            client.download_file(
                url="/api/file/download/abc123",
                save_path="result.zip",
                progress_callback=lambda p: print(f"Downloaded: {p:.1f}%")
            )
        """
        logger.info(f"Downloading file to: {save_path}")

        try:
            # 创建保存目录
            Path(save_path).parent.mkdir(parents=True, exist_ok=True)

            # 流式下载
            with self.http_client.http_client.stream("GET", url, **kwargs) as response:
                response.raise_for_status()

                total = int(response.headers.get("content-length", 0))
                downloaded = 0

                with open(save_path, "wb") as f:
                    for chunk in response.iter_bytes(chunk_size=8192):
                        f.write(chunk)
                        downloaded += len(chunk)

                        if progress_callback and total:
                            progress = (downloaded / total) * 100
                            progress_callback(progress)

                if progress_callback:
                    progress_callback(100.0)

            logger.info(f"Download completed: {save_path} ({format_bytes(downloaded)})")

        except Exception as e:
            logger.error(f"Download failed: {e}")
            raise HTTPFileTransferError(f"Failed to download file: {e}")
