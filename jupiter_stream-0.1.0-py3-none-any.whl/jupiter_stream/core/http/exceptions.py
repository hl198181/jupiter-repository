"""HTTP 异常类

HTTP exceptions / HTTP 异常定义
"""

from __future__ import annotations


class HTTPError(Exception):
    """HTTP 基础异常

    Base exception for all HTTP errors
    """

    pass


class HTTPConnectionError(HTTPError):
    """HTTP 连接异常

    Raised when connection to server fails

    连接到服务器失败时抛出
    """

    pass


class HTTPTimeoutError(HTTPError):
    """HTTP 超时异常

    Raised when request times out

    请求超时时抛出
    """

    pass


class HTTPAuthError(HTTPError):
    """HTTP 认证异常

    Raised when authentication fails

    认证失败时抛出
    """

    pass


class HTTPConfigError(HTTPError):
    """HTTP 配置异常

    Raised when configuration is invalid

    配置无效时抛出
    """

    pass


class HTTPFileTransferError(HTTPError):
    """HTTP 文件传输异常

    Raised when file upload/download fails

    文件上传/下载失败时抛出
    """

    pass


class HTTPAPINotFoundError(HTTPError):
    """HTTP API 未找到异常

    Raised when specified API is not found in configuration

    配置中未找到指定的 API 时抛出
    """

    pass


class HTTPStatusError(HTTPError):
    """HTTP 状态码异常

    Raised when server returns an error status code

    服务器返回错误状态码时抛出
    """

    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}")
