"""HTTP 模块

HTTP Client module for jupiter-stream

提供优雅的 HTTP 客户端功能：
- 配置驱动的 API 管理
- 多种认证策略支持
- 主备 URL 自动故障转移
- 大文件上传/下载
- 统一异常处理

Provides elegant HTTP client functionality:
- Configuration-driven API management
- Multiple authentication strategies
- Automatic failover for backup URLs
- Large file upload/download
- Unified exception handling
"""

from __future__ import annotations

import importlib.util

# 导入检查
if importlib.util.find_spec("httpx") is None:
    raise ImportError(
        "httpx is required for HTTP module. " "Install with: pip install jupiter-stream[http]"
    )

if importlib.util.find_spec("pydantic") is None:
    raise ImportError(
        "pydantic is required for HTTP module. " "Install with: pip install jupiter-stream[http]"
    )

# 导出公共接口
from .auth import AuthManager, AuthStrategy, DeviceTokenAuth, JWTAuth
from .client import HTTPClient
from .config import APIConfig, AuthConfig, EndpointConfig, HTTPClientConfig
from .exceptions import (
    HTTPAPINotFoundError,
    HTTPAuthError,
    HTTPConfigError,
    HTTPConnectionError,
    HTTPError,
    HTTPFileTransferError,
    HTTPTimeoutError,
)

__all__ = [
    # 客户端
    "HTTPClient",
    # 配置
    "HTTPClientConfig",
    "EndpointConfig",
    "APIConfig",
    "AuthConfig",
    # 认证
    "AuthStrategy",
    "DeviceTokenAuth",
    "JWTAuth",
    "AuthManager",
    # 异常
    "HTTPError",
    "HTTPConnectionError",
    "HTTPTimeoutError",
    "HTTPAuthError",
    "HTTPConfigError",
    "HTTPFileTransferError",
    "HTTPAPINotFoundError",
]
