"""HTTP 客户端

HTTP Client with configuration-driven API management
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, Optional

import httpx

from .auth import AuthManager, AuthStrategy, DeviceTokenAuth, JWTAuth
from .config import APIConfig, AuthConfig, EndpointConfig, HTTPClientConfig
from .endpoint import EndpointManager
from .exceptions import (
    HTTPAPINotFoundError,
    HTTPAuthError,
    HTTPConfigError,
    HTTPConnectionError,
)
from .utils import build_url, extract_path_vars, merge_dicts

logger = logging.getLogger(__name__)


class HTTPClient:
    """HTTP 客户端

    Configuration-driven HTTP client with:
    - Multiple authentication strategies
    - Automatic URL failover
    - API-level configuration
    - File upload/download support
    """

    def __init__(self, config: HTTPClientConfig):
        """初始化

        Args:
            config: HTTP 客户端配置
        """
        self.config = config

        # 认证管理器
        self.auth_manager = AuthManager.get_instance()
        self._init_auth_from_config()

        # Endpoint 管理器
        self.endpoint_manager = EndpointManager(config.endpoints)
        if config.default_endpoint:
            self.endpoint_manager.use_endpoint(config.default_endpoint)

        # httpx 客户端
        self.http_client = httpx.Client(verify=config.verify_ssl, timeout=config.default_timeout)

        # 统计信息
        self._stats = {
            "total_requests": 0,
            "success_count": 0,
            "error_count": 0,
        }
        self._lock = threading.RLock()

        logger.info("HTTPClient initialized")

    @classmethod
    def from_config(cls, config_path: str) -> HTTPClient:
        """从配置文件创建客户端

        Create client from configuration file

        Args:
            config_path: 配置文件路径

        Returns:
            HTTPClient 实例
        """
        config = HTTPClientConfig.from_file(config_path)
        return cls(config)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> HTTPClient:
        """从字典创建客户端

        Create client from dictionary

        Args:
            config_dict: 配置字典

        Returns:
            HTTPClient 实例
        """
        config = HTTPClientConfig.from_dict(config_dict)
        return cls(config)

    def _init_auth_from_config(self) -> None:
        """从配置初始化认证"""
        for name, auth_config in self.config.auth_configs.items():
            auth = self._create_auth_strategy(auth_config)
            self.auth_manager.register_auth(name, auth)
            logger.info(f"Registered auth: {name}")

    def _create_auth_strategy(self, config: AuthConfig) -> AuthStrategy:
        """根据配置创建认证策略"""
        if config.type == "device_token":
            return DeviceTokenAuth(token=config.token)
        elif config.type == "jwt":
            return JWTAuth(token=config.token, refresh_token=config.refresh_token)
        elif config.type == "custom":
            # TODO: 动态加载自定义认证类
            raise NotImplementedError("Custom auth not implemented yet")
        else:
            raise HTTPConfigError(f"Unknown auth type: {config.type}")

    def call(self, api_identifier: str, **kwargs) -> httpx.Response:
        """调用配置的 API

        Call configured API with simplified parameter design

        Args:
            api_identifier: "endpoint_name.api_name" 格式
            **kwargs: 请求参数
                - 路径变量：直接作为关键字参数（如 user_id="123"）
                - query: URL 查询参数（dict）
                - data: 请求体，自动识别 JSON 或表单（dict）
                - headers: 额外的请求头（dict）
                - files: 文件上传（dict）
                - timeout: 超时时间（float）

        Returns:
            HTTP 响应

        Examples:
            # GET + 路径变量
            client.call("api.getUser", user_id="123")

            # GET + 查询参数
            client.call("api.getUserList", query={"page": 1})

            # POST + JSON
            client.call("api.createUser", data={"name": "张三"})

            # 组合使用
            client.call("api.getUserPosts", user_id="123", query={"page": 1})
        """
        # 解析 API 标识符
        parts = api_identifier.split(".")
        if len(parts) != 2:
            raise HTTPConfigError(
                f"Invalid API identifier: {api_identifier}. "
                f"Expected format: endpoint_name.api_name"
            )

        endpoint_name, api_name = parts

        # 获取配置
        endpoint_config = self.endpoint_manager.endpoints.get(endpoint_name)
        if not endpoint_config:
            raise HTTPAPINotFoundError(f"Endpoint '{endpoint_name}' not found")

        api_config = self.endpoint_manager.get_api_config(endpoint_name, api_name)

        # 构建请求参数
        request_params = self._build_request_params(endpoint_config, api_config, kwargs)

        # 发送请求
        return self.request(
            method=api_config.method,
            path=api_config.path,
            endpoint_name=endpoint_name,
            **request_params,
        )

    def _build_request_params(
        self, endpoint_config: EndpointConfig, api_config: APIConfig, kwargs: dict
    ) -> dict:
        """构建请求参数（合并配置）

        新的参数设计：
        - 路径变量：从 kwargs 中提取（匹配 API path 中的 {var_name}）
        - query: URL 查询参数
        - data: 请求体（JSON 或表单）
        """
        # 提取路径变量
        path_vars, remaining_kwargs = extract_path_vars(api_config.path, kwargs)

        # 合并 headers
        headers = {}
        headers = merge_dicts(headers, endpoint_config.default_headers)
        headers = merge_dicts(headers, api_config.default_headers)
        headers = merge_dicts(headers, remaining_kwargs.get("headers", {}))

        # 合并 query（URL 查询参数）
        query = {}
        query = merge_dicts(query, endpoint_config.default_params)
        query = merge_dicts(query, api_config.default_params)
        query = merge_dicts(query, remaining_kwargs.get("query", {}))

        # data（请求体）
        data = remaining_kwargs.get("data")
        if data is None:
            # 使用默认 JSON
            if endpoint_config.default_json or api_config.default_json:
                data = {}
                data = merge_dicts(data, endpoint_config.default_json)
                data = merge_dicts(data, api_config.default_json)

        # 超时时间
        timeout = remaining_kwargs.get("timeout") or api_config.timeout or endpoint_config.timeout

        return {
            "headers": headers,
            "params": query if query else None,  # httpx 使用 params 作为查询参数
            "json": data if isinstance(data, dict) else None,  # dict 自动序列化为 JSON
            "data": data if data and not isinstance(data, dict) else None,  # 非 dict 作为表单数据
            "timeout": timeout,
            "files": remaining_kwargs.get("files"),
            "path_vars": path_vars,  # 传递给 request 方法
        }

    def request(
        self, method: str, path: str, endpoint_name: Optional[str] = None, **kwargs
    ) -> httpx.Response:
        """发送 HTTP 请求

        Send HTTP request with automatic failover

        Args:
            method: HTTP 方法
            path: 路径
            endpoint_name: Endpoint 名称（可选）
            **kwargs: 请求参数

        Returns:
            HTTP 响应
        """
        endpoint_name = endpoint_name or self.endpoint_manager.current_endpoint_name
        if not endpoint_name:
            raise HTTPConfigError("No endpoint selected")

        endpoint_config = self.endpoint_manager.endpoints[endpoint_name]
        url_manager = self.endpoint_manager.url_managers[endpoint_name]

        # 提取路径变量
        path_vars = kwargs.pop("path_vars", None)

        # 重试逻辑
        max_retries = kwargs.pop("max_retries", endpoint_config.max_retries)

        for attempt in range(max_retries + 1):
            try:
                # 获取当前 URL
                base_url = url_manager.get_current_url()
                full_url = build_url(base_url, path, path_vars)

                # 应用认证
                headers = kwargs.get("headers", {}).copy()
                headers = self._apply_auth(endpoint_config, headers)
                kwargs["headers"] = headers

                # 发送请求
                response = self.http_client.request(method, full_url, **kwargs)

                # 标记成功
                url_manager.mark_success(base_url)
                self._update_stats(success=True)

                logger.debug(f"{method} {full_url} -> {response.status_code}")
                return response

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                # 标记失败
                url_manager.mark_failure(base_url, endpoint_config.failover_threshold)

                if attempt == max_retries:
                    self._update_stats(success=False)
                    raise HTTPConnectionError(
                        f"Request failed after {max_retries + 1} attempts: {e}"
                    )

                # 等待后重试
                wait_time = 2**attempt
                logger.warning(
                    f"Request failed (attempt {attempt + 1}/{max_retries + 1}), "
                    f"retrying in {wait_time}s: {e}"
                )
                time.sleep(wait_time)

    def _apply_auth(
        self, endpoint_config: EndpointConfig, headers: Dict[str, str]
    ) -> Dict[str, str]:
        """应用认证"""
        if endpoint_config.auth_name:
            auth = self.auth_manager.get_auth(endpoint_config.auth_name)
            if auth:
                auth.refresh_if_needed()
                headers = auth.apply_auth(headers)
            else:
                raise HTTPAuthError(f"Auth '{endpoint_config.auth_name}' not found")
        return headers

    def _update_stats(self, success: bool) -> None:
        """更新统计信息"""
        with self._lock:
            self._stats["total_requests"] += 1
            if success:
                self._stats["success_count"] += 1
            else:
                self._stats["error_count"] += 1

    # 便捷方法
    def get(self, path: str, **kwargs) -> httpx.Response:
        """GET 请求"""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> httpx.Response:
        """POST 请求"""
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs) -> httpx.Response:
        """PUT 请求"""
        return self.request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs) -> httpx.Response:
        """DELETE 请求"""
        return self.request("DELETE", path, **kwargs)

    def use_endpoint(self, name: str) -> None:
        """切换 endpoint"""
        self.endpoint_manager.use_endpoint(name)

    def switch_network(self, endpoint_name: str, new_base_url: str) -> None:
        """切换网络（由粘合层调用）

        Switch network interface

        Args:
            endpoint_name: Endpoint 名称
            new_base_url: 新的 base URL
        """
        url_manager = self.endpoint_manager.url_managers.get(endpoint_name)
        if url_manager:
            url_manager.current_url = new_base_url
            logger.info(f"Switched network for {endpoint_name} to {new_base_url}")

    def get_stats(self) -> dict:
        """获取统计信息"""
        with self._lock:
            return {
                **self._stats,
                "current_endpoint": self.endpoint_manager.current_endpoint_name,
            }

    def close(self) -> None:
        """关闭客户端"""
        self.http_client.close()
        logger.info("HTTPClient closed")

    def __enter__(self):
        """上下文管理器"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器"""
        self.close()
