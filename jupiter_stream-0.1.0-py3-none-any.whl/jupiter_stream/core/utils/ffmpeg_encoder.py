"""FFmpeg video encoder utility class."""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class FFmpegEncoder:
    """
    FFmpeg 视频编码工具类

    封装 FFmpeg 进程管理和帧写入逻辑，供 Sink、Processor 等共享使用。
    支持惰性初始化（第一帧时启动进程）和手动启动两种方式。

    FFmpeg video encoder utility class.

    Encapsulates FFmpeg process management and frame writing logic,
    shared by Sink, Processor and other components.
    Supports both lazy initialization (start on first frame) and manual start.

    Examples:
        >>> # 惰性初始化
        >>> encoder = FFmpegEncoder("output.mp4", fps=30)
        >>> encoder.write_frame(frame_image)  # 自动启动进程
        >>> encoder.close()

        >>> # 手动启动
        >>> encoder = FFmpegEncoder("output.mp4", fps=30)
        >>> encoder.start(width=1920, height=1080)
        >>> encoder.write_frame(frame_image)
        >>> encoder.close()

        >>> # 上下文管理器
        >>> with FFmpegEncoder("output.mp4", fps=30) as encoder:
        ...     encoder.write_frame(frame_image)
    """

    def __init__(
        self,
        output_path: str,
        fps: float = 30.0,
        # 视频编码参数
        vcodec: str = "libx264",
        crf: Optional[int] = 23,
        preset: str = "medium",
        pix_fmt: str = "yuv420p",
        # 码率控制（与 CRF 二选一）
        video_bitrate: Optional[str] = None,
        maxrate: Optional[str] = None,
        bufsize: Optional[str] = None,
        # 音频参数
        acodec: Optional[str] = None,
        audio_bitrate: str = "128k",
        audio_source: Optional[str] = None,
        # 容器优化
        movflags: str = "+faststart",
        # 其他
        loglevel: str = "error",
    ):
        """
        初始化 FFmpegEncoder

        Args:
            output_path: 输出文件路径 / Output file path
            fps: 帧率 / Frame rate
            vcodec: 视频编码器（默认: libx264）/ Video codec
            crf: 恒定质量因子 (18=高质量, 28=低质量, 默认: 23) / Constant Rate Factor
            preset: 编码速度预设 / Encoding speed preset
            pix_fmt: 像素格式 / Pixel format
            video_bitrate: 视频目标码率（如 "4M"）/ Target video bitrate
            maxrate: 最大码率 / Maximum bitrate
            bufsize: VBV 缓冲区大小 / VBV buffer size
            acodec: 音频编码器 / Audio codec
            audio_bitrate: 音频码率 / Audio bitrate
            audio_source: 音频源文件路径 / Audio source file path
            movflags: MP4 容器标志 / MP4 container flags
            loglevel: FFmpeg 日志级别 / FFmpeg log level

        Raises:
            ImportError: 如果 ffmpeg-python 未安装
            FileNotFoundError: 如果系统未安装 ffmpeg
        """
        self._check_dependencies()

        # 路径配置
        self._output_path = Path(output_path)
        self._output_path.parent.mkdir(parents=True, exist_ok=True)

        # 编码参数
        self._fps = fps
        self._vcodec = vcodec
        self._crf = crf
        self._preset = preset
        self._pix_fmt = pix_fmt
        self._video_bitrate = video_bitrate
        self._maxrate = maxrate
        self._bufsize = bufsize
        self._acodec = acodec
        self._audio_bitrate = audio_bitrate
        self._audio_source = audio_source
        self._movflags = movflags
        self._loglevel = loglevel

        # 运行时状态
        self._process = None
        self._frame_size: Optional[Tuple[int, int]] = None
        self._is_started = False
        self._frame_count = 0

    @staticmethod
    def _check_dependencies():
        """检查依赖是否安装"""
        import importlib.util

        if importlib.util.find_spec("ffmpeg") is None:
            raise ImportError(
                "ffmpeg-python is required for FFmpegEncoder. "
                "Install with: pip install ffmpeg-python"
            )

        try:
            subprocess.run(
                ["ffmpeg", "-version"],
                capture_output=True,
                check=True,
            )
        except FileNotFoundError:
            raise FileNotFoundError(
                "ffmpeg is not installed on your system. "
                "Please install ffmpeg:\n"
                "  macOS: brew install ffmpeg\n"
                "  Ubuntu/Debian: sudo apt-get install ffmpeg\n"
                "  Windows: Download from https://ffmpeg.org/download.html"
            )

    def start(self, width: int, height: int):
        """
        启动 FFmpeg 进程

        Args:
            width: 视频宽度 / Video width
            height: 视频高度 / Video height

        Raises:
            RuntimeError: 如果进程已启动或启动失败
        """
        if self._is_started:
            raise RuntimeError("FFmpeg process is already started")

        import ffmpeg

        self._frame_size = (width, height)

        # 构建 FFmpeg 输入管道
        input_args = {
            "format": "rawvideo",
            "pix_fmt": "bgr24",
            "s": f"{width}x{height}",
            "r": self._fps,
        }

        stream = ffmpeg.input("pipe:", **input_args)

        # 构建输出参数
        output_args = {
            "vcodec": self._vcodec,
            "pix_fmt": self._pix_fmt,
            "preset": self._preset,
        }

        # 添加质量控制参数（CRF 或 bitrate）
        if self._video_bitrate:
            output_args["video_bitrate"] = self._video_bitrate
            if self._maxrate:
                output_args["maxrate"] = self._maxrate
            if self._bufsize:
                output_args["bufsize"] = self._bufsize
        elif self._crf is not None:
            output_args["crf"] = self._crf

        # 添加音频参数
        if self._acodec:
            if self._acodec == "copy" and self._audio_source:
                audio_input = ffmpeg.input(self._audio_source)
                stream = ffmpeg.output(
                    stream,
                    audio_input.audio,
                    str(self._output_path),
                    **output_args,
                    acodec="copy",
                )
            else:
                output_args["acodec"] = self._acodec
                output_args["audio_bitrate"] = self._audio_bitrate
                stream = ffmpeg.output(stream, str(self._output_path), **output_args)
        else:
            stream = ffmpeg.output(stream, str(self._output_path), **output_args)

        # 添加 movflags
        if self._movflags:
            stream = stream.global_args("-movflags", self._movflags)

        # 覆盖现有文件
        stream = stream.overwrite_output()

        # 启动 FFmpeg 进程
        try:
            self._process = stream.run_async(
                pipe_stdin=True,
                pipe_stderr=True,
                quiet=(self._loglevel == "quiet"),
            )
            self._is_started = True
            logger.info(
                f"FFmpegEncoder started: {self._output_path.name}, "
                f"{width}x{height} @ {self._fps:.2f} fps"
            )
        except ffmpeg.Error as e:
            error_msg = e.stderr.decode() if e.stderr else str(e)
            logger.error(f"Failed to start FFmpeg: {error_msg}")
            raise RuntimeError(f"Failed to start FFmpeg process: {error_msg}")

    def write_frame(self, image: np.ndarray):
        """
        写入一帧图像数据

        如果进程未启动，会自动根据图像尺寸启动进程。

        Args:
            image: BGR 格式的 numpy 数组 / BGR numpy array

        Raises:
            RuntimeError: 如果写入失败
        """
        # 惰性初始化
        if not self._is_started:
            height, width = image.shape[:2]
            self.start(width, height)

        try:
            # 检查帧大小是否一致
            height, width = image.shape[:2]
            if (width, height) != self._frame_size:
                try:
                    import cv2

                    image = cv2.resize(
                        image,
                        self._frame_size,
                        interpolation=cv2.INTER_LINEAR,
                    )
                    logger.debug(f"Frame resized to {self._frame_size}")
                except ImportError:
                    raise RuntimeError(
                        f"Frame size mismatch: expected {self._frame_size}, "
                        f"got ({width}, {height}). Install opencv-python for auto-resize."
                    )

            self._process.stdin.write(image.tobytes())
            self._frame_count += 1

        except BrokenPipeError:
            logger.error("FFmpeg process terminated unexpectedly")
            raise RuntimeError("FFmpeg process terminated unexpectedly")
        except Exception as e:
            logger.error(f"Failed to write frame: {e}")
            raise

    def close(self):
        """
        关闭 FFmpeg 进程，完成视频文件写入

        Close FFmpeg process and finalize video file
        """
        if self._process is not None:
            try:
                self._process.stdin.close()
                stderr_output = self._process.stderr.read()
                self._process.wait()

                if self._process.returncode != 0:
                    error_msg = stderr_output.decode() if stderr_output else "Unknown error"
                    logger.error(f"FFmpeg process failed: {error_msg}")
                else:
                    logger.info(
                        f"Video saved: {self._output_path} ({self._frame_count} frames)"
                    )

                self._is_started = False
                self._process = None

            except Exception as e:
                logger.error(f"Error closing FFmpeg process: {e}")
                if self._process:
                    self._process.kill()
                    self._process = None
                raise

    @property
    def is_started(self) -> bool:
        """进程是否已启动 / Whether process is started"""
        return self._is_started

    @property
    def output_path(self) -> Path:
        """输出文件路径 / Output file path"""
        return self._output_path

    @property
    def frame_size(self) -> Optional[Tuple[int, int]]:
        """帧尺寸 (width, height) / Frame size"""
        return self._frame_size

    @property
    def frame_count(self) -> int:
        """已写入的帧数 / Number of frames written"""
        return self._frame_count

    @property
    def fps(self) -> float:
        """帧率 / Frame rate"""
        return self._fps

    def __enter__(self):
        """上下文管理器：进入"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器：退出"""
        self.close()

    def __repr__(self) -> str:
        status = "started" if self._is_started else "not started"
        return (
            f"FFmpegEncoder({self._output_path.name}, "
            f"fps={self._fps}, {status}, frames={self._frame_count})"
        )
