"""MQTT 核心模块

MQTT core module for Jupiter-Stream

提供优雅的 MQTT 客户端功能:
- 配置驱动的客户端构建
- 自动重连和健康检查
- 可插拔消息处理器
- Topic 通配符匹配
- 离线消息队列

Provides elegant MQTT client features:
- Configuration-driven client construction
- Auto-reconnect and health check
- Pluggable message handlers
- Topic wildcard matching
- Offline message queue

Examples:
    >>> from jupiter_stream.core.mqtt import MQTTClient, MessageHandler, Message
    >>>
    >>> # 从配置创建客户端
    >>> client = MQTTClient.from_config("config/mqtt.yaml")
    >>>
    >>> # 自定义处理器
    >>> class MyHandler(MessageHandler):
    ...     def __init__(self):
    ...         super().__init__(topics=["my/topic/#"])
    ...
    ...     def handle(self, message: Message):
    ...         print(f"Received: {message.payload}")
    >>>
    >>> # 注册并运行
    >>> client.register_handler(MyHandler())
    >>> with client:
    ...     client.publish("my/topic/test", {"hello": "world"})
"""

from __future__ import annotations

# 核心类
from .client import MQTTClient
from .config import ConnectionConfig, HandlerConfig, MQTTConfig, TLSConfig
from .connection import ConnectionManager, ConnectionState

# 异常
from .exceptions import (
    MQTTConfigError,
    MQTTConnectionError,
    MQTTError,
    MQTTHandlerError,
    MQTTPublishError,
    MQTTReconnectError,
    MQTTSubscribeError,
    MQTTTimeoutError,
)
from .handler import MessageHandler
from .message import Message
from .publisher import Publisher
from .router import MessageRouter

# 工具函数
from .utils import (
    calculate_backoff_delay,
    parse_broker_url,
    sanitize_client_id,
    topic_matches,
    validate_publish_topic,
    validate_topic,
)

__all__ = [
    # 核心类
    "MQTTClient",
    "MessageHandler",
    "Message",
    "MessageRouter",
    "Publisher",
    "ConnectionManager",
    "ConnectionState",
    # 配置
    "MQTTConfig",
    "ConnectionConfig",
    "HandlerConfig",
    "TLSConfig",
    # 异常
    "MQTTError",
    "MQTTConnectionError",
    "MQTTReconnectError",
    "MQTTPublishError",
    "MQTTSubscribeError",
    "MQTTConfigError",
    "MQTTHandlerError",
    "MQTTTimeoutError",
    # 工具
    "topic_matches",
    "sanitize_client_id",
    "parse_broker_url",
    "validate_topic",
    "validate_publish_topic",
    "calculate_backoff_delay",
]
