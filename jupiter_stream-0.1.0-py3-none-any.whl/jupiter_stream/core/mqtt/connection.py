"""MQTT 连接管理器

连接管理器 / Connection manager with auto-reconnect and health check
"""

from __future__ import annotations

import logging
import threading
import time
from enum import Enum
from typing import Optional

from .config import MQTTConfig
from .exceptions import MQTTConnectionError, MQTTTimeoutError
from .utils import calculate_backoff_delay

logger = logging.getLogger(__name__)


class ConnectionState(str, Enum):
    """连接状态枚举

    Connection state enum
    """

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    ERROR = "error"


class ConnectionManager:
    """连接管理器

    负责:
    - 管理 MQTT 连接状态
    - 实现自动重连逻辑（指数退避）
    - 健康检查和心跳维护
    - 连接事件回调

    Connection manager responsible for:
    - Managing MQTT connection state
    - Auto-reconnect with exponential backoff
    - Health check and heartbeat
    - Connection event callbacks

    Args:
        mqtt_client: paho.mqtt.Client 实例
        config: MQTT 配置
    """

    def __init__(self, mqtt_client, config: MQTTConfig):
        """初始化连接管理器

        Args:
            mqtt_client: paho.mqtt.Client 实例
            config: MQTT 配置
        """
        self._client = mqtt_client
        self._config = config
        self._state = ConnectionState.DISCONNECTED
        self._lock = threading.RLock()

        # 重连控制
        self._reconnect_attempt = 0
        self._should_stop_reconnect = False
        self._reconnect_thread: Optional[threading.Thread] = None

        # 健康检查
        self._health_check_thread: Optional[threading.Thread] = None
        self._health_check_running = False
        self._last_ping_time = 0.0

        # 统计
        self._connect_time: Optional[float] = None
        self._disconnect_time: Optional[float] = None
        self._total_reconnects = 0

        # 设置 paho.mqtt 回调
        self._setup_callbacks()

    def _setup_callbacks(self) -> None:
        """设置 paho.mqtt 客户端回调

        Setup paho.mqtt client callbacks
        """
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect

    def _on_connect(self, client, userdata, flags, rc):
        """连接成功回调

        On connect callback

        Args:
            client: MQTT 客户端
            userdata: 用户数据
            flags: 连接标志
            rc: 返回码
        """
        with self._lock:
            if rc == 0:
                self._state = ConnectionState.CONNECTED
                self._connect_time = time.time()
                self._reconnect_attempt = 0
                logger.info(f"Connected to MQTT broker: {self._config.broker}:{self._config.port}")

                # 启动健康检查
                if self._config.connection.health_check_interval > 0:
                    self._start_health_check()
            else:
                self._state = ConnectionState.ERROR
                logger.error(f"Connection failed with rc={rc}")

    def _on_disconnect(self, client, userdata, rc):
        """断开连接回调

        On disconnect callback

        Args:
            client: MQTT 客户端
            userdata: 用户数据
            rc: 返回码
        """
        with self._lock:
            self._disconnect_time = time.time()
            self._stop_health_check()

            if rc != 0:
                # 非正常断开
                logger.warning(f"Unexpected disconnect from broker, rc={rc}")
                self._state = ConnectionState.DISCONNECTED

                # 自动重连
                if self._config.connection.auto_reconnect:
                    self._start_reconnect()
            else:
                # 正常断开
                self._state = ConnectionState.DISCONNECTED
                logger.info("Disconnected from MQTT broker")

    def connect(self, timeout: Optional[float] = None) -> bool:
        """连接到 MQTT broker

        Connect to MQTT broker

        Args:
            timeout: 连接超时(秒) / Connection timeout (seconds)

        Returns:
            是否成功连接 / Whether connection succeeded

        Raises:
            MQTTConnectionError: 连接失败时抛出
        """
        if timeout is None:
            timeout = self._config.connection.connect_timeout

        with self._lock:
            if self._state == ConnectionState.CONNECTED:
                logger.warning("Already connected to broker")
                return True

            self._state = ConnectionState.CONNECTING
            self._should_stop_reconnect = False

        try:
            logger.info(f"Connecting to {self._config.broker}:{self._config.port}...")
            self._client.connect(
                host=self._config.broker,
                port=self._config.port,
                keepalive=self._config.connection.keepalive,
            )

            # 启动网络循环
            self._client.loop_start()

            # 等待连接完成
            start_time = time.time()
            while time.time() - start_time < timeout:
                with self._lock:
                    if self._state == ConnectionState.CONNECTED:
                        return True
                    elif self._state == ConnectionState.ERROR:
                        raise MQTTConnectionError("Connection failed")
                time.sleep(0.1)

            # 超时
            with self._lock:
                self._state = ConnectionState.ERROR
            raise MQTTTimeoutError(f"Connection timeout after {timeout}s")

        except Exception as e:
            with self._lock:
                self._state = ConnectionState.ERROR
            raise MQTTConnectionError(f"Failed to connect: {e}") from e

    def disconnect(self, timeout: float = 5.0) -> bool:
        """断开连接

        Disconnect from MQTT broker

        Args:
            timeout: 断开超时(秒) / Disconnect timeout (seconds)

        Returns:
            是否成功断开 / Whether disconnection succeeded
        """
        with self._lock:
            if self._state == ConnectionState.DISCONNECTED:
                logger.warning("Already disconnected")
                return True

            # 停止重连和健康检查
            self._should_stop_reconnect = True
            self._stop_health_check()

        try:
            logger.info("Disconnecting from MQTT broker...")
            self._client.disconnect()

            # 等待断开完成
            start_time = time.time()
            while time.time() - start_time < timeout:
                with self._lock:
                    if self._state == ConnectionState.DISCONNECTED:
                        self._client.loop_stop()
                        return True
                time.sleep(0.1)

            # 超时，强制停止
            self._client.loop_stop()
            with self._lock:
                self._state = ConnectionState.DISCONNECTED
            logger.warning("Disconnect timeout, forced stop")
            return False

        except Exception as e:
            logger.error(f"Error during disconnect: {e}")
            self._client.loop_stop()
            with self._lock:
                self._state = ConnectionState.DISCONNECTED
            return False

    def _start_reconnect(self) -> None:
        """启动重连线程

        Start reconnect thread
        """
        if self._reconnect_thread and self._reconnect_thread.is_alive():
            logger.debug("Reconnect thread already running")
            return

        self._reconnect_thread = threading.Thread(
            target=self._reconnect_loop, daemon=True, name="MQTTReconnect"
        )
        self._reconnect_thread.start()
        logger.info("Reconnect thread started")

    def _reconnect_loop(self) -> None:
        """重连循环（指数退避）

        Reconnect loop with exponential backoff
        """
        with self._lock:
            self._state = ConnectionState.RECONNECTING
            self._reconnect_attempt = 0

        max_attempts = self._config.connection.max_reconnect_attempts

        while not self._should_stop_reconnect:
            if max_attempts >= 0 and self._reconnect_attempt >= max_attempts:
                logger.error(f"Max reconnect attempts ({max_attempts}) reached, giving up")
                with self._lock:
                    self._state = ConnectionState.ERROR
                break

            with self._lock:
                self._reconnect_attempt += 1
                attempt = self._reconnect_attempt

            # 计算延迟
            delay = calculate_backoff_delay(
                attempt=attempt - 1,
                min_delay=self._config.connection.reconnect_delay_min,
                max_delay=self._config.connection.reconnect_delay_max,
                exponential=self._config.connection.reconnect_exponential_backoff,
            )

            logger.info(f"Reconnect attempt {attempt}, waiting {delay:.1f}s...")
            time.sleep(delay)

            if self._should_stop_reconnect:
                break

            # 尝试重连
            try:
                self._client.reconnect()
                logger.info(f"Reconnect attempt {attempt} initiated")

                # 等待连接结果
                time.sleep(2.0)

                with self._lock:
                    if self._state == ConnectionState.CONNECTED:
                        logger.info(f"Reconnected successfully after {attempt} attempt(s)")
                        self._total_reconnects += 1
                        break
            except Exception as e:
                logger.warning(f"Reconnect attempt {attempt} failed: {e}")

        logger.info("Reconnect loop ended")

    def _start_health_check(self) -> None:
        """启动健康检查线程

        Start health check thread
        """
        with self._lock:
            if self._health_check_running:
                return

            self._health_check_running = True

        self._health_check_thread = threading.Thread(
            target=self._health_check_loop, daemon=True, name="MQTTHealthCheck"
        )
        self._health_check_thread.start()
        logger.info("Health check thread started")

    def _stop_health_check(self) -> None:
        """停止健康检查线程

        Stop health check thread
        """
        with self._lock:
            self._health_check_running = False

        if self._health_check_thread:
            self._health_check_thread.join(timeout=2.0)
            logger.info("Health check thread stopped")

    def _health_check_loop(self) -> None:
        """健康检查循环

        Health check loop
        """
        interval = self._config.connection.health_check_interval

        while self._health_check_running:
            time.sleep(interval)

            if not self._health_check_running:
                break

            with self._lock:
                if self._state != ConnectionState.CONNECTED:
                    continue

            # 执行 ping
            try:
                self._last_ping_time = time.time()
                # paho.mqtt 的 ping 是自动的，这里只是记录时间
                logger.debug("Health check ping")
            except Exception as e:
                logger.error(f"Health check error: {e}")

    @property
    def state(self) -> ConnectionState:
        """获取连接状态

        Get connection state
        """
        with self._lock:
            return self._state

    @property
    def is_connected(self) -> bool:
        """是否已连接

        Whether connected
        """
        with self._lock:
            return self._state == ConnectionState.CONNECTED

    @property
    def uptime(self) -> float:
        """连接时长(秒)

        Connection uptime (seconds)
        """
        with self._lock:
            if self._connect_time is None:
                return 0.0
            return time.time() - self._connect_time

    def get_stats(self) -> dict:
        """获取连接统计信息

        Get connection statistics
        """
        with self._lock:
            return {
                "state": self._state.value,
                "is_connected": self.is_connected,
                "uptime": self.uptime,
                "reconnect_attempt": self._reconnect_attempt,
                "total_reconnects": self._total_reconnects,
                "connect_time": self._connect_time,
                "disconnect_time": self._disconnect_time,
            }
