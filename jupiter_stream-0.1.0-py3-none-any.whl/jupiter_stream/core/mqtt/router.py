"""MQTT 消息路由器

消息路由器 / Message router implementing Observer pattern
"""

from __future__ import annotations

import logging
import threading
from typing import List, Set

from .handler import MessageHandler
from .message import Message

logger = logging.getLogger(__name__)


class MessageRouter:
    """消息路由器

    实现观察者模式，负责:
    - 管理消息处理器的注册和注销
    - 将接收到的消息分发给匹配的处理器
    - Topic 匹配（支持通配符）

    Message router implementing Observer pattern for:
    - Handler registration/unregistration
    - Message dispatching to matching handlers
    - Topic matching with wildcards

    线程安全 / Thread-safe
    """

    def __init__(self):
        """初始化路由器"""
        self._handlers: List[MessageHandler] = []
        self._lock = threading.RLock()
        self._message_count = 0
        self._dispatch_count = 0

    def register_handler(self, handler: MessageHandler) -> None:
        """注册消息处理器

        Register message handler

        Args:
            handler: 消息处理器实例 / Message handler instance
        """
        with self._lock:
            if handler in self._handlers:
                logger.warning(f"Handler {handler.__class__.__name__} already registered, skipping")
                return

            self._handlers.append(handler)
            logger.info(
                f"Registered handler: {handler.__class__.__name__} " f"for topics: {handler.topics}"
            )

    def unregister_handler(self, handler: MessageHandler) -> bool:
        """注销消息处理器

        Unregister message handler

        Args:
            handler: 消息处理器实例 / Message handler instance

        Returns:
            是否成功注销 / Whether unregistration succeeded
        """
        with self._lock:
            if handler not in self._handlers:
                logger.warning(
                    f"Handler {handler.__class__.__name__} not registered, cannot unregister"
                )
                return False

            self._handlers.remove(handler)
            logger.info(f"Unregistered handler: {handler.__class__.__name__}")
            return True

    def get_handlers(self) -> List[MessageHandler]:
        """获取所有已注册的处理器

        Get all registered handlers

        Returns:
            处理器列表（副本）/ List of handlers (copy)
        """
        with self._lock:
            return self._handlers.copy()

    def get_subscribed_topics(self) -> Set[str]:
        """获取所有需要订阅的 topic

        Get all topics that need to be subscribed

        Returns:
            Topic 集合（包含共享订阅格式）/ Set of topics (with shared subscription format)
        """
        with self._lock:
            topics = set()
            for handler in self._handlers:
                if handler.enabled:
                    topics.update(handler.get_subscription_topics())
            return topics

    def dispatch(self, message: Message) -> int:
        """分发消息到匹配的处理器

        Dispatch message to matching handlers

        Args:
            message: MQTT 消息 / MQTT message

        Returns:
            成功处理的处理器数量 / Number of handlers that successfully processed
        """
        with self._lock:
            self._message_count += 1
            handlers = self._handlers.copy()  # 复制以避免迭代时修改

        successful_count = 0

        for handler in handlers:
            if handler.process(message):
                successful_count += 1

        if successful_count > 0:
            with self._lock:
                self._dispatch_count += successful_count

            logger.debug(
                f"Dispatched message to {successful_count} handler(s): "
                f"topic={message.topic}, id={message.message_id}"
            )
        else:
            logger.debug(f"No handler matched for topic: {message.topic}")

        return successful_count

    def clear_handlers(self) -> int:
        """清空所有处理器

        Clear all handlers

        Returns:
            清空的处理器数量 / Number of handlers cleared
        """
        with self._lock:
            count = len(self._handlers)
            self._handlers.clear()
            logger.info(f"Cleared {count} handler(s)")
            return count

    def get_stats(self) -> dict:
        """获取路由器统计信息

        Get router statistics

        Returns:
            统计信息字典 / Statistics dictionary
        """
        with self._lock:
            handler_stats = [h.get_stats() for h in self._handlers]

            return {
                "total_handlers": len(self._handlers),
                "enabled_handlers": sum(1 for h in self._handlers if h.enabled),
                "subscribed_topics": list(self.get_subscribed_topics()),
                "message_count": self._message_count,
                "dispatch_count": self._dispatch_count,
                "handlers": handler_stats,
            }

    def reset_stats(self) -> None:
        """重置统计计数器

        Reset statistics counters
        """
        with self._lock:
            self._message_count = 0
            self._dispatch_count = 0
            for handler in self._handlers:
                handler.reset_stats()
            logger.info("Router statistics reset")

    def __repr__(self) -> str:
        """字符串表示 / String representation"""
        with self._lock:
            return (
                f"MessageRouter("
                f"handlers={len(self._handlers)}, "
                f"topics={len(self.get_subscribed_topics())})"
            )
