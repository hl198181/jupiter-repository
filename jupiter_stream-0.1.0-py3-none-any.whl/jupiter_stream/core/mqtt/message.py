"""MQTT 消息数据模型

消息数据模型 / Message data model
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class Message:
    """MQTT 消息数据模型

    封装 MQTT 消息的所有属性，提供序列化/反序列化功能。
    Encapsulates all MQTT message properties with serialization support.

    Attributes:
        topic: MQTT topic
        payload: 消息负载（字典格式）/ Message payload (dict format)
        qos: QoS 等级 (0, 1, 2) / QoS level
        retain: 是否保留消息 / Retain flag
        timestamp: 消息时间戳 / Message timestamp
        message_id: 唯一消息 ID / Unique message ID
    """

    topic: str
    payload: Dict[str, Any]
    qos: int = 1
    retain: bool = False
    timestamp: float = field(default_factory=time.time)
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_json(self) -> str:
        """序列化为 JSON 字符串

        Serialize to JSON string

        Returns:
            JSON 字符串 / JSON string
        """
        return json.dumps(
            {
                "topic": self.topic,
                "payload": self.payload,
                "qos": self.qos,
                "retain": self.retain,
                "timestamp": self.timestamp,
                "message_id": self.message_id,
            },
            ensure_ascii=False,
        )

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典

        Convert to dictionary

        Returns:
            字典 / Dictionary
        """
        return {
            "topic": self.topic,
            "payload": self.payload,
            "qos": self.qos,
            "retain": self.retain,
            "timestamp": self.timestamp,
            "message_id": self.message_id,
        }

    @classmethod
    def from_mqtt_message(cls, mqtt_msg, encoding: str = "utf-8") -> Message:
        """从 paho.mqtt.MQTTMessage 创建 Message 实例

        Create Message instance from paho.mqtt.MQTTMessage

        Args:
            mqtt_msg: paho.mqtt.MQTTMessage 对象
            encoding: 消息编码格式 / Message encoding

        Returns:
            Message 实例 / Message instance
        """
        try:
            payload = json.loads(mqtt_msg.payload.decode(encoding))
        except (json.JSONDecodeError, UnicodeDecodeError):
            # 如果解析失败，将原始 payload 包装为字典
            # If parsing fails, wrap raw payload as dict
            payload = {"raw": mqtt_msg.payload.decode(encoding, errors="replace")}

        return cls(
            topic=mqtt_msg.topic,
            payload=payload,
            qos=mqtt_msg.qos,
            retain=mqtt_msg.retain,
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Message:
        """从字典创建 Message 实例

        Create Message instance from dictionary

        Args:
            data: 包含消息数据的字典 / Dictionary containing message data

        Returns:
            Message 实例 / Message instance
        """
        return cls(
            topic=data["topic"],
            payload=data.get("payload", {}),
            qos=data.get("qos", 1),
            retain=data.get("retain", False),
            timestamp=data.get("timestamp", time.time()),
            message_id=data.get("message_id", str(uuid.uuid4())),
        )

    @classmethod
    def from_json(cls, json_str: str) -> Message:
        """从 JSON 字符串创建 Message 实例

        Create Message instance from JSON string

        Args:
            json_str: JSON 字符串 / JSON string

        Returns:
            Message 实例 / Message instance
        """
        data = json.loads(json_str)
        return cls.from_dict(data)

    def __repr__(self) -> str:
        """字符串表示

        String representation
        """
        return (
            f"Message(topic='{self.topic}', "
            f"qos={self.qos}, "
            f"message_id='{self.message_id[:8]}...')"
        )
