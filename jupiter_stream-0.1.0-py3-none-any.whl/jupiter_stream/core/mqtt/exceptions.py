"""MQTT 模块自定义异常类

自定义异常 / Custom Exceptions for MQTT module
"""

from __future__ import annotations


class MQTTError(Exception):
    """MQTT 基础异常类 / Base exception for MQTT module"""

    pass


class MQTTConnectionError(MQTTError):
    """连接错误 / Connection error"""

    pass


class MQTTReconnectError(MQTTError):
    """重连失败错误 / Reconnection failed error"""

    pass


class MQTTPublishError(MQTTError):
    """消息发布错误 / Message publish error"""

    pass


class MQTTSubscribeError(MQTTError):
    """订阅错误 / Subscription error"""

    pass


class MQTTConfigError(MQTTError):
    """配置错误 / Configuration error"""

    pass


class MQTTHandlerError(MQTTError):
    """消息处理器错误 / Message handler error"""

    pass


class MQTTTimeoutError(MQTTError):
    """超时错误 / Timeout error"""

    pass
