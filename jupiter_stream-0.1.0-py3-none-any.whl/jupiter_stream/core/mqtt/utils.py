"""MQTT 工具函数

工具函数 / Utility functions for MQTT module
"""

from __future__ import annotations

import re
from typing import Tuple


def topic_matches(topic: str, pattern: str) -> bool:
    """检查 topic 是否匹配 MQTT 通配符模式

    Check if topic matches MQTT wildcard pattern

    支持 MQTT 通配符:
    - `+`: 单级通配符 (devices/+/status 匹配 devices/001/status)
    - `#`: 多级通配符 (devices/# 匹配 devices/001/status/online)

    Args:
        topic: 实际 topic / Actual topic
        pattern: 匹配模式 / Pattern with wildcards

    Returns:
        是否匹配 / Whether topic matches pattern

    Examples:
        >>> topic_matches("devices/001/status", "devices/+/status")
        True
        >>> topic_matches("devices/001/status/online", "devices/#")
        True
        >>> topic_matches("devices/001/control", "devices/+/status")
        False
    """
    # 完全相同
    if topic == pattern:
        return True

    topic_parts = topic.split("/")
    pattern_parts = pattern.split("/")

    i, j = 0, 0

    while i < len(topic_parts) and j < len(pattern_parts):
        if pattern_parts[j] == "#":
            # 多级通配符匹配所有剩余部分
            return True
        elif pattern_parts[j] == "+":
            # 单级通配符匹配一个级别
            i += 1
            j += 1
        elif pattern_parts[j] == topic_parts[i]:
            # 精确匹配
            i += 1
            j += 1
        else:
            # 不匹配
            return False

    # 检查是否完全消费
    return i == len(topic_parts) and j == len(pattern_parts)


def sanitize_client_id(client_id: str) -> str:
    """清理客户端 ID，移除非法字符

    Sanitize client ID by removing invalid characters

    MQTT 客户端 ID 只允许: [0-9a-zA-Z_-]

    Args:
        client_id: 原始客户端 ID / Original client ID

    Returns:
        清理后的客户端 ID / Sanitized client ID
    """
    # 只保留字母、数字、下划线、连字符
    sanitized = re.sub(r"[^0-9a-zA-Z_-]", "", client_id)

    # 确保不为空
    if not sanitized:
        raise ValueError(f"Invalid client_id: '{client_id}' (becomes empty after sanitization)")

    # 限制长度 (MQTT 规范建议 < 23 字符)
    if len(sanitized) > 23:
        sanitized = sanitized[:23]

    return sanitized


def parse_broker_url(broker_url: str) -> Tuple[str, int, bool]:
    """解析 broker URL

    Parse broker URL

    支持格式:
    - mqtt://host:port
    - mqtts://host:port (使用 TLS)
    - host:port
    - host (默认端口 1883)

    Args:
        broker_url: Broker URL

    Returns:
        (host, port, use_tls) 元组

    Examples:
        >>> parse_broker_url("mqtt://localhost:1883")
        ('localhost', 1883, False)
        >>> parse_broker_url("mqtts://broker.example.com:8883")
        ('broker.example.com', 8883, True)
    """
    use_tls = False

    # 处理 mqtt:// 或 mqtts:// 前缀
    if broker_url.startswith("mqtts://"):
        broker_url = broker_url[8:]
        use_tls = True
    elif broker_url.startswith("mqtt://"):
        broker_url = broker_url[7:]

    # 解析 host:port
    if ":" in broker_url:
        host, port_str = broker_url.rsplit(":", 1)
        try:
            port = int(port_str)
        except ValueError:
            raise ValueError(f"Invalid port in broker URL: {broker_url}")
    else:
        host = broker_url
        port = 8883 if use_tls else 1883  # 默认端口

    return host, port, use_tls


def validate_topic(topic: str) -> bool:
    """验证 topic 格式是否合法

    Validate topic format

    MQTT Topic 规则:
    - 不能为空
    - 不能包含空字符 (NULL, \\0)
    - 长度限制 (建议 < 65535)
    - 通配符 +/# 只能用于订阅，不能用于发布

    Args:
        topic: Topic 字符串

    Returns:
        是否合法
    """
    if not topic:
        return False

    # 检查空字符
    if "\x00" in topic:
        return False

    # 检查长度
    if len(topic) > 65535:
        return False

    return True


def validate_publish_topic(topic: str) -> bool:
    """验证发布 topic（不允许通配符）

    Validate publish topic (no wildcards allowed)

    Args:
        topic: Topic 字符串

    Returns:
        是否合法
    """
    if not validate_topic(topic):
        return False

    # 发布 topic 不允许通配符
    if "+" in topic or "#" in topic:
        return False

    return True


def calculate_backoff_delay(
    attempt: int, min_delay: float = 1.0, max_delay: float = 60.0, exponential: bool = True
) -> float:
    """计算重连延迟时间（指数退避）

    Calculate reconnect delay with exponential backoff

    Args:
        attempt: 当前重试次数 / Current attempt number
        min_delay: 最小延迟 / Minimum delay
        max_delay: 最大延迟 / Maximum delay
        exponential: 是否使用指数退避 / Use exponential backoff

    Returns:
        延迟时间(秒) / Delay in seconds
    """
    if not exponential:
        return min_delay

    # 指数退避: delay = min_delay * (2 ^ attempt)
    delay = min_delay * (2**attempt)

    # 限制最大延迟
    return min(delay, max_delay)
