"""Pipeline 控制消息处理器

Pipeline control handler for remote pipeline management
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from ..handler import MessageHandler
from ..message import Message

if TYPE_CHECKING:
    from ...pipeline.manager import PipelineManager

logger = logging.getLogger(__name__)


class PipelineControlHandler(MessageHandler):
    """Pipeline 控制处理器

    处理 Pipeline 远程控制消息，支持:
    - 启动/停止/重启 Pipeline
    - 查询 Pipeline 状态
    - 列出所有 Pipeline

    Handle pipeline remote control messages supporting:
    - Start/stop/restart pipeline
    - Query pipeline status
    - List all pipelines

    Topic 格式:
    - devices/{device_id}/control/pipeline/start
    - devices/{device_id}/control/pipeline/stop
    - devices/{device_id}/control/pipeline/restart
    - devices/{device_id}/control/pipeline/status
    - devices/{device_id}/control/pipeline/list

    Payload 格式:
    {
        "pipeline_name": "camera_1",  # 可选，为空时操作所有 pipeline
        "params": {}  # 可选参数
    }

    Examples:
        >>> from jupiter_stream.core import PipelineManager
        >>> from jupiter_stream.core.mqtt import MQTTClient
        >>> from jupiter_stream.core.mqtt.handlers.pipeline import PipelineControlHandler
        >>>
        >>> manager = PipelineManager()
        >>> mqtt_client = MQTTClient.from_config("config/mqtt.yaml")
        >>>
        >>> handler = PipelineControlHandler(
        ...     manager=manager,
        ...     mqtt_client=mqtt_client,
        ...     device_id="jetson-001"
        ... )
        >>> mqtt_client.register_handler(handler)
    """

    def __init__(
        self,
        manager: PipelineManager,
        mqtt_client,
        device_id: str,
        topic_prefix: str = "devices",
    ):
        """初始化 Pipeline 控制处理器

        Args:
            manager: PipelineManager 实例
            mqtt_client: MQTT 客户端实例（用于发布响应）
            device_id: 设备 ID
            topic_prefix: Topic 前缀（默认 "devices"）
        """
        # 构建订阅 topics
        topics = [
            f"{topic_prefix}/{device_id}/control/pipeline/start",
            f"{topic_prefix}/{device_id}/control/pipeline/stop",
            f"{topic_prefix}/{device_id}/control/pipeline/restart",
            f"{topic_prefix}/{device_id}/control/pipeline/status",
            f"{topic_prefix}/{device_id}/control/pipeline/list",
        ]

        super().__init__(topics, qos=1)

        self._manager = manager
        self._mqtt_client = mqtt_client
        self._device_id = device_id
        self._topic_prefix = topic_prefix

    def handle(self, message: Message) -> None:
        """处理 Pipeline 控制消息

        Handle pipeline control message

        Args:
            message: MQTT 消息
        """
        # 解析 action
        topic_parts = message.topic.split("/")
        if len(topic_parts) < 4:
            logger.warning(f"Invalid topic format: {message.topic}")
            return

        action = topic_parts[-1]  # start/stop/restart/status/list

        # 获取 pipeline_name
        pipeline_name = message.payload.get("pipeline_name")

        # 执行操作
        try:
            if action == "start":
                self._handle_start(pipeline_name, message)
            elif action == "stop":
                self._handle_stop(pipeline_name, message)
            elif action == "restart":
                self._handle_restart(pipeline_name, message)
            elif action == "status":
                self._handle_status(pipeline_name, message)
            elif action == "list":
                self._handle_list(message)
            else:
                logger.warning(f"Unknown action: {action}")
                self._publish_response(message, success=False, error=f"Unknown action: {action}")

        except Exception as e:
            logger.error(f"Error handling {action}: {e}", exc_info=True)
            self._publish_response(message, success=False, error=str(e))

    def _handle_start(self, pipeline_name: Optional[str], message: Message) -> None:
        """处理启动命令

        Handle start command

        Args:
            pipeline_name: Pipeline 名称（None 表示启动所有）
            message: 原始消息
        """
        if pipeline_name:
            success = self._manager.start_pipeline(pipeline_name)
            self._publish_response(
                message,
                success=success,
                data={"pipeline_name": pipeline_name, "action": "started"},
            )
        else:
            results = self._manager.start_all()
            self._publish_response(
                message,
                success=all(results.values()),
                data={"results": results, "action": "start_all"},
            )

    def _handle_stop(self, pipeline_name: Optional[str], message: Message) -> None:
        """处理停止命令

        Handle stop command

        Args:
            pipeline_name: Pipeline 名称（None 表示停止所有）
            message: 原始消息
        """
        if pipeline_name:
            success = self._manager.stop_pipeline(pipeline_name)
            self._publish_response(
                message,
                success=success,
                data={"pipeline_name": pipeline_name, "action": "stopped"},
            )
        else:
            results = self._manager.stop_all()
            self._publish_response(
                message,
                success=all(results.values()),
                data={"results": results, "action": "stop_all"},
            )

    def _handle_restart(self, pipeline_name: Optional[str], message: Message) -> None:
        """处理重启命令

        Handle restart command

        Args:
            pipeline_name: Pipeline 名称
            message: 原始消息
        """
        if not pipeline_name:
            self._publish_response(message, success=False, error="pipeline_name is required")
            return

        success = self._manager.restart_pipeline(pipeline_name)
        self._publish_response(
            message,
            success=success,
            data={"pipeline_name": pipeline_name, "action": "restarted"},
        )

    def _handle_status(self, pipeline_name: Optional[str], message: Message) -> None:
        """处理状态查询命令

        Handle status query command

        Args:
            pipeline_name: Pipeline 名称（None 表示查询所有）
            message: 原始消息
        """
        if pipeline_name:
            status = self._manager.get_status(pipeline_name)
            self._publish_response(message, success=True, data={"status": status})
        else:
            statuses = self._manager.get_status()
            self._publish_response(message, success=True, data={"statuses": statuses})

    def _handle_list(self, message: Message) -> None:
        """处理列表查询命令

        Handle list query command

        Args:
            message: 原始消息
        """
        pipelines = self._manager.list_pipelines()
        self._publish_response(message, success=True, data={"pipelines": pipelines})

    def _publish_response(
        self,
        message: Message,
        success: bool,
        data: Optional[dict] = None,
        error: Optional[str] = None,
    ) -> None:
        """发布响应消息

        Publish response message

        Args:
            message: 原始消息
            success: 是否成功
            data: 响应数据
            error: 错误信息
        """
        response_topic = f"{self._topic_prefix}/{self._device_id}/status/pipeline/response"

        response_payload = {
            "success": success,
            "message_id": message.message_id,
            "timestamp": message.timestamp,
        }

        if data:
            response_payload["data"] = data

        if error:
            response_payload["error"] = error

        try:
            self._mqtt_client.publish(response_topic, response_payload, qos=1)
            logger.debug(f"Published response: success={success}, topic={response_topic}")
        except Exception as e:
            logger.error(f"Failed to publish response: {e}")
