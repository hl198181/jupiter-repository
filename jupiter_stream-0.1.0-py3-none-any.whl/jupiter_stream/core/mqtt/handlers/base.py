"""基础消息处理器

基础处理器 / Base message handler with common functionality
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from ..handler import MessageHandler
from ..message import Message

logger = logging.getLogger(__name__)


class BaseHandler(MessageHandler):
    """基础消息处理器

    提供通用的消息处理功能，可直接使用或继承。
    Base handler providing common message handling functionality.

    特性:
    - JSON payload 解析
    - 消息验证
    - 错误处理
    - 日志记录

    Examples:
        >>> handler = BaseHandler(
        ...     topics=["devices/+/status"],
        ...     on_message=lambda msg: print(msg.payload)
        ... )
    """

    def __init__(
        self, topics: List[str], qos: int = 1, on_message=None, validate_payload: bool = True
    ):
        """初始化基础处理器

        Args:
            topics: 订阅的 topic 列表
            qos: QoS 等级
            on_message: 消息处理回调函数 (message: Message) -> None
            validate_payload: 是否验证 payload 格式
        """
        super().__init__(topics, qos)
        self._on_message = on_message
        self._validate_payload = validate_payload

    def handle(self, message: Message) -> None:
        """处理消息

        Handle message

        Args:
            message: MQTT 消息
        """
        # 验证 payload
        if self._validate_payload:
            if not self.validate_payload(message.payload):
                logger.warning(
                    f"Invalid payload format: topic={message.topic}, " f"payload={message.payload}"
                )
                return

        # 调用回调
        if self._on_message:
            self._on_message(message)
        else:
            # 默认行为：记录日志
            self.log_message(message)

    def validate_payload(self, payload: Dict[str, Any]) -> bool:
        """验证 payload 格式（子类可重写）

        Validate payload format (can be overridden)

        Args:
            payload: 消息负载

        Returns:
            是否有效
        """
        # 默认：检查是否是字典
        return isinstance(payload, dict)

    def log_message(self, message: Message) -> None:
        """记录消息日志

        Log message

        Args:
            message: MQTT 消息
        """
        logger.info(
            f"Received message: topic={message.topic}, "
            f"payload={message.payload}, "
            f"qos={message.qos}"
        )

    def on_error(self, exception: Exception, message: Message) -> None:
        """错误处理

        Handle error

        Args:
            exception: 异常对象
            message: 导致错误的消息
        """
        logger.error(
            f"Error in BaseHandler: {exception}",
            exc_info=True,
            extra={"topic": message.topic, "payload": message.payload},
        )
