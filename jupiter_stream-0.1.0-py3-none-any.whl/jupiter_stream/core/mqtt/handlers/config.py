"""配置下载消息处理器

Configuration download handler for remote config management
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from ..handler import MessageHandler
from ..message import Message

if TYPE_CHECKING:
    from ...pipeline.manager import PipelineManager

logger = logging.getLogger(__name__)


class ConfigDownloadHandler(MessageHandler):
    """配置下载处理器

    处理配置下载消息，支持:
    - 从 URL 下载配置文件
    - 验证配置格式
    - 自动加载 Pipeline

    Handle config download messages supporting:
    - Download config from URL
    - Validate config format
    - Auto-load pipeline

    Topic 格式:
    - devices/{device_id}/control/config/download

    Payload 格式:
    {
        "config_url": "https://server.com/configs/camera1.yaml",
        "pipeline_name": "camera_1",  # 可选
        "auto_start": true,  # 是否自动启动
        "save_path": "/path/to/save"  # 可选，保存路径
    }

    Examples:
        >>> from jupiter_stream.core import PipelineManager
        >>> from jupiter_stream.core.mqtt import MQTTClient
        >>> from jupiter_stream.core.mqtt.handlers.config import ConfigDownloadHandler
        >>>
        >>> manager = PipelineManager()
        >>> mqtt_client = MQTTClient.from_config("config/mqtt.yaml")
        >>>
        >>> # 需要提供下载函数（由应用层实现）
        >>> def download_func(url, save_path):
        ...     import requests
        ...     response = requests.get(url)
        ...     with open(save_path, 'wb') as f:
        ...         f.write(response.content)
        ...     return save_path
        >>>
        >>> handler = ConfigDownloadHandler(
        ...     manager=manager,
        ...     mqtt_client=mqtt_client,
        ...     device_id="jetson-001",
        ...     download_func=download_func
        ... )
        >>> mqtt_client.register_handler(handler)
    """

    def __init__(
        self,
        manager: PipelineManager,
        mqtt_client,
        device_id: str,
        download_func: Callable[[str, str], str],
        config_dir: Optional[Path] = None,
        topic_prefix: str = "devices",
    ):
        """初始化配置下载处理器

        Args:
            manager: PipelineManager 实例
            mqtt_client: MQTT 客户端实例
            device_id: 设备 ID
            download_func: 下载函数 download_func(url, save_path) -> saved_path
            config_dir: 配置保存目录（默认 ./configs）
            topic_prefix: Topic 前缀
        """
        topics = [f"{topic_prefix}/{device_id}/control/config/download"]

        super().__init__(topics, qos=1)

        self._manager = manager
        self._mqtt_client = mqtt_client
        self._device_id = device_id
        self._download_func = download_func
        self._config_dir = config_dir or Path("./configs")
        self._topic_prefix = topic_prefix

        # 确保配置目录存在
        self._config_dir.mkdir(parents=True, exist_ok=True)

    def handle(self, message: Message) -> None:
        """处理配置下载消息

        Handle config download message

        Args:
            message: MQTT 消息
        """
        try:
            # 解析参数
            config_url = message.payload.get("config_url")
            if not config_url:
                raise ValueError("config_url is required")

            pipeline_name = message.payload.get("pipeline_name")
            auto_start = message.payload.get("auto_start", True)
            save_path = message.payload.get("save_path")

            # 下载配置
            logger.info(f"Downloading config from: {config_url}")
            downloaded_path = self._download_config(config_url, save_path)

            # 加载 Pipeline
            if pipeline_name:
                # 加载单个 Pipeline
                success = self._manager.add_pipeline(
                    name=pipeline_name, config_path=downloaded_path, auto_start=auto_start
                )

                if success:
                    self._publish_response(
                        message,
                        success=True,
                        data={
                            "pipeline_name": pipeline_name,
                            "config_path": str(downloaded_path),
                            "auto_start": auto_start,
                        },
                    )
                else:
                    self._publish_response(
                        message, success=False, error=f"Failed to add pipeline: {pipeline_name}"
                    )
            else:
                # 从配置文件加载（可能包含多个 Pipeline）
                count = self._manager.load_from_config(downloaded_path)

                self._publish_response(
                    message,
                    success=True,
                    data={
                        "pipelines_loaded": count,
                        "config_path": str(downloaded_path),
                    },
                )

        except Exception as e:
            logger.error(f"Error downloading config: {e}", exc_info=True)
            self._publish_response(message, success=False, error=str(e))

    def _download_config(self, config_url: str, save_path: Optional[str] = None) -> Path:
        """下载配置文件

        Download configuration file

        Args:
            config_url: 配置文件 URL
            save_path: 保存路径（可选）

        Returns:
            保存的文件路径

        Raises:
            Exception: 下载失败时抛出
        """
        if save_path:
            target_path = Path(save_path)
        else:
            # 从 URL 提取文件名
            filename = config_url.split("/")[-1]
            if not filename.endswith((".yaml", ".yml", ".json")):
                filename = "downloaded_config.yaml"
            target_path = self._config_dir / filename

        # 确保父目录存在
        target_path.parent.mkdir(parents=True, exist_ok=True)

        # 调用下载函数
        saved_path = self._download_func(config_url, str(target_path))

        logger.info(f"Config downloaded and saved to: {saved_path}")

        return Path(saved_path)

    def _publish_response(
        self,
        message: Message,
        success: bool,
        data: Optional[dict] = None,
        error: Optional[str] = None,
    ) -> None:
        """发布响应消息

        Publish response message

        Args:
            message: 原始消息
            success: 是否成功
            data: 响应数据
            error: 错误信息
        """
        response_topic = f"{self._topic_prefix}/{self._device_id}/status/config/response"

        response_payload = {
            "success": success,
            "message_id": message.message_id,
            "timestamp": message.timestamp,
        }

        if data:
            response_payload["data"] = data

        if error:
            response_payload["error"] = error

        try:
            self._mqtt_client.publish(response_topic, response_payload, qos=1)
            logger.debug(f"Published config response: success={success}")
        except Exception as e:
            logger.error(f"Failed to publish response: {e}")
