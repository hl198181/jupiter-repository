"""MQTT 内置消息处理器

Built-in message handlers for MQTT
"""

from __future__ import annotations

from .base import BaseHandler

__all__ = ["BaseHandler"]
