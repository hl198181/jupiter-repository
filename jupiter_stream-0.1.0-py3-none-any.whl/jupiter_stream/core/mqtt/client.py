"""MQTT 客户端

MQTT 客户端 / MQTT client (main entry point)
"""

from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from .config import MQTTConfig
from .connection import ConnectionManager, ConnectionState
from .exceptions import MQTTConfigError
from .handler import MessageHandler
from .message import Message
from .publisher import Publisher
from .router import MessageRouter
from .utils import sanitize_client_id

logger = logging.getLogger(__name__)

# 延迟导入 paho.mqtt
try:
    import paho.mqtt.client as mqtt_client
except ImportError:
    raise ImportError(
        "paho-mqtt is required for MQTT module. " "Install it with: pip install paho-mqtt>=2.0.0"
    )


class MQTTClient:
    """MQTT 客户端

    Jupiter-Stream MQTT 客户端，整合所有 MQTT 功能。
    Jupiter-Stream MQTT client integrating all MQTT features.

    主要功能:
    - 连接管理（连接/断开/重连）
    - 订阅/发布消息
    - 消息路由和处理器管理
    - 配置驱动构建

    Features:
    - Connection management (connect/disconnect/reconnect)
    - Subscribe/publish messages
    - Message routing and handler management
    - Configuration-driven construction

    Examples:
        >>> # 从配置文件创建
        >>> client = MQTTClient.from_config("config/mqtt.yaml")
        >>> client.connect()
        >>> # 注册处理器
        >>> client.register_handler(MyHandler())
        >>> # 发布消息
        >>> client.publish("topic/test", {"hello": "world"})
        >>> client.disconnect()

        >>> # 使用上下文管理器
        >>> with MQTTClient.from_config("config/mqtt.yaml") as client:
        ...     client.publish("topic/test", {"hello": "world"})
    """

    def __init__(self, config: MQTTConfig):
        """初始化 MQTT 客户端

        Args:
            config: MQTT 配置 / MQTT configuration
        """
        self._config = config

        # 生成客户端 ID
        if not config.client_id:
            config.client_id = self._generate_client_id()
        else:
            config.client_id = sanitize_client_id(config.client_id)

        # 创建 paho.mqtt 客户端
        self._paho_client = mqtt_client.Client(
            client_id=config.client_id,
            clean_session=config.clean_session,
            protocol=mqtt_client.MQTTv311,
        )

        # 设置认证
        if config.username and config.password:
            self._paho_client.username_pw_set(config.username, config.password)

        # 设置 TLS
        if config.tls and config.tls.enabled:
            self._setup_tls()

        # 创建子组件
        self._router = MessageRouter()
        self._publisher = Publisher(self._paho_client, config.topic_prefix)
        self._connection = ConnectionManager(self._paho_client, config)

        # 设置消息回调
        self._paho_client.on_message = self._on_message

        logger.info(f"MQTTClient initialized: client_id={config.client_id}")

    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> MQTTClient:
        """从配置文件创建客户端（Builder 模式）

        Create client from configuration file (Builder pattern)

        Args:
            config_path: 配置文件路径 / Configuration file path

        Returns:
            MQTTClient 实例 / MQTTClient instance

        Raises:
            MQTTConfigError: 配置加载失败时抛出
        """
        try:
            # 使用 jupiter-stream 的配置加载器
            from ....loaders import AutoConfigLoader

            loader = AutoConfigLoader()
            config_dict = loader.load(Path(config_path))

            # 提取 mqtt 配置
            if "mqtt" in config_dict:
                mqtt_config_dict = config_dict["mqtt"]
            else:
                mqtt_config_dict = config_dict

            # 创建配置对象
            config = MQTTConfig.from_dict(mqtt_config_dict)

            return cls(config)

        except Exception as e:
            raise MQTTConfigError(f"Failed to load config from {config_path}: {e}") from e

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> MQTTClient:
        """从字典创建客户端

        Create client from dictionary

        Args:
            config_dict: 配置字典 / Configuration dictionary

        Returns:
            MQTTClient 实例 / MQTTClient instance
        """
        config = MQTTConfig.from_dict(config_dict)
        return cls(config)

    def _generate_client_id(self) -> str:
        """生成唯一的客户端 ID

        Generate unique client ID

        Returns:
            客户端 ID / Client ID
        """
        return f"jupiter-stream-{uuid.uuid4().hex[:8]}"

    def _setup_tls(self) -> None:
        """设置 TLS/SSL

        Setup TLS/SSL
        """
        if not self._config.tls:
            return

        import ssl

        tls_config = self._config.tls

        # 映射证书要求
        cert_reqs_map = {
            "none": ssl.CERT_NONE,
            "optional": ssl.CERT_OPTIONAL,
            "required": ssl.CERT_REQUIRED,
        }

        cert_reqs = ssl.CERT_REQUIRED
        if tls_config.cert_reqs:
            cert_reqs = cert_reqs_map.get(tls_config.cert_reqs.lower(), ssl.CERT_REQUIRED)

        self._paho_client.tls_set(
            ca_certs=tls_config.ca_certs,
            certfile=tls_config.certfile,
            keyfile=tls_config.keyfile,
            cert_reqs=cert_reqs,
            tls_version=ssl.PROTOCOL_TLS,
            ciphers=tls_config.ciphers,
        )

        logger.info("TLS/SSL configured")

    def _on_message(self, client, userdata, mqtt_msg):
        """消息接收回调

        Message receive callback

        Args:
            client: MQTT 客户端
            userdata: 用户数据
            mqtt_msg: paho.mqtt.MQTTMessage
        """
        try:
            # 转换为 Message 对象
            message = Message.from_mqtt_message(mqtt_msg)

            # 分发到路由器
            self._router.dispatch(message)

        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)

    # ========== 连接管理 ==========

    def set_will(
        self,
        topic: str,
        payload: Union[str, bytes, dict] = None,
        qos: int = 0,
        retain: bool = False,
    ) -> None:
        """设置遗嘱消息（Last Will and Testament）

        Set Last Will and Testament message.
        Must be called before connect().

        遗嘱消息会在客户端异常断开连接时由 Broker 自动发布。

        Args:
            topic: 遗嘱消息主题 / Will message topic
            payload: 遗嘱消息内容（支持字符串、字节或字典）/ Will message payload
            qos: 服务质量等级 (0, 1, 2) / Quality of Service level
            retain: 是否保留消息 / Retain flag

        Raises:
            ValueError: 如果 topic 为空或 qos 不合法
            RuntimeError: 如果在已连接状态下调用

        Example:
            >>> client = MQTTClient.from_config("config.yaml")
            >>> client.set_will(
            ...     topic="device/123/status",
            ...     payload={"online": False},
            ...     qos=1,
            ...     retain=True
            ... )
            >>> client.connect()
        """
        import json

        if not topic:
            raise ValueError("Will topic cannot be empty")

        if qos not in (0, 1, 2):
            raise ValueError(f"Invalid QoS value: {qos}. Must be 0, 1, or 2")

        if self.is_connected:
            raise RuntimeError(
                "Cannot set will message after connection. Call set_will() before connect()"
            )

        # 处理 payload
        if isinstance(payload, dict):
            payload_bytes = json.dumps(payload).encode("utf-8")
        elif isinstance(payload, str):
            payload_bytes = payload.encode("utf-8")
        elif isinstance(payload, bytes):
            payload_bytes = payload
        elif payload is None:
            payload_bytes = b""
        else:
            raise ValueError(f"Unsupported payload type: {type(payload)}")

        # 调用底层 paho.mqtt 的 will_set
        self._paho_client.will_set(topic=topic, payload=payload_bytes, qos=qos, retain=retain)

        logger.info(f"Will message set: topic={topic}, qos={qos}, retain={retain}")

    def connect(self, timeout: Optional[float] = None) -> bool:
        """连接到 MQTT broker

        Connect to MQTT broker

        Args:
            timeout: 连接超时(秒) / Connection timeout (seconds)

        Returns:
            是否成功连接 / Whether connection succeeded

        Raises:
            MQTTConnectionError: 连接失败时抛出
        """
        success = self._connection.connect(timeout)

        if success:
            # 订阅所有处理器的 topics
            self._subscribe_all_handlers()

        return success

    def disconnect(self, timeout: float = 5.0) -> bool:
        """断开连接

        Disconnect from MQTT broker

        Args:
            timeout: 断开超时(秒) / Disconnect timeout (seconds)

        Returns:
            是否成功断开 / Whether disconnection succeeded
        """
        return self._connection.disconnect(timeout)

    # ========== 处理器管理 ==========

    def register_handler(self, handler: MessageHandler) -> None:
        """注册消息处理器

        Register message handler

        Args:
            handler: 消息处理器实例 / Message handler instance
        """
        self._router.register_handler(handler)

        # 如果已连接，订阅新处理器的 topics
        if self.is_connected:
            for topic in handler.topics:
                self._subscribe_topic(topic, handler.qos)

    def unregister_handler(self, handler: MessageHandler) -> bool:
        """注销消息处理器

        Unregister message handler

        Args:
            handler: 消息处理器实例 / Message handler instance

        Returns:
            是否成功注销 / Whether unregistration succeeded
        """
        return self._router.unregister_handler(handler)

    def get_handlers(self) -> List[MessageHandler]:
        """获取所有已注册的处理器

        Get all registered handlers

        Returns:
            处理器列表 / List of handlers
        """
        return self._router.get_handlers()

    def _subscribe_all_handlers(self) -> None:
        """订阅所有处理器的 topics

        Subscribe all handler topics
        """
        topics = self._router.get_subscribed_topics()
        for topic in topics:
            self._subscribe_topic(topic, qos=1)

        logger.info(f"Subscribed to {len(topics)} topic(s)")

    def _subscribe_topic(self, topic: str, qos: int = 1) -> None:
        """订阅单个 topic

        Subscribe to single topic

        Args:
            topic: Topic 字符串 / Topic string
            qos: QoS 等级 / QoS level
        """
        full_topic = self._config.get_full_topic(topic)
        result, mid = self._paho_client.subscribe(full_topic, qos)

        if result == mqtt_client.MQTT_ERR_SUCCESS:
            logger.debug(f"Subscribed: {full_topic} (QoS {qos})")
        else:
            logger.error(f"Subscribe failed: {full_topic} (rc={result})")

    # ========== 订阅/发布 ==========

    def subscribe(self, topic: str, qos: int = 1) -> None:
        """订阅 topic

        Subscribe to topic

        Args:
            topic: Topic 字符串 / Topic string
            qos: QoS 等级 / QoS level
        """
        self._subscribe_topic(topic, qos)

    def unsubscribe(self, topic: str) -> None:
        """取消订阅 topic

        Unsubscribe from topic

        Args:
            topic: Topic 字符串 / Topic string
        """
        full_topic = self._config.get_full_topic(topic)
        result, mid = self._paho_client.unsubscribe(full_topic)

        if result == mqtt_client.MQTT_ERR_SUCCESS:
            logger.debug(f"Unsubscribed: {full_topic}")
        else:
            logger.error(f"Unsubscribe failed: {full_topic} (rc={result})")

    def publish(
        self, topic: str, payload: Dict[str, Any], qos: int = 1, retain: bool = False
    ) -> bool:
        """发布消息

        Publish message

        Args:
            topic: Topic 字符串 / Topic string
            payload: 消息负载（字典）/ Message payload (dict)
            qos: QoS 等级 / QoS level
            retain: 是否保留消息 / Retain flag

        Returns:
            是否成功发布 / Whether publish succeeded
        """
        return self._publisher.publish(topic, payload, qos, retain)

    def publish_async(
        self,
        topic: str,
        payload: Dict[str, Any],
        callback: Optional[Callable[[bool, str], None]] = None,
        qos: int = 1,
        retain: bool = False,
    ) -> None:
        """异步发布消息

        Asynchronous message publish

        Args:
            topic: Topic 字符串 / Topic string
            payload: 消息负载 / Message payload
            callback: 回调函数 callback(success, topic)
            qos: QoS 等级 / QoS level
            retain: 是否保留消息 / Retain flag
        """
        self._publisher.publish_async(topic, payload, callback, qos, retain)

    # ========== 状态查询 ==========

    @property
    def is_connected(self) -> bool:
        """是否已连接

        Whether connected
        """
        return self._connection.is_connected

    @property
    def state(self) -> ConnectionState:
        """连接状态

        Connection state
        """
        return self._connection.state

    def get_status(self) -> Dict[str, Any]:
        """获取客户端完整状态

        Get client full status

        Returns:
            状态字典 / Status dictionary
        """
        return {
            "client_id": self._config.client_id,
            "broker": self._config.get_broker_url(),
            "connection": self._connection.get_stats(),
            "router": self._router.get_stats(),
            "publisher": self._publisher.get_stats(),
        }

    # ========== 上下文管理器 ==========

    def __enter__(self) -> MQTTClient:
        """进入上下文

        Enter context
        """
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文

        Exit context
        """
        self.disconnect()

    def __repr__(self) -> str:
        """字符串表示

        String representation
        """
        return (
            f"MQTTClient("
            f"client_id='{self._config.client_id}', "
            f"broker='{self._config.broker}:{self._config.port}', "
            f"state={self.state.value})"
        )
