"""MQTT 消息发布器

消息发布器 / Message publisher
"""

from __future__ import annotations

import json
import logging
import queue
import threading
from typing import Any, Callable, Dict, List, Optional

from .exceptions import MQTTPublishError
from .message import Message
from .utils import validate_publish_topic

logger = logging.getLogger(__name__)


class Publisher:
    """消息发布器

    封装消息发布逻辑，支持:
    - 同步发布
    - 异步发布（带回调）
    - 批量发布
    - 离线消息队列（断线时缓存）

    Message publisher supporting:
    - Synchronous publish
    - Asynchronous publish with callback
    - Batch publish
    - Offline message queue

    Args:
        mqtt_client: paho.mqtt.Client 实例 / paho.mqtt.Client instance
        topic_prefix: Topic 前缀 / Topic prefix
    """

    def __init__(self, mqtt_client, topic_prefix: str = ""):
        """初始化发布器

        Args:
            mqtt_client: paho.mqtt.Client 实例
            topic_prefix: Topic 前缀
        """
        self._client = mqtt_client
        self._topic_prefix = topic_prefix
        self._offline_queue: Optional[queue.Queue] = None
        self._offline_queue_enabled = False
        self._offline_queue_max_size = 100
        self._lock = threading.RLock()
        self._publish_count = 0
        self._error_count = 0

    def enable_offline_queue(self, max_size: int = 100) -> None:
        """启用离线消息队列

        Enable offline message queue

        当 MQTT 断开连接时，消息会被缓存到队列中，
        连接恢复后自动发送。

        Args:
            max_size: 队列最大大小 / Maximum queue size
        """
        with self._lock:
            self._offline_queue = queue.Queue(maxsize=max_size)
            self._offline_queue_enabled = True
            self._offline_queue_max_size = max_size
            logger.info(f"Offline queue enabled with max_size={max_size}")

    def disable_offline_queue(self) -> None:
        """禁用离线消息队列

        Disable offline message queue
        """
        with self._lock:
            self._offline_queue_enabled = False
            if self._offline_queue:
                queue_size = self._offline_queue.qsize()
                self._offline_queue = None
                logger.info(f"Offline queue disabled, {queue_size} messages discarded")

    def publish(
        self, topic: str, payload: Dict[str, Any], qos: int = 1, retain: bool = False
    ) -> bool:
        """同步发布消息

        Synchronous message publish

        Args:
            topic: MQTT topic
            payload: 消息负载（字典）/ Message payload (dict)
            qos: QoS 等级 / QoS level
            retain: 是否保留消息 / Retain flag

        Returns:
            是否成功发布 / Whether publish succeeded

        Raises:
            MQTTPublishError: 发布失败时抛出
        """
        # 创建 Message 对象
        message = Message(topic=topic, payload=payload, qos=qos, retain=retain)

        return self.publish_message(message)

    def publish_message(self, message: Message) -> bool:
        """发布 Message 对象

        Publish Message object

        Args:
            message: Message 对象 / Message object

        Returns:
            是否成功发布 / Whether publish succeeded

        Raises:
            MQTTPublishError: 发布失败时抛出
        """
        # 验证 topic
        if not validate_publish_topic(message.topic):
            raise MQTTPublishError(f"Invalid publish topic: {message.topic}")

        # 添加前缀
        full_topic = self._get_full_topic(message.topic)

        # 序列化 payload
        try:
            payload_str = json.dumps(message.payload, ensure_ascii=False)
        except (TypeError, ValueError) as e:
            raise MQTTPublishError(f"Failed to serialize payload: {e}")

        # 尝试发布
        try:
            result = self._client.publish(
                topic=full_topic, payload=payload_str, qos=message.qos, retain=message.retain
            )

            # 检查发布结果
            if result.rc == 0:  # paho.mqtt.MQTT_ERR_SUCCESS
                with self._lock:
                    self._publish_count += 1
                logger.debug(f"Published message: topic={full_topic}, id={message.message_id}")
                return True
            else:
                raise MQTTPublishError(f"Publish failed with rc={result.rc}")

        except Exception as e:
            with self._lock:
                self._error_count += 1

            # 尝试加入离线队列
            if self._offline_queue_enabled and self._offline_queue:
                try:
                    self._offline_queue.put_nowait(message)
                    logger.warning(
                        f"Message queued to offline queue: topic={full_topic}, "
                        f"queue_size={self._offline_queue.qsize()}"
                    )
                    return False
                except queue.Full:
                    logger.error(
                        f"Offline queue is full ({self._offline_queue_max_size}), "
                        f"message discarded: topic={full_topic}"
                    )

            raise MQTTPublishError(f"Failed to publish message: {e}") from e

    def publish_async(
        self,
        topic: str,
        payload: Dict[str, Any],
        callback: Optional[Callable[[bool, str], None]] = None,
        qos: int = 1,
        retain: bool = False,
    ) -> None:
        """异步发布消息

        Asynchronous message publish

        Args:
            topic: MQTT topic
            payload: 消息负载 / Message payload
            callback: 回调函数 callback(success: bool, topic: str)
            qos: QoS 等级 / QoS level
            retain: 是否保留消息 / Retain flag
        """

        def _publish_thread():
            try:
                success = self.publish(topic, payload, qos, retain)
                if callback:
                    callback(success, topic)
            except Exception as e:
                logger.error(f"Async publish error: {e}")
                if callback:
                    callback(False, topic)

        thread = threading.Thread(target=_publish_thread, daemon=True)
        thread.start()

    def publish_batch(self, messages: List[Message]) -> Dict[str, bool]:
        """批量发布消息

        Batch publish messages

        Args:
            messages: Message 对象列表 / List of Message objects

        Returns:
            {topic: success} 字典 / Dictionary of {topic: success}
        """
        results = {}

        for message in messages:
            try:
                success = self.publish_message(message)
                results[message.topic] = success
            except MQTTPublishError as e:
                logger.error(f"Batch publish error for topic {message.topic}: {e}")
                results[message.topic] = False

        logger.info(f"Batch publish completed: {sum(results.values())}/{len(messages)} succeeded")

        return results

    def flush_offline_queue(self) -> int:
        """发送离线队列中的所有消息

        Flush all messages in offline queue

        Returns:
            成功发送的消息数量 / Number of successfully sent messages
        """
        if not self._offline_queue:
            return 0

        success_count = 0
        failed_messages = []

        while not self._offline_queue.empty():
            try:
                message = self._offline_queue.get_nowait()
                if self.publish_message(message):
                    success_count += 1
                else:
                    failed_messages.append(message)
            except queue.Empty:
                break
            except Exception as e:
                logger.error(f"Error flushing offline queue: {e}")

        # 重新加入失败的消息
        for msg in failed_messages:
            try:
                self._offline_queue.put_nowait(msg)
            except queue.Full:
                logger.error(f"Failed to re-queue message: {msg.topic}")

        logger.info(
            f"Flushed offline queue: {success_count} sent, " f"{len(failed_messages)} failed"
        )

        return success_count

    def _get_full_topic(self, topic: str) -> str:
        """获取带前缀的完整 topic

        Get full topic with prefix

        Args:
            topic: 原始 topic / Original topic

        Returns:
            完整 topic / Full topic with prefix
        """
        if not self._topic_prefix:
            return topic

        # 避免重复添加前缀
        if topic.startswith(self._topic_prefix):
            return topic

        # 处理连接
        if self._topic_prefix.endswith("/") or topic.startswith("/"):
            return f"{self._topic_prefix}{topic}"
        else:
            return f"{self._topic_prefix}/{topic}"

    def get_stats(self) -> dict:
        """获取发布器统计信息

        Get publisher statistics

        Returns:
            统计信息字典 / Statistics dictionary
        """
        with self._lock:
            stats = {
                "publish_count": self._publish_count,
                "error_count": self._error_count,
                "offline_queue_enabled": self._offline_queue_enabled,
            }

            if self._offline_queue:
                stats["offline_queue_size"] = self._offline_queue.qsize()
                stats["offline_queue_max_size"] = self._offline_queue_max_size

            return stats

    def reset_stats(self) -> None:
        """重置统计计数器

        Reset statistics counters
        """
        with self._lock:
            self._publish_count = 0
            self._error_count = 0
            logger.info("Publisher statistics reset")
