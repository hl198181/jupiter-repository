"""MQTT 消息处理器抽象基类

消息处理器 / Message handler abstract base class
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import List, Optional

from .message import Message
from .utils import topic_matches

logger = logging.getLogger(__name__)


class MessageHandler(ABC):
    """消息处理器抽象基类

    实现策略模式，定义消息处理接口。
    Abstract base class for message handlers implementing Strategy pattern.

    子类需要实现:
    - handle(message): 处理消息的核心逻辑

    可选重写:
    - on_error(exception, message): 错误处理逻辑

    Attributes:
        topics: 订阅的 topic 列表（支持通配符）/ Topics to subscribe (wildcards supported)
        qos: QoS 等级 / QoS level
        enabled: 是否启用 / Enable flag
        shared_group: 共享订阅组名 / Shared subscription group name
    """

    def __init__(
        self,
        topics: List[str],
        qos: int = 1,
        enabled: bool = True,
        shared_group: Optional[str] = None,
    ):
        """初始化处理器

        Args:
            topics: 订阅的 topic 列表 / List of topics to subscribe
            qos: QoS 等级 (0, 1, 2) / QoS level
            enabled: 是否启用 / Enable flag
            shared_group: 共享订阅组名，用于负载均衡 / Shared subscription group name for load balancing
                格式: $share/<group_name>/<topic>
                多个客户端使用相同的 group_name 可实现消息负载均衡
                需要 broker 支持（MQTT 5.0 或 MQTT 3.1.1 扩展）
        """
        self.topics = topics
        self.qos = qos
        self.enabled = enabled
        self.shared_group = shared_group
        self._processed_count = 0
        self._error_count = 0

    @abstractmethod
    def handle(self, message: Message) -> None:
        """处理消息（子类必须实现）

        Handle message (must be implemented by subclass)

        Args:
            message: MQTT 消息 / MQTT message

        Raises:
            NotImplementedError: 如果子类未实现
        """
        raise NotImplementedError("Subclass must implement handle() method")

    def on_error(self, exception: Exception, message: Message) -> None:
        """错误处理（子类可选重写）

        Handle error (optional override)

        默认行为: 记录错误日志
        Default behavior: Log error

        Args:
            exception: 异常对象 / Exception object
            message: 导致错误的消息 / Message that caused error
        """
        logger.error(
            f"Error in {self.__class__.__name__}.handle(): {exception}",
            exc_info=True,
            extra={"topic": message.topic, "message_id": message.message_id},
        )

    def get_subscription_topics(self) -> List[str]:
        """获取实际订阅的 topics（包含共享订阅格式）

        Get actual subscription topics (with shared subscription format if applicable)

        Returns:
            订阅 topic 列表 / List of subscription topics
            如果设置了 shared_group，格式为 $share/{group}/{topic}
            If shared_group is set, format is $share/{group}/{topic}
        """
        if self.shared_group:
            return [f"$share/{self.shared_group}/{topic}" for topic in self.topics]
        return self.topics

    def match_topic(self, topic: str) -> bool:
        """检查 topic 是否匹配处理器的订阅列表

        Check if topic matches handler's subscription list

        Args:
            topic: 要检查的 topic / Topic to check

        Returns:
            是否匹配 / Whether topic matches
        """
        for pattern in self.topics:
            if topic_matches(topic, pattern):
                return True
        return False

    def process(self, message: Message) -> bool:
        """处理消息（带错误处理和统计）

        Process message with error handling and statistics

        Args:
            message: MQTT 消息 / MQTT message

        Returns:
            处理是否成功 / Whether processing succeeded
        """
        if not self.enabled:
            logger.debug(f"{self.__class__.__name__} is disabled, skipping message")
            return False

        if not self.match_topic(message.topic):
            logger.debug(
                f"{self.__class__.__name__} topic mismatch: "
                f"{message.topic} not in {self.topics}"
            )
            return False

        try:
            self.handle(message)
            self._processed_count += 1
            logger.debug(
                f"{self.__class__.__name__} processed message: "
                f"topic={message.topic}, id={message.message_id}"
            )
            return True
        except Exception as e:
            self._error_count += 1
            self.on_error(e, message)
            return False

    def enable(self) -> None:
        """启用处理器 / Enable handler"""
        self.enabled = True
        logger.info(f"{self.__class__.__name__} enabled")

    def disable(self) -> None:
        """禁用处理器 / Disable handler"""
        self.enabled = False
        logger.info(f"{self.__class__.__name__} disabled")

    def get_stats(self) -> dict:
        """获取处理器统计信息

        Get handler statistics

        Returns:
            统计信息字典 / Statistics dictionary
        """
        return {
            "handler": self.__class__.__name__,
            "enabled": self.enabled,
            "topics": self.topics,
            "processed_count": self._processed_count,
            "error_count": self._error_count,
        }

    def reset_stats(self) -> None:
        """重置统计计数器 / Reset statistics counters"""
        self._processed_count = 0
        self._error_count = 0

    def __repr__(self) -> str:
        """字符串表示 / String representation"""
        return (
            f"{self.__class__.__name__}("
            f"topics={self.topics}, "
            f"qos={self.qos}, "
            f"enabled={self.enabled})"
        )
