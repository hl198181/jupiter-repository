"""MQTT 配置模型

配置模型 / Configuration models using Pydantic
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from pydantic import BaseModel, Field, field_validator
except ImportError:
    raise ImportError(
        "Pydantic is required for MQTT module. " "Install it with: pip install pydantic>=2.0.0"
    )


class ConnectionConfig(BaseModel):
    """连接配置

    Connection configuration for MQTT client

    Attributes:
        auto_reconnect: 是否自动重连 / Auto reconnect flag
        reconnect_delay_min: 最小重连延迟(秒) / Min reconnect delay (seconds)
        reconnect_delay_max: 最大重连延迟(秒) / Max reconnect delay (seconds)
        reconnect_exponential_backoff: 是否使用指数退避 / Use exponential backoff
        max_reconnect_attempts: 最大重连次数 (-1 表示无限制) / Max reconnect attempts
        connect_timeout: 连接超时(秒) / Connection timeout (seconds)
        keepalive: 保持连接间隔(秒) / Keepalive interval (seconds)
        health_check_interval: 健康检查间隔(秒) / Health check interval (seconds)
        ping_timeout: Ping 超时(秒) / Ping timeout (seconds)
    """

    auto_reconnect: bool = True
    reconnect_delay_min: float = 1.0
    reconnect_delay_max: float = 60.0
    reconnect_exponential_backoff: bool = True
    max_reconnect_attempts: int = -1
    connect_timeout: float = 10.0
    keepalive: int = 60
    health_check_interval: float = 30.0
    ping_timeout: float = 5.0

    @field_validator("reconnect_delay_min", "reconnect_delay_max")
    @classmethod
    def validate_delay(cls, v: float) -> float:
        """验证延迟时间必须大于 0"""
        if v <= 0:
            raise ValueError("Delay must be greater than 0")
        return v

    @field_validator("keepalive")
    @classmethod
    def validate_keepalive(cls, v: int) -> int:
        """验证 keepalive 必须大于 0"""
        if v <= 0:
            raise ValueError("Keepalive must be greater than 0")
        return v


class TLSConfig(BaseModel):
    """TLS/SSL 配置

    TLS/SSL configuration

    Attributes:
        enabled: 是否启用 TLS / Enable TLS
        ca_certs: CA 证书路径 / CA certificate path
        certfile: 客户端证书路径 / Client certificate path
        keyfile: 客户端密钥路径 / Client key path
        cert_reqs: 证书要求级别 / Certificate requirements level
        tls_version: TLS 版本 / TLS version
        ciphers: 加密套件 / Cipher suites
    """

    enabled: bool = False
    ca_certs: Optional[str] = None
    certfile: Optional[str] = None
    keyfile: Optional[str] = None
    cert_reqs: Optional[str] = None
    tls_version: Optional[str] = None
    ciphers: Optional[str] = None


class HandlerConfig(BaseModel):
    """处理器配置

    Handler configuration

    Attributes:
        type: 处理器类型名称 / Handler type name
        topics: 订阅的 topic 列表 / List of topics to subscribe
        qos: QoS 等级 / QoS level
        params: 处理器特定参数 / Handler-specific parameters
    """

    type: str
    topics: List[str]
    qos: int = 1
    params: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("qos")
    @classmethod
    def validate_qos(cls, v: int) -> int:
        """验证 QoS 必须是 0, 1, 2"""
        if v not in (0, 1, 2):
            raise ValueError("QoS must be 0, 1, or 2")
        return v

    @field_validator("topics")
    @classmethod
    def validate_topics(cls, v: List[str]) -> List[str]:
        """验证 topics 不能为空"""
        if not v:
            raise ValueError("Topics list cannot be empty")
        return v


class MQTTConfig(BaseModel):
    """MQTT 主配置

    Main MQTT configuration

    Attributes:
        broker: MQTT broker 地址 (格式: mqtt://host:port) / MQTT broker URL
        client_id: 客户端 ID / Client ID (auto-generated if None)
        clean_session: 是否使用 clean session / Clean session flag
        username: 用户名 / Username
        password: 密码 / Password
        tls: TLS 配置 / TLS configuration
        topic_prefix: Topic 前缀 / Topic prefix
        connection: 连接配置 / Connection configuration
        handlers: 处理器配置列表 / List of handler configurations
    """

    broker: str
    port: int = 1883
    client_id: Optional[str] = None
    clean_session: bool = True
    username: Optional[str] = None
    password: Optional[str] = None
    tls: Optional[TLSConfig] = None
    topic_prefix: str = ""
    connection: ConnectionConfig = Field(default_factory=ConnectionConfig)
    handlers: List[HandlerConfig] = Field(default_factory=list)

    @field_validator("broker")
    @classmethod
    def validate_broker(cls, v: str) -> str:
        """验证 broker 地址格式"""
        if not v:
            raise ValueError("Broker address cannot be empty")
        return v

    @field_validator("port")
    @classmethod
    def validate_port(cls, v: int) -> int:
        """验证端口范围"""
        if not (1 <= v <= 65535):
            raise ValueError("Port must be between 1 and 65535")
        return v

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> MQTTConfig:
        """从字典创建配置

        Create configuration from dictionary

        Args:
            config_dict: 配置字典 / Configuration dictionary

        Returns:
            MQTTConfig 实例 / MQTTConfig instance
        """
        # 解析 broker URL 格式 (mqtt://host:port)
        broker = config_dict.get("broker", "")
        if broker.startswith("mqtt://"):
            broker = broker[7:]  # 移除 mqtt:// 前缀

        if ":" in broker:
            host, port_str = broker.rsplit(":", 1)
            config_dict["broker"] = host
            config_dict["port"] = int(port_str)
        else:
            config_dict["broker"] = broker

        return cls(**config_dict)

    def get_broker_url(self) -> str:
        """获取完整的 broker URL

        Get full broker URL

        Returns:
            Broker URL (格式: mqtt://host:port)
        """
        return f"mqtt://{self.broker}:{self.port}"

    def get_full_topic(self, topic: str) -> str:
        """获取带前缀的完整 topic

        Get full topic with prefix

        Args:
            topic: 原始 topic / Original topic

        Returns:
            完整 topic / Full topic with prefix
        """
        if not self.topic_prefix:
            return topic

        # 确保不会重复添加前缀
        if topic.startswith(self.topic_prefix):
            return topic

        # 处理前缀和 topic 的连接
        if self.topic_prefix.endswith("/") or topic.startswith("/"):
            return f"{self.topic_prefix}{topic}"
        else:
            return f"{self.topic_prefix}/{topic}"

    class Config:
        """Pydantic 配置"""

        validate_assignment = True
