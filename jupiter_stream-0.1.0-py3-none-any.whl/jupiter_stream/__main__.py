"""Jupiter Stream 命令行入口 / Jupiter Stream CLI Entry Point

使用新架构的配置运行器。
Uses the new architecture for configuration-based running.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .core.pipeline import Pipeline


def setup_logging(verbose: bool = False):
    """设置日志配置 / Setup logging configuration

    Args:
        verbose: 是否启用详细日志 / Enable verbose logging
    """
    level = logging.DEBUG if verbose else logging.INFO
    format_str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    logging.basicConfig(
        level=level, format=format_str, handlers=[logging.StreamHandler(sys.stdout)]
    )


def list_components():
    """列出所有已注册的组件 / List all registered components"""
    from .core.pipeline.registry import registry

    print("\n=== Registered Components ===\n")

    # Sources
    sources = registry.list_sources()
    if sources:
        print("Sources:")
        for name in sources:
            print(f"  - {name}")
    else:
        print("Sources: None")

    print()

    # Processors
    processors = registry.list_processors()
    if processors:
        print("Processors:")
        for name in processors:
            print(f"  - {name}")
    else:
        print("Processors: None")

    print()

    # Sinks
    sinks = registry.list_sinks()
    if sinks:
        print("Sinks:")
        for name in sinks:
            print(f"  - {name}")
    else:
        print("Sinks: None")

    print()

    # Templates
    templates = registry.list_templates()
    if templates:
        print("Templates:")
        for name in templates:
            print(f"  - {name}")
    else:
        print("Templates: None")

    print()


def validate_config(config_path: Path) -> bool:
    """验证配置文件 / Validate configuration file

    Args:
        config_path: 配置文件路径 / Configuration file path

    Returns:
        是否有效 / Whether valid
    """
    from .loaders import AutoConfigLoader

    try:
        loader = AutoConfigLoader()
        config = loader.load(config_path)
        print(f"✓ Configuration file is valid: {config_path}")

        # 显示配置摘要
        print("\n=== Configuration Summary ===")
        print(f"Source: {config.get('source', {}).get('type', 'None')}")

        processors = config.get("processors", [])
        if processors:
            print(f"Processors ({len(processors)}):")
            for proc in processors:
                print(f"  - {proc.get('type', 'Unknown')}")
        else:
            print("Processors: None")

        sinks = config.get("sinks", [])
        if sinks:
            print(f"Sinks ({len(sinks)}):")
            for sink in sinks:
                print(f"  - {sink.get('type', 'Unknown')}")
        else:
            print("Sinks: None")

        if "pipeline" in config:
            print(f"Pipeline FPS: {config['pipeline'].get('fps', 'Not set')}")

        return True

    except FileNotFoundError:
        print(f"✗ File not found: {config_path}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"✗ Invalid configuration: {e}", file=sys.stderr)
        return False


def run_pipeline(config_path: Path, verbose: bool = False):
    """运行 Pipeline / Run Pipeline

    Args:
        config_path: 配置文件路径 / Configuration file path
        verbose: 是否显示详细日志 / Show verbose logging
    """
    logger = logging.getLogger(__name__)

    try:
        # 使用新的 from_config API
        logger.info(f"Loading configuration from {config_path}")
        pipeline = Pipeline.from_config(config_path)

        # 显示 Pipeline 信息
        logger.info(f"Pipeline created: {pipeline}")

        # 运行 Pipeline
        logger.info("Starting pipeline...")
        pipeline.run()

        # 显示统计信息
        stats = pipeline.get_stats()
        print("\n=== Pipeline Statistics ===")
        print(f"Frames processed: {stats['frame_count']}")
        print(f"Errors: {stats['error_count']}")
        print(f"Elapsed time: {stats['elapsed_time']:.2f}s")
        print(f"Average FPS: {stats['current_fps']:.2f}")

    except KeyboardInterrupt:
        logger.info("Pipeline interrupted by user")
    except Exception as e:
        logger.error(f"Pipeline execution failed: {e}", exc_info=verbose)
        sys.exit(1)


def main():
    """主函数 / Main function"""
    parser = argparse.ArgumentParser(
        prog="jupiter-stream",
        description="Jupiter Stream - Video/Image Stream Processing Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run with configuration file
  python -m jupiter_stream config.yaml

  # Validate configuration
  python -m jupiter_stream --validate config.yaml

  # List available components
  python -m jupiter_stream --list

  # Run with verbose logging
  python -m jupiter_stream -v config.yaml
        """,
    )

    parser.add_argument("config", nargs="?", help="Configuration file path (YAML/JSON)")

    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")

    parser.add_argument(
        "--validate", action="store_true", help="Validate configuration file without running"
    )

    parser.add_argument("--list", action="store_true", help="List all registered components")

    args = parser.parse_args()

    # 设置日志
    setup_logging(args.verbose)

    # 列出组件
    if args.list:
        list_components()
        return

    # 检查配置文件参数
    if not args.config:
        parser.print_help()
        sys.exit(1)

    config_path = Path(args.config)

    # 验证配置
    if args.validate:
        success = validate_config(config_path)
        sys.exit(0 if success else 1)

    # 运行 Pipeline
    run_pipeline(config_path, args.verbose)


if __name__ == "__main__":
    main()
