"""Object detection processors using YOLO models."""

from __future__ import annotations

import threading
import time
from typing import List, Optional, Tuple

from ..core import Frame, Processor
from ..core.pipeline.registry import register_processor
from .cuda_manager import CUDAManager
from .model_loader import resolve_model

# 全局锁：确保 YOLO 模型加载是线程安全的
# 多个 YOLODetector 实例在多线程环境下同时加载模型会导致 CUDA 初始化竞态条件
_model_load_lock = threading.Lock()


@register_processor("YOLODetector")
class YOLODetector(Processor):
    """
    YOLO 目标检测处理器
    YOLODetector - Object Detection Processor using YOLO models

    使用 Ultralytics YOLOv11 进行实时目标检测，支持完整的参数配置。
    Performs real-time object detection using Ultralytics YOLOv11 with full parameter configuration.

    Features:
        - 支持多种 YOLO 模型 (yolo11n/s/m/l/x)
        - 可配置置信度和 IoU 阈值
        - 类别过滤支持
        - CPU/GPU 自动检测
        - 可选的边界框可视化
        - 检测结果保存到 frame.metadata

    Examples:
        >>> # 基础使用
        >>> detector = YOLODetector(model="yolo11n.pt")
        >>> processed = detector(frame)

        >>> # 高级配置
        >>> detector = YOLODetector(
        ...     model="yolo11m.pt",
        ...     conf=0.3,
        ...     classes=[0, 2, 5],  # 只检测人、车、公交
        ...     device="0",
        ...     draw_boxes=True
        ... )

        >>> # 访问检测结果
        >>> detections = frame.metadata['detections']
        >>> print(f"检测到 {detections['count']} 个目标")
        >>> for obj in detections['objects']:
        ...     print(f"{obj['class_name']}: {obj['confidence']:.2f}")
    """

    def __init__(
        self,
        model: str = "yolo11n.pt",
        conf: float = 0.25,
        iou: float = 0.7,
        device: Optional[str] = None,
        classes: Optional[List[int]] = None,
        max_det: int = 300,
        imgsz: int = 640,
        half: bool = False,
        draw_boxes: bool = True,
        draw_labels: bool = True,
        box_color: Tuple[int, int, int] = (0, 255, 0),
        text_color: Tuple[int, int, int] = (255, 255, 255),
        label_bg_color: Tuple[int, int, int] = (0, 0, 0),
        thickness: int = 2,
        font_scale: float = 0.5,
        enabled: bool = True,
    ):
        """
        初始化 YOLO 检测器

        Args:
            model: 模型路径或名称 (如 "yolo11n.pt", "yolo11m.pt" 或自定义路径)
            conf: 置信度阈值，低于此值的检测将被过滤 (默认 0.25)
            iou: NMS IoU 阈值，用于过滤重叠框 (默认 0.7)
            device: [已废弃] 此参数已被忽略，设备根据硬件自动检测
            classes: 类别ID列表，仅检测指定类别 (None=所有类别)
            max_det: 每张图片最大检测数量 (默认 300)
            imgsz: 推理图像大小 (默认 640)
            half: 是否使用 FP16 半精度推理 (需 GPU 支持)
            draw_boxes: 是否在帧上绘制边界框
            draw_labels: 是否绘制标签和置信度
            box_color: 边界框颜色 (B, G, R)
            text_color: 文本颜色 (B, G, R)
            label_bg_color: 标签背景颜色 (B, G, R)
            thickness: 边界框线条粗细
            font_scale: 字体大小
            enabled: 是否启用处理器

        Raises:
            ImportError: 如果未安装 ultralytics
            FileNotFoundError: 如果自定义模型文件不存在
        """
        super().__init__(enabled)

        # 检查 ultralytics 是否安装
        import importlib.util

        if importlib.util.find_spec("ultralytics") is None:
            raise ImportError(
                "Ultralytics YOLO is required for YOLODetector. "
                "Install with: pip install ultralytics"
            )

        # 解析模型路径
        # - URI (http://, s3://, etc.) -> 通过注册的加载器解析
        # - 本地路径 (/path/to/model.pt) -> 本地加载器
        # - 预训练模型名称 (yolo11n.pt) -> ultralytics 自动下载
        resolved_model = self._resolve_model_path(model)

        # 保存配置
        self.model_name = resolved_model
        self.conf = conf
        self.iou = iou
        self.classes = classes
        self.max_det = max_det
        self.imgsz = imgsz
        self.half = half
        self.draw_boxes = draw_boxes
        self.draw_labels = draw_labels
        self.box_color = box_color
        self.text_color = text_color
        self.label_bg_color = label_bg_color
        self.thickness = thickness
        self.font_scale = font_scale

        # 立即加载模型（在主线程中），避免多线程 CUDA 初始化问题
        self._model = None
        self._model_loaded = False
        self._cuda_manager = None


        # 设备自动检测（忽略 device 参数，平台硬件固定）
        if device is not None:
            self.logger.warning(
                f"device parameter '{device}' is ignored. "
                "Device is auto-detected based on hardware availability."
            )

        try:
            import torch

            self.device = "0" if torch.cuda.is_available() else "cpu"
        except ImportError:
            self.device = "cpu"

        # 立即加载模型（关键：在主线程中完成）
        self._load_model_immediate()

        self.logger.info(f"YOLODetector initialized with model: {model}, device: {self.device}")

    def _load_model_immediate(self):
        """
        立即加载 YOLO 模型（在主线程中调用）

        关键：模型必须在主线程中加载并移动到 GPU，
        这样多线程推理时才不会出现 CUDA 上下文竞争。
        """
        if self._model_loaded:
            return

        # 使用全局锁保护，确保多个 YOLODetector 串行加载
        with _model_load_lock:
            if self._model_loaded:
                return

            try:
                from ultralytics import YOLO

                # 只在非 CPU 模式下获取 CUDA 管理器（单例）
                if str(self.device) != "cpu":
                    self._cuda_manager = CUDAManager()
                else:
                    self._cuda_manager = None

                self.logger.info(f"Loading YOLO model: {self.model_name}...")
                self._model = YOLO(self.model_name)

                # 关键：使用 .to() 将模型移动到 GPU（而不是在 predict 时指定 device）
                # 这确保 CUDA 上下文在主线程中初始化
                if str(self.device) != "cpu":
                    device_str = str(self.device)
                    device_id = int(device_str) if device_str.isdigit() else 0
                    self.logger.info(f"Moving model to GPU device: {device_id}...")
                    self._model.to(device_id)

                    # 预热模型
                    self.logger.info("Warming up model...")
                    import numpy as np

                    dummy_input = np.zeros((640, 640, 3), dtype=np.uint8)
                    self._model.predict(source=dummy_input, verbose=False)

                self.logger.info(f"Model loaded successfully on device: {self.device}")
                self._model_loaded = True

            except Exception as e:
                self.logger.error(f"Failed to load YOLO model: {e}")
                raise

    def _load_model(self):
        """兼容旧接口，调用立即加载"""
        self._load_model_immediate()

    def _resolve_model_path(self, model: str) -> str:
        """
        解析模型路径

        根据模型路径格式决定如何加载：
        - URI (http://, https://, s3://, etc.) -> 通过注册的加载器下载
        - 本地绝对/相对路径 -> 本地加载器验证存在性
        - 预训练模型名称 (yolo11n.pt) -> 保持原样，由 ultralytics 自动下载

        Args:
            model: 模型路径、URI 或预训练模型名称

        Returns:
            解析后的本地模型路径（字符串）

        Raises:
            ValueError: 未注册对应协议的加载器
            FileNotFoundError: 本地模型文件不存在
        """
        # 检查是否为 URI（包含协议）
        if "://" in model:
            # 使用模型加载器解析 URI
            resolved_path = resolve_model(model)
            self.logger.info(f"Resolved model URI '{model}' to '{resolved_path}'")
            return str(resolved_path)

        # 检查是否为本地路径（包含路径分隔符）
        if "/" in model or "\\" in model:
            # 使用本地加载器验证文件存在
            resolved_path = resolve_model(model)
            return str(resolved_path)

        # 预训练模型名称（如 yolo11n.pt），由 ultralytics 自动处理
        # 不做任何处理，直接返回
        return model

    def process(self, frame: Frame) -> Frame:
        """
        处理单帧，执行目标检测

        Args:
            frame: 输入帧

        Returns:
            处理后的帧，检测结果保存在 frame.metadata['detections']
        """
        # 确保模型已加载
        if not self._model_loaded:
            self._load_model()

        # 记录推理开始时间
        start_time = time.time()

        try:
            # 构建推理参数
            predict_kwargs = {
                "source": frame.image,
                "conf": self.conf,
                "iou": self.iou,
                "classes": self.classes,
                "max_det": self.max_det,
                "imgsz": self.imgsz,
                "half": self.half,
                "verbose": False,  # 禁用控制台输出
            }

            # CPU 模式需要显式指定 device，GPU 模式不需要（已通过 .to() 设置）
            if str(self.device) == "cpu":
                predict_kwargs["device"] = "cpu"

            # 根据模式选择执行方式
            if self._cuda_manager:
                # GPU 模式：使用 CUDA 管理器序列化多线程 GPU 操作
                results = self._cuda_manager.run_inference(
                    self._model.predict,
                    **predict_kwargs,
                )
            else:
                # CPU 模式：直接调用模型
                results = self._model.predict(**predict_kwargs)

            # 处理结果（通常只有一个结果，因为输入是单帧）
            result = results[0]
            boxes = result.boxes

            # 提取检测信息
            detections = []
            if len(boxes) > 0:
                # 转换为 numpy 数组
                xyxy = boxes.xyxy.cpu().numpy()
                xyxyn = boxes.xyxyn.cpu().numpy()
                conf = boxes.conf.cpu().numpy()
                cls = boxes.cls.cpu().numpy().astype(int)

                for i in range(len(boxes)):
                    detection = {
                        "bbox": xyxy[i].tolist(),  # [x1, y1, x2, y2]
                        "bbox_norm": xyxyn[i].tolist(),  # 归一化坐标
                        "confidence": float(conf[i]),
                        "class_id": int(cls[i]),
                        "class_name": result.names[cls[i]],
                    }
                    detections.append(detection)

            # 计算推理时间
            inference_time = time.time() - start_time

            # 保存检测结果到 metadata
            frame.metadata["detections"] = {
                "count": len(detections),
                "objects": detections,
                "inference_time": inference_time,
            }

            # 可选：绘制边界框
            if self.draw_boxes and len(detections) > 0:
                self._draw_detections(frame, detections)

            # 只在检测到对象时输出日志
            if len(detections) > 0:
                self.logger.debug(
                    f"Detected {len(detections)} objects in {inference_time*1000:.1f}ms"
                )

        except Exception as e:
            self.logger.error(f"Error during YOLO inference: {e}", exc_info=True)
            # 出错时仍然返回原帧，但添加错误标记
            frame.metadata["detections"] = {"count": 0, "objects": [], "error": str(e)}

        return frame

    def _draw_detections(self, frame: Frame, detections: List[dict]):
        """
        在帧上绘制检测结果

        Args:
            frame: 要绘制的帧
            detections: 检测结果列表
        """
        try:
            import cv2
        except ImportError:
            self.logger.warning("OpenCV not available, skipping visualization")
            return

        for det in detections:
            x1, y1, x2, y2 = det["bbox"]
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

            # 绘制边界框
            cv2.rectangle(frame.image, (x1, y1), (x2, y2), self.box_color, self.thickness)

            # 绘制标签
            if self.draw_labels:
                label = f"{det['class_name']} {det['confidence']:.2f}"
                img_h, img_w = frame.image.shape[:2]

                # 计算文本大小
                (text_w, text_h), baseline = cv2.getTextSize(
                    label, cv2.FONT_HERSHEY_SIMPLEX, self.font_scale, self.thickness
                )

                # 计算标签位置，确保不溢出画面
                label_h = text_h + baseline + 5

                # 默认放在边界框上方
                if y1 - label_h >= 0:
                    # 上方有足够空间
                    bg_y1 = y1 - label_h
                    bg_y2 = y1
                    text_y = y1 - baseline - 2
                else:
                    # 上方空间不足，放在边界框内部下方
                    bg_y1 = y1
                    bg_y2 = y1 + label_h
                    text_y = y1 + text_h + 2

                # 检查右侧是否溢出
                label_x1 = x1
                label_x2 = x1 + text_w + 5
                if label_x2 > img_w:
                    # 右侧溢出，向左调整
                    label_x1 = max(0, img_w - text_w - 5)
                    label_x2 = img_w

                # 绘制背景矩形
                cv2.rectangle(
                    frame.image,
                    (label_x1, bg_y1),
                    (label_x2, bg_y2),
                    self.label_bg_color,
                    -1,
                )

                # 绘制文本
                cv2.putText(
                    frame.image,
                    label,
                    (label_x1 + 2, text_y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    self.font_scale,
                    self.text_color,
                    self.thickness,
                    cv2.LINE_AA,
                )

    def get_stats(self) -> dict:
        """
        获取检测器统计信息

        Returns:
            包含统计信息的字典
        """
        stats = super().get_stats()
        stats.update(
            {
                "model": self.model_name,
                "device": self.device,
                "conf_threshold": self.conf,
                "iou_threshold": self.iou,
                "model_loaded": self._model_loaded,
            }
        )
        return stats

    def __repr__(self) -> str:
        status = "enabled" if self.enabled else "disabled"
        device_str = self.device if self._model_loaded else "not loaded"
        return (
            f"YOLODetector({status}, "
            f"model={self.model_name}, "
            f"device={device_str}, "
            f"conf={self.conf})"
        )
