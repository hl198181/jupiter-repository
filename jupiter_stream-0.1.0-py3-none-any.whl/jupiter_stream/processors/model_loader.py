"""模型加载器

基于协议匹配的模型加载机制。
库提供抽象基类和注册管理，业务端实现具体加载器。

Model loader with protocol-based matching mechanism.
Library provides abstract base class and registry management,
business side implements concrete loaders.

Example:
    # 业务端实现加载器
    class HTTPModelLoader(ModelLoader):
        def __init__(self, cache_dir: str, http_client=None):
            self.cache_dir = Path(cache_dir)
            self.http_client = http_client

        def load(self, uri: str) -> Path:
            cache_path = self._get_cache_path(uri)
            if cache_path.exists():
                return cache_path
            # 使用业务端的 HTTP 客户端下载
            self._download(uri, cache_path)
            return cache_path

        @property
        def protocols(self) -> List[str]:
            return ["http", "https"]

    # 注册
    register_model_loader(HTTPModelLoader(
        cache_dir="/opt/models",
        http_client=my_http_client
    ))

    # 使用（YOLODetector 内部自动调用）
    path = resolve_model("https://example.com/model.pt")
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class ModelLoader(ABC):
    """模型加载器抽象基类

    业务端继承此类实现具体的加载逻辑（HTTP、S3、OSS 等）。
    Abstract base class for model loaders.
    Business side inherits this class to implement concrete loading logic.

    Example:
        class HTTPModelLoader(ModelLoader):
            def __init__(self, cache_dir: str, http_client=None):
                self.cache_dir = Path(cache_dir)
                self.http_client = http_client or default_client

            def load(self, uri: str) -> Path:
                # 业务端完全控制实现
                cache_path = self._get_cache_path(uri)
                if not cache_path.exists():
                    self._download(uri, cache_path)
                return cache_path

            @property
            def protocols(self) -> List[str]:
                return ["http", "https"]
    """

    @abstractmethod
    def load(self, uri: str) -> Path:
        """
        加载模型，返回本地文件路径
        Load model and return local file path.

        Args:
            uri: 完整的模型 URI（如 "https://example.com/model.pt"）
                 Complete model URI (e.g., "https://example.com/model.pt")

        Returns:
            本地模型文件路径
            Local model file path

        Raises:
            FileNotFoundError: 模型不存在 / Model not found
            Exception: 下载失败等其他错误 / Download failure or other errors
        """
        pass

    @property
    @abstractmethod
    def protocols(self) -> List[str]:
        """
        支持的协议列表
        List of supported protocols.

        Returns:
            协议名称列表，如 ["http", "https"] 或 ["s3"]
            Protocol names, e.g., ["http", "https"] or ["s3"]
        """
        pass


class LocalModelLoader(ModelLoader):
    """本地文件加载器（内置）
    Local file loader (built-in).
    """

    def load(self, uri: str) -> Path:
        """加载本地模型文件"""
        # 移除 file:// 前缀（如果有）
        if uri.startswith("file://"):
            uri = uri[7:]

        path = Path(uri)
        if not path.exists():
            raise FileNotFoundError(f"Model not found: {uri}")
        return path

    @property
    def protocols(self) -> List[str]:
        return ["local", "file"]


class ModelLoaderRegistry:
    """模型加载器注册表

    单例模式，管理所有已注册的模型加载器。
    根据 URI 协议自动选择合适的加载器。

    Singleton registry managing all registered model loaders.
    Automatically selects appropriate loader based on URI protocol.

    Example:
        # 获取注册表
        registry = ModelLoaderRegistry()

        # 注册加载器
        registry.register(HTTPModelLoader(cache_dir="/opt/models"))

        # 解析模型
        path = registry.resolve("https://example.com/model.pt")

        # 列出已注册协议
        protocols = registry.list_protocols()  # ["local", "file", "http", "https"]
    """

    _instance: Optional[ModelLoaderRegistry] = None

    def __new__(cls) -> ModelLoaderRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._loaders: Dict[str, ModelLoader] = {}
        self._initialized = True

        # 注册内置的本地加载器
        self._register_loader(LocalModelLoader())

        logger.debug("ModelLoaderRegistry initialized")

    def _register_loader(self, loader: ModelLoader) -> None:
        """内部注册方法"""
        for protocol in loader.protocols:
            self._loaders[protocol] = loader
            logger.debug(f"Registered loader for protocol: {protocol}")

    def register(self, loader: ModelLoader) -> None:
        """
        注册模型加载器
        Register a model loader.

        加载器会自动注册到其支持的所有协议。
        Loader is automatically registered to all protocols it supports.

        Args:
            loader: 模型加载器实例 / Model loader instance

        Example:
            registry.register(HTTPModelLoader(
                cache_dir="/opt/models",
                http_client=my_client
            ))
        """
        self._register_loader(loader)
        protocols = loader.protocols
        logger.info(f"Registered {loader.__class__.__name__} for protocols: {protocols}")

    def unregister(self, protocol: str) -> bool:
        """
        注销指定协议的加载器
        Unregister loader for specified protocol.

        Args:
            protocol: 协议名称 / Protocol name

        Returns:
            是否成功注销 / Whether unregistration was successful
        """
        # 保护内置的 local 和 file 协议
        if protocol in ["local", "file"]:
            logger.warning(f"Cannot unregister built-in protocol: {protocol}")
            return False

        if protocol in self._loaders:
            del self._loaders[protocol]
            logger.info(f"Unregistered loader for protocol: {protocol}")
            return True

        return False

    def get_loader(self, protocol: str) -> Optional[ModelLoader]:
        """
        获取指定协议的加载器
        Get loader for specified protocol.

        Args:
            protocol: 协议名称 / Protocol name

        Returns:
            加载器实例，未注册则返回 None
            Loader instance, or None if not registered
        """
        return self._loaders.get(protocol)

    def resolve(self, model: str) -> Path:
        """
        解析模型路径，返回本地文件
        Resolve model path and return local file.

        根据 URI 格式自动选择加载器：
        Automatically selects loader based on URI format:
        - "/path/to/model.pt" → local
        - "file:///path/to/model.pt" → local
        - "http://..." → http（需业务端注册 / requires business registration）
        - "https://..." → https（需业务端注册 / requires business registration）
        - "s3://..." → s3（需业务端注册 / requires business registration）

        Args:
            model: 模型路径或 URI / Model path or URI

        Returns:
            本地模型文件路径 / Local model file path

        Raises:
            ValueError: 未知协议且未注册加载器 / Unknown protocol without registered loader
            FileNotFoundError: 模型不存在 / Model not found
        """
        protocol = self._parse_protocol(model)

        loader = self._loaders.get(protocol)
        if not loader:
            raise ValueError(
                f"No loader registered for protocol '{protocol}'. "
                f"Available protocols: {self.list_protocols()}. "
                f"Register a loader with: registry.register(YourLoader())"
            )

        logger.debug(f"Resolving '{model}' with {loader.__class__.__name__}")
        return loader.load(model)

    def _parse_protocol(self, uri: str) -> str:
        """解析 URI 协议 / Parse URI protocol"""
        if "://" in uri:
            return uri.split("://", 1)[0].lower()

        # 无协议前缀，视为本地路径
        return "local"

    def list_protocols(self) -> List[str]:
        """
        列出所有已注册的协议
        List all registered protocols.

        Returns:
            协议名称列表 / List of protocol names
        """
        return list(self._loaders.keys())

    def list_loaders(self) -> Dict[str, List[str]]:
        """
        列出所有加载器及其支持的协议
        List all loaders and their supported protocols.

        Returns:
            加载器名称到协议列表的映射
            Mapping from loader name to list of protocols
        """
        result: Dict[str, List[str]] = {}
        for protocol, loader in self._loaders.items():
            loader_name = loader.__class__.__name__
            if loader_name not in result:
                result[loader_name] = []
            if protocol not in result[loader_name]:
                result[loader_name].append(protocol)
        return result

    def clear(self) -> None:
        """
        清空所有加载器（保留内置的 local）
        Clear all loaders (preserve built-in local).
        """
        local_loader = self._loaders.get("local")
        self._loaders.clear()
        if local_loader:
            self._register_loader(local_loader)
        logger.info("ModelLoaderRegistry cleared (local preserved)")


# ========== 便捷函数 / Convenience Functions ==========


def get_model_loader_registry() -> ModelLoaderRegistry:
    """
    获取模型加载器注册表单例
    Get model loader registry singleton.

    Returns:
        ModelLoaderRegistry 实例 / ModelLoaderRegistry instance
    """
    return ModelLoaderRegistry()


def register_model_loader(loader: ModelLoader) -> None:
    """
    注册模型加载器（便捷函数）
    Register model loader (convenience function).

    Args:
        loader: 模型加载器实例 / Model loader instance

    Example:
        register_model_loader(HTTPModelLoader(
            cache_dir="/opt/models",
            http_client=my_client
        ))
    """
    ModelLoaderRegistry().register(loader)


def resolve_model(model: str) -> Path:
    """
    解析模型路径（便捷函数）
    Resolve model path (convenience function).

    Args:
        model: 模型路径或 URI / Model path or URI

    Returns:
        本地模型文件路径 / Local model file path

    Example:
        # 本地文件
        path = resolve_model("/opt/models/yolo.pt")

        # HTTP（需先注册 HTTP 加载器）
        path = resolve_model("https://example.com/model.pt")
    """
    return ModelLoaderRegistry().resolve(model)
