"""Image transformation processors."""

from __future__ import annotations

from typing import Optional, Tuple, Union

from ..core import Frame, Processor
from ..core.pipeline.registry import register_processor


@register_processor("Resize")
class Resize(Processor):
    """
    调整图像大小处理器

    Examples:
        >>> processor = Resize(width=640, height=480)
        >>> output = processor(input_frame)

        >>> # 保持宽高比
        >>> processor = Resize(width=640, keep_aspect_ratio=True)
    """

    def __init__(
        self,
        width: Optional[int] = None,
        height: Optional[int] = None,
        keep_aspect_ratio: bool = False,
        interpolation: str = "linear",
        enabled: bool = True,
    ):
        """
        初始化 Resize 处理器

        Args:
            width: 目标宽度（None 表示自动计算）
            height: 目标高度（None 表示自动计算）
            keep_aspect_ratio: 是否保持宽高比
            interpolation: 插值方法 ("nearest", "linear", "cubic", "area", "lanczos")
            enabled: 是否启用

        Raises:
            ValueError: 如果 width 和 height 都为 None
            ImportError: 如果 OpenCV 未安装
        """
        super().__init__(enabled)

        if width is None and height is None:
            raise ValueError("At least one of width or height must be specified")

        try:
            import cv2
        except ImportError:
            raise ImportError(
                "OpenCV is required for Resize. " "Install with: pip install jupiter-stream[cv]"
            )

        self.width = width
        self.height = height
        self.keep_aspect_ratio = keep_aspect_ratio

        # 插值方法映射
        interp_methods = {
            "nearest": cv2.INTER_NEAREST,
            "linear": cv2.INTER_LINEAR,
            "cubic": cv2.INTER_CUBIC,
            "area": cv2.INTER_AREA,
            "lanczos": cv2.INTER_LANCZOS4,
        }
        self.interpolation = interp_methods.get(interpolation, cv2.INTER_LINEAR)

    def process(self, frame: Frame) -> Frame:
        """处理帧"""
        import cv2

        src_h, src_w = frame.height, frame.width

        # 计算目标尺寸
        if self.keep_aspect_ratio:
            if self.width is not None and self.height is None:
                # 固定宽度，计算高度
                ratio = self.width / src_w
                dst_w = self.width
                dst_h = int(src_h * ratio)
            elif self.height is not None and self.width is None:
                # 固定高度，计算宽度
                ratio = self.height / src_h
                dst_h = self.height
                dst_w = int(src_w * ratio)
            else:
                # 同时指定宽高，按最小缩放比例
                ratio = min(self.width / src_w, self.height / src_h)
                dst_w = int(src_w * ratio)
                dst_h = int(src_h * ratio)
        else:
            dst_w = self.width if self.width is not None else src_w
            dst_h = self.height if self.height is not None else src_h

        # 调整大小
        frame.image = cv2.resize(frame.image, (dst_w, dst_h), interpolation=self.interpolation)
        frame.metadata["resized"] = True
        frame.metadata["original_size"] = (src_w, src_h)
        frame.metadata["new_size"] = (dst_w, dst_h)

        return frame


@register_processor("Annotate")
class Annotate(Processor):
    """
    文本标注处理器

    Examples:
        >>> processor = Annotate(text="Processing...", position=(10, 30))
        >>> output = processor(input_frame)

        >>> # 动态文本
        >>> processor = Annotate(
        ...     text_func=lambda frame: f"Frame {frame.frame_id}",
        ...     color=(255, 0, 0)
        ... )
    """

    def __init__(
        self,
        text: Optional[str] = None,
        text_func: Optional[callable] = None,
        position: Tuple[int, int] = (10, 30),
        color: Tuple[int, int, int] = (0, 255, 0),
        font_scale: float = 0.6,
        thickness: int = 2,
        background: bool = False,
        background_color: Tuple[int, int, int] = (0, 0, 0),
        enabled: bool = True,
    ):
        """
        初始化 Annotate 处理器

        Args:
            text: 固定文本（与 text_func 二选一）
            text_func: 动态文本函数，接收 Frame 返回 str
            position: 文本位置 (x, y)
            color: 文本颜色 (B, G, R)
            font_scale: 字体大小
            thickness: 线条粗细
            background: 是否添加背景
            background_color: 背景颜色 (B, G, R)
            enabled: 是否启用

        Raises:
            ValueError: 如果 text 和 text_func 都未指定
            ImportError: 如果 OpenCV 未安装
        """
        super().__init__(enabled)

        if text is None and text_func is None:
            raise ValueError("Either text or text_func must be specified")

        import importlib.util

        if importlib.util.find_spec("cv2") is None:
            raise ImportError(
                "OpenCV is required for Annotate. " "Install with: pip install jupiter-stream[cv]"
            )

        self.text = text
        self.text_func = text_func
        self.position = position
        self.color = color
        self.font_scale = font_scale
        self.thickness = thickness
        self.background = background
        self.background_color = background_color

    def process(self, frame: Frame) -> Frame:
        """处理帧"""
        import cv2

        # 获取文本
        if self.text_func is not None:
            text = self.text_func(frame)
        else:
            text = self.text

        # 添加背景
        if self.background:
            (text_w, text_h), _ = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, self.font_scale, self.thickness
            )
            x, y = self.position
            cv2.rectangle(
                frame.image,
                (x - 5, y - text_h - 5),
                (x + text_w + 5, y + 5),
                self.background_color,
                -1,
            )

        # 添加文本
        cv2.putText(
            frame.image,
            text,
            self.position,
            cv2.FONT_HERSHEY_SIMPLEX,
            self.font_scale,
            self.color,
            self.thickness,
            cv2.LINE_AA,
        )

        frame.metadata["annotated"] = True

        return frame


@register_processor("Label")
class Label(Processor):
    """
    透明标签处理器

    在视频帧上添加带透明背景的标签，支持自定义背景颜色、尺寸、位置、
    透明度、文本内容和时间显示。

    Add a label with transparent background to video frames, supporting custom
    background color, size, position, opacity, text content, and timestamp display.

    Examples:
        >>> # 基本用法 - 半透明黑色背景
        >>> processor = Label(
        ...     text="Processing...",
        ...     position=(10, 30),
        ...     background_color=(0, 0, 0),
        ...     alpha=0.7
        ... )

        >>> # 固定尺寸标签
        >>> processor = Label(
        ...     text="Status: OK",
        ...     position=(10, 100),
        ...     size=(200, 50),
        ...     alpha=0.8
        ... )

        >>> # 显示格式化时间
        >>> processor = Label(
        ...     text="Video Time",
        ...     position=(10, 150),
        ...     show_timestamp=True,
        ...     time_format="Time: {:.2f}s",
        ...     alpha=0.75
        ... )

        >>> # 动态内容
        >>> processor = Label(
        ...     text_func=lambda f: f"Frame: {f.frame_id}",
        ...     position=(10, 200),
        ...     size="auto",
        ...     padding=(15, 8)
        ... )
    """

    def __init__(
        self,
        text: Optional[str] = None,
        text_func: Optional[callable] = None,
        position: Tuple[int, int] = (10, 30),
        size: Union[str, Tuple[int, int]] = "auto",
        padding: Tuple[int, int] = (10, 5),
        background_color: Tuple[int, int, int] = (0, 0, 0),
        text_color: Tuple[int, int, int] = (255, 255, 255),
        alpha: float = 0.7,
        font_scale: float = 0.6,
        thickness: int = 2,
        show_timestamp: bool = False,
        time_format: str = "{:.2f}s",
        enabled: bool = True,
    ):
        """
        初始化 Label 处理器

        Args:
            text: 固定文本（与 text_func 二选一）/ Fixed text (mutually exclusive with text_func)
            text_func: 动态文本函数，接收 Frame 返回 str / Dynamic text function (Frame -> str)
            position: 标签位置 (x, y) 左上角坐标 / Label position (x, y) top-left corner
            size: 标签尺寸，"auto" 自动计算或 (width, height) 固定尺寸 /
                  Label size, "auto" for automatic or (width, height) for fixed
            padding: 内边距 (水平, 垂直) / Padding (horizontal, vertical)
            background_color: 背景颜色 (B, G, R) / Background color (B, G, R)
            text_color: 文本颜色 (B, G, R) / Text color (B, G, R)
            alpha: 透明度 (0.0-1.0)，0 完全透明，1 完全不透明 /
                   Opacity (0.0-1.0), 0 is transparent, 1 is opaque
            font_scale: 字体大小 / Font scale
            thickness: 线条粗细 / Line thickness
            show_timestamp: 是否显示时间戳 / Whether to show timestamp
            time_format: 时间格式字符串，使用 {:.2f} 等格式化占位符 /
                        Time format string, use {:.2f} etc. for formatting
            enabled: 是否启用 / Whether to enable

        Raises:
            ValueError: 如果 text 和 text_func 都未指定 / If neither text nor text_func is specified
            ValueError: 如果 alpha 不在 0.0-1.0 范围内 / If alpha is not in range 0.0-1.0
            ImportError: 如果 OpenCV 未安装 / If OpenCV is not installed
        """
        super().__init__(enabled)

        if text is None and text_func is None and not show_timestamp:
            raise ValueError("At least one of text, text_func, or show_timestamp must be specified")

        if not 0.0 <= alpha <= 1.0:
            raise ValueError(f"alpha must be between 0.0 and 1.0, got {alpha}")

        import importlib.util

        if importlib.util.find_spec("cv2") is None:
            raise ImportError(
                "OpenCV is required for Label. " "Install with: pip install jupiter-stream[cv]"
            )

        self.text = text
        self.text_func = text_func
        self.position = position
        self.size = size
        self.padding = padding
        self.background_color = background_color
        self.text_color = text_color
        self.alpha = alpha
        self.font_scale = font_scale
        self.thickness = thickness
        self.show_timestamp = show_timestamp
        self.time_format = time_format

    def process(self, frame: Frame) -> Frame:
        """处理帧 / Process frame"""
        import cv2

        # 1. 构建显示文本 / Build display text
        text_parts = []

        # 添加主文本
        if self.text_func is not None:
            text_parts.append(self.text_func(frame))
        elif self.text is not None:
            text_parts.append(self.text)

        # 添加时间戳
        if self.show_timestamp:
            time_str = self.time_format.format(frame.timestamp)
            text_parts.append(time_str)

        display_text = " ".join(text_parts)

        if not display_text:
            return frame

        # 2. 计算文本尺寸 / Calculate text size
        (text_w, text_h), baseline = cv2.getTextSize(
            display_text, cv2.FONT_HERSHEY_SIMPLEX, self.font_scale, self.thickness
        )

        # 3. 确定标签尺寸 / Determine label size
        h_pad, v_pad = self.padding

        if self.size == "auto":
            # 自动计算尺寸
            label_w = text_w + 2 * h_pad
            label_h = text_h + baseline + 2 * v_pad
        else:
            # 使用固定尺寸
            label_w, label_h = self.size

        # 4. 计算标签区域 / Calculate label region
        x, y = self.position
        x1, y1 = x, y
        x2, y2 = x + label_w, y + label_h

        # 确保不超出图像边界 / Ensure within image bounds
        img_h, img_w = frame.image.shape[:2]
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(img_w, x2)
        y2 = min(img_h, y2)

        if x2 <= x1 or y2 <= y1:
            # 标签完全在图像外
            return frame

        # 5. 绘制透明背景 / Draw transparent background
        overlay = frame.image.copy()
        cv2.rectangle(overlay, (x1, y1), (x2, y2), self.background_color, -1)  # 填充

        # 使用 alpha 混合 / Alpha blending
        cv2.addWeighted(overlay, self.alpha, frame.image, 1 - self.alpha, 0, frame.image)

        # 6. 绘制文本 / Draw text
        # 计算文本位置（居中或左对齐）
        if self.size == "auto":
            text_x = x + h_pad
            text_y = y + v_pad + text_h
        else:
            # 固定尺寸时，文本居中
            text_x = x + (label_w - text_w) // 2
            text_y = y + (label_h + text_h) // 2

        cv2.putText(
            frame.image,
            display_text,
            (text_x, text_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            self.font_scale,
            self.text_color,
            self.thickness,
            cv2.LINE_AA,
        )

        # 更新元数据 / Update metadata
        frame.metadata["label_added"] = True
        frame.metadata["label_text"] = display_text

        return frame
