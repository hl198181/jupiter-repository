"""Frame processors for jupiter-stream."""

from __future__ import annotations

from .detect import YOLODetector
from .model_loader import (
    ModelLoader,
    ModelLoaderRegistry,
    get_model_loader_registry,
    register_model_loader,
    resolve_model,
)
from .transform import Annotate, Label, Resize

__all__ = [
    "Resize",
    "Annotate",
    "Label",
    "YOLODetector",
    # Model loader
    "ModelLoader",
    "ModelLoaderRegistry",
    "get_model_loader_registry",
    "register_model_loader",
    "resolve_model",
]
