"""Frame processors for jupiter-stream."""

from __future__ import annotations

from .transform import Resize, Annotate, Label
from .detect import YOLODetector

__all__ = ["Resize", "Annotate", "Label", "YOLODetector"]
