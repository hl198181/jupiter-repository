"""Frame processors for jupiter-stream."""

from __future__ import annotations

from .detect import YOLODetector
from .transform import Annotate, Label, Resize

__all__ = ["Resize", "Annotate", "Label", "YOLODetector"]
