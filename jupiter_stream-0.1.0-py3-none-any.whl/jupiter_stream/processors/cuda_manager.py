"""
CUDA 单例管理器

确保 CUDA 上下文在主线程中初始化一次，所有 GPU 处理器共享同一个上下文。
解决多线程环境下 CUDA 初始化竞态条件导致的 Segmentation fault 问题。

Usage:
    from jupiter_stream.processors.cuda_manager import CUDAManager

    # 获取单例实例
    cuda_mgr = CUDAManager()

    # 检查 CUDA 是否可用
    if cuda_mgr.is_available:
        device = cuda_mgr.device

    # 在 CUDA stream 中执行推理（自动序列化多线程操作）
    results = cuda_mgr.run_inference(model.predict, frame, device=0, ...)
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


class CUDAManager:
    """
    CUDA 单例管理器

    - 确保 CUDA 只初始化一次（在首次访问时）
    - 提供线程安全的推理执行
    - 使用 Semaphore 控制 GPU 推理并行度
    """

    _instance: Optional[CUDAManager] = None
    _lock = threading.Lock()
    _initialized = False

    # 默认最大并行推理数（可通过环境变量 CUDA_MAX_CONCURRENT 覆盖）
    # 注意：cuDNN 不支持真正的多线程并行，设置 > 1 可能导致 CUDNN_STATUS_EXECUTION_FAILED
    DEFAULT_MAX_CONCURRENT = 1

    def __new__(cls) -> CUDAManager:
        if cls._instance is None:
            with cls._lock:
                # 双重检查锁定
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        # 防止重复初始化
        if CUDAManager._initialized:
            return

        with CUDAManager._lock:
            if CUDAManager._initialized:
                return

            self._is_available = False
            self._device = None
            self._stream = None

            # 从环境变量读取并行度配置，默认为 2
            import os

            max_concurrent = int(os.environ.get("CUDA_MAX_CONCURRENT", self.DEFAULT_MAX_CONCURRENT))
            self._max_concurrent = max_concurrent
            self._inference_semaphore = threading.Semaphore(max_concurrent)

            self._initialize_cuda()
            CUDAManager._initialized = True

    def _initialize_cuda(self):
        """初始化 CUDA 环境"""
        try:
            import torch

            if torch.cuda.is_available():
                # 初始化 CUDA
                torch.cuda.init()

                # 获取设备信息
                device_count = torch.cuda.device_count()
                device_name = torch.cuda.get_device_name(0) if device_count > 0 else "N/A"

                self._is_available = True
                self._device = torch.device("cuda:0")

                # 创建专用 CUDA stream 用于序列化推理操作
                self._stream = torch.cuda.Stream()

                logger.info("CUDA initialized successfully")
                logger.info(f"  Device count: {device_count}")
                logger.info(f"  Device name: {device_name}")
                logger.info(
                    f"  Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB"
                )
                logger.info(f"  Max concurrent inferences: {self._max_concurrent}")
            else:
                logger.info("CUDA not available, using CPU")
                self._is_available = False
                self._device = None

        except ImportError:
            logger.warning("PyTorch not installed, CUDA support disabled")
            self._is_available = False
            self._device = None
        except Exception as e:
            logger.error(f"Failed to initialize CUDA: {e}")
            self._is_available = False
            self._device = None

    @property
    def is_available(self) -> bool:
        """CUDA 是否可用"""
        return self._is_available

    @property
    def device(self) -> Optional[Any]:
        """获取 CUDA 设备"""
        return self._device

    @property
    def device_id(self) -> str:
        """获取设备 ID 字符串（用于 YOLO 等库）"""
        return "0" if self._is_available else "cpu"

    def run_inference(self, func: Callable, *args, **kwargs) -> Any:
        """
        在 CUDA stream 中执行推理函数

        通过 Semaphore 控制并行度，允许最多 max_concurrent 个推理同时执行。

        Args:
            func: 推理函数（如 model.predict）
            *args: 位置参数
            **kwargs: 关键字参数

        Returns:
            推理结果
        """
        if not self._is_available or self._stream is None:
            # CPU 模式，直接执行
            return func(*args, **kwargs)

        import torch

        # 使用信号量控制并行度
        with self._inference_semaphore:
            with torch.cuda.stream(self._stream):
                result = func(*args, **kwargs)
                # 同步等待当前 stream 完成
                self._stream.synchronize()

        return result

    @property
    def max_concurrent(self) -> int:
        """获取最大并行推理数"""
        return self._max_concurrent

    def synchronize(self):
        """同步 CUDA 操作"""
        if self._is_available:
            import torch

            torch.cuda.synchronize()

    def get_memory_info(self) -> dict:
        """获取 GPU 内存信息"""
        if not self._is_available:
            return {"available": False}

        import torch

        return {
            "available": True,
            "allocated": torch.cuda.memory_allocated(0) / 1024**2,  # MB
            "reserved": torch.cuda.memory_reserved(0) / 1024**2,  # MB
            "max_allocated": torch.cuda.max_memory_allocated(0) / 1024**2,  # MB
        }

    def __repr__(self) -> str:
        if self._is_available:
            import torch

            return f"CUDAManager(device={torch.cuda.get_device_name(0)}, available=True)"
        return "CUDAManager(available=False)"


# 便捷函数：获取单例实例
def get_cuda_manager() -> CUDAManager:
    """获取 CUDA 管理器单例"""
    return CUDAManager()
