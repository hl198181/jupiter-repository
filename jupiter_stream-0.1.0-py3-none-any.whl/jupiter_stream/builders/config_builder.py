"""配置文件方式构建 Pipeline / Config-based Pipeline Builder"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict

from ..core.pipeline.builder import PipelineBuilder
from ..core.pipeline.factory import factory

if TYPE_CHECKING:
    from ..core.pipeline import Pipeline

logger = logging.getLogger(__name__)


class ConfigPipelineBuilder(PipelineBuilder):
    """配置文件方式构建 Pipeline / Config-based Pipeline Builder

    从配置字典构建 Pipeline，配置通过 ConfigLoader 加载。
    Builds Pipeline from configuration dict loaded by ConfigLoader.

    配置格式 / Configuration format:
        {
            "pipeline": {"fps": 30},
            "source": {
                "type": "VideoSource",
                "params": {"video_path": "input.mp4"}
            },
            "processors": [
                {
                    "type": "Resize",
                    "params": {"width": 640, "height": 480}
                }
            ],
            "sinks": [
                {
                    "type": "DisplaySink",
                    "params": {}
                }
            ]
        }

    Example:
        >>> from jupiter_stream.builders import ConfigPipelineBuilder
        >>> config = {
        ...     "source": {"type": "VideoSource", "params": {"video_path": "input.mp4"}},
        ...     "processors": [{"type": "Resize", "params": {"width": 640}}],
        ...     "sinks": [{"type": "DisplaySink", "params": {}}]
        ... }
        >>> builder = ConfigPipelineBuilder(config)
        >>> pipeline = builder.build()
        >>> pipeline.run()
    """

    def __init__(self, config: Dict[str, Any]):
        """初始化配置构建器

        Args:
            config: 配置字典

        Raises:
            ValueError: 如果配置格式无效
        """
        # 从配置中提取 fps
        fps = config.get("pipeline", {}).get("fps", None)
        super().__init__(fps)

        self.config = config
        self._validate_config()

        logger.debug(f"ConfigPipelineBuilder initialized with config keys: {list(config.keys())}")

    def _validate_config(self) -> None:
        """验证配置结构

        Raises:
            ValueError: 如果配置无效
        """
        if not isinstance(self.config, dict):
            raise ValueError("Configuration must be a dictionary")

        # 必须有 source
        if "source" not in self.config:
            raise ValueError("Missing required field: 'source'")

        source_config = self.config["source"]
        if not isinstance(source_config, dict):
            raise ValueError("'source' must be a dictionary")
        if "type" not in source_config:
            raise ValueError("'source' must have a 'type' field")

        # processors 是可选的，但如果存在必须是列表
        if "processors" in self.config:
            processors_config = self.config["processors"]
            if not isinstance(processors_config, list):
                raise ValueError("'processors' must be a list")
            for i, proc in enumerate(processors_config):
                if not isinstance(proc, dict):
                    raise ValueError(f"Processor {i} must be a dictionary")
                if "type" not in proc:
                    raise ValueError(f"Processor {i} must have a 'type' field")

        # sinks 是可选的，但如果存在必须是列表
        if "sinks" in self.config:
            sinks_config = self.config["sinks"]
            if not isinstance(sinks_config, list):
                raise ValueError("'sinks' must be a list")
            for i, sink in enumerate(sinks_config):
                if not isinstance(sink, dict):
                    raise ValueError(f"Sink {i} must be a dictionary")
                if "type" not in sink:
                    raise ValueError(f"Sink {i} must have a 'type' field")

        logger.debug("Configuration validation passed")

    def set_source(self, source_type: str, params: Dict[str, Any]) -> ConfigPipelineBuilder:
        """设置 Source（内部方法，不直接使用）

        这个方法主要是为了符合 PipelineBuilder 接口。
        实际的 Source 创建在 build() 方法中完成。

        Args:
            source_type: Source 类型
            params: Source 参数

        Returns:
            self

        Raises:
            NotImplementedError: 总是抛出，提示使用 build() 方法
        """
        raise NotImplementedError(
            "ConfigPipelineBuilder does not support manual source setting. "
            "Source is configured through the config dict. Use build() method."
        )

    def add_processor(self, processor_type: str, params: Dict[str, Any]) -> ConfigPipelineBuilder:
        """添加 Processor（内部方法，不直接使用）

        Args:
            processor_type: Processor 类型
            params: Processor 参数

        Returns:
            self

        Raises:
            NotImplementedError: 总是抛出，提示使用 build() 方法
        """
        raise NotImplementedError(
            "ConfigPipelineBuilder does not support manual processor adding. "
            "Processors are configured through the config dict. Use build() method."
        )

    def add_sink(self, sink_type: str, params: Dict[str, Any]) -> ConfigPipelineBuilder:
        """添加 Sink（内部方法，不直接使用）

        Args:
            sink_type: Sink 类型
            params: Sink 参数

        Returns:
            self

        Raises:
            NotImplementedError: 总是抛出，提示使用 build() 方法
        """
        raise NotImplementedError(
            "ConfigPipelineBuilder does not support manual sink adding. "
            "Sinks are configured through the config dict. Use build() method."
        )

    def build(self) -> Pipeline:
        """从配置构建 Pipeline

        Returns:
            配置好的 Pipeline 实例

        Raises:
            ValueError: 如果创建组件失败
        """
        from ..core.pipeline import Pipeline

        # 创建 Pipeline 实例
        pipeline = Pipeline(fps=self.fps)
        logger.info(f"Creating Pipeline with fps={self.fps}")

        # 1. 创建并设置 Source
        source_config = self.config["source"]
        try:
            source = factory.create_source(
                source_type=source_config["type"], params=source_config.get("params", {})
            )
            pipeline.source = source
            logger.info(f"Pipeline source set: {source}")
        except Exception as e:
            raise ValueError(f"Failed to create source: {e}")

        # 2. 创建并添加 Processors
        processors_config = self.config.get("processors", [])
        for i, proc_config in enumerate(processors_config):
            try:
                processor = factory.create_processor(
                    processor_type=proc_config["type"], params=proc_config.get("params", {})
                )
                pipeline.processors.append(processor)
                logger.info(f"Pipeline processor {i} added: {processor}")
            except Exception as e:
                logger.error(f"Failed to create processor {i}: {e}")
                raise ValueError(f"Failed to create processor {i} ({proc_config['type']}): {e}")

        # 3. 创建并添加 Sinks
        sinks_config = self.config.get("sinks", [])
        if not sinks_config:
            logger.warning("No sinks configured, pipeline will run without output")

        for i, sink_config in enumerate(sinks_config):
            # 跳过 CallbackSink（配置文件不支持）
            if sink_config["type"] == "CallbackSink":
                logger.warning("CallbackSink is not supported in config files, skipping")
                continue

            try:
                sink = factory.create_sink(
                    sink_type=sink_config["type"], params=sink_config.get("params", {})
                )
                pipeline.sinks.append(sink)
                logger.info(f"Pipeline sink {i} added: {sink}")
            except Exception as e:
                logger.error(f"Failed to create sink {i}: {e}")
                raise ValueError(f"Failed to create sink {i} ({sink_config['type']}): {e}")

        self._pipeline = pipeline
        logger.info(
            f"Pipeline built successfully with source={source_config['type']}, "
            f"{len(processors_config)} processors, {len(pipeline.sinks)} sinks"
        )

        return pipeline

    def update_config(self, config: Dict[str, Any]) -> ConfigPipelineBuilder:
        """更新配置

        允许在构建前修改配置。

        Args:
            config: 新的配置字典

        Returns:
            self (支持链式调用)
        """
        self.config = config
        # 重新提取 fps
        self.fps = config.get("pipeline", {}).get("fps", None)
        self._validate_config()
        logger.debug("Configuration updated")
        return self

    def merge_config(self, partial_config: Dict[str, Any]) -> ConfigPipelineBuilder:
        """合并配置

        将部分配置合并到现有配置中。

        Args:
            partial_config: 部分配置字典

        Returns:
            self (支持链式调用)
        """
        # 深度合并配置
        import copy

        def deep_merge(base: dict, update: dict) -> dict:
            result = copy.deepcopy(base)
            for key, value in update.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = deep_merge(result[key], value)
                else:
                    result[key] = value
            return result

        self.config = deep_merge(self.config, partial_config)
        # 重新提取 fps
        self.fps = self.config.get("pipeline", {}).get("fps", self.fps)
        self._validate_config()
        logger.debug(f"Configuration merged with keys: {list(partial_config.keys())}")
        return self

    @classmethod
    def build_multiple(cls, config: Dict[str, Any]) -> Dict[str, Pipeline]:
        """从配置构建多个 Pipeline

        支持包含 'pipelines' 数组的配置文件。每个 Pipeline 必须有 'name' 字段。

        Args:
            config: 包含 'pipelines' 数组的配置字典

        Returns:
            {pipeline_name: Pipeline 实例} 字典

        Raises:
            ValueError: 如果配置格式无效

        Example:
            >>> config = {
            ...     "pipelines": [
            ...         {
            ...             "name": "camera_1",
            ...             "pipeline": {"fps": 30},
            ...             "source": {"type": "RTSPSource", "params": {"url": "rtsp://..."}},
            ...             "processors": [...],
            ...             "sinks": [...]
            ...         },
            ...         {
            ...             "name": "camera_2",
            ...             ...
            ...         }
            ...     ]
            ... }
            >>> pipelines = ConfigPipelineBuilder.build_multiple(config)
            >>> for name, pipeline in pipelines.items():
            ...     pipeline.run(threaded=True)
        """
        if "pipelines" not in config:
            raise ValueError("Config must contain 'pipelines' key for multiple pipeline build")

        pipelines_config = config["pipelines"]

        if not isinstance(pipelines_config, list):
            raise ValueError("'pipelines' must be a list")

        pipelines = {}
        for i, pipeline_config in enumerate(pipelines_config):
            if not isinstance(pipeline_config, dict):
                logger.error(f"Pipeline {i} must be a dictionary")
                continue

            if "name" not in pipeline_config:
                logger.error(f"Pipeline {i} missing required 'name' field")
                continue

            name = pipeline_config["name"]

            # 提取实际的 pipeline 配置（移除 name 字段）
            actual_config = {k: v for k, v in pipeline_config.items() if k != "name"}

            try:
                builder = cls(actual_config)
                pipeline = builder.build()
                pipelines[name] = pipeline
                logger.info(f"Built pipeline '{name}' successfully")
            except Exception as e:
                logger.error(f"Failed to build pipeline '{name}': {e}")
                raise ValueError(f"Failed to build pipeline '{name}': {e}")

        logger.info(f"Built {len(pipelines)} pipeline(s) successfully")
        return pipelines

    def __repr__(self) -> str:
        """字符串表示"""
        source_type = self.config.get("source", {}).get("type", "None")
        proc_count = len(self.config.get("processors", []))
        sink_count = len(self.config.get("sinks", []))
        return (
            f"ConfigPipelineBuilder(fps={self.fps}, "
            f"source={source_type}, "
            f"processors={proc_count}, "
            f"sinks={sink_count})"
        )
