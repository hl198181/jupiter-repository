"""代码方式构建 Pipeline / Code-based Pipeline Builder"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from ..core.pipeline.builder import FluentPipelineBuilder

if TYPE_CHECKING:
    from ..core.pipeline import Pipeline
    from ..core.pipeline.processor import Processor
    from ..core.pipeline.sink import Sink
    from ..core.pipeline.source import Source

logger = logging.getLogger(__name__)


class CodePipelineBuilder(FluentPipelineBuilder):
    """代码方式构建 Pipeline / Code-based Pipeline Builder

    用于支持链式调用的代码构建方式。
    Supports method chaining for code-based construction.

    Example:
        >>> from jupiter_stream.builders import CodePipelineBuilder
        >>> from jupiter_stream.sources import VideoSource
        >>> from jupiter_stream.processors import Resize
        >>> from jupiter_stream.sinks import DisplaySink
        >>>
        >>> builder = CodePipelineBuilder(fps=30)
        >>> pipeline = (builder
        ...     .set_source(VideoSource("input.mp4"))
        ...     .add_processor(Resize(640, 480))
        ...     .add_sink(DisplaySink())
        ...     .build())
        >>> pipeline.run()

    或者更简洁的方式：
        >>> pipeline = (CodePipelineBuilder(fps=30)
        ...     .set_source(VideoSource("input.mp4"))
        ...     .add_processor(Resize(640, 480))
        ...     .add_sink(DisplaySink())
        ...     .build())
    """

    def __init__(self, fps: Optional[float] = None):
        """初始化代码构建器

        Args:
            fps: Pipeline 目标帧率（None 表示使用源的原始帧率）
        """
        super().__init__(fps)
        logger.debug(f"CodePipelineBuilder initialized with fps={fps}")

    def set_source(self, source: Source) -> CodePipelineBuilder:
        """设置 Source 实例

        Args:
            source: Source 对象

        Returns:
            self (支持链式调用)

        Raises:
            TypeError: 如果 source 不是 Source 实例
        """
        from ..core.pipeline.source import Source

        if not isinstance(source, Source):
            raise TypeError(f"Expected Source instance, got {type(source)}")

        self._source = source
        logger.debug(f"Set source: {source}")
        return self

    def add_processor(self, processor: Processor) -> CodePipelineBuilder:
        """添加 Processor 实例

        Args:
            processor: Processor 对象

        Returns:
            self (支持链式调用)

        Raises:
            TypeError: 如果 processor 不是 Processor 实例
        """
        from ..core.pipeline.processor import Processor

        if not isinstance(processor, Processor):
            raise TypeError(f"Expected Processor instance, got {type(processor)}")

        self._processors.append(processor)
        logger.debug(f"Added processor: {processor}")
        return self

    def add_sink(self, sink: Sink) -> CodePipelineBuilder:
        """添加 Sink 实例

        Args:
            sink: Sink 对象

        Returns:
            self (支持链式调用)

        Raises:
            TypeError: 如果 sink 不是 Sink 实例
        """
        from ..core.pipeline.sink import Sink

        if not isinstance(sink, Sink):
            raise TypeError(f"Expected Sink instance, got {type(sink)}")

        self._sinks.append(sink)
        logger.debug(f"Added sink: {sink}")
        return self

    def add_processors(self, *processors: Processor) -> CodePipelineBuilder:
        """批量添加多个 Processor

        Args:
            *processors: Processor 对象列表

        Returns:
            self (支持链式调用)

        Example:
            >>> builder.add_processors(
            ...     Resize(640, 480),
            ...     Annotate(text="Processing"),
            ...     YOLODetector()
            ... )
        """
        for processor in processors:
            self.add_processor(processor)
        return self

    def add_sinks(self, *sinks: Sink) -> CodePipelineBuilder:
        """批量添加多个 Sink

        Args:
            *sinks: Sink 对象列表

        Returns:
            self (支持链式调用)

        Example:
            >>> builder.add_sinks(
            ...     DisplaySink(),
            ...     VideoSink("output.mp4"),
            ...     ImageSaveSink("frames/")
            ... )
        """
        for sink in sinks:
            self.add_sink(sink)
        return self

    def build(self) -> Pipeline:
        """构建 Pipeline

        Returns:
            配置好的 Pipeline 实例

        Raises:
            ValueError: 如果未设置 Source
        """
        if not self.validate():
            raise ValueError("Invalid configuration: Source not set. Call set_source() first.")

        from ..core.pipeline import Pipeline

        # 创建 Pipeline 实例
        pipeline = Pipeline(fps=self.fps)

        # 设置 source
        pipeline.source = self._source
        logger.info(f"Pipeline source set: {self._source}")

        # 添加 processors
        for processor in self._processors:
            pipeline.processors.append(processor)
            logger.info(f"Pipeline processor added: {processor}")

        # 添加 sinks
        for sink in self._sinks:
            pipeline.sinks.append(sink)
            logger.info(f"Pipeline sink added: {sink}")

        self._pipeline = pipeline
        logger.info(
            f"Pipeline built successfully with {len(self._processors)} processors and {len(self._sinks)} sinks"
        )

        return pipeline

    def __repr__(self) -> str:
        """字符串表示"""
        return (
            f"CodePipelineBuilder(fps={self.fps}, "
            f"source={self._source is not None}, "
            f"processors={len(self._processors)}, "
            f"sinks={len(self._sinks)})"
        )
