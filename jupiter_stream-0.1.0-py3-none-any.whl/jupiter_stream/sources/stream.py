"""Network stream source implementations (RTSP/RTMP/HLS)."""

from __future__ import annotations

import logging
import os
import queue
import threading
import time
from typing import Literal, Optional

from ..core import Frame, Source
from ..core.pipeline.registry import register_source

try:
    import cv2
except ImportError:
    cv2 = None


@register_source("RTSPSource")
class RTSPSource(Source):
    """
    RTSP 视频流源（基于 OpenCV）

    通过 OpenCV 的 VideoCapture 读取 RTSP/RTMP/HTTP 流。
    实现简单可靠，兼容性好，适用于大多数场景。

    特性：
    - 自动重连机制（指数退避）
    - 超时检测和恢复
    - 缓冲区优化（减少延迟）
    - 支持 RTSP/RTMP/HTTP 等多种协议

    Attributes:
        url: 流媒体 URL
        transport: 传输协议（tcp/udp）
        reconnect_interval: 重连间隔（秒）
        timeout: 读取超时（秒）
        buffer_size: 缓冲区大小（帧数，建议 1-3）
        max_reconnect_attempts: 最大重连次数（0 表示无限重试）

    Examples:
        >>> # RTSP 流
        >>> source = RTSPSource("rtsp://admin:password@192.168.1.100:554/stream1")
        >>> for frame in source:
        ...     process(frame)

        >>> # 使用 TCP 传输（更可靠，适合网络不稳定场景）
        >>> source = RTSPSource("rtsp://192.168.1.100:554/stream1", transport="tcp")

        >>> # RTMP 流
        >>> source = RTSPSource("rtmp://server/live/stream")

        >>> # HTTP 流
        >>> source = RTSPSource("http://server:8080/video.mjpg")
    """

    def __init__(
        self,
        url: str,
        transport: Optional[Literal["tcp", "udp"]] = None,
        reconnect_interval: int = 5,
        timeout: int = 10,
        buffer_size: int = 1,
        max_reconnect_attempts: int = 0,
        source_id: Optional[str] = None,
        threaded_read: bool = True,  # 强制启用，保留参数以兼容旧配置
        frame_queue_size: int = 30,
    ):
        """
        初始化 RTSP 流源

        Args:
            url: RTSP/RTMP/HTTP URL
            transport: RTSP 传输协议（"tcp" 或 "udp"，默认 None 使用系统默认）
                      - tcp: 更可靠，丢包会重传，但延迟略高
                      - udp: 延迟低，但可能丢包导致花屏
                      建议网络不稳定时使用 tcp
            reconnect_interval: 重连间隔（秒，默认 5）
            timeout: 读取超时（秒，默认 10）
            buffer_size: 缓冲区大小（帧数，默认 1，建议 1-3）
            max_reconnect_attempts: 最大重连次数（默认 0 表示无限重试）
            source_id: 数据源 ID（默认从 URL 提取）
            threaded_read: 已废弃，始终使用后台线程读取
            frame_queue_size: 帧队列大小（默认 30）

        Raises:
            ImportError: 如果 OpenCV 未安装
            RuntimeError: 如果初始连接失败
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for RTSPSource. " "Install with: pip install jupiter-stream[cv]"
            )

        # 从 URL 提取 source_id
        if source_id is None:
            # 提取 host 部分作为 ID，例如 rtsp://192.168.1.100:554/stream1 -> 192.168.1.100
            try:
                host = url.split("://")[1].split("/")[0].split("@")[-1].split(":")[0]
                source_id = f"stream:{host}"
            except Exception:
                source_id = "stream:unknown"

        super().__init__(source_id)

        self.url = url
        self.transport = transport
        self.reconnect_interval = reconnect_interval
        self.timeout = timeout
        self.buffer_size = buffer_size
        self.max_reconnect_attempts = max_reconnect_attempts
        self.frame_queue_size = frame_queue_size

        # 核心状态
        self._closed = False  # 唯一的结束标志，只有 close() 设置
        self._reconnecting = False  # 重连中标志，让 monitor 跳过检测
        self._cap_lock = threading.Lock()

        # 连接状态
        self.cap = None
        self._last_read_time = None
        self._reconnect_count = 0

        # 后台读取线程
        self._frame_queue: queue.Queue = queue.Queue(maxsize=frame_queue_size)
        self._read_thread: Optional[threading.Thread] = None
        self._dropped_frames = 0  # 因队列满而丢弃的帧数

        # 超时监控线程
        self._monitor_thread: Optional[threading.Thread] = None

        # 初始连接
        self._connect()

        # 启动后台线程
        self._start_read_thread()
        self._start_timeout_monitor()

    def _connect(self):
        """建立连接"""
        transport_info = f", transport={self.transport}" if self.transport else ""
        self.logger.info(f"Connecting to stream: {self._sanitize_url(self.url)}{transport_info}")

        # 设置 FFmpeg 选项（如 RTSP 传输协议）
        old_ffmpeg_options = os.environ.get("OPENCV_FFMPEG_CAPTURE_OPTIONS", "")
        if self.transport:
            os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = f"rtsp_transport;{self.transport}"

        try:
            # 使用 FFmpeg 后端打开流
            self.cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG)
        finally:
            # 恢复原来的环境变量
            if self.transport:
                if old_ffmpeg_options:
                    os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = old_ffmpeg_options
                else:
                    os.environ.pop("OPENCV_FFMPEG_CAPTURE_OPTIONS", None)

        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to connect to stream: {self._sanitize_url(self.url)}")

        # 设置缓冲区大小（减少延迟）
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, self.buffer_size)

        # 获取流属性
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # 验证连接是否真正成功
        # OpenCV 有时 isOpened() 返回 True 但流并未真正建立（元数据异常）
        if self.width == 0 or self.height == 0 or self.fps <= 0 or self.fps > 1000:
            self.logger.warning(
                f"Stream metadata invalid (resolution={self.width}x{self.height}, fps={self.fps}), "
                f"verifying connection by reading first frame..."
            )
            # 尝试读取一帧来验证连接
            ret, test_frame = self.cap.read()
            if not ret or test_frame is None:
                self.cap.release()
                raise RuntimeError(
                    f"Failed to verify stream connection: {self._sanitize_url(self.url)} "
                    f"(invalid metadata: {self.width}x{self.height}, {self.fps} FPS)"
                )
            # 从实际帧获取分辨率
            self.height, self.width = test_frame.shape[:2]
            self.logger.info(f"Verified stream with first frame: {self.width}x{self.height}")
            # 如果 FPS 仍然异常，使用默认值
            if self.fps <= 0 or self.fps > 1000:
                self.fps = 25.0  # 默认 FPS
                self.logger.info(f"Using default FPS: {self.fps}")

        self._last_read_time = time.time()

        self.logger.info(
            f"Connected to stream: {self._sanitize_url(self.url)} "
            f"({self.width}x{self.height}, {self.fps:.2f} FPS)"
        )

    def _reconnect(self) -> bool:
        """
        尝试重新连接（会持续重试直到成功或达到最大次数）

        Returns:
            是否重连成功
        """
        self._reconnecting = True
        try:
            return self._do_reconnect()
        finally:
            self._reconnecting = False

    def _do_reconnect(self) -> bool:
        """实际的重连逻辑"""
        while not self._closed:
            # 检查是否超过最大重试次数
            if (
                self.max_reconnect_attempts > 0
                and self._reconnect_count >= self.max_reconnect_attempts
            ):
                self.logger.error(
                    f"Max reconnect attempts ({self.max_reconnect_attempts}) reached, giving up"
                )
                return False

            # 先释放旧连接
            with self._cap_lock:
                if self.cap is not None:
                    self.cap.release()
                    self.cap = None

            self._reconnect_count += 1

            # 指数退避：间隔时间随重试次数增加，最大 60 秒
            wait_time = min(
                self.reconnect_interval * (2 ** min(self._reconnect_count - 1, 4)), 60
            )

            self.logger.info(
                f"Reconnecting (attempt {self._reconnect_count}), waiting {wait_time:.1f}s..."
            )

            time.sleep(wait_time)

            # 检查是否在等待期间被关闭
            if self._closed:
                self.logger.info("Reconnect cancelled due to close()")
                return False

            # 尝试重新连接
            try:
                self._connect()
                self.logger.info(
                    f"Reconnected successfully after {self._reconnect_count} attempt(s)"
                )
                self._reconnect_count = 0  # 重连成功后重置计数
                return True
            except Exception as e:
                self.logger.warning(f"Reconnect attempt {self._reconnect_count} failed: {e}")
                # 继续下一次尝试

        return False

    def _start_timeout_monitor(self):
        """
        启动超时监控线程

        用于检测 cap.read() 阻塞的情况。当检测到超时时，
        强制释放连接让阻塞的 read() 返回，由 _read_loop 触发重连。

        注意：只有在成功读取过至少一帧后才开始超时检测，
        避免在 Pipeline 初始化阶段误判。
        """

        def monitor():
            check_interval = max(1.0, min(self.timeout / 3, 10.0))

            self.logger.debug(
                f"Timeout monitor started (interval={check_interval:.1f}s, "
                f"timeout={self.timeout}s)"
            )

            while not self._closed:
                time.sleep(check_interval)

                if self._closed:
                    break

                # 没有读取时间记录，跳过
                if self._last_read_time is None:
                    continue

                # 只有成功读取过至少一帧后才开始检测
                if self._frame_count == 0:
                    continue

                # 正在重连时跳过检测
                if self._reconnecting:
                    continue

                # 检查是否超时
                elapsed = time.time() - self._last_read_time
                if elapsed > self.timeout:
                    self.logger.warning(
                        f"Timeout: no frame for {elapsed:.1f}s (threshold={self.timeout}s), "
                        f"releasing connection..."
                    )
                    # 释放连接，让阻塞的 cap.read() 返回
                    with self._cap_lock:
                        if self.cap is not None:
                            try:
                                self.cap.release()
                                self.cap = None
                                self.logger.debug("Connection released by timeout monitor")
                            except Exception as e:
                                self.logger.debug(f"Error releasing connection: {e}")

            self.logger.debug("Timeout monitor stopped")

        self._monitor_thread = threading.Thread(
            target=monitor, daemon=True, name=f"RTSPSource-Monitor-{self.source_id}"
        )
        self._monitor_thread.start()

    def _read_from_queue(self) -> Optional[Frame]:
        """
        从帧队列读取（threaded_read 模式）

        持续等待直到获取帧或 _closed=True。
        重连由 _read_loop 线程负责，此方法只负责从队列取帧。
        """
        while not self._closed:
            # 检查读取线程状态
            if self._read_thread is None or not self._read_thread.is_alive():
                if self._closed:
                    break
                self.logger.warning("Read thread not alive, restarting...")
                self._start_read_thread()

            try:
                # 短超时，以便及时响应 _closed 状态变化
                frame = self._frame_queue.get(timeout=1.0)
                return frame
            except queue.Empty:
                # 队列为空，继续等待
                # 日志级别用 debug，避免刷屏
                self.logger.debug("Queue empty, waiting for frames...")

        self.logger.debug("_read_from_queue exiting due to _closed=True")
        return None

    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        Returns:
            Frame 对象，如果流结束或达到最大重连次数则返回 None
        """
        return self._read_from_queue()

    def _is_connected(self) -> bool:
        """检查实际连接状态（内部方法）"""
        return self.cap is not None and self.cap.isOpened()

    def is_opened(self) -> bool:
        """
        检查流是否正在工作

        返回 True 表示流正在工作（包括重连中的情况）。
        只有 close() 被调用后才返回 False。
        """
        return not self._closed

    def _start_read_thread(self):
        """启动后台读取线程"""
        self._read_thread = threading.Thread(
            target=self._read_loop,
            daemon=True,
            name=f"RTSPSource-Reader-{self.source_id}",
        )
        self._read_thread.start()
        self.logger.info(f"Read thread started (queue_size={self.frame_queue_size})")

    def _read_loop(self):
        """
        后台读取循环

        职责：从流中读取帧、处理重连、放入队列。
        只有 _closed=True 或达到最大重连次数才退出。
        """
        self.logger.debug("Read loop started")

        while not self._closed:
            # 检查连接状态
            if not self._is_connected():
                self.logger.info("Read thread: connection lost, reconnecting...")
                if not self._reconnect():
                    self.logger.error("Read thread: reconnect failed, exiting")
                    break
                self.logger.info("Read thread: reconnected successfully")
                continue

            # 读取帧
            with self._cap_lock:
                if self.cap is None:
                    continue
                ret, image = self.cap.read()

            if not ret:
                self.logger.warning("Read thread: failed to read frame")
                continue  # 下次循环会检测到连接断开

            # 更新读取时间
            self._last_read_time = time.time()

            # 创建 Frame 对象
            frame = Frame(
                image=image,
                timestamp=time.time(),
                frame_id=self._frame_count,
                source_id=self.source_id,
                metadata={
                    "stream_url": self._sanitize_url(self.url),
                    "stream_fps": self.fps,
                    "reconnect_count": self._reconnect_count,
                    "threaded_read": True,
                },
            )
            self._frame_count += 1

            # 放入队列（如果满了就丢弃旧帧）
            try:
                self._frame_queue.put_nowait(frame)
            except queue.Full:
                try:
                    self._frame_queue.get_nowait()
                    self._dropped_frames += 1
                except queue.Empty:
                    pass
                try:
                    self._frame_queue.put_nowait(frame)
                except queue.Full:
                    pass

        self.logger.info("Read thread stopped")

    def close(self):
        """
        关闭流

        设置 _closed=True，停止所有线程，释放资源。
        这是唯一设置 _closed 的地方。
        """
        if self._closed:
            return  # 避免重复关闭

        self.logger.info(f"Closing stream: {self._sanitize_url(self.url)}")
        self._closed = True  # 通知所有线程退出

        # 等待读取线程退出
        if self._read_thread is not None and self._read_thread.is_alive():
            self._read_thread.join(timeout=2.0)
            if self._read_thread.is_alive():
                self.logger.warning("Read thread did not stop in time")

        # 等待监控线程退出
        if self._monitor_thread is not None and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=2.0)

        # 释放连接
        with self._cap_lock:
            if self.cap is not None:
                self.cap.release()
                self.cap = None

        self.logger.info(f"Stream closed: {self._sanitize_url(self.url)}")

    def __iter__(self):
        """
        支持重连的迭代器

        与基类不同，使用 _closed 判断是否退出，而不是 is_opened()。
        这样在重连期间（cap=None）不会导致迭代器退出。
        """
        while not self._closed:
            frame = self.read()
            if frame is None:
                if self._closed:
                    break
                # read() 返回 None 但 _closed=False，说明是达到最大重连次数
                self.logger.info("Iterator exiting: read() returned None")
                break
            yield frame

    def _sanitize_url(self, url: str) -> str:
        """隐藏 URL 中的敏感信息（用户名/密码）"""
        if "@" in url:
            # rtsp://user:pass@host:port/path -> rtsp://***@host:port/path
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_path = rest.split("@", 1)
                return f"{protocol}://***@{host_path}"
        return url

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()

        # 运行状态
        read_thread_alive = self._read_thread is not None and self._read_thread.is_alive()
        monitor_thread_alive = self._monitor_thread is not None and self._monitor_thread.is_alive()

        stats.update(
            {
                "stream_url": self._sanitize_url(self.url),
                "transport": self.transport or "default",
                "fps": self.fps if hasattr(self, "fps") else 0,
                "resolution": (self.width, self.height) if hasattr(self, "width") else (0, 0),
                "reconnect_count": self._reconnect_count,
                "buffer_size": self.buffer_size,
                "dropped_frames": self._dropped_frames,
                "queue_size": self._frame_queue.qsize(),
                # 运行状态
                "connected": self._is_connected(),
                "closed": self._closed,
                "read_thread_alive": read_thread_alive,
                "monitor_thread_alive": monitor_thread_alive,
            }
        )
        return stats


@register_source("GStreamerSource")
class GStreamerSource(Source):
    """
    GStreamer 视频流源（Jetson 硬件加速）

    使用 GStreamer pipeline 实现高性能、低延迟的流媒体处理。
    在 Jetson 平台上自动启用硬件解码（nvv4l2decoder）。

    特性：
    - 硬件加速解码（H.264/H.265）
    - 低延迟（< 100ms）
    - 支持 RTSP/RTMP/HLS/UDP
    - 自动协议检测
    - CPU 降级机制

    Attributes:
        url: 流媒体 URL
        protocol: 协议类型（auto/rtsp/rtmp/hls/udp）
        use_hw_decoder: 是否使用硬件解码
        latency_ms: 延迟设置（毫秒）

    Examples:
        >>> # RTSP 流（硬件加速）
        >>> source = GStreamerSource("rtsp://192.168.1.100:554/stream1")

        >>> # RTMP 流
        >>> source = GStreamerSource("rtmp://server/live/stream", protocol="rtmp")

        >>> # 关闭硬件加速（CPU 解码）
        >>> source = GStreamerSource("rtsp://...", use_hw_decoder=False)
    """

    def __init__(
        self,
        url: str,
        protocol: str = "auto",
        use_hw_decoder: bool = True,
        latency_ms: int = 100,
        source_id: Optional[str] = None,
    ):
        """
        初始化 GStreamer 流源

        Args:
            url: 流媒体 URL
            protocol: 协议类型（auto/rtsp/rtmp/hls/udp，默认 auto）
            use_hw_decoder: 是否使用硬件解码（默认 True，Jetson 平台）
            latency_ms: 延迟设置（毫秒，默认 100）
            source_id: 数据源 ID（默认从 URL 提取）

        Raises:
            ImportError: 如果 OpenCV 未安装
            RuntimeError: 如果初始连接失败
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for GStreamerSource. "
                "Install with: pip install jupiter-stream[cv]"
            )

        # 从 URL 提取 source_id
        if source_id is None:
            try:
                host = url.split("://")[1].split("/")[0].split("@")[-1].split(":")[0]
                source_id = f"gst:{host}"
            except Exception:
                source_id = "gst:unknown"

        super().__init__(source_id)

        self.url = url
        self.protocol = protocol
        self.use_hw_decoder = use_hw_decoder and self._is_jetson()
        self.latency_ms = latency_ms

        # 检测协议
        if protocol == "auto":
            self.protocol = self._detect_protocol(url)

        # 构建 GStreamer pipeline
        pipeline = self._build_pipeline()

        self.logger.info(
            f"GStreamer pipeline: {pipeline[:100]}..."
            if len(pipeline) > 100
            else f"GStreamer pipeline: {pipeline}"
        )

        # 打开流
        self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)

        if not self.cap.isOpened():
            # 如果硬件解码失败，尝试 CPU 降级
            if self.use_hw_decoder:
                self.logger.warning(
                    "Failed to open stream with hardware decoder, " "falling back to CPU decoder..."
                )
                self.use_hw_decoder = False
                pipeline = self._build_pipeline()
                self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)

            if not self.cap.isOpened():
                raise RuntimeError(
                    f"Failed to open GStreamer stream: {self._sanitize_url(self.url)}"
                )

        # 获取流属性
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        decoder_type = "HW" if self.use_hw_decoder else "CPU"
        self.logger.info(
            f"Opened GStreamer stream ({decoder_type}): {self._sanitize_url(self.url)} "
            f"({self.width}x{self.height}, {self.fps:.2f} FPS)"
        )

    def _is_jetson(self) -> bool:
        """检测是否为 Jetson 平台"""
        try:
            # 检查 /etc/nv_tegra_release 文件（Jetson 特有）
            with open("/etc/nv_tegra_release") as f:
                return "tegra" in f.read().lower()
        except FileNotFoundError:
            return False

    def _detect_protocol(self, url: str) -> str:
        """自动检测协议类型"""
        url_lower = url.lower()
        if url_lower.startswith("rtsp://"):
            return "rtsp"
        elif url_lower.startswith("rtmp://"):
            return "rtmp"
        elif url_lower.startswith("http://") or url_lower.startswith("https://"):
            if ".m3u8" in url_lower:
                return "hls"
            return "http"
        elif url_lower.startswith("udp://"):
            return "udp"
        else:
            self.logger.warning(f"Unknown protocol in URL: {url}, defaulting to rtsp")
            return "rtsp"

    def _build_pipeline(self) -> str:
        """构建 GStreamer pipeline"""
        # 解码器选择
        if self.use_hw_decoder:
            decoder = "nvv4l2decoder"  # Jetson 硬件解码
            converter = "nvvidconv ! video/x-raw,format=BGRx ! videoconvert"
        else:
            decoder = "avdec_h264"  # CPU 软件解码
            converter = "videoconvert"

        # 根据协议构建 pipeline
        if self.protocol == "rtsp":
            pipeline = (
                f"rtspsrc location={self.url} latency={self.latency_ms} "
                f"! rtph264depay ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        elif self.protocol == "rtmp":
            pipeline = (
                f"rtmpsrc location={self.url} "
                f"! flvdemux ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        elif self.protocol == "hls":
            pipeline = (
                f"souphttpsrc location={self.url} "
                f"! hlsdemux ! tsdemux ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        elif self.protocol == "udp":
            pipeline = (
                f"udpsrc uri={self.url} "
                f"! application/x-rtp,encoding-name=H264 "
                f"! rtph264depay ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        else:  # http or unknown
            pipeline = (
                f"souphttpsrc location={self.url} "
                f"! decodebin "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        return pipeline

    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        Returns:
            Frame 对象，如果流结束则返回 None
        """
        if not self.is_opened():
            return None

        ret, image = self.cap.read()

        if not ret:
            self.logger.warning("Failed to read frame from GStreamer stream")
            return None

        # 创建 Frame 对象
        frame = Frame(
            image=image,
            timestamp=time.time(),
            frame_id=self._frame_count,
            source_id=self.source_id,
            metadata={
                "stream_url": self._sanitize_url(self.url),
                "stream_protocol": self.protocol,
                "stream_fps": self.fps,
                "hw_decoder": self.use_hw_decoder,
            },
        )

        self._frame_count += 1
        return frame

    def is_opened(self) -> bool:
        """检查流是否打开"""
        return self.cap is not None and self.cap.isOpened()

    def close(self):
        """关闭流"""
        if self.cap is not None:
            self.cap.release()
            self.logger.info(f"Closed GStreamer stream: {self._sanitize_url(self.url)}")

    def _sanitize_url(self, url: str) -> str:
        """隐藏 URL 中的敏感信息（用户名/密码）"""
        if "@" in url:
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_path = rest.split("@", 1)
                return f"{protocol}://***@{host_path}"
        return url

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "stream_url": self._sanitize_url(self.url),
                "protocol": self.protocol,
                "fps": self.fps,
                "resolution": (self.width, self.height),
                "hw_decoder": self.use_hw_decoder,
                "latency_ms": self.latency_ms,
            }
        )
        return stats


@register_source("StreamSource")
class StreamSource(Source):
    """
    统一流媒体源（自动选择最优实现）

    智能选择最优的流媒体后端：
    - Jetson 平台 + GStreamer 可用 → GStreamerSource (硬件加速)
    - 其他情况 → RTSPSource (OpenCV)

    这是推荐使用的流媒体 Source，可自动适配不同平台。

    Attributes:
        url: 流媒体 URL
        backend: 使用的后端（gstreamer/opencv）

    Examples:
        >>> # 自动选择最优后端
        >>> source = StreamSource("rtsp://192.168.1.100:554/stream1")
        >>> print(source.backend)  # gstreamer (on Jetson) or opencv (others)

        >>> # 配置文件使用
        >>> source:
        >>>   type: StreamSource
        >>>   params:
        >>>     url: "rtsp://192.168.1.100:554/stream1"
    """

    def __init__(self, url: str, source_id: Optional[str] = None, **kwargs):
        """
        初始化统一流媒体源

        Args:
            url: 流媒体 URL
            source_id: 数据源 ID（可选）
            **kwargs: 传递给底层 Source 的额外参数

        Raises:
            ImportError: 如果 OpenCV 未安装
            RuntimeError: 如果初始连接失败
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for StreamSource. "
                "Install with: pip install jupiter-stream[cv]"
            )

        # 不调用 super().__init__()，因为我们会委托给实际的 Source
        # 但我们需要设置 logger
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

        # 选择后端
        self.backend = self._select_backend(url)

        # 创建实际的 Source 实例
        if self.backend == "gstreamer":
            self.logger.info(f"Using GStreamerSource backend for {self._sanitize_url(url)}")
            self._source = GStreamerSource(url, source_id=source_id, **kwargs)
        else:
            self.logger.info(f"Using RTSPSource backend for {self._sanitize_url(url)}")
            self._source = RTSPSource(url, source_id=source_id, **kwargs)

        # 委托属性
        self.source_id = self._source.source_id
        self._frame_count = 0  # StreamSource 保持自己的计数

    def _select_backend(self, url: str) -> str:
        """
        选择后端

        Returns:
            始终返回 "opencv"（RTSPSource），因为它有完整的重连机制
        """
        # 强制使用 RTSPSource，因为 GStreamerSource 没有重连机制
        return "opencv"

    def _is_jetson(self) -> bool:
        """检测是否为 Jetson 平台"""
        try:
            with open("/etc/nv_tegra_release") as f:
                return "tegra" in f.read().lower()
        except FileNotFoundError:
            return False

    def _check_gstreamer(self) -> bool:
        """检测 GStreamer 是否可用"""
        try:
            # 尝试创建一个简单的测试 pipeline
            test_pipeline = "videotestsrc num-buffers=1 ! appsink"
            test_cap = cv2.VideoCapture(test_pipeline, cv2.CAP_GSTREAMER)
            is_available = test_cap.isOpened()
            test_cap.release()
            return is_available
        except Exception as e:
            self.logger.debug(f"GStreamer check failed: {e}")
            return False

    def read(self) -> Optional[Frame]:
        """委托给底层 Source"""
        frame = self._source.read()
        if frame is not None:
            self._frame_count += 1
        return frame

    def is_opened(self) -> bool:
        """委托给底层 Source"""
        return self._source.is_opened()

    def close(self):
        """委托给底层 Source"""
        self._source.close()

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = self._source.get_stats()
        stats["backend"] = self.backend
        return stats

    def __iter__(self):
        """委托给底层 Source"""
        return self._source.__iter__()

    def __enter__(self):
        """委托给底层 Source"""
        self._source.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """委托给底层 Source"""
        self._source.__exit__(exc_type, exc_val, exc_tb)

    def _sanitize_url(self, url: str) -> str:
        """隐藏 URL 中的敏感信息"""
        if "@" in url:
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_path = rest.split("@", 1)
                return f"{protocol}://***@{host_path}"
        return url
