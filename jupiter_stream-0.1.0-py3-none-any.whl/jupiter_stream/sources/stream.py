"""Network stream source implementations (RTSP/RTMP/HLS)."""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Literal, Optional

from ..core import Frame, Source
from ..core.pipeline.registry import register_source

try:
    import cv2
except ImportError:
    cv2 = None


@register_source("RTSPSource")
class RTSPSource(Source):
    """
    RTSP 视频流源（基于 OpenCV）

    通过 OpenCV 的 VideoCapture 读取 RTSP/RTMP/HTTP 流。
    实现简单可靠，兼容性好，适用于大多数场景。

    特性：
    - 自动重连机制（指数退避）
    - 超时检测和恢复
    - 缓冲区优化（减少延迟）
    - 支持 RTSP/RTMP/HTTP 等多种协议

    Attributes:
        url: 流媒体 URL
        transport: 传输协议（tcp/udp）
        reconnect_interval: 重连间隔（秒）
        timeout: 读取超时（秒）
        buffer_size: 缓冲区大小（帧数，建议 1-3）
        max_reconnect_attempts: 最大重连次数（0 表示无限重试）

    Examples:
        >>> # RTSP 流
        >>> source = RTSPSource("rtsp://admin:password@192.168.1.100:554/stream1")
        >>> for frame in source:
        ...     process(frame)

        >>> # 使用 TCP 传输（更可靠，适合网络不稳定场景）
        >>> source = RTSPSource("rtsp://192.168.1.100:554/stream1", transport="tcp")

        >>> # RTMP 流
        >>> source = RTSPSource("rtmp://server/live/stream")

        >>> # HTTP 流
        >>> source = RTSPSource("http://server:8080/video.mjpg")
    """

    def __init__(
        self,
        url: str,
        transport: Optional[Literal["tcp", "udp"]] = None,
        reconnect_interval: int = 5,
        timeout: int = 10,
        buffer_size: int = 1,
        max_reconnect_attempts: int = 0,
        source_id: Optional[str] = None,
    ):
        """
        初始化 RTSP 流源

        Args:
            url: RTSP/RTMP/HTTP URL
            transport: RTSP 传输协议（"tcp" 或 "udp"，默认 None 使用系统默认）
                      - tcp: 更可靠，丢包会重传，但延迟略高
                      - udp: 延迟低，但可能丢包导致花屏
                      建议网络不稳定时使用 tcp
            reconnect_interval: 重连间隔（秒，默认 5）
            timeout: 读取超时（秒，默认 10）
            buffer_size: 缓冲区大小（帧数，默认 1，建议 1-3）
            max_reconnect_attempts: 最大重连次数（默认 0 表示无限重试）
            source_id: 数据源 ID（默认从 URL 提取）

        Raises:
            ImportError: 如果 OpenCV 未安装
            RuntimeError: 如果初始连接失败
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for RTSPSource. " "Install with: pip install jupiter-stream[cv]"
            )

        # 从 URL 提取 source_id
        if source_id is None:
            # 提取 host 部分作为 ID，例如 rtsp://192.168.1.100:554/stream1 -> 192.168.1.100
            try:
                host = url.split("://")[1].split("/")[0].split("@")[-1].split(":")[0]
                source_id = f"stream:{host}"
            except Exception:
                source_id = "stream:unknown"

        super().__init__(source_id)

        self.url = url
        self.transport = transport
        self.reconnect_interval = reconnect_interval
        self.timeout = timeout
        self.buffer_size = buffer_size
        self.max_reconnect_attempts = max_reconnect_attempts

        # 状态跟踪
        self.cap = None
        self._last_read_time = None
        self._reconnect_count = 0
        self._is_opened = False

        # 超时监控线程
        self._stop_monitor = False
        self._monitor_thread = None
        self._force_reconnect_flag = False
        self._cap_lock = threading.Lock()
        self._reconnecting = False  # 重连中标志，防止超时监控干扰

        # 尝试初始连接
        self._connect()

        # 启动超时监控线程
        self._start_timeout_monitor()

    def _connect(self):
        """建立连接"""
        transport_info = f", transport={self.transport}" if self.transport else ""
        self.logger.info(f"Connecting to stream: {self._sanitize_url(self.url)}{transport_info}")

        # 设置 FFmpeg 选项（如 RTSP 传输协议）
        old_ffmpeg_options = os.environ.get("OPENCV_FFMPEG_CAPTURE_OPTIONS", "")
        if self.transport:
            os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = f"rtsp_transport;{self.transport}"

        try:
            # 使用 FFmpeg 后端打开流
            self.cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG)
        finally:
            # 恢复原来的环境变量
            if self.transport:
                if old_ffmpeg_options:
                    os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = old_ffmpeg_options
                else:
                    os.environ.pop("OPENCV_FFMPEG_CAPTURE_OPTIONS", None)

        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to connect to stream: {self._sanitize_url(self.url)}")

        # 设置缓冲区大小（减少延迟）
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, self.buffer_size)

        # 获取流属性
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        self._is_opened = True
        self._last_read_time = time.time()
        self._reconnect_count = 0

        self.logger.info(
            f"Connected to stream: {self._sanitize_url(self.url)} "
            f"({self.width}x{self.height}, {self.fps:.2f} FPS)"
        )

    def _reconnect(self) -> bool:
        """
        尝试重新连接（会持续重试直到成功或达到最大次数）

        Returns:
            是否重连成功
        """
        self._reconnecting = True  # 标记正在重连，防止超时监控干扰

        try:
            while True:
                # 检查是否超过最大重试次数
                if (
                    self.max_reconnect_attempts > 0
                    and self._reconnect_count >= self.max_reconnect_attempts
                ):
                    self.logger.error(
                        f"Max reconnect attempts ({self.max_reconnect_attempts}) reached. Giving up."
                    )
                    return False

                # 先释放旧连接（避免资源占用和连接数限制问题）
                with self._cap_lock:
                    if self.cap is not None:
                        self.cap.release()
                        self.cap = None

                self._reconnect_count += 1

                # 指数退避：间隔时间随重试次数增加，最大 60 秒
                # 限制指数增长的次数，避免过长等待
                wait_time = min(
                    self.reconnect_interval * (2 ** min(self._reconnect_count - 1, 4)), 60
                )

                self.logger.warning(
                    f"Reconnecting to stream (attempt {self._reconnect_count}), "
                    f"waiting {wait_time:.1f}s..."
                )

                time.sleep(wait_time)

                # 尝试重新连接
                try:
                    self._connect()
                    self.logger.info(
                        f"Reconnected successfully after {self._reconnect_count} attempts"
                    )
                    return True
                except Exception as e:
                    self.logger.error(f"Reconnect attempt {self._reconnect_count} failed: {e}")
                    # 继续下一次尝试，不返回 False
        finally:
            self._reconnecting = False

    def _start_timeout_monitor(self):
        """
        启动超时监控线程

        独立于 read() 调用的监控线程，用于检测 read() 阻塞的情况。
        当检测到超时时，强制释放连接让阻塞的 read() 返回。

        注意：只有在成功读取过至少一帧后才开始超时检测，
        避免在 Pipeline 初始化阶段误判。
        """

        def monitor():
            # 检查间隔：timeout 的 1/3，但至少 1 秒，最多 10 秒
            check_interval = max(1.0, min(self.timeout / 3, 10.0))

            self.logger.debug(
                f"Timeout monitor started (check_interval={check_interval:.1f}s, "
                f"timeout={self.timeout}s)"
            )

            while not self._stop_monitor:
                time.sleep(check_interval)

                # 如果已停止监控，直接退出
                if self._stop_monitor:
                    break

                # 如果未打开或没有读取时间记录，跳过检测
                if not self._is_opened or self._last_read_time is None:
                    continue

                # 如果正在重连，跳过超时检测（避免干扰重连过程）
                if self._reconnecting:
                    continue

                # 只有在成功读取过至少一帧后才开始超时检测
                # 这样可以避免在 Pipeline 初始化阶段（加载模型等）误判
                if self._frame_count == 0:
                    continue

                # 计算自上次成功读取以来的时间
                elapsed = time.time() - self._last_read_time

                # 如果超时，触发强制重连
                if elapsed > self.timeout:
                    self.logger.warning(
                        f"Timeout monitor: no frame for {elapsed:.1f}s "
                        f"(threshold: {self.timeout}s), forcing reconnect..."
                    )
                    self._force_reconnect()

            self.logger.debug("Timeout monitor stopped")

        self._stop_monitor = False
        self._monitor_thread = threading.Thread(
            target=monitor, daemon=True, name=f"RTSPSource-Monitor-{self.source_id}"
        )
        self._monitor_thread.start()

    def _force_reconnect(self):
        """
        强制重连（用于中断阻塞的 read() 调用）

        通过释放 VideoCapture 连接来强制让阻塞的 read() 返回。
        设置标志让 read() 方法知道需要重连。

        注意：不要在这里设置 _is_opened = False，否则会导致 Source.__iter__()
        的循环退出，Pipeline 会意外清理退出。应该让 read() 方法处理重连逻辑。
        """
        self.logger.info("Force reconnecting due to timeout...")

        # 设置强制重连标志
        self._force_reconnect_flag = True

        # 释放当前连接（这会让阻塞的 read() 返回）
        with self._cap_lock:
            if self.cap is not None:
                try:
                    self.cap.release()
                    self.logger.debug("Released VideoCapture to unblock read()")
                except Exception as e:
                    self.logger.debug(f"Error releasing VideoCapture: {e}")

            # 注意：不要设置 self._is_opened = False
            # 让 read() 方法检测 _force_reconnect_flag 并处理重连

    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        Returns:
            Frame 对象，如果流结束或重连失败则返回 None
        """
        # 检查是否需要强制重连（由监控线程触发）
        if self._force_reconnect_flag:
            self._force_reconnect_flag = False
            self.logger.info("Handling force reconnect triggered by timeout monitor")
            if not self._reconnect():
                return None

        if not self.is_opened():
            return None

        # 超时检测（作为备份机制，主要依赖监控线程）
        if self._last_read_time is not None:
            elapsed = time.time() - self._last_read_time
            if elapsed > self.timeout:
                self.logger.warning(
                    f"Read timeout ({elapsed:.1f}s > {self.timeout}s), reconnecting..."
                )
                if not self._reconnect():
                    return None

        # 执行读取（可能阻塞，但监控线程会检测并强制中断）
        with self._cap_lock:
            if self.cap is None:
                return None
            ret, image = self.cap.read()

        # 检查是否是监控线程强制中断的
        if self._force_reconnect_flag:
            self._force_reconnect_flag = False
            self.logger.info("Read interrupted by timeout monitor, reconnecting...")
            if not self._reconnect():
                return None
            # 重连后再次尝试读取
            with self._cap_lock:
                if self.cap is None:
                    return None
                ret, image = self.cap.read()
                if not ret:
                    return None

        if not ret:
            self.logger.warning("Failed to read frame, reconnecting...")
            if not self._reconnect():
                return None
            # 重连后再次尝试读取
            with self._cap_lock:
                if self.cap is None:
                    return None
                ret, image = self.cap.read()
                if not ret:
                    return None

        # 更新读取时间
        self._last_read_time = time.time()

        # 创建 Frame 对象
        frame = Frame(
            image=image,
            timestamp=time.time(),
            frame_id=self._frame_count,
            source_id=self.source_id,
            metadata={
                "stream_url": self._sanitize_url(self.url),
                "stream_fps": self.fps,
                "reconnect_count": self._reconnect_count,
            },
        )

        self._frame_count += 1
        return frame

    def is_opened(self) -> bool:
        """检查流是否打开"""
        return self._is_opened and self.cap is not None and self.cap.isOpened()

    def close(self):
        """关闭流"""
        # 停止监控线程
        self._stop_monitor = True
        if self._monitor_thread is not None and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=2.0)

        # 关闭连接
        with self._cap_lock:
            if self.cap is not None:
                self.cap.release()
                self._is_opened = False
        self.logger.info(f"Closed stream: {self._sanitize_url(self.url)}")

    def _sanitize_url(self, url: str) -> str:
        """隐藏 URL 中的敏感信息（用户名/密码）"""
        if "@" in url:
            # rtsp://user:pass@host:port/path -> rtsp://***@host:port/path
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_path = rest.split("@", 1)
                return f"{protocol}://***@{host_path}"
        return url

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "stream_url": self._sanitize_url(self.url),
                "transport": self.transport or "default",
                "fps": self.fps if hasattr(self, "fps") else 0,
                "resolution": (self.width, self.height) if hasattr(self, "width") else (0, 0),
                "reconnect_count": self._reconnect_count,
                "buffer_size": self.buffer_size,
            }
        )
        return stats


@register_source("GStreamerSource")
class GStreamerSource(Source):
    """
    GStreamer 视频流源（Jetson 硬件加速）

    使用 GStreamer pipeline 实现高性能、低延迟的流媒体处理。
    在 Jetson 平台上自动启用硬件解码（nvv4l2decoder）。

    特性：
    - 硬件加速解码（H.264/H.265）
    - 低延迟（< 100ms）
    - 支持 RTSP/RTMP/HLS/UDP
    - 自动协议检测
    - CPU 降级机制

    Attributes:
        url: 流媒体 URL
        protocol: 协议类型（auto/rtsp/rtmp/hls/udp）
        use_hw_decoder: 是否使用硬件解码
        latency_ms: 延迟设置（毫秒）

    Examples:
        >>> # RTSP 流（硬件加速）
        >>> source = GStreamerSource("rtsp://192.168.1.100:554/stream1")

        >>> # RTMP 流
        >>> source = GStreamerSource("rtmp://server/live/stream", protocol="rtmp")

        >>> # 关闭硬件加速（CPU 解码）
        >>> source = GStreamerSource("rtsp://...", use_hw_decoder=False)
    """

    def __init__(
        self,
        url: str,
        protocol: str = "auto",
        use_hw_decoder: bool = True,
        latency_ms: int = 100,
        source_id: Optional[str] = None,
    ):
        """
        初始化 GStreamer 流源

        Args:
            url: 流媒体 URL
            protocol: 协议类型（auto/rtsp/rtmp/hls/udp，默认 auto）
            use_hw_decoder: 是否使用硬件解码（默认 True，Jetson 平台）
            latency_ms: 延迟设置（毫秒，默认 100）
            source_id: 数据源 ID（默认从 URL 提取）

        Raises:
            ImportError: 如果 OpenCV 未安装
            RuntimeError: 如果初始连接失败
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for GStreamerSource. "
                "Install with: pip install jupiter-stream[cv]"
            )

        # 从 URL 提取 source_id
        if source_id is None:
            try:
                host = url.split("://")[1].split("/")[0].split("@")[-1].split(":")[0]
                source_id = f"gst:{host}"
            except Exception:
                source_id = "gst:unknown"

        super().__init__(source_id)

        self.url = url
        self.protocol = protocol
        self.use_hw_decoder = use_hw_decoder and self._is_jetson()
        self.latency_ms = latency_ms

        # 检测协议
        if protocol == "auto":
            self.protocol = self._detect_protocol(url)

        # 构建 GStreamer pipeline
        pipeline = self._build_pipeline()

        self.logger.info(
            f"GStreamer pipeline: {pipeline[:100]}..."
            if len(pipeline) > 100
            else f"GStreamer pipeline: {pipeline}"
        )

        # 打开流
        self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)

        if not self.cap.isOpened():
            # 如果硬件解码失败，尝试 CPU 降级
            if self.use_hw_decoder:
                self.logger.warning(
                    "Failed to open stream with hardware decoder, " "falling back to CPU decoder..."
                )
                self.use_hw_decoder = False
                pipeline = self._build_pipeline()
                self.cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)

            if not self.cap.isOpened():
                raise RuntimeError(
                    f"Failed to open GStreamer stream: {self._sanitize_url(self.url)}"
                )

        # 获取流属性
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        decoder_type = "HW" if self.use_hw_decoder else "CPU"
        self.logger.info(
            f"Opened GStreamer stream ({decoder_type}): {self._sanitize_url(self.url)} "
            f"({self.width}x{self.height}, {self.fps:.2f} FPS)"
        )

    def _is_jetson(self) -> bool:
        """检测是否为 Jetson 平台"""
        try:
            # 检查 /etc/nv_tegra_release 文件（Jetson 特有）
            with open("/etc/nv_tegra_release") as f:
                return "tegra" in f.read().lower()
        except FileNotFoundError:
            return False

    def _detect_protocol(self, url: str) -> str:
        """自动检测协议类型"""
        url_lower = url.lower()
        if url_lower.startswith("rtsp://"):
            return "rtsp"
        elif url_lower.startswith("rtmp://"):
            return "rtmp"
        elif url_lower.startswith("http://") or url_lower.startswith("https://"):
            if ".m3u8" in url_lower:
                return "hls"
            return "http"
        elif url_lower.startswith("udp://"):
            return "udp"
        else:
            self.logger.warning(f"Unknown protocol in URL: {url}, defaulting to rtsp")
            return "rtsp"

    def _build_pipeline(self) -> str:
        """构建 GStreamer pipeline"""
        # 解码器选择
        if self.use_hw_decoder:
            decoder = "nvv4l2decoder"  # Jetson 硬件解码
            converter = "nvvidconv ! video/x-raw,format=BGRx ! videoconvert"
        else:
            decoder = "avdec_h264"  # CPU 软件解码
            converter = "videoconvert"

        # 根据协议构建 pipeline
        if self.protocol == "rtsp":
            pipeline = (
                f"rtspsrc location={self.url} latency={self.latency_ms} "
                f"! rtph264depay ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        elif self.protocol == "rtmp":
            pipeline = (
                f"rtmpsrc location={self.url} "
                f"! flvdemux ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        elif self.protocol == "hls":
            pipeline = (
                f"souphttpsrc location={self.url} "
                f"! hlsdemux ! tsdemux ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        elif self.protocol == "udp":
            pipeline = (
                f"udpsrc uri={self.url} "
                f"! application/x-rtp,encoding-name=H264 "
                f"! rtph264depay ! h264parse "
                f"! {decoder} "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        else:  # http or unknown
            pipeline = (
                f"souphttpsrc location={self.url} "
                f"! decodebin "
                f"! {converter} ! video/x-raw,format=BGR "
                f"! appsink max-buffers=1 drop=true"
            )

        return pipeline

    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        Returns:
            Frame 对象，如果流结束则返回 None
        """
        if not self.is_opened():
            return None

        ret, image = self.cap.read()

        if not ret:
            self.logger.warning("Failed to read frame from GStreamer stream")
            return None

        # 创建 Frame 对象
        frame = Frame(
            image=image,
            timestamp=time.time(),
            frame_id=self._frame_count,
            source_id=self.source_id,
            metadata={
                "stream_url": self._sanitize_url(self.url),
                "stream_protocol": self.protocol,
                "stream_fps": self.fps,
                "hw_decoder": self.use_hw_decoder,
            },
        )

        self._frame_count += 1
        return frame

    def is_opened(self) -> bool:
        """检查流是否打开"""
        return self.cap is not None and self.cap.isOpened()

    def close(self):
        """关闭流"""
        if self.cap is not None:
            self.cap.release()
            self.logger.info(f"Closed GStreamer stream: {self._sanitize_url(self.url)}")

    def _sanitize_url(self, url: str) -> str:
        """隐藏 URL 中的敏感信息（用户名/密码）"""
        if "@" in url:
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_path = rest.split("@", 1)
                return f"{protocol}://***@{host_path}"
        return url

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "stream_url": self._sanitize_url(self.url),
                "protocol": self.protocol,
                "fps": self.fps,
                "resolution": (self.width, self.height),
                "hw_decoder": self.use_hw_decoder,
                "latency_ms": self.latency_ms,
            }
        )
        return stats


@register_source("StreamSource")
class StreamSource(Source):
    """
    统一流媒体源（自动选择最优实现）

    智能选择最优的流媒体后端：
    - Jetson 平台 + GStreamer 可用 → GStreamerSource (硬件加速)
    - 其他情况 → RTSPSource (OpenCV)

    这是推荐使用的流媒体 Source，可自动适配不同平台。

    Attributes:
        url: 流媒体 URL
        backend: 使用的后端（gstreamer/opencv）

    Examples:
        >>> # 自动选择最优后端
        >>> source = StreamSource("rtsp://192.168.1.100:554/stream1")
        >>> print(source.backend)  # gstreamer (on Jetson) or opencv (others)

        >>> # 配置文件使用
        >>> source:
        >>>   type: StreamSource
        >>>   params:
        >>>     url: "rtsp://192.168.1.100:554/stream1"
    """

    def __init__(self, url: str, source_id: Optional[str] = None, **kwargs):
        """
        初始化统一流媒体源

        Args:
            url: 流媒体 URL
            source_id: 数据源 ID（可选）
            **kwargs: 传递给底层 Source 的额外参数

        Raises:
            ImportError: 如果 OpenCV 未安装
            RuntimeError: 如果初始连接失败
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for StreamSource. "
                "Install with: pip install jupiter-stream[cv]"
            )

        # 不调用 super().__init__()，因为我们会委托给实际的 Source
        # 但我们需要设置 logger
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

        # 选择后端
        self.backend = self._select_backend(url)

        # 创建实际的 Source 实例
        if self.backend == "gstreamer":
            self.logger.info(f"Using GStreamerSource backend for {self._sanitize_url(url)}")
            self._source = GStreamerSource(url, source_id=source_id, **kwargs)
        else:
            self.logger.info(f"Using RTSPSource backend for {self._sanitize_url(url)}")
            self._source = RTSPSource(url, source_id=source_id, **kwargs)

        # 委托属性
        self.source_id = self._source.source_id
        self._frame_count = 0  # StreamSource 保持自己的计数

    def _select_backend(self, url: str) -> str:
        """
        选择最优后端

        Returns:
            "gstreamer" 或 "opencv"
        """
        # 检测是否为 Jetson 平台
        if self._is_jetson():
            # 检测 GStreamer 是否可用
            if self._check_gstreamer():
                return "gstreamer"

        return "opencv"

    def _is_jetson(self) -> bool:
        """检测是否为 Jetson 平台"""
        try:
            with open("/etc/nv_tegra_release") as f:
                return "tegra" in f.read().lower()
        except FileNotFoundError:
            return False

    def _check_gstreamer(self) -> bool:
        """检测 GStreamer 是否可用"""
        try:
            # 尝试创建一个简单的测试 pipeline
            test_pipeline = "videotestsrc num-buffers=1 ! appsink"
            test_cap = cv2.VideoCapture(test_pipeline, cv2.CAP_GSTREAMER)
            is_available = test_cap.isOpened()
            test_cap.release()
            return is_available
        except Exception as e:
            self.logger.debug(f"GStreamer check failed: {e}")
            return False

    def read(self) -> Optional[Frame]:
        """委托给底层 Source"""
        frame = self._source.read()
        if frame is not None:
            self._frame_count += 1
        return frame

    def is_opened(self) -> bool:
        """委托给底层 Source"""
        return self._source.is_opened()

    def close(self):
        """委托给底层 Source"""
        self._source.close()

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = self._source.get_stats()
        stats["backend"] = self.backend
        return stats

    def __iter__(self):
        """委托给底层 Source"""
        return self._source.__iter__()

    def __enter__(self):
        """委托给底层 Source"""
        self._source.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """委托给底层 Source"""
        self._source.__exit__(exc_type, exc_val, exc_tb)

    def _sanitize_url(self, url: str) -> str:
        """隐藏 URL 中的敏感信息"""
        if "@" in url:
            protocol, rest = url.split("://", 1)
            if "@" in rest:
                credentials, host_path = rest.split("@", 1)
                return f"{protocol}://***@{host_path}"
        return url
