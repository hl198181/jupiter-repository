"""Folder source implementation for processing multiple video files sequentially."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from ..core import Frame, Source
from ..core.pipeline.registry import register_source
from .video import VideoSource


@register_source("FolderSource")
class FolderSource(Source):
    """
    文件夹视频源

    从文件夹中顺序读取多个视频文件，像处理单个连续视频流一样。
    当一个视频读取完毕后，自动切换到下一个视频。

    Attributes:
        folder_path: 文件夹路径
        extension: 视频文件扩展名（默认 ".mp4"）
        video_files: 文件夹中的视频文件列表
        current_index: 当前正在处理的视频索引
        current_source: 当前 VideoSource 实例

    Examples:
        >>> source = FolderSource("/path/to/videos")
        >>> for frame in source:
        ...     print(frame.metadata['video_name'])

        >>> # 指定文件扩展名
        >>> source = FolderSource("/path/to/videos", extension=".avi")
    """

    def __init__(
        self,
        folder_path: str,
        extension: str = ".mp4",
        source_id: Optional[str] = None,
        **video_kwargs,
    ):
        """
        初始化文件夹视频源

        Args:
            folder_path: 文件夹路径
            extension: 视频文件扩展名（默认 ".mp4"）
            source_id: 数据源ID（默认使用文件夹名）
            **video_kwargs: 传递给 VideoSource 的其他参数（如 start_frame, end_frame）

        Raises:
            FileNotFoundError: 如果文件夹不存在
            ValueError: 如果文件夹中没有匹配的视频文件
        """
        self.folder_path = Path(folder_path)

        if not self.folder_path.exists():
            raise FileNotFoundError(f"Folder not found: {folder_path}")

        if not self.folder_path.is_dir():
            raise ValueError(f"Path is not a directory: {folder_path}")

        # 使用文件夹名作为 source_id
        if source_id is None:
            source_id = f"folder:{self.folder_path.name}"

        super().__init__(source_id)

        self.extension = extension.lower()
        if not self.extension.startswith("."):
            self.extension = "." + self.extension

        # 扫描文件夹获取所有视频文件并排序
        self.video_files = sorted(
            [
                f
                for f in self.folder_path.iterdir()
                if f.is_file() and f.suffix.lower() == self.extension
            ]
        )

        if not self.video_files:
            raise ValueError(
                f"No video files with extension '{self.extension}' found in {folder_path}"
            )

        self.logger.info(f"Found {len(self.video_files)} video files in {self.folder_path.name}")

        # 保存 VideoSource 参数
        self.video_kwargs = video_kwargs

        # 当前视频索引和 VideoSource 实例
        self.current_index = 0
        self.current_source: Optional[VideoSource] = None

        # 打开第一个视频
        self._open_current_video()

    def _open_current_video(self):
        """打开当前索引指向的视频文件"""
        if self.current_index < len(self.video_files):
            video_path = self.video_files[self.current_index]

            # 关闭之前的视频（如果有）
            if self.current_source is not None:
                self.current_source.close()

            # 打开新视频
            self.current_source = VideoSource(
                str(video_path), loop=False, **self.video_kwargs  # 文件夹模式下不循环单个视频
            )

            self.logger.info(
                f"Processing video {self.current_index + 1}/{len(self.video_files)}: "
                f"{video_path.name}"
            )

    def _switch_to_next_video(self) -> bool:
        """
        切换到下一个视频

        Returns:
            如果成功切换到下一个视频返回 True，否则返回 False
        """
        self.current_index += 1

        if self.current_index < len(self.video_files):
            self._open_current_video()
            return True

        return False

    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        当当前视频读取完毕时，自动切换到下一个视频。

        Returns:
            Frame 对象，如果所有视频都读取完毕则返回 None
        """
        if self.current_source is None:
            return None

        # 从当前视频读取帧
        frame = self.current_source.read()

        # 如果当前视频读完了，切换到下一个
        if frame is None:
            if self._switch_to_next_video():
                # 递归调用，从新视频读取第一帧
                return self.read()
            else:
                # 所有视频都读完了
                return None

        # 增加总帧计数
        self._frame_count += 1

        # 添加文件夹相关的 metadata
        frame.metadata["folder_path"] = str(self.folder_path)
        frame.metadata["video_index"] = self.current_index
        frame.metadata["video_name"] = self.video_files[self.current_index].name
        frame.metadata["video_stem"] = self.video_files[self.current_index].stem
        frame.metadata["total_videos"] = len(self.video_files)

        return frame

    def is_opened(self) -> bool:
        """检查是否还有视频可以读取"""
        return self.current_source is not None and (
            self.current_source.is_opened() or self.current_index < len(self.video_files) - 1
        )

    def close(self):
        """关闭当前视频源并释放资源"""
        if self.current_source is not None:
            self.current_source.close()
            self.current_source = None

        self.logger.info(
            f"Closed folder source: processed {self.current_index + 1}/{len(self.video_files)} videos"
        )

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "folder_path": str(self.folder_path),
                "total_videos": len(self.video_files),
                "current_video_index": self.current_index,
                "processed_videos": (
                    self.current_index + 1 if self.current_source else self.current_index
                ),
                "extension": self.extension,
            }
        )

        # 添加当前视频的统计信息
        if self.current_source is not None:
            stats["current_video"] = self.current_source.get_stats()

        return stats
