"""Image source implementation for processing image files."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Union

import cv2

from ..core import Frame, Source
from ..core.pipeline.registry import register_source


@register_source("ImageSource")
class ImageSource(Source):
    """
    图片源

    从单张图片或图片列表中读取帧。每张图片作为一帧返回。

    Attributes:
        image_paths: 图片文件路径列表
        current_index: 当前正在处理的图片索引
        loop: 是否循环读取

    Examples:
        >>> # 单张图片
        >>> source = ImageSource("photo.jpg")
        >>> frame = source.read()

        >>> # 多张图片
        >>> source = ImageSource(["img1.jpg", "img2.jpg", "img3.jpg"])
        >>> for frame in source:
        ...     print(frame.metadata['image_name'])

        >>> # 通配符模式
        >>> source = ImageSource("images/*.jpg")
    """

    def __init__(
        self,
        image_path: Union[str, List[str]],
        loop: bool = False,
        source_id: Optional[str] = None,
    ):
        """
        初始化图片源

        Args:
            image_path: 图片文件路径或路径列表，支持通配符（如 "*.jpg"）
            loop: 是否循环读取（默认 False）
            source_id: 数据源ID（默认使用文件名）

        Raises:
            FileNotFoundError: 如果图片文件不存在
            ValueError: 如果没有找到匹配的图片
        """
        # 处理输入路径
        if isinstance(image_path, str):
            path_obj = Path(image_path)

            # 检查是否使用通配符
            if "*" in image_path or "?" in image_path:
                # 通配符模式
                parent = path_obj.parent if path_obj.parent.exists() else Path(".")
                pattern = path_obj.name
                self.image_paths = sorted(parent.glob(pattern))
            else:
                # 单个文件
                if not path_obj.exists():
                    raise FileNotFoundError(f"Image file not found: {image_path}")
                self.image_paths = [path_obj]
        else:
            # 路径列表
            self.image_paths = [Path(p) for p in image_path]

        # 验证所有路径存在
        for path in self.image_paths:
            if not path.exists():
                raise FileNotFoundError(f"Image file not found: {path}")

        if not self.image_paths:
            raise ValueError(f"No image files found: {image_path}")

        # 使用第一张图片名作为 source_id
        if source_id is None:
            source_id = f"image:{self.image_paths[0].stem}"

        super().__init__(source_id)

        self.loop = loop
        self.current_index = 0

        self.logger.info(f"Initialized ImageSource with {len(self.image_paths)} image(s)")

    def read(self) -> Optional[Frame]:
        """
        读取下一张图片作为帧

        Returns:
            Frame 对象，如果所有图片都读取完毕则返回 None
        """
        # 检查是否读完
        if self.current_index >= len(self.image_paths):
            if self.loop:
                self.current_index = 0
            else:
                return None

        # 读取当前图片
        image_path = self.image_paths[self.current_index]
        image = cv2.imread(str(image_path))

        if image is None:
            self.logger.warning(f"Failed to read image: {image_path}")
            self.current_index += 1
            return self.read()  # 尝试下一张

        # 创建帧
        frame = Frame(
            image=image,
            frame_id=self._frame_count,
            source_id=self.source_id,
            timestamp=self.current_index,  # 使用索引作为时间戳
        )

        # 添加图片元数据
        frame.metadata["image_path"] = str(image_path)
        frame.metadata["image_name"] = image_path.name
        frame.metadata["image_stem"] = image_path.stem
        frame.metadata["image_index"] = self.current_index
        frame.metadata["total_images"] = len(self.image_paths)

        # 更新计数和索引
        self._frame_count += 1
        self.current_index += 1

        return frame

    def is_opened(self) -> bool:
        """检查是否还有图片可以读取"""
        return self.current_index < len(self.image_paths) or self.loop

    def close(self):
        """关闭图片源并释放资源"""
        self.logger.info(
            f"Closed image source: processed {self.current_index}/{len(self.image_paths)} images"
        )

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "total_images": len(self.image_paths),
                "current_index": self.current_index,
                "loop": self.loop,
            }
        )
        return stats


@register_source("ImageFolderSource")
class ImageFolderSource(Source):
    """
    图片文件夹源

    从文件夹中顺序读取所有图片文件。

    Attributes:
        folder_path: 文件夹路径
        extensions: 支持的图片扩展名列表
        image_files: 文件夹中的图片文件列表
        current_index: 当前正在处理的图片索引

    Examples:
        >>> source = ImageFolderSource("/path/to/images")
        >>> for frame in source:
        ...     print(frame.metadata['image_name'])

        >>> # 只处理 PNG 图片
        >>> source = ImageFolderSource("/path/to/images", extensions=[".png"])
    """

    # 默认支持的图片格式
    DEFAULT_EXTENSIONS = [".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"]

    def __init__(
        self,
        folder_path: str,
        extensions: Optional[List[str]] = None,
        source_id: Optional[str] = None,
    ):
        """
        初始化图片文件夹源

        Args:
            folder_path: 文件夹路径
            extensions: 图片扩展名列表（默认支持常见图片格式）
            source_id: 数据源ID（默认使用文件夹名）

        Raises:
            FileNotFoundError: 如果文件夹不存在
            ValueError: 如果文件夹中没有图片文件
        """
        self.folder_path = Path(folder_path)

        if not self.folder_path.exists():
            raise FileNotFoundError(f"Folder not found: {folder_path}")

        if not self.folder_path.is_dir():
            raise ValueError(f"Path is not a directory: {folder_path}")

        # 使用文件夹名作为 source_id
        if source_id is None:
            source_id = f"image_folder:{self.folder_path.name}"

        super().__init__(source_id)

        # 处理扩展名
        if extensions is None:
            extensions = self.DEFAULT_EXTENSIONS

        self.extensions = [
            ext.lower() if ext.startswith(".") else f".{ext.lower()}" for ext in extensions
        ]

        # 扫描文件夹获取所有图片文件并排序
        self.image_files = sorted(
            [
                f
                for f in self.folder_path.iterdir()
                if f.is_file() and f.suffix.lower() in self.extensions
            ]
        )

        if not self.image_files:
            raise ValueError(
                f"No image files found in {folder_path} " f"with extensions {self.extensions}"
            )

        self.logger.info(f"Found {len(self.image_files)} image files in {self.folder_path.name}")

        self.current_index = 0

    def read(self) -> Optional[Frame]:
        """
        读取下一张图片作为帧

        Returns:
            Frame 对象，如果所有图片都读取完毕则返回 None
        """
        # 检查是否读完
        if self.current_index >= len(self.image_files):
            return None

        # 读取当前图片
        image_path = self.image_files[self.current_index]
        image = cv2.imread(str(image_path))

        if image is None:
            self.logger.warning(f"Failed to read image: {image_path}")
            self.current_index += 1
            return self.read()  # 尝试下一张

        # 创建帧
        frame = Frame(
            image=image,
            frame_id=self._frame_count,
            source_id=self.source_id,
            timestamp=self.current_index,
        )

        # 添加元数据
        frame.metadata["folder_path"] = str(self.folder_path)
        frame.metadata["image_path"] = str(image_path)
        frame.metadata["image_name"] = image_path.name
        frame.metadata["image_stem"] = image_path.stem
        frame.metadata["image_index"] = self.current_index
        frame.metadata["total_images"] = len(self.image_files)

        # 更新计数和索引
        self._frame_count += 1
        self.current_index += 1

        return frame

    def is_opened(self) -> bool:
        """检查是否还有图片可以读取"""
        return self.current_index < len(self.image_files)

    def close(self):
        """关闭图片文件夹源并释放资源"""
        self.logger.info(
            f"Closed image folder source: processed {self.current_index}/{len(self.image_files)} images"
        )

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        stats.update(
            {
                "folder_path": str(self.folder_path),
                "total_images": len(self.image_files),
                "current_index": self.current_index,
                "extensions": self.extensions,
            }
        )
        return stats
