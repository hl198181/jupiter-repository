"""Video file source implementation."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional, Union

from ..core import Frame, Source
from ..core.pipeline.registry import register_source
from ..utils import format_time, parse_time

try:
    import cv2
except ImportError:
    cv2 = None  # Will raise error in __init__ if used


@register_source("VideoSource")
class VideoSource(Source):
    """
    视频文件帧源

    从视频文件读取帧，支持所有 OpenCV 支持的格式。
    支持按帧号或时间指定播放范围，时间支持多种格式。

    Attributes:
        video_path: 视频文件路径
        loop: 是否循环播放
        start_frame: 起始帧号
        end_frame: 结束帧号（None 表示到视频结尾）
        start_time: 起始时间（支持多种格式）
        end_time: 结束时间（支持多种格式）

    Examples:
        >>> source = VideoSource("input.mp4")
        >>> for frame in source:
        ...     print(frame)

        >>> # 循环播放
        >>> source = VideoSource("input.mp4", loop=True)
        >>> source.run()

        >>> # 指定帧范围
        >>> source = VideoSource("input.mp4", start_frame=100, end_frame=500)

        >>> # 指定时间范围（秒）
        >>> source = VideoSource("input.mp4", start_time=10.5, end_time=30.0)

        >>> # 使用 MM:SS 格式
        >>> source = VideoSource("input.mp4", start_time="1:30", end_time="2:45")

        >>> # 使用 HH:MM:SS 格式
        >>> source = VideoSource("input.mp4", start_time="0:10:30", end_time="0:15:45")

        >>> # 使用 HH:MM:SS.mmm 格式（毫秒精度）
        >>> source = VideoSource("input.mp4", start_time="0:01:30.500", end_time="0:02:45.750")

        >>> # 播放前10秒
        >>> source = VideoSource("input.mp4", end_time="0:10")
    """

    def __init__(
        self,
        video_path: str,
        loop: bool = False,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        start_time: Union[str, int, Optional[float]] = None,
        end_time: Union[str, int, Optional[float]] = None,
        source_id: Optional[str] = None,
    ):
        """
        初始化视频文件源

        Args:
            video_path: 视频文件路径
            loop: 是否循环播放（默认 False）
            start_frame: 起始帧号（与 start_time 互斥）
            end_frame: 结束帧号（与 end_time 互斥）
            start_time: 起始时间，支持格式：
                - 秒数: 10, 10.5
                - MM:SS: "1:30"
                - HH:MM:SS: "1:30:45"
                - HH:MM:SS.mmm: "1:30:45.500"
            end_time: 结束时间，格式同 start_time
            source_id: 数据源ID（默认使用文件名）

        Raises:
            ImportError: 如果 OpenCV 未安装
            FileNotFoundError: 如果视频文件不存在
            ValueError: 如果同时指定了帧号和时间参数，或时间格式无效
        """
        if cv2 is None:
            raise ImportError(
                "OpenCV is required for VideoSource. "
                "Install with: pip install jupiter-stream[cv]"
            )

        # 验证参数冲突
        if start_frame is not None and start_time is not None:
            raise ValueError("Cannot specify both start_frame and start_time")
        if end_frame is not None and end_time is not None:
            raise ValueError("Cannot specify both end_frame and end_time")

        self.video_path = Path(video_path)
        if not self.video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

        if not self.video_path.is_file():
            raise ValueError(
                f"Path is not a file: {video_path}. "
                f"Use FolderSource to process all videos in a directory."
            )

        # 使用文件名作为 source_id
        if source_id is None:
            source_id = f"video:{self.video_path.name}"

        super().__init__(source_id)

        self.loop = loop

        # 保存原始时间参数（字符串格式）
        self.start_time_param = start_time
        self.end_time_param = end_time

        # OpenCV VideoCapture
        self.cap = cv2.VideoCapture(str(self.video_path))

        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to open video: {video_path}")

        # 获取视频属性
        frame_count_raw = self.cap.get(cv2.CAP_PROP_FRAME_COUNT)
        self.video_fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # 验证并处理可能的无效帧数
        if frame_count_raw < 0 or frame_count_raw > 1e10:  # 检查异常值
            self.logger.warning(
                f"Invalid frame count detected: {frame_count_raw}. "
                f"Video metadata may be corrupted. Setting to 0."
            )
            self.total_frames = 0
            self.video_duration = 0.0
        else:
            self.total_frames = int(frame_count_raw)
            self.video_duration = self.total_frames / self.video_fps if self.video_fps > 0 else 0

        # 解析时间为秒（支持多种格式）
        start_seconds = None
        end_seconds = None

        if start_time is not None:
            try:
                start_seconds = parse_time(start_time)
            except ValueError as e:
                raise ValueError(f"Invalid start_time format: {e}")

        if end_time is not None:
            try:
                end_seconds = parse_time(end_time)
            except ValueError as e:
                raise ValueError(f"Invalid end_time format: {e}")

        # 转换时间为帧号
        if start_seconds is not None:
            self.start_frame = int(start_seconds * self.video_fps)
            self.start_frame = max(0, min(self.start_frame, self.total_frames - 1))
        elif start_frame is not None:
            self.start_frame = max(0, min(start_frame, self.total_frames - 1))
        else:
            self.start_frame = 0

        if end_seconds is not None:
            self.end_frame = int(end_seconds * self.video_fps)
            self.end_frame = max(0, min(self.end_frame, self.total_frames))
        elif end_frame is not None:
            self.end_frame = max(0, min(end_frame, self.total_frames))
        else:
            self.end_frame = None

        # 验证范围合理性
        if self.end_frame is not None and self.end_frame <= self.start_frame:
            raise ValueError(
                f"End frame ({self.end_frame}) must be after start frame ({self.start_frame})"
            )

        # 设置起始帧并验证
        if self.start_frame > 0:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.start_frame)

            # 验证 seek 是否成功：尝试读取一帧测试
            ret, test_frame = self.cap.read()

            if not ret:
                # Seek 失败，抛出明确的错误
                time_str = (
                    str(self.start_time_param)
                    if self.start_time_param is not None
                    else f"frame {self.start_frame}"
                )
                raise ValueError(
                    f"无法 seek 到指定的 start_time/start_frame: {time_str} (帧号: {self.start_frame})。\n"
                    f"可能的原因：\n"
                    f"  1. 视频元数据损坏，实际帧数少于声称的 {self.total_frames} 帧\n"
                    f"  2. start_time 超出了视频的实际时长\n"
                    f"  3. 视频编码格式不支持精确 seek\n"
                    f"建议：移除或调整配置文件中的 'start_time' 参数，从视频开头播放。\n"
                    f"\n"
                    f"Failed to seek to start_time/start_frame: {time_str} (frame: {self.start_frame}).\n"
                    f"Possible causes:\n"
                    f"  1. Video metadata is corrupted, actual frames < claimed {self.total_frames} frames\n"
                    f"  2. start_time exceeds actual video duration\n"
                    f"  3. Video codec doesn't support precise seeking\n"
                    f"Suggestion: Remove or adjust 'start_time' parameter in config to play from beginning."
                )

            # 读取成功，重新 seek 回起始帧准备正式播放
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.start_frame)
            actual_pos = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES))
            self.logger.debug(f"Successfully seeked to frame {actual_pos}")

        # 构建日志信息
        if self.total_frames > 0:
            duration_str = format_time(self.video_duration)
        else:
            duration_str = "unknown duration"

        log_msg = (
            f"Opened video: {self.video_path.name} "
            f"({self.width}x{self.height}, {self.video_fps:.2f} FPS, "
            f"{self.total_frames} frames, {duration_str})"
        )

        # 添加时间范围信息
        if self.start_time_param is not None or self.end_time_param is not None:
            if self.start_time_param is not None:
                start_str = str(self.start_time_param)
            else:
                start_str = "0:00"

            if self.end_time_param is not None:
                end_str = str(self.end_time_param)
            else:
                end_str = format_time(self.video_duration)

            log_msg += f" - Playing {start_str} to {end_str}"
        elif self.start_frame > 0 or self.end_frame is not None:
            end_f = self.end_frame if self.end_frame is not None else self.total_frames
            log_msg += f" - Playing frames {self.start_frame} to {end_f}"

        self.logger.info(log_msg)

    def read(self) -> Optional[Frame]:
        """
        读取下一帧

        Returns:
            Frame 对象，如果视频结束则返回 None
        """
        if not self.is_opened():
            return None

        # 检查是否到达结束帧
        if self.end_frame is not None:
            current_pos = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES))
            if current_pos >= self.end_frame:
                if self.loop:
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.start_frame)
                else:
                    return None

        ret, image = self.cap.read()

        if not ret:
            current_pos = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES))
            self.logger.debug(
                f"Failed to read frame at position {current_pos}. "
                f"Reached end of video or read error."
            )
            if self.loop:
                # 循环播放：回到起始帧
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.start_frame)
                ret, image = self.cap.read()

                if not ret:
                    return None
            else:
                return None

        # 创建 Frame 对象
        frame = Frame(
            image=image,
            timestamp=time.time(),
            frame_id=self._frame_count,
            source_id=self.source_id,
            metadata={
                "video_path": str(self.video_path),
                "video_frame": int(self.cap.get(cv2.CAP_PROP_POS_FRAMES)),
                "video_fps": self.video_fps,
                "video_timestamp": self.cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0,
            },
        )

        self._frame_count += 1
        return frame

    def is_opened(self) -> bool:
        """检查视频是否打开"""
        return self.cap is not None and self.cap.isOpened()

    def close(self):
        """关闭视频文件"""
        if self.cap is not None:
            self.cap.release()
            self.logger.info(f"Closed video: {self.video_path.name}")

    def seek(self, frame_number: int):
        """
        跳转到指定帧

        Args:
            frame_number: 目标帧号
        """
        if self.is_opened():
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
            self.logger.debug(f"Seeked to frame {frame_number}")

    def seek_to_time(self, time_input: Union[str, int, float]):
        """
        跳转到指定时间位置

        Args:
            time_input: 目标时间，支持格式：
                - 秒数: 10, 10.5
                - MM:SS: "1:30"
                - HH:MM:SS: "1:30:45"
                - HH:MM:SS.mmm: "1:30:45.500"
        """
        if self.is_opened():
            try:
                time_seconds = parse_time(time_input)
            except ValueError as e:
                self.logger.error(f"Invalid time format: {e}")
                return

            target_frame = int(time_seconds * self.video_fps)
            target_frame = max(0, min(target_frame, self.total_frames - 1))
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
            self.logger.debug(f"Seeked to time {format_time(time_seconds)} (frame {target_frame})")

    def get_stats(self) -> dict:
        """获取统计信息"""
        stats = super().get_stats()
        current_frame = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES)) if self.is_opened() else 0
        current_time = current_frame / self.video_fps if self.video_fps > 0 else 0

        stats.update(
            {
                "video_path": str(self.video_path),
                "total_frames": self.total_frames,
                "video_fps": self.video_fps,
                "video_duration": self.video_duration,
                "video_duration_formatted": (
                    format_time(self.video_duration) if self.video_duration > 0 else "unknown"
                ),
                "resolution": (self.width, self.height),
                "loop": self.loop,
                "current_frame": current_frame,
                "current_time": current_time,
                "current_time_formatted": format_time(current_time),
                "play_range": {
                    "start_frame": self.start_frame,
                    "end_frame": self.end_frame,
                    "start_time": self.start_frame / self.video_fps if self.video_fps > 0 else 0,
                    "end_time": (
                        (self.end_frame / self.video_fps if self.end_frame else self.video_duration)
                        if self.video_fps > 0
                        else 0
                    ),
                    "start_time_formatted": (
                        format_time(self.start_frame / self.video_fps)
                        if self.video_fps > 0
                        else "0:00"
                    ),
                    "end_time_formatted": (
                        format_time(
                            self.end_frame / self.video_fps
                            if self.end_frame
                            else self.video_duration
                        )
                        if self.video_fps > 0 and self.video_duration > 0
                        else "unknown"
                    ),
                },
            }
        )
        return stats
